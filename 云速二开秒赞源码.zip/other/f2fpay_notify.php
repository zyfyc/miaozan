<?php
/* *
 * 支付宝当面付异步通知页面
 */

$mod='blank';
$nosecu=true;
require_once("../includes/common.php");
require_once(SYSTEM_ROOT."f2fpay/config.php");
require_once(SYSTEM_ROOT."f2fpay/AlipayTradeService.php");

//计算得出通知验证结果
$alipaySevice = new AlipayTradeService($config); 
//$alipaySevice->writeLog(var_export($_POST,true));
$verify_result = $alipaySevice->check($_POST);

if($verify_result && $conf['alipay_api']==3) {//验证成功
	//商户订单号
	$out_trade_no = daddslashes($_POST['out_trade_no']);

	//支付宝交易号
	$trade_no = $_POST['trade_no'];

	//交易状态
	$trade_status = $_POST['trade_status'];

	//买家支付宝
	$buyer_id = daddslashes($_POST['buyer_id']);

	$srow=$DB->get_row("SELECT * FROM ".DBQZ."_pay WHERE orderid='{$out_trade_no}' limit 1");
	$uid=$srow['uid'];

    if ($_POST['trade_status'] == 'TRADE_SUCCESS' && $srow['status']==0) {
		//付款完成后，支付宝系统发送该交易状态通知
		$DB->query("update `".DBQZ."_pay` set `status` ='1',`endtime` ='$date' where `orderid`='$out_trade_no'");
		$msg = 'OK';
		$row=$DB->get_row("select * from ".DBQZ."_user where userid='".$uid."' limit 1");
		if($row['vip']==1 && strtotime($row['vipdate'])>time() || $row['vip']==2){
			$isvip=1;
		}else{
			$isvip=0;
		}
		getshop($srow['shopid'],$srow['qq'],$msg);
    }

	echo "success";
}
else {
    //验证失败
    echo "fail";
}
?>