<?php
 /*
　*QQ消息群发助手
*/ 
if(!defined('IN_CRONLITE'))exit();
$title="QQ消息群发助手";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq='.$_GET['qq'].'">'.$_GET['qq'].'</a></li>
<li class="active"><a href="#">QQ消息群发助手</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-12" role="main">';

if($islogin==1){
vipfunc_check('dx');
$qq=daddslashes($_GET['qq']);
if(!$qq) {
	showmsg('参数不能为空！');
}
$row=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
if($row['uid']!=$uid && $isadmin==0) {
	showmsg('你只能操作自己的QQ哦！');
}
if ($row['status']!=1) {
	showmsg('skey已过期！');
}
$skey=$row['skey'];
$pskey=$row['pskey'];

$runkey=md5($dbconfig['user'].md5($dbconfig['pwd']));
$ssid=md5($runkey.$qq.$runkey);
$cookie_file=ROOT.'qq/cookie/'.$ssid.'.txt';

require_once ROOT.'qq/webqq.class.php';
$qzone=new webqq($qq);

if(file_exists($cookie_file)){
	$qzone->cookie=file_get_contents($cookie_file);
	if($qzone->login2()){
		$process=true;
	}else{
		exit("<script language='javascript'>window.location.href='index.php?mod=webqq&qq={$qq}&return=index.php%3Fmod%3Dqunfa%26qq%3D{$qq}';</script>");
	}
}else{
	exit("<script language='javascript'>window.location.href='index.php?mod=webqq&qq={$qq}&return=index.php%3Fmod%3Dqunfa%26qq%3D{$qq}';</script>");
}
if($process){
	$qzone->online();
	if(!$list = $qzone->get_user_friends()){
		showmsg('从WEBQQ获取好友列表失败，请刷新重试');
	}
	$list = $list['info'];
}

$gtk = getGTK($pskey);
$cookie='pt2gguin=o0'.$qq.'; uin=o0'.$qq.'; skey='.$skey.'; p_uin=o0'.$qq.'; p_skey='.$pskey.';';
$url = 'http://mobile.qzone.qq.com/friend/mfriend_list?g_tk='.$gtk.'&res_uin='.$qq.'&res_type=normal&format=json&count_per_page=10&page_index=0&page_type=0&mayknowuin=&qqmailstat=';
$json = get_curl($url,0,1,$cookie);
$json=mb_convert_encoding($json, "UTF-8", "UTF-8");
$arr = json_decode($json, true);
//print_r($arr);exit;
if (!$arr) {
	showmsg('好友列表获取失败！');
}elseif ($arr["code"] == -3000) {
	showmsg('SKEY已过期！');
}
$arr=$arr["data"]["list"];
for($i=0;$i<count($list);$i++){
	$list[$i]['nick']=$arr[$i]['remark'];
	$list[$i]['tuin']=$arr[$i]['uin'];
}
?>
<script>
function SelectAll(chkAll) {
	var items = $('.uins');
	for (i = 0; i < items.length; i++) {
		if (items[i].id.indexOf("uins") != -1) {
			if (items[i].type == "checkbox") {
				items[i].checked = chkAll.checked;
			}
		}
	}
}
var qqcount=0;
function qqqunfa(touin,flag){
	touins=touin.split(",");
	$('#load').html('正在发送中，当前已完成发送'+qqcount+'个QQ');
	$.each(touins, function(i, item){
		$("#to"+item).html("<img src='images/load.gif' height=25>");
	});
	var content = $("#content").val();
	var url="<?php echo $siteurl ?>qq/api/msg.php";
	xiha.postData(url,'uin=<?php echo $qq ?>&ssid=<?php echo urlencode($ssid)?>&touin='+encodeURIComponent(touin)+'&content='+encodeURIComponent(content), function(d) {
		if(d.code==0){
			$.each(d.data, function(i, item){
				if(item.is==1){
					var num = $('#hydx').text();
					num=parseInt(num);
					num++;
					$("#to"+item.touin).html('<span class="btn btn-large btn-block"><font color="green">成功</font></span>');
					$('#hydx').text(num);
				}else{
					$("#to"+item.touin).html('<span class="btn btn-large btn-block"><font color="red">失败</font></span>');
				}
				//$('.uins[value='+item.touin+']').removeAttr('checked');
				$('.uins[value='+item.touin+']').attr("checked",false);
				qqcount++;
			});
		}else if(d.code==-1){
			$('#load').html('<font color="red">SKEY已过期，请更新SKEY！</font>');
			alert('SKEY已过期，请更新SKEY！');
			return false;
		}else{
			$('#load').html('<font color="red">失败，请重试！</font>');
		}
		if ($('#load').attr("data-lock") === "true") return;
		if(flag!=1){
			if($("input[name=uins]:checked").length>0){
				touin = '';num=0;
				$("input[name=uins]:checked").each(function(){
					touin+=','+$(this).val();
					num++;
					if(num>0)return false;
				});
				setTimeout(function () {
					qqqunfa(touin);
				}, 100);
			}else{
				$('#load').html('发送完成');
				return false;
			}
		}
	});
}
$(document).ready(function() {
	$('#startsend').click(function(){
		var self=$(this);
		if($("#content").val()==''){
			alert('发送内容不能为空！');
			return false;
		}
		if (self.attr("data-lock") === "true") return;
			else self.attr("data-lock", "true");
		$('#load').attr("data-lock", "false");
		var num=0;
		$('#load').html('正在发送中，请稍候');
		if($("input[name=uins]:checked").length>0){
			var touin = '';
			$("input[name=uins]:checked").each(function(){
				touin+=','+$(this).val();
				num++;
				if(num>0)return false;
			});
			qqqunfa(touin);
		}else{
			$('#load').html('没有待发送的');
		}
		self.attr("data-lock", "false");
	});
	$('#stopsend').click(function(){
		$('#load').attr("data-lock", "true");
		$('#load').html('已停止群发');
	});
	$('.recheck').click(function(){
		if($("#content").val()==''){
			alert('发送内容不能为空！');
			return false;
		}
		var self=$(this),
			touin=self.attr('uin');
		qqqunfa(touin,1);
	});
});
var xiha={
	postData: function(url, parameter, callback, dataType, ajaxType) {
		if(!dataType) dataType='json';
		$.ajax({
			type: "POST",
			url: url,
			async: true,
			dataType: dataType,
			json: "callback",
			data: parameter,
			success: function(data,status) {
				if (callback == null) {
					return;
				}
				callback(data);
			},
			error: function(error) {
				//alert('创建连接失败');
			}
		});
	}
}
</script>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">使用说明</h3>
	</div>
	<div class="panel-body" align="left">
		<p style="color:red">群发不建议频繁使用，否则会出现发送失败的情况
		</p>
	</div>
</div>
<div class="panel panel-primary checkbtn">
	<div class="panel-body">
		<center><textarea class="form-control" id="content" rows="3" placeholder="填写消息内容"></textarea>
		<p id="load"></p></center>
	</div>
</div>
<div class="panel panel-warning">
	<div class="panel-heading">
		<div class="panel-title">
			<div class="input-group" style="padding:8px 0;">
				<div class="input-group-addon btn">全选<input type="checkbox" onclick="SelectAll(this)" /></div>
				<div class="input-group-addon btn" id="startsend">点此开始群发</div>
				<div class="input-group-addon btn" id="stopsend">停止群发</div>
			</div>
		</div>
	</div>
</div>

<div class="panel panel-primary">
	<table class="table table-bordered">
		<tbody>
			<tr>
			<td align="center"><span style="color:silver;"><b>QQ</b></span></td>
			<td align="center"><span style="color:silver;"><b>昵称</b></span></td>
			<td align="center"><span style="color:silver;"><b>结果</b></span></td>
			</tr>
			<?php
			echo '<tr><td colspan="4" align="center">总共<span id="hyall">'.count($arr).'<span>个好友,已经发送<span id="hydx">0</span>个好友！</td></tr>';
			foreach($list as $row) {
			echo '<tr><td uin="'.$row['uin'].'"><input name="uins" type="checkbox" id="uins" class="uins" value="'.$row['uin'].'"><a href="tencent://message/?uin='.$row['tuin'].'&amp;Site=QQ&amp;Menu=yes">'.$row['tuin'].'</a></td><td>'.$row['nick'].'</td><td id="to'.$row['uin'].'" uin="'.$row['uin'].'" class="nocheck recheck" align="center"><span class="btn btn-large btn-block btn-primary">发送</span></td></tr>';
			}
			?>
		</tbody>
	</table>
</div>

<?php
}
else{
showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>