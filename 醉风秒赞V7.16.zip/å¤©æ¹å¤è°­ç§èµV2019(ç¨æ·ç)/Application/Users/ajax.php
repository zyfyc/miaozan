<?php
require_once('conn.php');
header('Content-Type:application/json');
if($_POST['ajax']=='qqlogin'){
	$uid = $userrow['uid'];
	$nick = $_POST['nick'];
	$uin = $_POST['uin'];
	$pwd = $_POST['pwd'];
	$sid = $_POST['sid'];
	$skey = $_POST['skey'];
	$p_skey = $_POST['p_skey'];
	$superkey = $_POST['superkey'];
	$addtime = date('y-m-d h:i:s',time());
	if($uin=="" || $pwd=="" || $sid=="" || $skey=="" || $p_skey=="" || $superkey==""){
		$output = array('code' => 0, 'msg' => '缺少数据，添加QQ失败！');
	}else{
		$cookie = "uin=o0".$uin.";skey=".$skey.";p_skey=".$p_skey.";superkey=".$superkey.";sid=".$sid.";pt2gguin=o0" . $uin . ";p_uin=o0" . $uin . ";";
		if($row = $db->get_row("select * from {$mysql}qq where qq='{$uin}' limit 1")){
			$set = "nick='{$nick}',pwd='{$pwd}',sid='{$sid}',skey='{$skey}',p_skey='{$p_skey}',superkey='{$superkey}',cookie='{$cookie}',gxtime='{$addtime}'";
			if($db->query("update {$mysql}qq set {$set} where qq='{$uin}'")){
				$output = array('code' => 1, 'msg' => '更新QQ：'.$uin.'成功！');
			}else{
				$output = array('code' => 0, 'msg' => "更新QQ：{$uin}失败！系统错误");
			}
		}else{
			if($db->query("insert into {$mysql}qq (`uid`,`nick`,`qq`,`pwd`,`sid`,`skey`,`p_skey`,`superkey`,`cookie`,`addtime`)values('{$uid}','{$nick}','{$uin}','{$pwd}','{$sid}','{$skey}','{$p_skey}','{$superkey}','{$cookie}','{$addtime}')")){
				$output = array('code' => 1, 'msg' => '添加QQ：'.$uin.'成功！');
			}else{
				$output = array('code' => 0, 'msg' => "添加QQ：{$uin}失败！系统错误");
			}
		}
	}
	echo json_encode($output);
}