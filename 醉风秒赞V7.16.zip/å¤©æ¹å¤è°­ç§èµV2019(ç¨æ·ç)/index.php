<?php
/**
 * 天方夜谭
 */
//加载核心文件
require_once('Include/common.php');

//加载首页
include_once 'Template/Index.html';