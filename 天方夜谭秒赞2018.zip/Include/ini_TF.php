<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 报错设置
 */
@error_reporting(E_ALL & ~E_NOTICE);

/**
 * 设置时区
 */
@date_default_timezone_set('PRC');

/**
 * 设置 Content-Type
 */
@header('Content-Type: text/html; charset=UTF-8');

/**
 * 检测 PHP 版本
 */
if(version_compare(PHP_VERSION,'5.3.0','<')){
	die('require PHP > 5.3.0 !');
}

/**
 * 检测数据库
 */
if(!file_exists(dirname(__FILE__) . '/data_ini/config.php')){
	@header("Location:/Include/Guide/Install.php");
}

/**
 * 设置目录
 */
define('SYSTEM_ROOT', dirname(preg_replace('@\(.*\(.*$@', '', preg_replace('@\(.*\(.*$@', '', __FILE__))) . '/');

/**
 * 设置系统版本号
 */
define('TFYT_Version', '1000');

/**
 * 引入天方夜谭 [数据运行库]
 */
require_once "ini_YT.php";

/**
 * 存储登录 cookie
 * 判断是否登录
 */
$cookiesid = $_COOKIE['tfyt_sid'];
if ($cookiesid && $TFYT_User = $db->get_row("select * from {$TFYT_Mysql}user where sid ='$cookiesid' limit 1")) {
    TFYT_Data('loginuser', $TFYT_User['user']);
    TFYT_Data('loginuid', $TFYT_User['uid']);
}

/**
 * 数据库更新
 */
if(TFYT_Data("TFYT_Version")!="1000"){
	$db->query("insert into {$TFYT_Mysql}website set vkey='TFYT_Version',value='1000' on duplicate key update value='1000'");
	@header("Location:/Include/update.php");
}

//代码编写完毕，就是那么简单 ！(●'◡'●) ！