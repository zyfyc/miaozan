<?php
class TFYT{
	//初始化首页
	public static function Home(){
		$Home = "/Application/index/Home/";
		return $Home;
	}
	//初始化用户登录
	public static function Login(){
		$Login = "/Application/index/Login/";
		return $Login;
	}
	//初始化用户注册
	public static function Enroll(){
		$Enroll = "/Application/index/Enroll/";
		return $Enroll;
	}
	//初始化找回密码
	public static function Back(){
		$Back = "/Application/index/Back/";
		return $Back;
	}
	//初始化用户中心
	public static function User(){
		$User = "/Application/users/";
		return $User;
	}
	//初始化首页模板
	public static function Template_Home(){
		$Home = "template/index/Home";
		return $Home;
	}
	//初始化登录页模板
	public static function Template_Login(){
		$Login = "template/index/Login";
		return $Login;
	}
	//初始化注册页模板
	public static function Template_Enroll(){
		$Enroll = "template/index/Enroll";
		return $Enroll;
	}
	//初始化找回密码模板
	public static function Template_Back(){
		$Back = "template/index/Back";
		return $Back;
	}
	//初始化用户中心模板
	public static function Template_User(){
		$Back = "template/users";
		return $Back;
	}
	//初始化用户中心头部模板
	public static function User_Head(){
		$Back = "../../template/users";
		return $Back;
	}
	//初始化用户中心模板
	public static function User_Index(){
		$Back = "../../template/users";
		return $Back;
	}
	//初始化用户中心底部模板
	public static function User_Foot(){
		$Back = "../../template/users";
		return $Back;
	}
}