<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 引入配置
 */
define('TFYT_Ini', 'Data');

/**
 * 引入360安全卫士
 */
require_once "data_ini/360_safe3.php";

/**
 * 引入核心功能库
 */
include_once "data_ini/function.php";

/**
 * 加载数据库配置
 */
include_once "data_ini/sql_core.php";
 
/**
 * 加载数据库配置
 */
include_once "data_ini/sql_mysql.php";

/**
 * 加载数据库信息
 */
$mysql = require ("data_ini/config.php");

/**
 * 无参获取所有
 */
TFYT_Data($mysql);

/**
 * 加载数据库
 */
$db=new ezSQL_mysql(TFYT_Data('DB_USER'),TFYT_Data('DB_PWD'),TFYT_Data('DB_NAME'),TFYT_Data('DB_HOST').':'.TFYT_Data('DB_PORT'));
/**
 * 设置 utf8
 */
$db->query("set names utf8"); 

/**
 * 定义变量 TFYT_Mysql
 */
$TFYT_Mysql=$mysql['DB_PREFIX'];

/**
 * 加载配置
 */
if ($rows = $db->get_results('select * from ' . $TFYT_Mysql . 'website')) {
	foreach ($rows as $row) {
		$website[$row['vkey']] = $row['value'];
	}
	TFYT_Data($website);
}

/**
 * 反腾讯检测系统
 */
if(TFYT_Data('txprotect')==1){
	include_once "txprotect.php";
}

/**
 * 计算系统活动天数
 */
date_default_timezone_set('Asia/Shanghai');
function Sec2Time($time){
	if(is_numeric($time)){
		$value = array(
				"years" => 0, "days" => 0, "hours" => 0,
				"minutes" => 0, "seconds" => 0,
		);
		if($time >= 31556926){
			$value["years"] = floor($time/31556926);
			$time = ($time%31556926);
		}
		if($time >= 86400){
			$value["days"] = floor($time/86400);
			$time = ($time%86400);
		}
		if($time >= 3600){
			$value["hours"] = floor($time/3600);
			$time = ($time%3600);
		}
		if($time >= 60){
			$value["minutes"] = floor($time/60);
			$time = ($time%60);
		}
		$value["seconds"] = floor($time);
		return (array) $value;
	}else{
		return (bool) FALSE;
	}
}
$daya = TFYT_Data('TFYT_Number_Rundays');
// 本站创建的时间
$site_create_time = strtotime("{$daya}");
$time = time() - $site_create_time;
$uptime = Sec2Time($time);

//代码编写完毕，就是那么简单 ！(●'◡'●) ！
