﻿DROP TABLE IF EXISTS `tfyt_chats`;
CREATE TABLE IF NOT EXISTS `tfyt_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(1000) DEFAULT NULL,
  `con` varchar(1000) DEFAULT NULL,
  `qqs` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_qq`;
CREATE TABLE `tfyt_qq` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `qq` decimal(10,0) NOT NULL,
  `pwd` varchar(80) DEFAULT NULL,
  `sid` varchar(80) NOT NULL,
  `skey` varchar(20) NOT NULL,
  `ptsig` varchar(50) NOT NULL,
  `p_skey` varchar(50) NOT NULL,
  `p_skey2` varchar(50) NOT NULL,
  `cookie` varchar(1000) NOT NULL,
  `pookie` varchar(1000) NOT NULL,
  `sidzt` tinyint(1) DEFAULT '0',
  `skeyzt` tinyint(1) DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `isqipao` tinyint(1) DEFAULT '0',
  `lastqipao` datetime DEFAULT NULL,
  `nextqipao` datetime DEFAULT NULL,
  `iszan` tinyint(1) DEFAULT '0',
  `zanrate` int(3) DEFAULT '60',
  `zannet` tinyint(1) DEFAULT '0',
  `lastzan` datetime DEFAULT NULL,
  `nextzan` datetime DEFAULT NULL,
  `istype` tinyint(1) DEFAULT '0',
  `zanlist` text,
  `isreply` tinyint(1) DEFAULT '0',
  `replycon` varchar(1000) DEFAULT NULL,
  `replypic` varchar(1000) DEFAULT NULL,
  `replyrate` int(3) DEFAULT '60',
  `replynet` tinyint(1) DEFAULT '0',
  `lastreply` datetime DEFAULT NULL,
  `nextreply` datetime DEFAULT NULL,
  `isshuo` tinyint(1) DEFAULT '0',
  `shuotype` tinyint(1) DEFAULT '0',
  `shuorate` int(3) DEFAULT '30',
  `shuonet` tinyint(1) DEFAULT '0',
  `shuoshuo` text,
  `shuogg` text,
  `shuopic` text,
  `lastshuo` datetime DEFAULT NULL,
  `nextshuo` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `delnet` tinyint(1) DEFAULT '0',
  `lastdel` datetime DEFAULT NULL,
  `nextdel` datetime DEFAULT NULL,
  `isdell` tinyint(1) DEFAULT '0',
  `dellnet` tinyint(1) DEFAULT '0',
  `lastdell` datetime DEFAULT NULL,
  `nextdell` datetime DEFAULT NULL,
  `isqd` tinyint(1) DEFAULT NULL,
  `qdcon` varchar(1000) DEFAULT NULL,
  `qdnet` tinyint(1) DEFAULT '0',
  `lastqd` datetime DEFAULT NULL,
  `nextqd` datetime DEFAULT NULL,
  `isly` tinyint(1) NOT NULL DEFAULT '0',
  `lastly` datetime DEFAULT NULL,
  `nextly` datetime DEFAULT NULL,
  `isyyqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastyyqd` datetime DEFAULT NULL,
  `nextyyqd` datetime DEFAULT NULL,
  `isdtqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastdtqd` datetime DEFAULT NULL,
  `nextdtqd` datetime DEFAULT NULL,
  `isqqllqqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastqqllqqd` datetime DEFAULT NULL,
  `nextqqllqqd` datetime DEFAULT NULL,
  `isqlqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastqlqd` datetime DEFAULT NULL,
  `nextqlqd` datetime DEFAULT NULL,
  `isqzoneqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastqzoneqd` datetime DEFAULT NULL,
  `nextqzoneqd` datetime DEFAULT NULL,
  `ishlwqd` tinyint(1) NOT NULL DEFAULT '0',
  `lasthlwqd` datetime DEFAULT NULL,
  `nexthlwqd` datetime DEFAULT NULL,
  `ismqqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastmqqd` datetime DEFAULT NULL,
  `nextmqqd` datetime DEFAULT NULL,
  `iscwqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastcwqd` datetime DEFAULT NULL,
  `nextcwqd` datetime DEFAULT NULL,
  `iswyqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastwyqd` datetime DEFAULT NULL,
  `nextwyqd` datetime DEFAULT NULL,
  `isdjc` tinyint(1) NOT NULL DEFAULT '0',
  `lastdjc` datetime DEFAULT NULL,
  `nextdjc` datetime DEFAULT NULL,
  `isjpgame` tinyint(1) NOT NULL DEFAULT '0',
  `lastjpgame` datetime DEFAULT NULL,
  `nextjpgame` datetime DEFAULT NULL,
  `isxrqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastxrqd` datetime DEFAULT NULL,
  `nextxrqd` datetime DEFAULT NULL,
  `islld` tinyint(1) NOT NULL DEFAULT '0',
  `lastlld` datetime DEFAULT NULL,
  `nextlld` datetime DEFAULT NULL,
  `isdldqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastdldqd` datetime DEFAULT NULL,
  `nextdldqd` datetime DEFAULT NULL,
  `isslqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastslqd` datetime DEFAULT NULL,
  `nextslqd` datetime DEFAULT NULL,
  `isgjqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastgjqd` datetime DEFAULT NULL,
  `nextgjqd` datetime DEFAULT NULL,
  `ismc` tinyint(1) NOT NULL DEFAULT '0',
  `lastmc` datetime DEFAULT NULL,
  `nextmc` datetime DEFAULT NULL,
  `isnc` tinyint(1) NOT NULL DEFAULT '0',
  `lastnc` datetime DEFAULT NULL,
  `nextnc` datetime DEFAULT NULL,
  `isqqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastqqd` datetime DEFAULT NULL,
  `nextqqd` datetime DEFAULT NULL,
  `isblqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastblqd` datetime DEFAULT NULL,
  `nextblqd` datetime DEFAULT NULL,
  `isjfqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastjfqd` datetime DEFAULT NULL,
  `nextjfqd` datetime DEFAULT NULL,
  `qunnum` text,
  `isqt` tinyint(1) NOT NULL DEFAULT '0',
  `lastqt` datetime DEFAULT NULL,
  `nextqt` datetime DEFAULT NULL,
  `isfw` tinyint(1) NOT NULL DEFAULT '0',
  `lastfw` datetime DEFAULT NULL,
  `nextfw` datetime DEFAULT NULL,
  `isvipqd` tinyint(1) NOT NULL DEFAULT '0',
  `lastvipqd` datetime DEFAULT NULL,
  `nextvipqd` datetime DEFAULT NULL,
  `iszyzan` tinyint(1) NOT NULL DEFAULT '0',
  `lastzyzan` datetime DEFAULT NULL,
  `nextzyzan` datetime DEFAULT NULL,
  `isrq` tinyint(1) NOT NULL DEFAULT '0',
  `lastrq` datetime DEFAULT NULL,
  `nextrq` datetime DEFAULT NULL,
  `iszf` tinyint(4) NOT NULL DEFAULT '0',
  `zfok` text,
  `zfcon` text,
  `zfrate` tinyint(1) NOT NULL DEFAULT '15',
  `zfnet` tinyint(1) NOT NULL DEFAULT '0',
  `lastzf` datetime DEFAULT NULL,
  `nextzf` datetime DEFAULT NULL,
  `isht` tinyint(1) NOT NULL DEFAULT '0',
  `lastht` datetime DEFAULT NULL,
  `nextht` datetime DEFAULT NULL,
  `ists` tinyint(1) NOT NULL DEFAULT '0',
  `lastts` datetime DEFAULT NULL,
  `nextts` datetime DEFAULT NULL,
  `islw` tinyint(1) NOT NULL DEFAULT '0',
  `lastlw` datetime DEFAULT NULL,
  `nextlw` datetime DEFAULT NULL,
  `islq` tinyint(1) NOT NULL DEFAULT '0',
  `lastlq` datetime DEFAULT NULL,
  `nextlq` datetime DEFAULT NULL,
  `isqb` tinyint(1) NOT NULL DEFAULT '0',
  `lastqb` datetime DEFAULT NULL,
  `nextqb` datetime DEFAULT NULL,
  `is3gqq` tinyint(1) NOT NULL DEFAULT '0',
  `last3gqq` datetime DEFAULT NULL,
  `next3gqq` datetime DEFAULT NULL,
  `nextauto` datetime DEFAULT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_cami`;
CREATE TABLE IF NOT EXISTS `tfyt_cami` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(1000) DEFAULT NULL,
  `uid` varchar(1000) DEFAULT NULL,
  `user` varchar(1000) DEFAULT NULL,
  `cami` varchar(1000) DEFAULT NULL,
  `money` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  `isuse` varchar(1000) DEFAULT NULL,
  `usetime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_daili`;
CREATE TABLE IF NOT EXISTS `tfyt_daili` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colour` varchar(1000) DEFAULT NULL,
  `datas` varchar(1000) DEFAULT NULL,
  `price` varchar(1000) DEFAULT NULL,
  `stock` varchar(1000) DEFAULT NULL,
  `styles` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_peie`;
CREATE TABLE IF NOT EXISTS `tfyt_peie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colour` varchar(1000) DEFAULT NULL,
  `nums` varchar(1000) DEFAULT NULL,
  `price` varchar(1000) DEFAULT NULL,
  `stock` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_vip`;
CREATE TABLE IF NOT EXISTS `tfyt_vip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `colour` varchar(1000) DEFAULT NULL,
  `datas` varchar(1000) DEFAULT NULL,
  `price` varchar(1000) DEFAULT NULL,
  `stock` varchar(1000) DEFAULT NULL,
  `styles` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_template`;
CREATE TABLE IF NOT EXISTS `tfyt_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) DEFAULT NULL,
  `img` varchar(1000) DEFAULT NULL,
  `tnum` varchar(1000) DEFAULT NULL,
  `template` varchar(1000) DEFAULT NULL,
  `home` varchar(1000) DEFAULT NULL,
  `login` varchar(1000) DEFAULT NULL,
  `enroll` varchar(1000) DEFAULT NULL,
  `back` varchar(1000) DEFAULT NULL,
  `user` varchar(1000) DEFAULT NULL,
  `addtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_user`;
CREATE TABLE `tfyt_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `activate` tinyint(2) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `user` varchar(255) NOT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `agent` int(1) DEFAULT '0',
  `agentstart` date DEFAULT NULL,
  `agentend` date DEFAULT NULL,
  `vip` tinyint(1) DEFAULT '0',
  `vipstart` date DEFAULT NULL,
  `vipend` date DEFAULT NULL,
  `money` int(5) DEFAULT '0',
  `peie` tinyint(2) DEFAULT '1',
  `pwd` varchar(40) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `syqn` varchar(255) DEFAULT NULL,
  `star` varchar(255) DEFAULT NULL,
  `login` tinyint(255) DEFAULT '1',
  `city` varchar(50) DEFAULT NULL,
  `regip` varchar(50) DEFAULT NULL,
  `lastip` varchar(50) DEFAULT NULL,
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_website`;
CREATE TABLE `tfyt_website` (
  `vkey` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`vkey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `tfyt_website` VALUES ('TFYT_Version', '1000');
INSERT INTO `tfyt_website` VALUES ('TFYT_Server', '200');
INSERT INTO `tfyt_website` VALUES ('TFYT_Server_Mz', '3');
INSERT INTO `tfyt_website` VALUES ('TFYT_Server_Shuo', '3');
INSERT INTO `tfyt_website` VALUES ('TFYT_Server_Shuo', '3');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Tnum', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Img1', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Home', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Login', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Enroll', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_Back', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Template_User', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Name', '天方夜谭秒赞');
INSERT INTO `tfyt_website` VALUES ('TFYT_Domain', 'tfyt.eirds.cn:9096');
INSERT INTO `tfyt_website` VALUES ('TFYT_Keywords', 'By天方夜谭');
INSERT INTO `tfyt_website` VALUES ('TFYT_Description', '天方夜谭全新的秒赞系统');
INSERT INTO `tfyt_website` VALUES ('TFYT_Group', '294470669');
INSERT INTO `tfyt_website` VALUES ('TFYT_Foot', 'By天方夜谭');
INSERT INTO `tfyt_website` VALUES ('TFYT_Monitor', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Monitor_Key', '123456');
INSERT INTO `tfyt_website` VALUES ('TFYT_Number_Visitor', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Number_Rundays', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Reg_Peie', '1');
INSERT INTO `tfyt_website` VALUES ('TFYT_Reg_Money', '1');
INSERT INTO `tfyt_website` VALUES ('TFYT_User_Activate', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Notice_User', '天方夜谭秒赞系统安装说明：<br/>1.本程序为部分开源程序，可能会有部分Bug<br/>2.程序为免费版本，请勿倒卖<br/>3.如果您喜欢本程序，请加群：294470669<br/>4.程序由longhui and Forever 编写，QQ：1790716272<br/>5.版权所有天方夜谭，侵权者将会承担法律责任!!!');
INSERT INTO `tfyt_website` VALUES ('TFYT_Notice_Cami', '<p>购买物品：卡密购买</p><p>卡密购买请加QQ：1790716272</p><p>支持微信扫码、QQ扫码、支付宝、财付通等各种付款方式</p><p>付款后自动发货，卡密直接在聊天框显示，请复制下来在此页面选择卡密方式使用即可！</p>');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Quan_state', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Quan_vip', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Quan_api', '');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Chat_state', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Chat_vip', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Cqy_state', '0');
INSERT INTO `tfyt_website` VALUES ('TFYT_Function_Cqy_vip', '0');
INSERT INTO `tfyt_template` (`id`, `name`, `img`, `tnum`, `template`, `home`, `login`, `enroll`, `back`, `user`, `addtime`) VALUES
(1, '天方夜谭秒赞第一套默认模板', '/ThinkPHP/Moban/index_1.png', '1', '1', '/default/', '/default/', '/default/', '/default/', '/default/', '2018-02-26');