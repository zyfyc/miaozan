﻿<?php
require_once('../conn.php');
if($_GET['template']=='update_1'){
	if(!file_exists('../Lock/template.lock')){
		$template = 1;
		$tnum = 1;
		$img = "https://desk-fd.zol-img.com.cn/t_s1920x1080c5/g5/M00/07/0E/ChMkJ1Z4-O-IZK_EAAP0wtonFAMAAGeuAEo7z4AA_Ta701.jpg";
		$home = "/default/";
		$login = "/default/";
		$enroll = "/default/";
		$back = "/default/";
		$user = "/default/";
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template',value='$template' on duplicate key update value='$template'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Tnum',value='$tnum' on duplicate key update value='$tnum'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Img1',value='$img' on duplicate key update value='$img'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Home',value='$home' on duplicate key update value='$home'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Login',value='$login' on duplicate key update value='$login'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Enroll',value='$enroll' on duplicate key update value='$enroll'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Back',value='$back' on duplicate key update value='$back'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_User',value='$user' on duplicate key update value='$user'"));
		@file_put_contents('../Lock/template.lock','数据导入锁！作者QQ：1790716272');
		echo"<script language='javascript'>alert('完成安装！现在你可以尽情的使用了');window.location.href='/';</script>";
	}else{
		@header("Location:/");
		exit();
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="http://themes.iki-bir.com/frost/start/style/images/favicon.png">
<title>选择风格 - <?=TFYT_Data("TFYT_Name")?></title>
<!-- Bootstrap core CSS -->
<link href="http://themes.iki-bir.com/frost/start/style/css/bootstrap.css" rel="stylesheet">
<link href="http://themes.iki-bir.com/frost/start/style/css/settings.css" rel="stylesheet">
<link href="http://themes.iki-bir.com/frost/start/style/css/owl.carousel.css" rel="stylesheet">
<link href="http://themes.iki-bir.com/frost/start/style/js/google-code-prettify/prettify.css" rel="stylesheet">
<link href="http://themes.iki-bir.com/frost/start/style/js/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://themes.iki-bir.com/frost/start/style/js/fancybox/helpers/jquery.fancybox-thumbs.css?v=1.0.2" rel="stylesheet" type="text/css" />
<link href="http://themes.iki-bir.com/frost/start/style.css" rel="stylesheet">
<link href="http://themes.iki-bir.com/frost/start/style/css/color/blue.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Josefin+Sans:400,600,700,400italic,600italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800' rel='stylesheet' type='text/css'>
<link href="style/type/fontello.css" rel="stylesheet">
<link href="style/type/budicons.css" rel="stylesheet">
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="style/js/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
      <![endif]-->
<style type="text/css">
	.styles {
		text-align: center;
	}
	.styles strong {
		text-transform: uppercase;
	}
	.styles figure {
		margin-bottom: 20px;
	}
</style>
</head>
<body>
<div id="preloader"><div id="status"><div class="spinner"></div></div></div>
<div class="body-wrapper">
  <div class="navbar default">
    <div class="navbar-header">
      <div class="container">
        <div class="basic-wrapper">
			<br/>
         <h1><font class="navbar-brand" color="#000000">TFYT</font></h1>
			<br/>
         </div>
      </div>
    </div>
    <!--/.nav-collapse --> 
  </div>
  <!--/.navbar -->
  <div class="offset" style="padding-top: 80px;"></div>
  <div class="light-wrapper">
      <div class="container inner">
        <h2 class="section-title text-center">嗨！欢迎使用天方夜谭秒赞系统</h2>
        <p class="lead main text-center">好了，那是最后一步了，现在开始选择你的风格吧！</p>
        <div class="row styles">
	        <div class="col-sm-6">
		        <figure>
					<a href="?template=update_1">
						<img src="http://themes.iki-bir.com/frost/start/raleway-blue.png" alt="" />
					</a>
				</figure>
		        <strong>风格一:</strong> 二次元
	        </div>
	        <div class="col-sm-6">
		        <figure>
					<a href="#">
						<img src="http://themes.iki-bir.com/frost/start/josefin-red.png" alt="" />
					</a>
				</figure>
		        <strong>风格二:</strong> 经典
	        </div>
        </div>
      </div>
  </div>
</div>
<!-- .body-wrapper --> 
<script src="http://themes.iki-bir.com/frost/start/style/js/jquery.min.js"></script> 
<script src="http://themes.iki-bir.com/frost/start/style/js/bootstrap.min.js"></script> 
<script src="http://themes.iki-bir.com/frost/start/style/js/retina.js"></script> 
<script src="http://themes.iki-bir.com/frost/start/style/js/scripts.js"></script>
</body>
</html>