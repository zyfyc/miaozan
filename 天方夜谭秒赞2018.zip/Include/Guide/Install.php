﻿<?php
/**
 * 报错设置
 */
error_reporting(E_ALL & ~E_NOTICE);

/**
 * 设置 Content-Type
 */
@header('Content-Type: text/html; charset=UTF-8');

/**
 * 判断是否安装
 */
if(file_exists('../Lock/install.lock')){
	$step=5;
}else{
	$step=is_numeric($_GET['step'])?$_GET['step']:'1';
}

/**
 * 定义模板 头部
 */
function Head(){
	echo '<!DOCTYPE html>
			<html lang="en" class="app">
			<head>  
			  <meta charset="utf-8" />
			  <title>程序安装 - 天方夜谭秒赞系统</title>
			  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/bootstrap.css" type="text/css" />
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/animate.css" type="text/css" />
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/font-awesome.min.css" type="text/css" />
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/icon.css" type="text/css" />
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/font.css" type="text/css" />
			  <link rel="stylesheet" href="/ThinkPHP/Users/css/app.css" type="text/css" />  
				<!--[if lt IE 9]>
				<script src="/ThinkPHP/Users/js/ie/html5shiv.js"></script>
				<script src="/ThinkPHP/Users/js/ie/respond.min.js"></script>
				<script src="/ThinkPHP/Users/js/ie/excanvas.js"></script>
			  <![endif]-->
			</head>
			<body class="">';
}

/**
 * 定义模板 底部
 */
function Foot(){
	echo '  <!-- footer -->
			  <footer id="footer">
				<div class="text-center padder">
				  <p>
					<small>copyright  &copy; '.date("Y").' <a href="http://www.tfytmz.top/">By天方夜谭</a></small>
				  </p>
				</div>
			  </footer>
			  <!-- / footer -->
			  <script src="/ThinkPHP/Users/js/jquery.min.js"></script>
			  <!-- Bootstrap -->
			  <script src="/ThinkPHP/Users/js/bootstrap.js"></script>
			  <!-- App -->
			  <script src="/ThinkPHP/Users/js/app.js"></script>  
			  <script src="/ThinkPHP/Users/js/slimscroll/jquery.slimscroll.min.js"></script>
			  <script src="/ThinkPHP/Users/js/app.plugin.js"></script>
			</body>
			</html>';
}

/**
 *php函数检测1
 */
function checkfunc($a, $b = false){
	if (function_exists($a)) {
		return '<font color="green">可用</font>';
	} else {
		if ($b == false) {
			return '<font color="black">不支持</font>';
		} else {
			return '<font color="red">不支持</font>';
		}
	}
}

/**
 * php函数检测2
 */
function checkclass($a, $b = false){
	if (class_exists($a)) {
		return '<font color="green">可用</font>';
	} else {
		if ($b == false) {
			return '<font color="black">不支持</font>';
		} else {
			return '<font color="red">不支持</font>';
		}
	}
}
Head();
?>
<?php if($step=='1'){?>
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="#">系统安装</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>请认真阅读说明后再继续操作</strong>
        </header>
        <form action="?step=2" method="post">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" value="天方夜谭秒赞系统安装说明：" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="1.本程序为部分开源程序，可能会有部分Bug" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="2.程序为官方版本，请勿倒卖" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="3.如果您喜欢本程序或有疑问，请加群：294470669" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="4.程序由 龙辉和久妄编写，QQ：1790716272" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="5.版权所有天方夜谭，侵权者将承担法律责任" class="form-control no-border" readonly>
            </div>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">我同意，开始安装</button>
          <div class="line line-dashed"></div>
          <p class="text-muted text-center"><small>不会安装？点击帮助（费用：1￥）</small></p>
        </form>
      </section>
    </div>
  </section>
<?php }else if($step=='2'){ ?>
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="#">系统安装</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>环境检测</strong>
        </header>
        <form action="?step=3" method="post">
          <div class="list-group">
			<table class="table table-striped">
				<thead>
				<tr>
					<th>函数检测</th>
					<th>需求</th>
					<th>当前</th>
					<th>用途</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td>PHP 5.2+</td>
					<td>必须</td>
					<td><?php echo phpversion(); ?></td>
					<td>PHP版本支持</td>
				</tr>
				<tr>
					<td>curl_exec()</td>
					<td>必须</td>
					<td><?php echo checkfunc('curl_exec', true); ?></td>
					<td>抓取网页</td>
				</tr>
				<tr>
					<td>file_get_contents()</td>
					<td>必须</td>
					<td><?php echo checkfunc('file_get_contents', true); ?></td>
					<td>读取文件</td>
				</tr>
				<tr>
					<td>fsockopen()</td>
					<td>必须</td>
					<td><?php echo checkfunc('fsockopen'); ?></td>
					<td>发送邮件</td>
				</tr>
				<tr>
					<td>ZipArchive</td>
					<td>推荐</td>
					<td><?php echo checkclass('ZipArchive'); ?></td>
					<td>Zip 解包和压缩</td>
				</tr>
				<tr>
					<td>写入权限</td>
					<td>推荐</td>
					<td><?php if (is_writable('./')) {
							echo '<font color="green">可用</font>';
						} else {
							echo '<font color="black">不支持</font>';
						} ?></td>
					<td>写入文件(1/2)</td>
				</tr>
				<tr>
					<td>file_put_contents()</td>
					<td>推荐</td>
					<td><?php echo checkfunc('file_put_contents'); ?></td>
					<td>写入文件(2/2)</td>
				</tr>
				</tbody>
			</table>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">确定，下一步</button>
          <div class="line line-dashed"></div>
          <p class="text-muted text-center"><small>不会安装？点击帮助（费用：1￥）</small></p>
        </form>
      </section>
    </div>
  </section>
<?php }else if($step=='3'){ ?>
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="#">系统安装</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>配置数据库</strong>
        </header>
        <form action="?step=4" method="post">
		 <input type="hidden" name="ok" value="install">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" name="DB_HOST" value="localhost" class="form-control no-border" placeholder="请输入数据库地址">
            </div>
            <div class="list-group-item">
              <input type="text" name="DB_PORT" value="3306" class="form-control no-border" placeholder="请输入数据库端口">
            </div>
            <div class="list-group-item">
              <input type="text" name="DB_NAME" class="form-control no-border" placeholder="请输入数据库名称">
            </div>
            <div class="list-group-item">
              <input type="text" name="DB_USER" class="form-control no-border" placeholder="请输入数据库用户名">
            </div>
            <div class="list-group-item">
              <input type="text" name="DB_PWD" class="form-control no-border" placeholder="请输入数据库密码">
            </div>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">开始安装</button>
          <div class="line line-dashed"></div>
          <p class="text-muted text-center"><small>不会安装？点击帮助（费用：1￥）</small></p>
        </form>
      </section>
    </div>
  </section>
<?php }else if($step=='4'){
	if($_POST['ok']=='install'){
		if(!$_POST['DB_HOST'] || !$_POST['DB_PORT'] || !$_POST['DB_NAME'] || !$_POST['DB_USER'] || !$_POST['DB_PWD']){
			echo'<script language=\'javascript\'>alert(\'所有项都不能为空\');history.go(-1);</script>';
		}else{
			if(!$con=mysql_connect($_POST['DB_HOST'].':'.$_POST['DB_PORT'],$_POST['DB_USER'],$_POST['DB_PWD'])){
				echo'<script language=\'javascript\'>alert("连接数据库失败，'.mysql_error().'");history.go(-1);</script>';
			}else if(!mysql_select_db($_POST['DB_NAME'],$con)){
				echo'<script language=\'javascript\'>alert("选择的数据库不存在，'.mysql_error().'");history.go(-1);</script>';
			}else{
				mysql_query("set names utf8",$con);
				$data="
<?php
return array(
	'DB_HOST'               =>  '{$_POST['DB_HOST']}',
	'DB_NAME'               =>  '{$_POST['DB_NAME']}',
	'DB_USER'               =>  '{$_POST['DB_USER']}',
	'DB_PWD'                =>  '{$_POST['DB_PWD']}',
	'DB_PORT'               =>  '{$_POST['DB_PORT']}',
	'DB_PREFIX'             =>  'tfyt_',
);";
				if(file_put_contents('../data_ini/config.php',$data)){
					$sqls=file_get_contents("Mysql.sql");
					$explode = explode(";",$sqls);
					$num = count($explode);
					foreach($explode as $sql){
						if($sql=trim($sql)){
							mysql_query($sql);
						}
					}
					if(mysql_error()){
						echo'<script language=\'javascript\'>alert("导入数据表时错误，'.mysql_error().'");history.go(-1);</script>';
					}else{
						@file_put_contents('../Lock/install.lock','安装锁！作者QQ：17404785');
?>
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">
    <div class="container aside-xl">
      <a class="navbar-brand block" href="#">系统安装</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>程序安装完成，现在你可以尽情的使用了！</strong>
        </header>
        <form action="website.php" method="post">
		 <input type="hidden" name="ok" value="website">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" value="网站安装成功！" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="本次安装共导入 <?php echo $num;?> 条数据" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="第一个注册的是管理员账号" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="要想正常运行，需要监控，监控说明请到后台查看" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="更多设置选项请登录后台管理进行修改" class="form-control no-border" readonly>
            </div>
          </div>
          <a href="website.php?website=install" class="btn btn-lg btn-primary btn-block">确定，下一步</a>
          <div class="line line-dashed"></div>
          <p class="text-muted text-center"><small>不会安装？点击帮助（费用：1￥）</small></p>
        </form>
      </section>
    </div>
  </section>
<?php 
					}
				}else{
					echo'<script language=\'javascript\'>alert("保存数据库配置文件失败，请检查网站是否有写入权限！");history.go(-1);</script>';
				}
			}
		}
	}
}elseif($step=='5'){
?>
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="#">系统安装</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>系统检测到您已经安装本程序，如需重新安装，请删除根目录/Include/里/Lock/文件夹里带有（.lock）后轴的文件即可！</strong>
        </header>
      </section>
    </div>
  </section>
<?php } ?>
<?php
Foot();
?>