﻿<?php
require_once('../conn.php');
if($_GET['website']=='install'){
	if(!file_exists('../Lock/website.lock')){
		$time = date('Y-m-d h:i:s',time());
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Number_Rundays',value='$time' on duplicate key update value='$time'"));
		@file_put_contents('../Lock/website.lock','数据导入锁！作者QQ：1790716272');
		@header("Location:template.php");
		exit();
	}else{
		@header("Location:/");
		exit();
	}
}