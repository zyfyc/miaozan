<?php
/*
反腾讯网址安全检测系统
Description:屏蔽腾讯电脑管家网址安全检测
Version:2.0
Author:消失的彩虹海
*/
//IP屏蔽
define('SYSTEM_ROOT', dirname(preg_replace('@\(.*\(.*$@', '', preg_replace('@\(.*\(.*$@', '', __FILE__))) . '/');
$iptables=file_get_contents(SYSTEM_ROOT.'/protect/iptables.dat');
$remoteiplong=bindec(decbin(ip2long(getip())));
foreach(explode('|',$iptables) as $iprows){
	$ipbanrange=explode('~',$iprows);
	if($remoteiplong>=$ipbanrange[0] && $remoteiplong<=$ipbanrange[1]){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Welcome to My Home！</title>
<style>
li {list-style:none; line-height:30px; font-size:12px; font-family:Arial, Helvetica, sans-serif}

</style>
</head>
<body>
	<div style="width:800px;margin:200px auto 0 auto; text-align:center; border:#F60 solid 1px">
    <h2>温馨提醒：<span style="color:#F60">网站升级完成</span></h2>
  	<ul style="text-align:left">
		<li>出现本页面原因:</li>
    	<li>原因一：非法访问；</li>
        <li>原因二：网站维护中；</li>
        <li>原因三：网站备案中；</li>
        <li>谢谢合作！</li>
    </ul>
    </div>


</body></html>
<?php
exit;
}
}
//HEADER特征屏蔽
if(preg_match("/manager/", strtolower($_SERVER['HTTP_USER_AGENT'])) || strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'], 'en')!==false && strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'], 'zh')===false || preg_match("/Windows NT 6.1/", $_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_ACCEPT']=='*/*' || preg_match("/vnd.wap.wml/", $_SERVER['HTTP_ACCEPT']) && preg_match("/Windows NT 5.1/", $_SERVER['HTTP_USER_AGENT']) || strpos($_SERVER['HTTP_REFERER'], 'urls.tr.com')!==false || empty($_SERVER['HTTP_USER_AGENT'])) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Welcome to My Home！</title>
<style>
li {list-style:none; line-height:30px; font-size:12px; font-family:Arial, Helvetica, sans-serif}

</style>
</head>
<body>
	<div style="width:800px;margin:200px auto 0 auto; text-align:center; border:#F60 solid 1px">
    <h2>温馨提醒：<span style="color:#F60">网站升级完成</span></h2>
  	<ul style="text-align:left">
		<li>出现本页面原因:</li>
    	<li>原因一：非法访问；</li>
        <li>原因二：网站维护中；</li>
        <li>原因三：网站备案中；</li>
        <li>谢谢合作！</li>
    </ul>
    </div>


</body></html>
<?php
	exit;
}
