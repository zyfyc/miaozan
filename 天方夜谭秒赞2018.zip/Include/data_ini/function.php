<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 模块开启提示
 */
function getxz($do, $did = 0) { //模块开启提示
    if ($do == 1) {
        if ($did) {
            return 'btn-success';
        } else {
            return '触屏版';
        }
    } elseif ($do == 2) {
        if ($did) {
            return 'btn-success';
        } else {
            return 'P&nbsp;C版';
        }
    } else {
        if ($did) {
            return 'btn-default';
        } else {
            return '已关闭';
        }
    }
}
 
/**
 * 目前开启/关闭状态
 */
function getzt($do) { //目前开启/关闭状态
    if ($do == 2) {
        return "<font color=green>P&nbsp;C版</font>";
    } elseif ($do == 0) {
        return "<font color=red>已关闭</font>";
    } else {
        return "<font color=green>触屏版</font>";
    }
}

/**
 * 状态
 */
function getzts($do) { //状态
    if ($do == 0) {
        return true;
    } else {
        return false;
    }
}

/**
 * 获取运行时间
 */
function zhtime($time = '') { //获取运行时间
    if ($time) {
        return str_replace(array(
            '2018-',
            '0000-'
        ) , array(
            '',
            ''
        ) , $time);
    } else {
        return '0000-00-00';
    }
}
 
/**
 * 计算g_tk
 */
function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash+= ($hash << 5) + ord($skey[$i]);
    }
    return $hash & 0x7fffffff; 
    
}

/**
 * CheckSubstrs
 */
function CheckSubstrs($substrs, $text) {
	foreach ($substrs as $substr) if (false !== strpos($text, $substr)) {
		return true;
	}
	return false;
}

/**
 * 计算会员g_tk
 */
function getGTK2($skey) {
    $salt = 5381;
    $md5key = 'tencentQQVIP123443safde&!%^%1282';
    $hash = array();
    $hash[] = ($salt << 5);
    $len = strlen($skey);
    for ($i = 0; $i < $len; $i++) {
        $ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
        $ASCIICode = hexdec(bin2hex($ASCIICode));
        $hash[] = (($salt << 5) + $ASCIICode);
        $salt = $ASCIICode;
    }
    $md5str = md5(implode($hash) . $md5key);
    return $md5str; 
}

/**
 * 获取随机数
 */
function get_random($param){
    $str="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $key = "";
    for($i=0;$i<$param;$i++)
     {
         $key .= $str{mt_rand(0,64)};    //生成php随机数
     }
     return $key;
 }
 
/**
 * 无参数时获取所有
 */
function TFYT_Data($name = null, $value = null, $default = null) {
    static $_config = array();
    // 无参数时获取所有
    if (empty($name)) {
        return $_config;
    }
    // 优先执行设置获取或赋值
    if (is_string($name)) {
        if (!strpos($name, '.')) {
            $name = strtoupper($name);
            if (is_null($value)) return isset($_config[$name]) ? $_config[$name] : $default;
            $_config[$name] = $value;
            return;
        }
        // 二维数组设置和获取支持
        $name = explode('.', $name);
        $name[0] = strtoupper($name[0]);
        if (is_null($value)) return isset($_config[$name[0]][$name[1]]) ? $_config[$name[0]][$name[1]] : $default;
        $_config[$name[0]][$name[1]] = $value;
        return;
    }
    // 批量设置
    if (is_array($name)) {
        $_config = array_merge($_config, array_change_key_case($name, CASE_UPPER));
        return;
    }
    return null; // 避免非法参数
    
}

/**
 * 统计访客
 */
function TFYT_Number_Visitor($num) {
    Global $db;
    $mysql = require ("config.php");
    $dbhost = $mysql['DB_HOST'] . ':' . $mysql['DB_PORT'];
    $dbuser = $mysql['DB_USER'];
    $dbpassword = $mysql['DB_PWD'];
    $dbmysql = $mysql['DB_NAME'];
    if ($con = mysql_connect($dbhost, $dbuser, $dbpassword)) {
        mysql_select_db($dbmysql, $con);
    } else {
        exit('数据库链接失败！');
    }
    mysql_query("set names utf8");
	$tableqz = $mysql['DB_PREFIX'];
    $nums = $num + 1;
    mysql_query(("insert into {$tableqz}website set vkey='TFYT_Number_Visitor',value='$nums' on duplicate key update value='$nums'"));
}

/**
 * 过滤危险字符
 */
function safestr($str) {
    if (!get_magic_quotes_gpc()) {
        return addslashes($str);
    } else {
        return $str; //过滤危险字符
        
    }
}

/**
 * 获取ip地址
 */
function get_real_ip(){
	$ip=false;
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		$ip=$_SERVER['HTTP_CLIENT_IP'];
	}
	if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		$ips=explode (', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
		if($ip){ array_unshift($ips, $ip); $ip=FALSE; }
		for ($i=0; $i < count($ips); $i++){
			if(!eregi ('^(10│172.16│192.168).', $ips[$i])){
				$ip=$ips[$i];
				break;
			}
		}
	}
	return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}

/**
 * 获取ip地址所在地理位置
 */
function get_ip_city($ip) {
    $url = 'http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js&ip=';
    @$city = file_get_contents($url . $ip);
    $city = str_replace(array(
        'var remote_ip_info = ',
        '};'
    ) , array(
        '',
        '}'
    ) , $city);
    $city = json_decode($city, true);
    if ($city['city']) {
        $location = $city['city'];
    } else {
        $location = $city['province'];
    }
    if ($location) {
        return $location;
    } else {
        return; 
        
    }
}

/**
 * 计算数量
 */
function get_count($table, $where = '1=1', $key = '*') {
    Global $db;
    $mysql = require ("config.php");
    $dbhost = $mysql['DB_HOST'] . ':' . $mysql['DB_PORT'];
    $dbuser = $mysql['DB_USER'];
    $dbpassword = $mysql['DB_PWD'];
    $dbmysql = $mysql['DB_NAME'];
    if ($con = mysql_connect($dbhost, $dbuser, $dbpassword)) {
        mysql_select_db($dbmysql, $con);
    } else {
        exit('数据库链接失败！');
    }
    mysql_query("set names utf8");
	$tableqz = $mysql['DB_PREFIX'];
    $row = $db->get_row("select count($key) as count from {$tableqz}{$table} where {$where}");
    $count = $row['count'];
    return $count; 
}

/**
 * 检测是否VIP
 */
function get_isvip($vip, $end) {
    if ($vip) {
        if (strtotime($end) > time()) {
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0; 
    }
}

/**
 * 检测是否代理
 */
function get_isdl($daili, $end) {
    if ($daili) {
        if (strtotime($end) > time()) {
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0; 
    }
}

/**
 * QQ昵称获取
 */
function get_qqnick($uin) { 
    if ($data = file_get_contents("http://r.pengyou.com/fcg-bin/cgi_get_portrait.fcg?uins=" . $uin)) {
        $data = str_replace(array(
            'portraitCallBack(',
            ')'
        ) , array(
            '',
            ''
        ) , $data);
        $data = mb_convert_encoding($data, "UTF-8", "GBK");
        $row = json_decode($data, true);;
        return $row[$uin][6];
    }
}

/**
 * get_curl
 */
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1); //主要头部
        //curl_setopt($ch, CURLOPT_FOLLOWLOCATION,0);
        
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}

//代码编写完毕，就是那么简单 ！(●'◡'●) ！