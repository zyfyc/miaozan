<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 资料修改
 */
$newsid=md5(uniqid().rand(1,1000));
$db->query("update {$TFYT_Mysql}user set sid='$newsid' where uid='{$TFYT_User['uid']}'");
setcookie("tfyt_sid","",-1,'/');
@header("refresh:3;url=user.php");
 
/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'logon.php';
 
//代码编写完毕，就是那么简单 ！(●'◡'●) ！