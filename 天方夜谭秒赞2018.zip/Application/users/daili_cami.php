<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if(get_isdl($TFYT_User['agent'],$TFYT_User['agentend'])){
	$output = "欢迎您！";
}else{
	exit("<script language='javascript'>alert('您不是代理！');window.location.href='index.php';</script>");
}

/**
 * 页面切换
 */
$index=is_string($_GET['index'])?$_GET['index']:'jhm';

/**
 * 标题 title
 */
function Title(){
	return '添加卡密';
}
 
/**
 *生成卡密
 */
if($_POST['add']=='km'){
	$kind = $_POST['kind'];
	if($kind=='1'){
		$number=is_numeric($_POST['number'])?$_POST['number']:'1';
		$money=is_numeric($_POST['money'])?$_POST['money']:'1';
		if($number>20) $output = "一次性最多生成20个激活码！";
		if($money>100) $output = "激活码余额不能大于100！";
		$user = $TFYT_User['user'];
		$addtime = date("Y-m-d H:i:s");
		for($i=0;$i<$number;$i++){
			$camia=get_random(5);
			$camib=get_random(5);
			$camic=get_random(5);
			$camib=get_random(5);
			$cami = "{$camia}-{$camib}-{$camic}-{$camib}";
			$db->query("insert into {$TFYT_Mysql}cami (kind,user,cami,money,addtime) values ('$kind','$user','$cami','$money','$addtime')");
			$km.="<tr><td>{$cami}</td></tr>";
			$index = "km";
		}
	}else if($kind=='2'){
		$number=is_numeric($_POST['number'])?$_POST['number']:'1';
		$money=is_numeric($_POST['money'])?$_POST['money']:'1';
		if($number>20) $output = "一次性最多生成20个充值卡！";
		if($money>100) $output = "充值卡余额不能大于100！";
		$user = $TFYT_User['user'];
		$addtime = date("Y-m-d H:i:s");
		$mysql = $db->query("insert into {$TFYT_Mysql}cami (kind,user,cami,money,addtime) values ('$kind','$user','$cami','$money','$addtime')");
		for($i=0;$i<$number;$i++){
			$camia=get_random(5);
			$camib=get_random(5);
			$camic=get_random(5);
			$camib=get_random(5);
			$cami = "{$camia}-{$camib}-{$camic}-{$camib}";
			$db->query("insert into {$TFYT_Mysql}cami (kind,user,cami,money,addtime) values ('$kind','$user','$cami','$money','$addtime')");
			$km.="<tr><td>{$cami}</td></tr>";
			$index = "km";
		}
	}else{
		$output = "请先选择卡密的类型！";
	}
}

/**
 * 删除
 */
if($_GET['del']=='km'){
	$id=$_GET['id'];
	if($id && $row=$db->get_row("select * from {$TFYT_Mysql}cami where id='{$id}' limit 1")){
		if(!$db->query("delete from {$TFYT_Mysql}cami where id='$id'")){}
		$output = "删除成功！";
	}else{
		$output = "要删除的卡密不存在！";
	}
}
 
/**
 * 删除全部
 */
if($_GET['delll']=='km'){
	$db->query("delete from {$TFYT_Mysql}cami where 1");
	$output = "清空成功！";
}
 
/**
 * 删除已用卡密
 */
if($_GET['dell']=='km'){
	$db->query("delete from {$TFYT_Mysql}cami where isuse='1'");
	$output = "删除成功！";
}
 
/**
 * 分页
 */
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=15;
$start=($p-1)*$pagesize;
if($index=="jhm"){
	$pages=ceil(get_count('cami','kind=1')/$pagesize);
}else if($index=="czk"){
	$pages=ceil(get_count('cami','kind=2')/$pagesize);
}

if(!$pages) $pages=1;
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
if($index=="jhm"){
	$rows=$db->get_results("select * from {$TFYT_Mysql}cami where 1=1 order by id desc limit $start,$pagesize");
}else if($index=="czk"){
	$rows=$db->get_results("select * from {$TFYT_Mysql}cami where 1=1 order by id desc limit $start,$pagesize");
}
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'daili_cami.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！