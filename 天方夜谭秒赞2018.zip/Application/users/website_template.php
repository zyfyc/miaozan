<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if($TFYT_User['uid']!=1){
	@header("refresh:0;url=index.php");
}
 
/**
 * 标题 title
 */
function Title(){
	return '模板更换';
}
 
/**
 * 存入数据
 */
if($_GET['update']=='template'){
	$tnum = $_GET['tnum'];
	$template = $_GET['template'];
	$home = $_GET['home'];
	$login = $_GET['login'];
	$enroll = $_GET['enroll'];
	$back = $_GET['back'];
	$user = $_GET['user'];
	if($template==TFYT_Data("TFYT_Template")){
		echo "<script language='javascript'>alert('你已设置此模板，无需重复设置！');window.location.href='website_template.php';</script>";
	}else{
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Tnum',value='$tnum' on duplicate key update value='$tnum'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template',value='$template' on duplicate key update value='$template'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Home',value='$home' on duplicate key update value='$home'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Login',value='$login' on duplicate key update value='$login'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Enroll',value='$enroll' on duplicate key update value='$enroll'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_Back',value='$back' on duplicate key update value='$back'"));
		mysql_query(("insert into {$TFYT_Mysql}website set vkey='TFYT_Template_User',value='$user' on duplicate key update value='$user'"));
		echo "<script language='javascript'>alert('更换此模板成功！');window.location.href='website_template.php';</script>";
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'website_template.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！