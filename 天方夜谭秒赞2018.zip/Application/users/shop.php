<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 标题 title
 */
function Title(){
	return '自助商城';
}

/**
 * 判断是否存在商品
 */
if((get_count('vip','id') + get_count('peie','id') + get_count('daili','id'))==0){
	if($TFYT_User['uid']==1){
		$index = '
		  <div class="alert alert-danger alert-block">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
			<h4><i class="fa fa-bell-alt"></i>提示：</h4>
			<p>目前还没有任何商品 <a href="website_shop.php">点击添加</a></p>
		  </div>
		';
	}else{
		$index = '
		  <div class="alert alert-danger alert-block">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
			<h4><i class="fa fa-bell-alt"></i>提示：</h4>
			<p>目前还没有任何商品，请等待管理员添加！</p>
		  </div>
		';
	}
}

/**
 * 购买VIP会员
 */
if($_GET['vip']=='buy'){
	$id = $_GET['id'];
	$datas = $_GET['datas'];
	$price = $_GET['price'];
	$stock = $_GET['stock'];
	$styles = $_GET['styles'];
	if($styles=='day'){
		$mus='天';
	}else if($styles=='week'){
		$mus='周';
	}else if($styles=='month'){
		$mus='个月';
	}else if($styles=='year'){
		$mus='年';
	}
	if($stock!=0){
		$num = $stock-$datas;
		if($TFYT_User['money']<$price){
			$output = "您的余额不足！购买失败";
		}else{
			if(get_isvip($TFYT_User['vip'],$TFYT_User['vipend'])){
				$vipend = date("Y-m-d",strtotime("+ $datas $styles",strtotime($TFYT_User['vipend'])));
				$db->query("update {$TFYT_Mysql}user set money=money-{$price},vip=1,vipstart='".date("Y-m-d")."',vipend='{$vipend}' where uid='{$TFYT_User['uid']}'");
				$output = "成功购买{$datas}{$mus}VIP";
			}else{
				$vipend=date("Y-m-d",strtotime("+ $datas $styles"));
				$db->query("update {$TFYT_Mysql}user set money=money-{$price},vip=1,vipstart='".date("Y-m-d")."',vipend='{$vipend}' where uid='{$TFYT_User['uid']}'");
				$output = "成功购买{$datas}{$mus}VIP";
			}
		}
	}else{
		$output = "此商品库存不足，无法购买！";
	}
}
 
/**
 * 购买挂机配额
 */
if($_GET['peie']=='buy'){
	$id = $_GET['id'];
	$nums = $_GET['nums'];
	$price = $_GET['price'];
	$stock = $_GET['stock'];
	if($stock!=0){
		$num = $stock-$nums;
		if($TFYT_User['money']<$price){
			$output = "您的余额不足！购买失败";
		}else{
			if($db->query("update {$TFYT_Mysql}peie set stock='{$num}' where id='$id'")){
				$db->query("update {$TFYT_Mysql}user set money=money-{$price},peie=peie+$nums where uid='{$TFYT_User['uid']}'");
				$output = "您成功购买{$nums}个挂机配额！";
			}else{
				$output = "购买失败！系统出错";
			}
		}
	}else{
		$output = "此商品库存不足，无法购买！";
	}
}
 
/**
 * 购买代理
 */
if($_GET['daili']=='buy'){
	$id = $_GET['id'];
	$datas = $_GET['datas'];
	$price = $_GET['price'];
	$stock = $_GET['stock'];
	$styles = $_GET['styles'];
	if($styles=='day'){
		$mus='天';
	}else if($styles=='week'){
		$mus='周';
	}else if($styles=='month'){
		$mus='个月';
	}else if($styles=='year'){
		$mus='年';
	}
	if($stock!=0){
		$num = $stock-$datas;
		if($TFYT_User['money']<$price){
			$output = "您的余额不足！购买失败";
		}else{
			if(get_isvip($TFYT_User['agent'],$TFYT_User['agentend'])){
				$agentend = date("Y-m-d",strtotime("+ $datas $styles",strtotime($TFYT_User['agentend'])));
				$db->query("update {$TFYT_Mysql}user set money=money-{$price},agent=1,agentstart='".date("Y-m-d")."',agentend='{$agentend}' where uid='{$TFYT_User['uid']}'");
				$output = "成功购买{$datas}{$mus}代理";
			}else{
				$agentend=date("Y-m-d",strtotime("+ $datas $styles"));
				$db->query("update {$TFYT_Mysql}user set money=money-{$price},agent=1,agentstart='".date("Y-m-d")."',agentend='{$agentend}' where uid='{$TFYT_User['uid']}'");
				$output = "成功购买{$datas}{$mus}代理";
			}
		}
	}else{
		$output = "此商品库存不足，无法购买！";
	}
}

/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'shop.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！