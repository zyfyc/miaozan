<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if($TFYT_User['uid']!=1){
	@header("refresh:0;url=index.php");
}
 
/**
 * 标题 title
 */
function Title(){
	return '网站设置';
}
 
/**
 * 存入数据
 */
if($_POST['site']=='update'){
	foreach($_POST as $k=> $value){
		$db->query("insert into {$TFYT_Mysql}website set vkey='".safestr($k)."',value='".safestr($value)."' on duplicate key update value='".safestr($value)."'");
	}
	if($rows=$db->get_results("select * from {$TFYT_Mysql}website")){
		foreach($rows as $row){
			$website[$row['vkey']]=$row['value'];
		}
		TFYT_Data($website);
	}
	$output = "保存成功！";
	@header("refresh:0;url=website_site.php");
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'website_site.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！