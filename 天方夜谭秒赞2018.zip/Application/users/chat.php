<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 标题 title
 */
function Title(){
	return '聊天大厅';
}

/**
 * 判断是否符合条件
 */
if(TFYT_Data("TFYT_Function_Chat_state")==1){
	if(TFYT_Data("TFYT_Function_Chat_vip")==1){
		if(get_isvip($TFYT_User['vip'],$TFYT_User['vipend'])){
			$output = "欢迎使用！";
		}else{
			echo "<script language='javascript'>alert('此功能需要VIP才能使用！');window.location.href='index.php';</script>";
		}
	}
}else{
	echo "<script language='javascript'>alert('此功能未开启！');window.location.href='index.php';</script>";
}
 
/**
 * 存入数据
 */
if($_POST['ok']=='chat'){
	$uid = $TFYT_User['uid'];
	$con = $_POST['con'];
	$qqs = $TFYT_User['qq'];
	$addtime=date('Y-m-d');
	if($uid=='' or $con=='' or $qqs==''){
		$output = "说点什么吧！";
	}else{
		if($db->query("insert into {$TFYT_Mysql}chats (uid,con,qqs,addtime) values ('$uid','$con','$qqs','$addtime')")){
			header("Location:chat.php");
		}else{
			$output = "系统出错！";
		}
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'chat.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！