<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 引入核心文件
 */
include_once '../../Include/conn.php';

/**
 * 判断登录状态
 */
if(!TFYT_Data('loginuid')){
	@header("Location:/?Index=Login");
	exit();
}
 
/**
 * 判断激活状态
 */
if(TFYT_Data("TFYT_User_Activate")==1){
	if($TFYT_User['uid']!=1){
		if($TFYT_User['activate']==0){
			if($acti!=1){
				echo "<script language='javascript'>alert('系统检测到你的账号未激活，点击确定前往激活！');window.location.href='cami.php';</script>";
			}
		}
	}
}
 
/**
 * 计算VIP
 */
$vip_1 = date("Y-m-d");
$vip_2 = $TFYT_User['vipend'];
$data_1 = strtotime($vip_1);
$data_2 = strtotime($vip_2);
$outvip = round(($data_2-$data_1)/3600/24);

/**
 * 计算代理
 */
$dl_1 = date("Y-m-d");
$dl_2 = $TFYT_User['agentend'];
$data_1 = strtotime($dl_1);
$data_2 = strtotime($dl_2);
$outdl = round(($data_2-$data_1)/3600/24);

//代码编写完毕，就是那么简单 ！(●'◡'●) ！