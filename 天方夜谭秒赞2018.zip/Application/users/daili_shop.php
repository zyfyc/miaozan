<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if(get_isdl($TFYT_User['agent'],$TFYT_User['agentend'])){
	$output = "欢迎您！";
}else{
	exit("<script language='javascript'>alert('您不是代理！');window.location.href='index.php';</script>");
}
 
/**
 * 标题 title
 */
function Title(){
	return '添加商品';
}

/**
 * 设置默认页
 */
$add=is_string($_GET['add'])?$_GET['add']:'Home';
 
/**
 * 添加 删除/编辑 会员
 */
if($add=="Vip"){
	if($_POST['ok']=='addvip'){	//添加
		$arr=array('info','success','dark','warning','badge','tfyt');
		shuffle($arr);
		foreach($arr as $values){
		  $Colour=$values;
		}
		$datas=$_POST['datas'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		$styles=$_POST['styles'];
		$addtime=date('Y-m-d');
		if($datas=='' or $price=='' or $stock==''){
			$output = "所有填项不能为空！";
		}else if($db->query("insert into {$TFYT_Mysql}vip (colour,datas,price,stock,styles,addtime) values ('$colour','$datas','$price','$stock','$styles','$addtime')")){
			$output = "添加成功！";
		}else{
			$output = "添加失败！系统出错";
		}
	}
	if($_GET['del']=='vip'){	//删除
		$id=$_GET['id'];
		if (!$db->query("delete from {$TFYT_Mysql}vip where id='$id'")){ }
		$output = "删除成功！";
		@header("refresh:1;url=?add=Vip");
	}
	if($_GET['edit']=='vip'){	//选择
		$id=$_GET['id'];
		if(!$row=$db->get_row("select * from {$TFYT_Mysql}vip where id='$id' limit 1")){
			$output = "要编辑的商品不存在！";
		}else{
			$id = $row['id'];
			$datas = $row['datas'];
			$price = $row['price'];
			$stock = $row['stock'];
			$styles = $row['styles'];
			$output = "已选择，开始修改你的内容吧！";
			$index=1;
		}
	}
	if($_POST['edit']=="ok"){	//编辑
		$id=$_POST['id'];
		$datas=$_POST['datas'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		$styles=$_POST['styles'];
		if($db->query("update {$TFYT_Mysql}vip set datas='{$datas}',price='{$price}',stock='{$stock}',styles='{$styles}' where id='$id'")){
			$output = "保存成功！";
			@header("refresh:0;url=?add=Vip");
		}else{
			$output = "保存失败！原因：你没有做任何修改";
		}
	}
}

/**
 * 添加 删除/编辑 挂机配额
 */
if($add=="Peie"){
	if($_POST['ok']=='addpeie'){	//添加
		$arr=array('info','success','dark','warning','badge','666');
		shuffle($arr);
		foreach($arr as $values){
		  $colour=$values;
		}
		$nums=$_POST['nums'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		$addtime=date('Y-m-d');
		if($nums=='' or $price=='' or $stock==''){
			$output = "所有填项不能为空！";
		}else if($db->query("insert into {$TFYT_Mysql}peie (colour,nums,price,stock,addtime) values ('$colour','$nums','$price','$stock','$addtime')")){
			$output = "添加成功！";
		}else{
			$output = "添加失败！系统出错";
		}
	}
	if($_GET['del']=='peie'){	//删除
		$id=$_GET['id'];
		if (!$db->query("delete from {$TFYT_Mysql}peie where id='$id'")){ }
		$output = "删除成功！";
		@header("refresh:1;url=?add=Peie");
	}
	if($_GET['edit']=='peie'){	//选择
		$id=$_GET['id'];
		if(!$row=$db->get_row("select * from {$TFYT_Mysql}peie where id='$id' limit 1")){
			$output = "要编辑的商品不存在！";
		}else{
			$id = $row['id'];
			$nums = $row['nums'];
			$price = $row['price'];
			$stock = $row['stock'];
			$output = "已选择，开始修改你的内容吧！";
			$index=1;
		}
	}
	if($_POST['edit']=="ok"){	//编辑
		$id=$_POST['id'];
		$nums=$_POST['nums'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		if($db->query("update {$TFYT_Mysql}peie set nums='{$nums}',price='{$price}',stock='{$stock}' where id='$id'")){
			$output = "保存成功！";
			@header("refresh:1;url=?add=Peie");
		}else{
			$output = "保存失败！原因：你没有做任何修改";
		}
	}
}

/**
 * 添加 删除/编辑 平台代理
 */
if($add=="Daili"){
	if($_POST['ok']=='adddaili'){	//添加
		$arr=array('info','success','dark','warning','badge','666');
		shuffle($arr);
		foreach($arr as $values){
		  $colour=$values;
		}
		$datas=$_POST['datas'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		$styles=$_POST['styles'];
		$addtime=date('Y-m-d');
		if($datas=='' or $price=='' or $stock==''){
			$output = "所有填项不能为空！";
		}else if($db->query("insert into {$TFYT_Mysql}daili (colour,datas,price,stock,styles,addtime) values ('$colour','$datas','$price','$stock','$styles','$addtime')")){
			$output = "添加成功！";
		}else{
			$output = "添加失败！系统出错";
		}
	}
	if($_GET['del']=='daili'){	//删除
		$id=$_GET['id'];
		if (!$db->query("delete from {$TFYT_Mysql}daili where id='$id'")){ }
		$output = "删除成功！";
		@header("refresh:1;url=?add=Daili");
	}
	if($_GET['edit']=='daili'){	//选择
		$id=$_GET['id'];
		if(!$row=$db->get_row("select * from {$TFYT_Mysql}daili where id='$id' limit 1")){
			$output = "要编辑的商品不存在！";
		}else{
			$id = $row['id'];
			$datas = $row['datas'];
			$price = $row['price'];
			$stock = $row['stock'];
			$styles = $row['styles'];
			$output = "已选择，开始修改你的内容吧！";
			$index=1;
		}
	}
	if($_POST['edit']=="ok"){	//编辑
		$id=$_POST['id'];
		$datas=$_POST['datas'];
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		$styles=$_POST['styles'];
		if($db->query("update {$TFYT_Mysql}daili set datas='{$datas}',price='{$price}',stock='{$stock}',styles='{$styles}' where id='$id'")){
			$output = "保存成功！";
			@header("refresh:0;url=?add=Daili");
		}else{
			$output = "保存失败！原因：你没有做任何修改";
		}
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'daili_shop.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！