<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 定义标题 title
 */
function Title(){
	return '功能配置';
}

/**
 * 获取对应值
 */
$qid = $_GET['qid'];
$uid = $TFYT_User['uid'];
 
/**
 * 判断QID是否存在
 */
if(!$qid || !$qqset=$db->get_row("select * from {$TFYT_Mysql}qq where qid='$qid' and uid='$uid' limit 1")){
	echo "<script language='javascript'>alert('此QQ不存在');window.location.href='qq.php';</script>";
}

/**
 * 删除挂机
 */
if($_GET['del']=='qq'){
	$uid = $qqset['uid'];
	if($uid!=$TFYT_User['uid']){
		echo "<script language='javascript'>alert('非法操作！');window.location.href='qq.php';</script>";
	}else{
		if($db->query("delete from {$TFYT_Mysql}qq where qid='$qid'")){
			echo "<script language='javascript'>alert('删除成功！');window.location.href='qq.php';</script>";
		}else{
			echo "<script language='javascript'>alert('删除失败！');window.location.href='qq.php';</script>";
		}
	}
}
 
/**
 * 功能配置
 */
if($_POST['ok']=='zan'){
	$is=is_numeric($_POST['is'])?$_POST['is']:'0';
	$net=is_numeric($_POST['net'])?$_POST['net']:'0';
	$rate=is_numeric($_POST['rate'])?$_POST['rate']:'60';
	if($is && !$net){
		echo"<script language='javascript'>alert('请选择个合适的服务器');window.location.href='qqset.php?qid=$qid';</script>";	
	}else if(($net && $qqset['zannet']!=$net && get_count('qq',"zannet='$net'",'qid')>=TFYT_Data('TFYT_Server'))){
		echo"<script language='javascript'>alert('{$net}号服务器已满，请换一个服务器！');window.location.href='qqset.php?qid=$qid';</script>";	
	}else{
		if(!TFYT_Data('TFYT_Free') && !get_isvip($TFYT_User[vip],$TFYT_User[vipend]) && ($net==(TFYT_Data('TFYT_Server_Mz')+1) or $net==(TFYT_Data('TFYT_Server_Mz')+2))){
			$db->query("update {$TFYT_Mysql}qq set iszan='$is',zannet='$net',zanrate='$rate' where qid='$qid'");
			echo"<script language='javascript'>alert('说说秒赞修改成功');window.location.href='qqset.php?qid=$qid';</script>";
		}
	}
}

/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'qqset.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！