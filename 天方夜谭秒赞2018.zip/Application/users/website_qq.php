<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if($TFYT_User['uid']!=1){
	@header("refresh:0;url=index.php");
}
 
/**
 * 标题 title
 */
function Title(){
	return '挂机管理';
}
 
/**
 * 挂机删除
 */
if($_GET['del']=='qq'){
	$qid = $_GET['qid'];
	if($db->query("delete from {$TFYT_Mysql}qq where qid='$qid'")){
		echo "<script language='javascript'>alert('删除成功！');window.location.href='website_qq.php';</script>";
	}else{
		echo "<script language='javascript'>alert('删除失败！');window.location.href='website_qq.php';</script>";
	}
}

/**
 * 分页 / 查询
 */
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=12;
$start=($p-1)*$pagesize;
if($_GET['do']=='search' && $s=safestr($_GET['s'])){
	$pagedo='seach';
	$qq=$db->get_results("select * from {$TFYT_Mysql}qq where qid='{$s}' or qq like'%{$s}%' order by (case when qid='{$s}' then 8 else 0 end)+(case when qq like '%{$s}%' then 3 else 0 end) desc limit 20");
}else{
	$pages=ceil(get_count('qq','1=1','qid')/$pagesize);
	$qq=$db->get_results("select * from {$TFYT_Mysql}qq order by qid desc limit $start,$pagesize");
}
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'website_qq.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！