<?php
/**
 * 引入核心文件
 */
$acti = 1;
 
require_once 'conn.php';

/**
 * 标题 title
 */
function Title(){
	return '自助充值';
}
 
/**
 * 卡密充值
 */
if($_POST['ok']=='km'){
	$kind = $_POST['kind'];
	if($kind=='1'){
		$cami = $_POST['cami'];
		if(!$row_km=$db->get_row("select * from {$TFYT_Mysql}cami where cami='$cami' limit 1")){
			$output = "该卡密不存在！";
		}else if($row_km['isuse']){
			$output = "该卡密已被使用！";
		}else{
			$usetime = date("Y-m-d H:i:s");
			$uid = $TFYT_User['uid'];
			$id = $row_km['id'];
			$money = $row_km['money'];
			if($row_km['kind']!=1){
				$output = "您输入的不是激活码！";
			}else{
				$db->query("update {$TFYT_Mysql}cami set isuse=1,uid='{$uid}',usetime='$usetime' where id='{$id}'");
				$db->query("update {$TFYT_Mysql}user set activate=1,money=money+{$money} where uid='{$uid}'");
				if($row_km['activate']!=1){
					echo "<script language='javascript'>alert('您的账号已成功激活，由于您的卡密里有{$money}元，所以系统已自动为您充值{$money}元,现在你可以玩转".TFYT_Data("TFYT_Name")."了！');window.location.href='index.php';</script>";
				}else{
					$output = "你成功充值 $money 元";
				}
			}
		}
	}else if($kind=='2'){
		$cami = $_POST['cami'];
		if(!$row_km=$db->get_row("select * from {$TFYT_Mysql}cami where cami='$cami' limit 1")){
			$output = "该卡密不存在！";
		}else if($row_km['isuse']){
			$output = "该卡密已被使用！";
		}else{
			$usetime = date("Y-m-d H:i:s");
			$uid = $TFYT_User['uid'];
			$id = $row_km['id'];
			$money = $row_km['money'];
			if($row_km['kind']!=2){
				$output = "您输入的不是充值卡！";
			}else{
				$db->query("update {$TFYT_Mysql}cami set isuse=1,uid='{$uid}',usetime='$usetime' where id='{$id}'");
				$db->query("update {$TFYT_Mysql}user set activate=1,money=money+{$money} where uid='{$uid}'");
				$output = "你成功充值 $money 元";
			}
		}
	}else{
		$output = "请先选择卡密类型！";
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'cami.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！