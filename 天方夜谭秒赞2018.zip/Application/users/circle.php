<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 定义标题 title
 */
function Title(){
	return '圈圈赞99+';
}

/**
 * 判断是否符合条件
 */
if(TFYT_Data("TFYT_Function_Quan_state")==1){
	if(TFYT_Data("TFYT_Function_Quan_vip")==1){
		if(get_isvip($TFYT_User['vip'],$TFYT_User['vipend'])){
			$output = "欢迎使用！";
		}else{
			echo "<script language='javascript'>alert('此功能需要VIP才能使用！');window.location.href='index.php';</script>";
		}
	}
}else{
	echo "<script language='javascript'>alert('此功能未开启！');window.location.href='index.php';</script>";
}

/**
 * 提交API
 */
if($_POST['ok']=='qqzan'){
	$qq=$_POST['qq'];
	if(TFYT_Data("TFYT_Function_Quan_api")==''){
		echo "<script>alert('提交失败！站长未配置API接口');window.location.href='circle.php';</script>";
	}else{
		if($qq==''){
			echo "<script>alert('QQ不能为空！');window.location.href='circle.php';</script>";
		}else{
			file_get_contents("http://".TFYT_Data("TFYT_Function_Quan_api")."/{$qq}");
			echo "<script>alert('QQ".$qq."提交成功');window.location.href='circle.php';</script>";
		}
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'circle.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！