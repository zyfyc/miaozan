<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 标题 title
 */
function Title(){
	return '资料修改';
}

/**
 * 资料修改
 */
if($_POST['ok']=='user'){
	$name = safestr($_POST['name']);
	$qq = safestr($_POST['qq']);
	$syqn = safestr($_POST['syqn']);
	$star = safestr($_POST['star']);
	$update="name='{$name}',qq='{$qq}',syqn='{$syqn}',star='{$star}'";
	if($_POST['password']){
		$Pwd=md5(md5($_POST['password']).md5('17404785'));
		$update.=",pwd='{$pwd}'";
	}
	if(!$syqn or !$star){
		$output = "为了你的账号安全，密保不能为空！";
	}else if($db->get_row("select * from {$TFYT_Mysql}user where qq='{$qq}' and uid!='{$TFYT_User['uid']}' limit 1")){
		$output = "保存失败！QQ:{$qq}已存在系统中，换一个试试";
	}else{
		if($db->query("update {$TFYT_Mysql}user set {$update} where uid='{$TFYT_User['uid']}'")){
			$output = "保存成功！";
			@header("refresh:0;url=user.php");
		}else{
			$output = "保存失败！原因：你没有做任何修改";
		}
	}
}
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'user.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！