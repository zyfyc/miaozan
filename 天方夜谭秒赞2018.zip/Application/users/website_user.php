<?php
/**
 * 引入核心文件
 */
require_once 'conn.php';

/**
 * 判断是否管理员
 */
if($TFYT_User['uid']!=1){
	@header("refresh:0;url=index.php");
}
 
/**
 * 标题 title
 */
function Title(){
	return '用户管理';
}
 
/**
 * 优先页
 */
$index=is_string($_GET['index'])?$_GET['index']:'user';

/**
 * 选择
 */
if($_GET['choice']=='user'){
	$uid = $_GET['uid'];
	if(!$uid || !$TFYT_Uset=$db->get_row("select * from {$TFYT_Mysql}user where uid='$uid' limit 1")){
		echo "<script language='javascript'>alert('用户不存在！');window.location.href='website_user.php';</script>";
	}else{
		$index = "uset";
		
	}
}

/**
 * 用户修改
 */
if($_POST['update']=='uset'){
	$uid = $_POST['uid'];
	$name = safestr($_POST['name']);
	$qq = safestr($_POST['qq']);
	if($_POST['pwd']){
		$pwd=md5(md5($_POST['pwd']).md5('17404785'));
		$set.=",pwd='{$pwd}'";
	}
	$update="name='{$name}',qq='{$qq}'";
	if($db->get_row("select * from {$TFYT_Mysql}user where qq='{$qq}' and uid!='$uid' limit 1")){
		echo "<script language='javascript'>alert('QQ:{$qq}已存在系统中，换一个试试');window.location.href='?choice=user&uid={$uid}';</script>";
	}else if($db->query("update {$TFYT_Mysql}user set {$update} where uid='$uid'")){
		echo "<script language='javascript'>alert('修改成功！');window.location.href='?choice=user&uid={$uid}';</script>";
	}else{
		echo "<script language='javascript'>alert('修改失败！');window.location.href='?choice=user&uid={$uid}';</script>";
	}
}

/**
 * 用户激活
 */

if($_POST['uset']=='activate'){
	$uid = $_POST['uid'];
	$activate = safestr($_POST['activate']);
	if($db->query("update {$TFYT_Mysql}user set activate={$activate} where uid='$uid'")){
		if($activate==1){
			echo "<script language='javascript'>alert('激活此用户成功！');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			echo "<script language='javascript'>alert('取消激活此用户成功！');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}else{
		echo "<script language='javascript'>alert('修改失败！');window.location.href='?choice=user&uid={$uid}';</script>";
	}
}
 
/**
 * 充值会员
 */
if($_POST['uset']=='vip'){
	$uid = $_POST['uid'];
	$vip = $_POST['vip'];
	$datas = $_POST['datas'];
	$styles = $_POST['styles'];
	if($styles=='day'){
		$mus='天';
	}else if($styles=='week'){
		$mus='周';
	}else if($styles=='month'){
		$mus='个月';
	}else if($styles=='year'){
		$mus='年';
	}
	$db->query("update {$TFYT_Mysql}user set vip={$vip} where uid='{$uid}'");
	if($vip==1){
		if(get_isvip($TFYT_Uset['vip'],$TFYT_Uset['vipend'])){
			$vipend = date("Y-m-d",strtotime("+ $datas $styles",strtotime($TFYT_Uset['vipend'])));
			$db->query("update {$TFYT_Mysql}user set vip=1,vipend='{$vipend}' where uid='{$uid}'");
			echo "<script language='javascript'>alert('成功续费{$datas}{$mus}VIP会员');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			$vipend=date("Y-m-d",strtotime("+ $datas $styles"));
			$db->query("update {$TFYT_Mysql}user set vip=1,vipstart='".date("Y-m-d")."',vipend='{$vipend}' where uid='{$uid}'");
			echo "<script language='javascript'>alert('成功充值{$datas}{$mus}VIP会员');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}else{
		$db->query("update {$TFYT_Mysql}user set vip=0,vipstart='0000-00-00',vipend='0000-00-00' where uid='{$uid}'");
		echo "<script language='javascript'>alert('成功取消VIP');window.location.href='?choice=user&uid={$uid}';</script>";
	}
}
 
/**
 * 开通代理
 */
if($_POST['uset']=='daili'){
	$uid = $_POST['uid'];
	$agent = $_POST['agent'];
	$datas = $_POST['datas'];
	$styles = $_POST['styles'];
	if($styles=='day'){
		$mus='天';
	}else if($styles=='week'){
		$mus='周';
	}else if($styles=='month'){
		$mus='个月';
	}else if($styles=='year'){
		$mus='年';
	}
	$db->query("update {$TFYT_Mysql}user set agent={$agent} where uid='{$uid}'");
	if($agent==1){
		if(get_isdl($TFYT_Uset['agent'],$TFYT_Uset['agentend'])){
			$agentend = date("Y-m-d",strtotime("+ $datas $styles",strtotime($TFYT_Uset['agentend'])));
			$db->query("update {$TFYT_Mysql}user set agent=1,agentend='{$agentend}' where uid='{$uid}'");
			echo "<script language='javascript'>alert('成功续费{$datas}{$mus}平台代理');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			$agentend=date("Y-m-d",strtotime("+ $datas $styles"));
			$db->query("update {$TFYT_Mysql}user set agent=1,agentstart='".date("Y-m-d")."',agentend='{$agentend}' where uid='{$uid}'");
			echo "<script language='javascript'>alert('成功开通{$datas}{$mus}平台代理');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}else{
		$db->query("update {$TFYT_Mysql}user set agent=0,agentstart='0000-00-00',agentend='0000-00-00' where uid='{$uid}'");
		echo "<script language='javascript'>alert('成功取消代理');window.location.href='?choice=user&uid={$uid}';</script>";
	}
}
 
/**
 * 充值余额
 */
 
if($_POST['uset']=='money'){
	$uid = $_POST['uid'];
	$style = $_POST['style'];
	$money = $_POST['money'];
	if($style==1){
		if($db->query("update {$TFYT_Mysql}user set money=money+{$money} where uid='$uid'")){
			echo "<script language='javascript'>alert('成功充值{$money}元');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			echo "<script language='javascript'>alert('充值金额失败！');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}else{
		if($db->query("update {$TFYT_Mysql}user set money=money-{$money} where uid='$uid'")){
			echo "<script language='javascript'>alert('成功扣除{$money}元');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			echo "<script language='javascript'>alert('扣除金额失败！');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}
}

/**
 * 充值配额
 */
 
if($_POST['uset']=='peie'){
	$uid = $_POST['uid'];
	$style = $_POST['style'];
	$peie = $_POST['peie'];
	if($style==1){
		if($db->query("update {$TFYT_Mysql}user set peie=peie+{$peie} where uid='$uid'")){
			echo "<script language='javascript'>alert('成功充值{$peie}个配额');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			echo "<script language='javascript'>alert('充值配额失败！');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}else{
		if($db->query("update {$TFYT_Mysql}user set peie=peie-{$peie} where uid='$uid'")){
			echo "<script language='javascript'>alert('成功扣除{$peie}个配额');window.location.href='?choice=user&uid={$uid}';</script>";
		}else{
			echo "<script language='javascript'>alert('扣除配额失败！');window.location.href='?choice=user&uid={$uid}';</script>";
		}
	}
}

/** 
 * 删除用户
 */
if($_GET['del']=='user'){
	$uid = $_GET['uid'];
	if($uid!=1){
		if($db->query("delete from {$TFYT_Mysql}user where uid='$uid'")){
			echo "<script language='javascript'>alert('删除成功！');window.location.href='website_user.php';</script>";
		}else{
			echo "<script language='javascript'>alert('删除失败！');window.location.href='website_user.php';</script>";
		}
	}else{
		echo "<script language='javascript'>alert('你妈的，不能删除管理员！');window.location.href='website_user.php';</script>";
	}
}
 
/**
 * 用户管理
 */
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=12;
$start=($p-1)*$pagesize;
if($_GET['do']=='search' && $s=safestr($_GET['s'])){
	$pagedo='seach';
	$rows=$db->get_results("select * from {$TFYT_Mysql}user where uid='{$s}' or user like'%{$s}%' order by (case when uid='{$s}' then 8 else 0 end)+(case when user like '%{$s}%' then 3 else 0 end) desc limit 20");
}else{
	$pages=ceil(get_count('user','1=1','uid')/$pagesize);
	$rows=$db->get_results("select * from {$TFYT_Mysql}user order by uid desc limit $start,$pagesize");
}
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
 
/**
 * 计算VIP
 */
$vip_1 = date("Y-m-d");
$vip_2 = $TFYT_Uset['vipend'];
$data_1 = strtotime($vip_1);
$data_2 = strtotime($vip_2);
$outvips = round(($data_2-$data_1)/3600/24);

/**
 * 计算代理
 */
$dl_1 = date("Y-m-d");
$dl_2 = $TFYT_Uset['agentend'];
$data_1 = strtotime($dl_1);
$data_2 = strtotime($dl_2);
$outdls = round(($data_2-$data_1)/3600/24);
 
/**
 * 加载模板头部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'head.php';

/**
 * 加载所有模板
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'website_user.php';
 
/**
 * 加载模板底部
 */
include_once TFYT::User_Head().TFYT_Data("TFYT_Template_User").'foot.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！