<?php
/**
 * 引入核心文件
 */
require_once '../users/conn.php';

/**
 * 添加挂机
 */
if($_GET['add']=='qq'){		//pwd
	$uid = $TFYT_User['uid'];
	$qq = $_POST['qq'];
	$sid = $_POST['sid'];
	$skey = $_POST['skey'];
	$ptsig = $_POST['ptsig'];
	$p_skey = $_POST['p_skey'];
	$p_skey2 = $_POST['p_skey2'];
	$pwd = $_POST['pwd'];
	$addtime = date("Y-m-d H:i:s");
	$pwd=md5(md5($pwd).md5('17404785'));
	if($qq!='' or $sid!='' or $skey!='' or $p_skey!='' or $p_skey2!='' or $pwd!=''){
		if($row = $db->get_row("select * from {$TFYT_Mysql}qq where qq='$qq' limit 1")){
			$set = "sid='{$sid}',skey='{$skey}',p_skey='{$p_skey}',p_skey2='{$p_skey2}',ptsig='{$ptsig}',pwd='{$pwd}'";
			$db->query("update {$TFYT_Mysql}qq set {$set} where qq='$qq'");
			$rows=$db->get_row("select * from {$TFYT_Mysql}qq where qq='$qq' limit 1");
			exit('{"saveOK":0,"msg":"QQ：'.$rows['qq'].'更新成功！"}');
		}else{
			if(get_count('qq',"uid='$TFYT_User[uid]'",'qid')>= $TFYT_User['peie']){
				$peie = $TFYT_User['peie'];
				exit('{"saveOK":0,"msg":"对不起，你最大允许添加'.$peie.'个QQ！"}');
			}else{
				if($db->query("insert into {$TFYT_Mysql}qq (uid,qq,pwd,sid,skey,ptsig,p_skey,p_skey2,addtime) values ('$uid','$qq','$pwd','$sid','$skey','$ptsig','$p_skey','$p_skey2','$addtime')")){
					exit('{"saveOK":0,"msg":"添加成功！"}');
				}else{
					exit('{"saveOK":0,"msg":"添加失败！系统出错"}');
				}
			}
		}
	}else{
		exit('{"saveOK":0,"msg":"获取所有值失败！"}');
	}
}
//代码编写完毕，就是那么简单 ！(●'◡'●) ！