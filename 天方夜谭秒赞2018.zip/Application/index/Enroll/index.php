<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 用户注册
 */
if($_POST['ok']=='Enroll'){
	session_start();
	$user=safestr($_POST['username']);
	$pwd=safestr($_POST['password']);
	$pwd2=safestr($_POST['password2']);
	$vcode=safestr($_POST['code']);
	$ip=get_real_ip();
	if(!$user or !$pwd or !$pwd2 or !$vcode){
		$output = "注册失败！所有项不能为空";
	}else if(strlen($user) < 5){
		$output = "注册失败！用户名不能小于5位";
	}else if(strlen($user) >= 18){
		$output = "注册失败！用户名不能大于18位";
	}else if(strlen($pwd) < 5){
		$output = "注册失败！密码不能小于5位";
	}else if(strlen($pwd) >= 18){
		$output = "注册失败！密码不能大于18位";
	}else if($pwd2!=$pwd && $pwd!=$pwd2){
		$output = "注册失败！两次输入的密码不一致";
	}else if(!$vcode || strtolower($_SESSION['tfyt_code'])!=strtolower($vcode)){
		$output = "注册失败！验证码错误";
	}else if($db->get_row("select uid from {$TFYT_Mysql}user where user='{$user}' limit 1")){
		$output = "注册失败！此用户名已被注册，换一个试试";
	}else{
		$_SESSION['tfyt_code'] =md5(rand(100,500).time());
		$sid=md5(uniqid().rand(1,1000));
		$pwd=md5(md5($pwd).md5('17404785'));
		$regtime=date("Y-m-d H:i:s");
		$city=get_ip_city($ip);
		$money=TFYT_Data("TFYT_Reg_Money");
		$peie=TFYT_Data("TFYT_Reg_Peie");
		$mysql=$db->query("insert into  {$TFYT_Mysql}user (user,money,peie,pwd,sid,city,regip,lastip,regtime,lasttime) values ('$user','$money','$peie','$pwd','$sid','$city','$ip','$ip','$regtime','$lasttime')");
		if($mysql){
			$output = "注册成功！您的用户名为：{$user}<br/>浏览器将3秒后自动转跳";
			@header("refresh:3;url=/?Index=Login");
		}else{
			$output = "注册失败！系统出错";
		}
	}
}
 
/**
 * 加载模板
 */
require_once TFYT::Template_Enroll().TFYT_Data("TFYT_Template_Enroll").'index.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！