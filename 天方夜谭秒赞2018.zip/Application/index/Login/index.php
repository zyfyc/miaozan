<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 用户登录
 */
if($_POST['ok']=='login'){
	$user=safestr($_POST['username']);
	$pwd=safestr($_POST['password']);
	$ip=get_real_ip();
	if(!$user){
		$output = "登录失败！<br/>用户名不能为空";
	}else if(!$pwd){
		$output = "登录失败！<br/>密码不能为空";
	}else if(strlen($user) < 5){
		$output = "登录失败！<br/>用户名不能小于5位";
	}else if(strlen($user) >= 18){
		$output = "登录失败！<br/>用户名不能大于18位";
	}else if(strlen($pwd) < 5){
		$output = "登录失败！<br/>密码不能小于5位";
	}else if(strlen($pwd) >= 18){
		$output = "登录失败！<br/>密码不能大于18位";
	}else if(!$db->get_row("select uid from {$TFYT_Mysql}user where user='{$user}' limit 1")){
		$output = "登录失败！<br/>用户名不存在！";
	}else{
		$pwd=md5(md5($pwd).md5('17404785'));
		$where="user='$user' and pwd='$pwd'";
		if($ROW_User=$db->get_row("select uid,user,name from {$TFYT_Mysql}user where {$where} limit 1")){
			$sid=md5(uniqid().rand(1,1000));
			$now=date("Y-m-d G:H:s");
			$ip=get_real_ip();
			$db->query("update {$TFYT_Mysql}user set sid='$sid',lasttime='$now',lastip='$ip' where uid='{$ROW_User['uid']}'");
			setcookie("tfyt_sid",$sid,time()+3600*24*14,'/');
			if(TFYT_Data("TFYT_User_Activate")==1){
				if($ROW_User['activate']==1){
					if($ROW_User['name']!=''){
						$output = "尊敬的{$ROW_User['name']},欢迎您回来！<br/>浏览器三秒后将自动转跳！";
						@header("refresh:3;url=/?Index=User");
					}else{
						$output = "尊敬的{$ROW_User['user']},欢迎您回来！<br/>浏览器三秒后将自动转跳！";
						@header("refresh:3;url=/?Index=User");
					}
				}else{
					if($ROW_User['uid']==1){
						$output = "尊敬的{$ROW_User['user']},欢迎您回来！<br/>浏览器三秒后将自动转跳！";
						@header("refresh:3;url=/?Index=User");
					}else{
						$output = "登录成功，系统检测到您的账号未激活，请先激活您的账号后再进行操作！<br/>浏览器三秒后将自动转跳！";
						@header("refresh:3;url=/?Index=User");
					}
				}
			}else{
				if($ROW_User['name']!=''){
					$output = "尊敬的{$ROW_User['name']},欢迎您回来！<br/>浏览器三秒后将自动转跳";
					@header("refresh:3;url=/?Index=User");
				}else{
					$output = "尊敬的{$ROW_User['user']},欢迎您回来！<br/>浏览器三秒后将自动转跳";
					@header("refresh:3;url=/?Index=User");
				}
			}
		}
	}
}
 
/**
 * 加载模板
 */
require_once TFYT::Template_Login().TFYT_Data("TFYT_Template_Login").'index.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！