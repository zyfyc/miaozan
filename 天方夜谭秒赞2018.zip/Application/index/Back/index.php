<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------
 
/**
 * 找回密码 1
 */
if($_POST['ok']=='Vcode'){
	session_start();
	$code=safestr($_POST['code']);
	$username=safestr($_POST['username']);
	if(!$code || strtolower($_SESSION['tfyt_code'])!=strtolower($code)){
		$output = "验证失败！验证码错误";
	}else if($user=$db->get_row("select * from {$TFYT_Mysql}user where user='$username' limit 1")){
		$syqn=$user['syqn'];
		$user=$user['user'];
	}else{
		$output = "验证失败！该账号不存在";
	}
}

/**
 * 设置优先页
 */
if($syqn==''){
	$index = 1;
}else{
	$index = 2;
}

/**
 * 接收器
 */
$syqn=$syqn;
$user=$user;
 
/**
 * 找回密码 2
 */
 if($_POST['ok']=='Back'){
	 $user=safestr($_POST['user']);
	 $aqanswer=safestr($_POST['aqanswer']);
	 $pwd=md5(md5(safestr($_POST['password'])).md5('17404785'));
	 if($db->get_row("select * from {$TFYT_Mysql}user where star='{$aqanswer}' and user='{$user}' limit 1")){
		 if($db->query("update {$TFYT_Mysql}user set pwd='{$pwd}' where user='{$user}'")){
			 $output = "密码重置成功！浏览器将三秒后自动转跳";
			 @header("refresh:3;url=/?Index=Login");
		 }else{
			 $output = "密码重置失败！系统出错";
		 }
	 }else{
		 $output = "密码重置失败！您貌似不是该账号的主人哦";
	 }
 }
 
/**
 * 加载模板
 */
require_once TFYT::Template_Back().TFYT_Data("TFYT_Template_Back").'index.php';

//代码编写完毕，就是那么简单 ！(●'◡'●) ！