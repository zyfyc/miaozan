<!DOCTYPE html>
<html lang="en">
<head>
<title>网站首页 - <?=TFYT_Data("TFYT_Name")?></title>
<meta name="description" content="<?=TFYT_Data("TFYT_Description")?>">
<meta name="keywords" content="<?=TFYT_Data("TFYT_Keywords")?>">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/bootstrap.min.css">
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/animate.css">
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/font-awesome.min.css">
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/owl.theme.css">
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/owl.carousel.css">
<!-- Main css -->
<link rel="stylesheet" href="/ThinkPHP/Home/Index_1/css/style.css">
<style type="text/css">
#intro {
    background: url('<?=TFYT_Data("TFYT_Template_Img1")?>') 50% 0 repeat-y fixed;
    -webkit-background-size: cover;
    background-size: cover;
    background-position: center center;
    color: #ffffff;
    display: -webkit-box;
    display: -webkit-flex;
     display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
     -webkit-align-items: center;
      -ms-flex-align: center;
          align-items: center;
    height: 100vh;
    text-align: center;
}
</style>
<style type="text/css">
#foota {
    background: url('<?=TFYT_Data("TFYT_Template_Img1")?>') 50% 0 repeat-y fixed;
    -webkit-background-size: cover;
    background-size: cover;
    background-position: center center;
    color: #ffffff;
    display: -webkit-box;
    display: -webkit-flex;
     display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
     -webkit-align-items: center;
      -ms-flex-align: center;
          align-items: center;
    height: 80vh;
    text-align: center;
}
</style>
</head>
<body data-spy="scroll" data-offset="50" data-target=".navbar-collapse">
<div class="preloader">
	<div class="sk-rotating-plane"></div>
</div>
<div class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">TFYT</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#intro" class="smoothScroll">网站首页</a></li>
				<li><a href="/?Index=Login" class="smoothScroll">用户登录</a></li>
				<li><a href="/?Index=Enroll" class="smoothScroll">用户注册</a></li>
				<li><a href="/?Index=Back" class="smoothScroll">找回密码</a></li>
				<li><a href="#register" class="smoothScroll">代理验证</a></li>
				<li><a href="#venue" class="smoothScroll">联系方式</a></li>
			</ul>
		</div>
	</div>
</div>
<section id="intro" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h1 class="wow fadeInUp" data-wow-delay="0.9s"><?=TFYT_Data("TFYT_Name")?></h1>
				<h3 class="wow bounceIn" data-wow-delay="1.6s">腾讯不倒&nbsp;秒赞要好</h3>
				<a href="/?Index=Login" class="btn btn-lg btn-default smoothScroll wow fadeInUp hidden-xs" data-wow-delay="2.3s">立即体验</a>
			</div>
		</div>
	</div>
</section>
<section id="overview" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="wow fadeInUp col-md-6 col-sm-6" data-wow-delay="0.6s">
				<img src="/ThinkPHP/Home/Index_1/images/about.png" class="img-responsive" alt="Overview">
			</div>
			<div class="wow fadeInUp col-md-6 col-sm-6" data-wow-delay="0.9s">
				<h1>我们的特色</h1>
				<h3>使用<?=TFYT_Data("TFYT_Name")?>进行挂机，无需安装任何额外软件，注册登陆后添加QQ即可正常运行，
				您可以随时在电脑/手机/平板登陆本网站进行功能设置。高配置服务器采用分布式监控系统的运行，
				24小时不间断稳定不宕机，服务器秒级切换更改随心，离线托管完美使用体验！</h3>
				<br/>
				<p><a href="#register" class="btn btn-lg btn-danger smoothScroll wow fadeInUp" data-wow-delay="2.3s">立即体验</a></p>
			</div>
		</div>
	</div>
</section>
<section id="detail" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="wow fadeInLeft col-md-4 col-sm-4" data-wow-delay="0.3s">
				<i class="fa fa-group"></i>
				<h3>空间类</h3>
				<p>离线秒赞、秒评、发图片说说、说说转发、说说圈图、批量删除说说、批量删除留言、互刷主页赞、互刷留言等</p>
			</div>
			<div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.6s">
				<i class="fa fa-clock-o"></i>
				<h3>签到类</h3>
				<p>空间签到、会员签到、钱包签到、QQ群签到、群问问签到、部落签到、花藤服务、书城签到、QQ浏览器赚积分、微云签到、绿钻黄钻蓝钻粉钻签到等等</p>
			</div>
			<div class="wow fadeInRight col-md-4 col-sm-4" data-wow-delay="0.9s">
				<i class="fa fa-microphone"></i>
				<h3>工具类</h3>
				<p>单项检测、秒赞检测、刷圈圈赞、说说刷赞、互刷人气、刷说说队形、空间音乐查询、批量添加好友、导出群成员</p>
			</div>
		</div>
	</div>
</section>
<section id="foota" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="wow bounceIn col-md-12 col-sm-12">
				<div class="section-title">
					<h1>他们正在使用我们提供的服务！</h1>
					<p><font color="red">运营<?php echo $uptime['years']; ?>年<?php echo $uptime['days']; ?>天来，我们已有<?=get_count('user','uid')?>位用户和<?=get_count('qq','qid')?>个QQ</font></p>
				</div>
			</div>
			<div class="wow fadeInUp col-md-12 col-sm-12 col-xs-12" data-wow-delay="0.3s">
			<ul>
			<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}qq where 1=1 order by qid desc")){ foreach($rows as $qq){?>
				<img style="border:1px solid #FFF;-moz-box-shadow:0 0 3px #AAA;-webkit-box-shadow:0 0 3px #AAA;box-shadow:0 0 3px #AAA;padding:3px;margin-right:10px;margin-top:15px;margin-left:15px;" src="http://q2.qlogo.cn/headimg_dl?bs=qq&amp;dst_uin=<?=$qq[qq]?>&amp;spec=100" width="80px" height="80px" alt="<?=get_qqnick($qq['qq'])?>的QQ头像" title="<?=$qq[qq]?>|添加时间:<?=$qq[addtime]?>"></a>
			<?php }}?>
			</ul>
			</div>
		</div>
	</div>
</section>
<footer>
<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12">
			<p class="wow fadeInUp" data-wow-delay="0.6s">Copyright &copy; 2018 <a href="http://<?=TFYT_Data("TFYT_Domain")?>/"><?=TFYT_Data("TFYT_Foot")?></a></p>
			<ul class="social-icon">
				<li><a href="#" class="fa fa-facebook wow fadeInUp" data-wow-delay="1s"></a></li>
				<li><a href="#" class="fa fa-twitter wow fadeInUp" data-wow-delay="1.3s"></a></li>
				<li><a href="#" class="fa fa-dribbble wow fadeInUp" data-wow-delay="1.6s"></a></li>
				<li><a href="#" class="fa fa-behance wow fadeInUp" data-wow-delay="1.9s"></a></li>
				<li><a href="#" class="fa fa-google-plus wow fadeInUp" data-wow-delay="2s"></a></li>
			</ul>
		</div>
	</div>
</div>
</footer>
<!-- Back top -->
<a href="#back-top" class="go-top"><i class="fa fa-angle-up"></i></a>
<!-- =========================
     SCRIPTS   
============================== -->
<script src="/ThinkPHP/Home/Index_1/js/jquery.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/bootstrap.min.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/jquery.parallax.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/owl.carousel.min.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/smoothscroll.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/wow.min.js"></script>
<script src="/ThinkPHP/Home/Index_1/js/custom.js"></script>
</body>
</html>