<?php if($index=='1'){?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>  
  <meta charset="utf-8" />
  <title>账号验证 - <?=TFYT_Data("TFYT_Name")?></title>
  <meta name="description" content="<?=TFYT_Data("TFYT_Description")?>" />
  <meta name="keywords" content="<?=TFYT_Data("TFYT_Keywords")?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="/ThinkPHP/Users/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/icon.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/app.css" type="text/css" />  
    <!--[if lt IE 9]>
    <script src="/ThinkPHP/Users/js/ie/html5shiv.js"></script>
    <script src="/ThinkPHP/Users/js/ie/respond.min.js"></script>
    <script src="/ThinkPHP/Users/js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="/">账号验证</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>在这里你可以找回你遗忘的密码！<?php if($output){?><br/><font color="red"><?=$output?></font><?php }?></strong>
        </header>
        <form onsubmit="?" method="post">
		 <input type="hidden" name="ok" value="Vcode">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" name="username" placeholder="请输入用户名" class="form-control no-border">
            </div>
            <div class="list-group-item">
               <input type="password" name="code" placeholder="请输入4为验证码" class="form-control no-border">
            </div>
            <div class="list-group-item">
               <div class="text-center"><img title="点击刷新" src="/vcode.php" onclick="this.src='/vcode.php?'+Math.random();"></div>
            </div>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">点击验证</button>
          <div class="text-center m-t m-b"><a href="/?Index=Enroll"><small>还有账号？点击创建一个</small></a></div>
          <div class="line line-dashed"></div>
          <a href="/?Index=Login" class="btn btn-lg btn-default btn-block">用户登录</a>
        </form>
      </section>
    </div>
  </section>
  <!-- footer -->
  <footer id="footer">
    <div class="text-center padder">
      <p>
        <small>copyright  &copy; <?=date("Y")?> <a href="http://<?=TFYT_Data("TFYT_Domain")?>/"><?=TFYT_Data("TFYT_Foot")?></a></small>
      </p>
    </div>
  </footer>
  <!-- / footer -->
  <script src="/ThinkPHP/Users/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="/ThinkPHP/Users/js/bootstrap.js"></script>
  <!-- App -->
  <script src="/ThinkPHP/Users/js/app.js"></script>  
  <script src="/ThinkPHP/Users/js/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="/ThinkPHP/Users/js/app.plugin.js"></script>
</body>
</html>
<?php }else if($index=='2'){?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>  
  <meta charset="utf-8" />
  <title>找回密码 - <?=TFYT_Data("TFYT_Name")?></title>
  <meta name="description" content="<?=TFYT_Data("TFYT_Description")?>" />
  <meta name="keywords" content="<?=TFYT_Data("TFYT_Keywords")?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="/ThinkPHP/Users/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/icon.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/app.css" type="text/css" />  
    <!--[if lt IE 9]>
    <script src="/ThinkPHP/Users/js/ie/html5shiv.js"></script>
    <script src="/ThinkPHP/Users/js/ie/respond.min.js"></script>
    <script src="/ThinkPHP/Users/js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="/">找回密码</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>在这里你可以找回你遗忘的密码！<?php if($output){?><br/><font color="red"><?=$output?></font><?php }?></strong>
        </header>
        <form onsubmit="?" method="post">
		 <input type="hidden" name="ok" value="Back">
		 <input type="hidden" name="user" value="<?=$user?>">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" value="用户名：<?=$user?>" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" value="密保问题：<?=$syqn?>" class="form-control no-border" readonly>
            </div>
            <div class="list-group-item">
              <input type="text" name="aqanswer" placeholder="请输入密保答案" class="form-control no-border">
            </div>
            <div class="list-group-item">
               <input type="text" name="password" placeholder="请输入新密码" class="form-control no-border">
            </div>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">点击重置</button>
          <div class="text-center m-t m-b"><a href="/?Index=Enroll"><small>还有账号？点击创建一个</small></a></div>
          <div class="line line-dashed"></div>
          <a href="/?Index=Login" class="btn btn-lg btn-default btn-block">用户登录</a>
        </form>
      </section>
    </div>
  </section>
  <!-- footer -->
  <footer id="footer">
    <div class="text-center padder">
      <p>
        <small>copyright  &copy; <?=date("Y")?> <a href="http://<?=TFYT_Data("TFYT_Domain")?>/"><?=TFYT_Data("TFYT_Foot")?></a></small>
      </p>
    </div>
  </footer>
  <!-- / footer -->
  <script src="/ThinkPHP/Users/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="/ThinkPHP/Users/js/bootstrap.js"></script>
  <!-- App -->
  <script src="/ThinkPHP/Users/js/app.js"></script>  
  <script src="/ThinkPHP/Users/js/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="/ThinkPHP/Users/js/app.plugin.js"></script>
</body>
</html>
<?php }?>