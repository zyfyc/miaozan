<!DOCTYPE html>
<html lang="en" class="app">
<head>  
  <meta charset="utf-8" />
  <title>用户登录 - <?=TFYT_Data("TFYT_Name")?></title>
  <meta name="description" content="<?=TFYT_Data("TFYT_Description")?>" />
  <meta name="keywords" content="<?=TFYT_Data("TFYT_Keywords")?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="/ThinkPHP/Users/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/icon.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/app.css" type="text/css" />  
    <!--[if lt IE 9]>
    <script src="/ThinkPHP/Users/js/ie/html5shiv.js"></script>
    <script src="/ThinkPHP/Users/js/ie/respond.min.js"></script>
    <script src="/ThinkPHP/Users/js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xl">
      <a class="navbar-brand block" href="/">用户登录</a>
      <section class="m-b-lg">
        <header class="wrapper text-center">
          <strong>请登录后再进行操作<?php if($output){?><br/><font color="red"><?=$output?></font><?php }?></strong>
        </header>
        <form onsubmit="?" method="post">
		 <input type="hidden" name="ok" value="login">
          <div class="list-group">
            <div class="list-group-item">
              <input type="text" name="username" placeholder="请输入用户名" class="form-control no-border">
            </div>
            <div class="list-group-item">
               <input type="password" name="password" placeholder="请输入密码" class="form-control no-border">
            </div>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block">立即登录</button>
          <div class="text-center m-t m-b"><a href="/?Index=Back"><small>忘记密码了？点击找回</small></a></div>
          <div class="line line-dashed"></div>
          <a href="/?Index=Enroll" class="btn btn-lg btn-default btn-block">创建一个账号</a>
        </form>
      </section>
    </div>
  </section>
  <!-- footer -->
  <footer id="footer">
    <div class="text-center padder">
      <p>
        <small>copyright  &copy; <?=date("Y")?> <a href="http://<?=TFYT_Data("TFYT_Domain")?>/"><?=TFYT_Data("TFYT_Foot")?></a></small>
      </p>
    </div>
  </footer>
  <!-- / footer -->
  <script src="/ThinkPHP/Users/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="/ThinkPHP/Users/js/bootstrap.js"></script>
  <!-- App -->
  <script src="/ThinkPHP/Users/js/app.js"></script>  
  <script src="/ThinkPHP/Users/js/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/ThinkPHP/Users/js/app.plugin.js"></script>
</body>
</html>