	<section id="content">
	  <section class="hbox stretch">
		<section>
		  <section class="vbox">
			<section class="scrollable padder">              
			  <section class="row m-b-md">
				<div class="col-sm-6">
				  <h3 class="m-b-xs text-black">控制台</h3>
				  <small>尊敬的<?php if($TFYT_User['uid']==1){echo '管理员';}else if(get_isvip($TFYT_User['agent'],$TFYT_User['agentend'])){echo '代理';}?> <?php if(!$TFYT_User['name']){echo $TFYT_User['user'];}else{echo $TFYT_User['name'];}?>, 欢迎您回来！</small>
				</div>
				<div class="col-sm-6 text-right text-left-xs m-t-md">
				  <a href="#nav,#crse" class="btn btn-icon b-2x btn-info btn-rounded" data-toggle="class:nav-xs, show"><i class="fa fa-bars"></i></a>
				</div>
			  </section>
			  <div class="row">
				<div class="col-md-3 col-sm-6">
				  <div class="panel b-a">
					<div class="panel-heading no-border bg-danger lt text-center">
					  <a href="#">
						<i class="fa fa-users fa fa-3x m-t m-b text-white"></i>
					  </a>
					</div>
					<div class="padder-v text-center clearfix">                            
					  <div class="col-xs-12">
						<div class="h3 font-bold"><?=get_count('user','uid')?></div>
						<small class="text-muted">平台用户</small>
					  </div>
					</div>
				  </div>
				</div>
				<div class="col-md-3 col-sm-6">
				  <div class="panel b-a">
					<div class="panel-heading no-border bg-success lt text-center">
					  <a href="#">
						<i class="fa fa-linux fa fa-3x m-t m-b text-white"></i>
					  </a>
					</div>
					<div class="padder-v text-center clearfix">                            
					  <div class="col-xs-12">
						<div class="h3 font-bold"><?=get_count('qq','qid')?></div>
						<small class="text-muted">平台挂机</small>
					  </div>
					</div>
				  </div>
				</div>
				<div class="col-md-3 col-sm-6">
				  <div class="panel b-a">
					<div class="panel-heading no-border bg-info lt text-center">
					  <a href="#">
						<i class="fa fa-coffee fa fa-3x m-t m-b text-white"></i>
					  </a>
					</div>
					<div class="padder-v text-center clearfix">                            
					  <div class="col-xs-12">
						<div class="h3 font-bold"><?=TFYT_Data("TFYT_Number_Visitor")?></div>
						<small class="text-muted">平台访客</small>
					  </div>
					</div>
				  </div>
				</div>
				<div class="col-md-3 col-sm-6">
				  <div class="panel b-a">
					<div class="panel-heading no-border bg-primary lter text-center">
					  <a href="#">
						<i class="fa fa-cloud fa fa-3x m-t m-b text-white"></i>
					  </a>
					</div>
					<div class="padder-v text-center clearfix">                            
					  <div class="col-xs-12">
						<div class="h3 font-bold"><?php echo $uptime['years']; ?>年<?php echo $uptime['days']; ?>天</div>
						<small class="text-muted">安全运行</small>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-8">
				  <section class="panel b-light">
					<header class="panel-heading"><strong><i class="fa fa-bullhorn"></i> 公告</strong></header>
					<div class="panel-body flot-legend bg-light">
					  <div style="height:420px"><?=TFYT_Data("TFYT_Notice_User")?></div>
					</div>
				  </section>
				</div>
				<div class="col-md-4">
				  <section class="panel b-light">
					<header class="panel-heading"><strong><i class="fa fa-calendar-o"></i> 日历</strong></header>
					<div id="calendar" class="bg-light dker m-l-n-xxs m-r-n-xxs"></div>
					<div class="list-group">
					  <a href="#" class="list-group-item text-ellipsis"> 
						<span class="badge bg-success"><?=date('Y-m-d h:i:s',time())?></span> 
						世界时间：
					  </a>
					</div>
				  </section>
				</div>
			  </div>
			</section>
		  </section>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
	<!-- side content -->
	<aside class="aside-md bg-black hide" id="crse">
	  <section class="vbox animated fadeInRight">
		<section class="scrollable">
		  <div class="wrapper"><strong>平台客服</strong></div>
		  <ul class="list-group no-bg no-borders auto">
		  <?php if($rows=$db->get_results("select uid,user,qq,name,agent from {$TFYT_Mysql}user order by uid desc")){ foreach($rows as $Row_user){?>
		  <?php if($Row_user['uid']==1 || $Row_user['agent']==1){?>
			<li class="list-group-item">
			  <div class="media">
				<span class="pull-left thumb-sm avatar">
				  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$Row_user['qq']){echo'10001';}else{echo $Row_user['qq'];}?>&s=100" alt="QQ:<?php if(!$Row_user['qq']){echo'10001';}else{echo''.get_qqnick($Row_user['qq']).'';}?>的头像">
				  <i class="on b-black bottom"></i>
				</span>
				<div class="media-body">
				  <div><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php if(!$Row_user['qq']){echo'17404785';}else{echo $Row_user['qq'];}?>&site=qq&menu=yes"><?php if(!$Row_user['name']){echo'超级管理员';}else{echo $Row_user['name'];}?></a>  [<?php if($Row_user['uid']==1){echo'站长';}else if($Row_user['agent']==1){echo'代理';}?>]</div>
				  <small class="text-muted">QQ：<?php if(!$Row_user['qq']){echo'10001';}else{echo $Row_user['qq'];}?></small>
				</div>
			  </div>
			</li>
		  <?php }?>
		  <?php }}?>
		  </ul>
		</section>
	  </section>              
	</aside>
	<!-- / side content -->
  </section>