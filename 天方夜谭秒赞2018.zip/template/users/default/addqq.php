	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">添加Q Q </h3>
		  </div>
		  <div class="row">
			<div class="col-sm-6">
              <section class="panel panel-default">
			  <header class="panel-heading">
				<span class="h4">警告</span>
			  </header>
                <div class="list-group bg-white">
                  <a href="#" class="list-group-item">
                    1、首次使用本网站可能会因为异地登陆而被TX临时冻结QQ，改密即可解冻
                  </a>
                  <a href="#" class="list-group-item">
                    2、添加后会提示广州的异地登陆提醒，以及可能被盗号的安全提醒，本站承诺不盗号读取数据
                  </a>
                  <a href="#" class="list-group-item">
                    * 帐号配额：已用<font color=green><?=get_count('qq',"uid='$TFYT_User[uid]'",'qid')?></font>个，共有<?=$TFYT_User[peie]?>个
                  </a>
                  <a href="#" class="list-group-item">
                    <strong>添加QQ即代表同意本站协议并自愿使用，不同意以上内容请关闭本网站。</strong>
                  </a>
                </div>
              </section>
			</div>
		  <?php if($addqq=="Home"){?>
			<div class="col-sm-6">
			<section class="panel panel-default">
			  <header class="panel-heading">
				<span class="h4">添加Q Q- [<a href="#">扫码添加</a>]</span>
			  </header>
			  <div class="panel-body">
				<iframe frameborder="0" scrolling="no" marginwidth="0" marginheight="0"  width="100%" height="330" src="http://<?=$_SERVER['SERVER_NAME']?>/Application/addq/index.html"></iframe>
			  </div>
			</section>
			</div>
		  <?php }else if($addqq=="Code"){ ?>
			<div class="col-sm-6">
			<section class="panel panel-default">
			  <header class="panel-heading">
				<span class="h4">添加QQ - [<a href="?addqq=Home">密码添加</a>]</span>
			  </header>
			  <div class="panel-body">
				<iframe frameborder="0" scrolling="no" marginwidth="0" marginheight="0"  width="100%" height="400" src="http://<?=$_SERVER['SERVER_NAME']?>/Application/addq/index2.html"></iframe>
			  </div>
			</section>
			</div>
		  <?php }?>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
