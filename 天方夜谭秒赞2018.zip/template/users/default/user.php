	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">我的资料</h3>
		  </div>
		  <?php if($output){?>
		  <div class="alert alert-danger alert-block">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
			<h4><i class="fa fa-bell-alt"></i>提示：</h4>
			<p><?=$output?></p>
		  </div>
		  <?php }?>
		  <div class="row">
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-dark">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <div class="easypiechart" data-percent="80" data-line-width="5" data-bar-color="#1aae88" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="139" data-line-cap='butt' data-animate="1000">
						<div class="thumb-lg">
						  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$TFYT_User['qq']){echo'10001';}else{echo''.$TFYT_User['qq'].'';}?>&s=160" class="img-circle">
						</div>
					  </div>
					  <div class="h4 m-t m-b-xs"><?php if(!$TFYT_User['name']){echo '新平台用户';}else{echo $TFYT_User['name'];}?></div>
					  <small class="text-muted m-b"><?=$TFYT_User['user']?> <?php if(TFYT_Data("TFYT_User_Activate")==1){echo '[<font color="#006633">已激活</font>]';}?></small>
					</div>                      
				  </div>
				</div>
				<div class="list-group no-radius alt">
				  <a class="list-group-item" href="#">
					<span class="badge bg-success">当前身份</span>
					<?php if(get_isvip($TFYT_User['vip'],$TFYT_User['vipend'])){ echo "VIP用户（还有 ".$outvip." 天）";}else{echo"免费用户";}?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-info">账户余额</span>
					<?=$TFYT_User['money']?> 元
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-dark">挂机配额</span>
					0/<?=$TFYT_User['peie']?> 个
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-primary">平台代理</span>
					<?php if(get_isdl($TFYT_User['agent'],$TFYT_User['agentend'])){ echo "是（还有 ".$outdl." 天）";}else{echo"不是代理";}?>
				  </a>
				</div>
				  <div id="collapseTwo" class="panel-collapse collapse">
				  <a class="list-group-item" href="#">
					<span class="badge bg-info">登录 I P</span>
					<?=$TFYT_User['lastip']?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-primary">注册 I P</span>
					<?=$TFYT_User['regip']?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-danger">登录时间</span>
					<?=$TFYT_User['lasttime']?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-warning">注册时间</span>
					<?=$TFYT_User['regtime']?>
				  </a>
				  </div>
				<div class="btn-group btn-group-justified">
				  <a data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo" class="btn btn-success">查看更多</a>
				</div>
			  </section>
			</div>
			<div class="col-sm-8">
			  <form action="?" method="post">
			   <input type="hidden" name="ok" value="user">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">资料修改</span>
				  </header>
				  <div class="panel-body">
					<p class="text-muted">在这里，你可以修改你的个人信息</p>
					<div class="form-group">
					<label>用户UID：</label>
						<input type="text" value="<?=$TFYT_User['uid']?>" class="form-control" readonly>
					</div>
					<div class="form-group">
					<label>用户名：</label>
						<input type="text" value="<?=$TFYT_User['user']?>" class="form-control" readonly>
					</div>
					<div class="form-group">
					<label>名  称：</label>
						<input type="text" name="name" value="<?=$TFYT_User['name']?>" class="form-control" placeholder="请输入你的称呼">
					</div>
					<div class="form-group">
					<label>Q Q 号：</label>
						<input type="text" name="qq"  value="<?=$TFYT_User['qq']?>" class="form-control" placeholder="请输入你的QQ账号">
					</div>
					<div class="form-group">
					<label>密保问题：</label>
					<select name="syqn" class="form-control m-t">
					<?php if(!$TFYT_User['syqn']){?>
						<option value="">请先选择一个问题</option>
					<?php }else{?>
						<option value="<?=$TFYT_User['syqn']?>">当前：<?=$TFYT_User['syqn']?></option>
					<?php }?>
						<option value="我的名字是？">我的名字是？</option>
						<option value="我最好的朋友是？">我最好的朋友是？</option>
						<option value="我母亲的姓名？">我母亲的姓名？</option>
						<option value="我就读的第一所学校的名称？">我就读的第一所学校的名称？</option>
						<option value="我父亲的姓名？">我父亲的姓名？</option>
						<option value="我父亲的职业？">我父亲的职业？</option>
						<option value="我的出生地是？">我的出生地是？</option>
						<option value="我母亲的职业？">我母亲的职业？</option>
						<option value="我初中班主任的名字是？">我初中班主任的名字是？</option>
						<option value="我最爱的人的名字？">我最爱的人的名字？</option>
						<option value="我们公司总经理的姓名?">我们公司总经理的姓名?</option>
						<option value="我们公司出纳的姓名?">我们公司出纳的姓名?</option>
					</select>
					</div>
					<div class="form-group">
					<label>密保答案：</label>
						<input type="text" name="star" class="form-control" value="<?=$TFYT_User['star']?>" placeholder="不修改请留空">
					</div>
					<div class="form-group">
					<label>新密码：</label>
						<input type="text" name="password" class="form-control" placeholder="不修改请留空">
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>