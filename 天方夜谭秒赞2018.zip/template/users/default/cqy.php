	<section id="content">
	  <section class="vbox">
		<header class="header bg-white b-b b-light">
		  <p>Cqy交友</p>
		</header>
		<section class="scrollable wrapper">              
		  <div class="row">
		  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}qq where 1=1 order by qid desc")){ foreach($rows as $qq){?>
		  <?php 
		  $arr=array('info','success','dark','warning','badge','666');
			shuffle($arr);
			foreach($arr as $values){
			  $nmb=$values;
			}
			?>
			<div class="col-sm-3">
			  <section class="panel panel-<?=$nmb?>">
				<div class="panel-body bg-<?=$nmb?>">
				  <a href="#" class="thumb pull-right m-l m-t-xs avatar">
					<img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$qq[qq]?>&s=100">
					<i class="on md b-white bottom"></i>
				  </a>
				  <div class="clear">
					<a href="#" class="text-info">名称：<?=get_qqnick($qq['qq'])?><i class="icon-twitter"></i></a>
					<small class="block text-muted">Q Q：<?=$qq[qq]?></small>
					<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?=$qq[qq]?>&site=&menu=yes" class="btn btn-xs btn-success m-t-xs">加为好友</a>
				  </div>
				</div>
			  </section>
			</div>
		  <?php }}?>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>