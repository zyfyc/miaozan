	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">功能配置 <?php if($output){?>[提示：<?=$output?>]<?php }?></h3>
		  </div>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  圈圈赞
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="function" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">是否开启</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Quan_state" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Quan_state")?>">当前：<?php if(TFYT_Data("TFYT_Function_Quan_state")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php if(TFYT_Data("TFYT_Function_Quan_state")!=0){?>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">VIP才能使用</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Quan_vip" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Quan_vip")?>">当前：<?php if(TFYT_Data("TFYT_Function_Quan_vip")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php } ?>
				<?php if(TFYT_Data("TFYT_Function_Quan_state")!=0){?>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">圈圈赞接口</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Function_Quan_api" class="form-control rounded" value="<?=TFYT_Data("TFYT_Function_Quan_api")?>" placeholder="请输入圈圈赞接口（不需要加http://）">                        
				  </div>
				</div>
				<?php } ?>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  聊天大厅
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="function" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">是否开启</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Chat_state" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Chat_state")?>">当前：<?php if(TFYT_Data("TFYT_Function_Chat_state")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php if(TFYT_Data("TFYT_Function_Chat_state")!=0){?>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">VIP才能使用</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Chat_vip" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Chat_vip")?>">当前：<?php if(TFYT_Data("TFYT_Function_Chat_vip")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php } ?>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  Cay交友系统
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="function" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">是否开启</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Cqy_state" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Cqy_state")?>">当前：<?php if(TFYT_Data("TFYT_Function_Cqy_state")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php if(TFYT_Data("TFYT_Function_Cqy_state")!=0){?>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">VIP才能使用</label>
				  <div class="col-sm-11">
					<select name="TFYT_Function_Cqy_vip" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_Function_Cqy_vip")?>">当前：<?php if(TFYT_Data("TFYT_Function_Cqy_vip")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<?php } ?>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>