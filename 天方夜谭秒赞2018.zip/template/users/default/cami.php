        <section id="content">
          <section class="vbox">
            <section class="scrollable padder">
              <div class="m-b-md">
                <h3 class="m-b-none">自助充值</h3>
              </div>
              <div class="row">
                <div class="col-sm-6">
				  <section class="panel b-light">
					<header class="panel-heading"><strong><i class="fa fa-bullhorn"></i> 公告</strong></header>
					<div class="panel-body flot-legend">
					  <?=TFYT_Data("TFYT_Notice_Cami")?>
					</div>
				  </section>
                </div>
                <div class="col-sm-6">
                  <form action="?" method="post">
				   <input type="hidden" name="ok" value="km">
                    <section class="panel panel-default">
                      <header class="panel-heading">
                        <span class="h4">卡密充值<?php if($output){?>[提示：<?=$output?>]<?php }?></span>
                      </header>
                      <div class="panel-body">
                        <p class="text-muted">在这里，你可以使用卡密进行充值！</p>                        
                          <div class="form-group">
                            <label>卡密类型</label>
                            <select name="kind" class="form-control m-t">
                                <option>请选择类型</option>
                                <option value="1">激活码</option>
                                <option value="2">充值卡</option>
                            </select>
                          </div>
                          <div class="form-group">
                            <label>卡密</label>
                            <input class="form-control" name="cami" placeholder="请输入卡密">
                          </div>
                      </div>
                      <footer class="panel-footer text-right bg-light lter">
                        <button type="submit" class="btn btn-success btn-s-xs">立即充值</button>
                      </footer>
                    </section>
                  </form>
                </div>
              </div>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
        </section>