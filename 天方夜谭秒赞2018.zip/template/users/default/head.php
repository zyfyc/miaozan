<!DOCTYPE html>
<html lang="en" class="app">
<head>  
  <meta charset="utf-8" />
  <title><?=Title()?> - <?=TFYT_Data("TFYT_Name")?></title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="/ThinkPHP/Users/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/icon.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/font.css" type="text/css" />
  <link rel="stylesheet" href="/ThinkPHP/Users/css/app.css" type="text/css" />  
  <link rel="stylesheet" href="/ThinkPHP/Users/js/calendar/bootstrap_calendar.css" type="text/css" />
  <!--[if lt IE 9]>
    <script src="/ThinkPHP/Users/js/ie/html5shiv.js"></script>
    <script src="/ThinkPHP/Users/js/ie/respond.min.js"></script>
    <script src="/ThinkPHP/Users/js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  <section class="vbox">
    <header class="bg-white header header-md navbar navbar-fixed-top-xs box-shadow">
      <div class="navbar-header aside-md dk">
        <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav">
          <i class="fa fa-bars"></i>
        </a>
        <a href="index.html" class="navbar-brand">
          <img src="/ThinkPHP/Users/images/logo.png" class="m-r-sm" alt="scale">
          <span class="hidden-nav-xs">控制台</span>
        </a>
        <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user">
          <i class="fa fa-cog"></i>
        </a>
      </div>
      <ul class="nav navbar-nav hidden-xs">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="i i-grid"></i>
          </a>
          <section class="dropdown-menu aside-lg bg-white on animated fadeInLeft">
            <div class="row m-l-none m-r-none m-t m-b text-center">
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-mail i-2x text-primary-lt"></i>
                    </span>
                    <small class="text-muted">Mailbox</small>
                  </a>
                </div>
              </div>
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-calendar i-2x text-danger-lt"></i>
                    </span>
                    <small class="text-muted">Calendar</small>
                  </a>
                </div>
              </div>
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-map i-2x text-success-lt"></i>
                    </span>
                    <small class="text-muted">Map</small>
                  </a>
                </div>
              </div>
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-paperplane i-2x text-info-lt"></i>
                    </span>
                    <small class="text-muted">Trainning</small>
                  </a>
                </div>
              </div>
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-images i-2x text-muted"></i>
                    </span>
                    <small class="text-muted">Photos</small>
                  </a>
                </div>
              </div>
              <div class="col-xs-4">
                <div class="padder-v">
                  <a href="#">
                    <span class="m-b-xs block">
                      <i class="i i-clock i-2x text-warning-lter"></i>
                    </span>
                    <small class="text-muted">Timeline</small>
                  </a>
                </div>
              </div>
            </div>
          </section>
        </li>
      </ul>
      <form class="navbar-form navbar-left input-s-lg m-t m-l-n-xs hidden-xs" role="search">
        <div class="form-group">
          <div class="input-group">
            <span class="input-group-btn">
              <button type="submit" class="btn btn-sm bg-white b-white btn-icon"><i class="fa fa-search"></i></button>
            </span>
            <input type="text" class="form-control input-sm no-border" placeholder="Search apps, projects...">            
          </div>
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
        <li class="hidden-xs">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="i i-chat3"></i>
            <span class="badge badge-sm up bg-danger count">2</span>
          </a>
          <section class="dropdown-menu aside-xl animated flipInY">
            <section class="panel bg-white">
              <div class="panel-heading b-light bg-light">
                <strong>You have <span class="count">2</span> notifications</strong>
              </div>
              <div class="list-group list-group-alt">
                <a href="#" class="media list-group-item">
                  <span class="pull-left thumb-sm">
                    <img src="/ThinkPHP/Users/images/a0.png" alt="..." class="img-circle">
                  </span>
                  <span class="media-body block m-b-none">
                    Use awesome animate.css<br>
                    <small class="text-muted">10 minutes ago</small>
                  </span>
                </a>
                <a href="#" class="media list-group-item">
                  <span class="media-body block m-b-none">
                    1.0 initial released<br>
                    <small class="text-muted">1 hour ago</small>
                  </span>
                </a>
              </div>
              <div class="panel-footer text-sm">
                <a href="#" class="pull-right"><i class="fa fa-cog"></i></a>
                <a href="#notes" data-toggle="class:show animated fadeInRight">See all the notifications</a>
              </div>
            </section>
          </section>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <span class="thumb-sm avatar pull-left">
              <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$TFYT_User['qq']){echo'10001';}else{echo''.$TFYT_User['qq'].'';}?>&s=100" alt="QQ:<?php if(!$TFYT_User['qq']){echo'10001';}else{echo''.get_qqnick($TFYT_User['qq']).'';}?>的头像">
            </span>
            <?php if(!$TFYT_User['name']){echo $TFYT_User['user'];}else{echo $TFYT_User['name'];}?> <b class="caret"></b>
          </a>
          <ul class="dropdown-menu animated fadeInRight">            
            <li>
              <span class="arrow top"></span>
              <a href="user.php">个人资料</a>
            </li>
            <li>
              <a href="qq.php">我的挂机</a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="logon.php">安全退出</a>
            </li>
          </ul>
        </li>
      </ul>      
    </header>
    <section>
      <section class="hbox stretch">
        <!-- .aside -->
        <aside class="bg-black aside-md hidden-print" id="nav">          
          <section class="vbox">
            <section class="w-f scrollable">
              <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-railOpacity="0.2">
                <div class="clearfix wrapper dk nav-user hidden-xs">
                  <div class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      <span class="thumb avatar pull-left m-r">                        
                        <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$TFYT_User['qq']){echo'10001';}else{echo''.$TFYT_User['qq'].'';}?>&s=100" class="dker" alt="QQ:<?php if($TFYT_User['qq']==''){echo'10001';}else{echo''.get_qqnick($TFYT_User['qq']).'';}?>的头像">
                        <i class="on md b-black"></i>
                      </span>
                      <span class="hidden-nav-xs clear">
                        <span class="block m-t-xs">
                          <strong class="font-bold text-lt"><?php if(!$TFYT_User['name']){echo '平台新用户';}else{echo $TFYT_User['name'];}?></strong>
                          <b class="caret"></b>
                        </span>
                        <span class="text-muted text-xs block"><?=$TFYT_User['user']?></span>
                      </span>
                    </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                      <li>
                        <span class="arrow top hidden-nav-xs"></span>
                        <a href="user.php">个人资料</a>
                      </li>
                      <li>
                        <a href="qq.php">我的挂机</a>
                      </li>
                      <li class="divider"></li>
                      <li>
                        <a href="logon.php">安全退出</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <!-- nav -->                 
                <nav class="nav-primary hidden-xs">
                  <div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">导航栏</div>
                  <ul class="nav nav-main" data-ride="collapse">
                    <li  class="active">
                      <a href="index.php" class="auto">
                        <i class="i i-screen icon">
                        </i>
                        <span class="font-bold">控制台</span>
                      </a>
                    </li>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="i i-users2 icon"></i>
                        <span class="font-bold">用户中心</span>
                      </a>
                      <ul class="nav dk">
                        <li >
                          <a href="#table" class="auto">                            
                            <span class="pull-right text-muted">
                              <i class="i i-circle-sm-o text"></i>
                              <i class="i i-circle-sm text-active"></i>
                            </span>                            
                            <i class="i i-dot"></i>
                            <span>我的资料</span>
                          </a>
                          <ul class="nav dker">
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>用户 UID：<?=$TFYT_User['uid']?></span>
                              </a>
                            </li>
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>用 户 名：<?=$TFYT_User['user']?></span>
                              </a>
                            </li>
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>登录 I P：<?=$TFYT_User['lastip']?></span>
                              </a>
                            </li>
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>注册 I P：<?=$TFYT_User['regip']?></span>
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li >
                          <a href="#form" class="auto">                            
                            <span class="pull-right text-muted">
                              <i class="i i-circle-sm-o text"></i>
                              <i class="i i-circle-sm text-active"></i>
                            </span>                            
                            <i class="i i-dot"></i>
                            <span>我的财产</span>
                          </a>
                          <ul class="nav dker">
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>账户余额：<?=$TFYT_User['money']?> 元</span>
                              </a>
                            </li>
                            <li >
                              <a href="#">
                                <i class="i i-dot"></i>
                                <span>挂机配额：<?=$TFYT_User['peie']?> 个</span>
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li>
                          <a href="user.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>资料修改</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="i i-slider icon">
                        </i>
                        <span class="font-bold">平台工具</span>
                      </a>
                      <ul class="nav dk">
					  <?php if(TFYT_Data("TFYT_Function_Chat_state")!=0){?>
                        <li >
                          <a href="chat.php" class="auto">
						  <?php if(TFYT_Data("TFYT_Function_Chat_vip")!=0){?>
						   <b class="badge bg-danger pull-right">VIP</b>
						  <?php }?>
                            <i class="i i-dot"></i>
                            <span>聊天大厅</span>
                          </a>
                        </li>
					  <?php } ?>
					  <?php if(TFYT_Data("TFYT_Function_Quan_state")!=0){?>
                        <li >
                          <a href="circle.php" class="auto">
						  <?php if(TFYT_Data("TFYT_Function_Quan_vip")!=0){?>
						   <b class="badge bg-danger pull-right">VIP</b>
						  <?php }?>
                            <i class="i i-dot"></i>
                            <span>圈圈99+</span>
                          </a>
                        </li>
					  <?php } ?>
					  <?php if(TFYT_Data("TFYT_Function_Cqy_state")!=0){?>
                        <li >
                          <a href="cqy.php" class="auto">
						  <?php if(TFYT_Data("TFYT_Function_Cqy_vip")!=0){?>
						   <b class="badge bg-danger pull-right">VIP</b>
						  <?php }?>
                            <i class="i i-dot"></i>
                            <span>Cay交友</span>
                          </a>
                        </li>
					  <?php } ?>
                        <li >
                          <a href="chat.php" class="auto">
						   <b class="badge bg-danger pull-right">VIP</b>
                            <i class="i i-dot"></i>
                            <span>全网报复系统</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="i i-cart icon">
                        </i>
                        <span class="font-bold">自助商城</span>
                      </a>
                      <ul class="nav dk">
                        <li >
                          <a href="cami.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>自助充值</span>
                          </a>
                        </li>
                        <li >
                          <a href="shop.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>自助商城</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="i i-settings icon">
                        </i>
                        <span class="font-bold">挂机管理</span>
                      </a>
                      <ul class="nav dk">
                        <li >
                          <a href="addqq.php" class="auto">                                                                                  
                            <i class="i i-dot"></i>
                            <span>添加挂机</span>
                          </a>
                        </li>
                        <li >
                          <a href="qq.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>挂机管理</span>
                          </a>
                        </li>
                      </ul>
                    </li>
					<?php if(get_isdl($TFYT_User['agent'],$TFYT_User['agentend'])){?>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="i i-docs icon">
                        </i>
                        <span class="font-bold">代理专区</span>
                      </a>
                      <ul class="nav dk">
                        <li >
                          <a href="daili_cami.php" class="auto">                                                                                  
                            <i class="i i-dot"></i>
                            <span>卡密管理</span>
                          </a>
                        </li>
                        <li >
                          <a href="daili_shop.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>商城管理</span>
                          </a>
                        </li>
                      </ul>
                    </li>
					<?php }?>
					<?php if($TFYT_User['uid']==1){?>
                    <li >
                      <a href="#" class="auto">
                        <span class="pull-right text-muted">
                          <i class="i i-circle-sm-o text"></i>
                          <i class="i i-circle-sm text-active"></i>
                        </span>
                        <i class="fa fa-cloud-upload icon"></i>
                        <span class="font-bold">后台管理</span>
                      </a>
                      <ul class="nav dk">
                        <li >
                          <a href="#table" class="auto">                            
                            <span class="pull-right text-muted">
                              <i class="i i-circle-sm-o text"></i>
                              <i class="i i-circle-sm text-active"></i>
                            </span>                            
                            <i class="i i-dot"></i>
                            <span>网站管理</span>
                          </a>
                          <ul class="nav dker">
                            <li >
                              <a href="website_site.php">
                                <i class="i i-dot"></i>
                                <span>网站设置</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_notice.php">
                                <i class="i i-dot"></i>
                                <span>公告管理</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_template.php">
                                <i class="i i-dot"></i>
                                <span>模板更换</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_function.php">
                                <i class="i i-dot"></i>
                                <span>功能设置</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_cron.php">
                                <i class="i i-dot"></i>
                                <span>监控说明</span>
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li >
                          <a href="#form" class="auto">                            
                            <span class="pull-right text-muted">
                              <i class="i i-circle-sm-o text"></i>
                              <i class="i i-circle-sm text-active"></i>
                            </span>                            
                            <i class="i i-dot"></i>
                            <span>商品管理</span>
                          </a>
                          <ul class="nav dker">
                            <li >
                              <a href="website_cami.php">
                                <i class="i i-dot"></i>
                                <span>卡密管理</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_shop.php">
                                <i class="i i-dot"></i>
                                <span>商品管理</span>
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li >
                          <a href="#form" class="auto">                            
                            <span class="pull-right text-muted">
                              <i class="i i-circle-sm-o text"></i>
                              <i class="i i-circle-sm text-active"></i>
                            </span>                            
                            <i class="i i-dot"></i>
                            <span>用户管理</span>
                          </a>
                          <ul class="nav dker">
                            <li >
                              <a href="website_user.php">
                                <i class="i i-dot"></i>
                                <span>用户管理</span>
                              </a>
                            </li>
                            <li >
                              <a href="website_qq.php">
                                <i class="i i-dot"></i>
                                <span>挂机管理</span>
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li>
                          <a href="website_about.php" class="auto">                                                        
                            <i class="i i-dot"></i>
                            <span>关于系统</span>
                          </a>
                        </li>
                      </ul>
                    </li>
					<?php }?>
                  </ul>
                  <div class="line dk hidden-nav-xs"></div>
                  <div class="text-muted text-xs hidden-nav-xs padder m-t-sm m-b-sm">系统统计</div>
                  <ul class="nav">
                    <li>
                      <a href="#">
                        <i class="i i-circle-sm text-success-dk"></i>
                        <span>平台用户：<?=get_count('user','uid')?> 个</span>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="i i-circle-sm text-danger-dk"></i>
                        <span>平台挂机：<?=get_count('qq','qid')?> 个</span>
                      </a>
                    </li>
                  </ul>
                </nav>
                <!-- / nav -->
              </div>
            </section>
            <footer class="footer hidden-xs no-padder text-center-nav-xs">
              <a href="modal.lockme.html" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs">
                <i class="i i-logout"></i>
              </a>
              <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs">
                <i class="i i-circleleft text"></i>
                <i class="i i-circleright text-active"></i>
              </a>
            </footer>
          </section>
        </aside>
        <!-- /.aside -->