	<section id="content">
	  <section class="vbox">
		<header class="header bg-white b-b b-light">
		  <p>自助商城 <?php if($output){?>[提示：<?=$output?>]<?php } ?></p>
		</header>
		<section class="scrollable wrapper">
		<?=$index?>
		  <div class="row">
		  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}vip where 1=1 order by id desc")){ foreach($rows as $vip){?>
			<?php
			if($vip['styles']=='day'){
				$mus='天';
			}else if($vip['styles']=='week'){
				$mus='周';
			}else if($vip['styles']=='month'){
				$mus='个月';
			}else if($vip['styles']=='year'){
				$mus='年';
			}
			?>
			<div class="col-sm-3">
			  <section class="panel panel-info bg-<?=$vip['colour']?>">
				<div class="panel-body">
				  <a href="#" class="thumb pull-right m-l m-t-xs avatar">
					<img src="/ThinkPHP/Users/images/a4.png">
					<i class="on md b-white bottom"></i>
				  </a>
				  <div class="clear">
					<a href="#" class="text-info"><?=$vip['datas']?> <?=$mus?>VIP <i class="icon-twitter"></i></a>
					<small class="block text-muted">库存：<?=$vip['stock']?> / 价格：<?=$vip['price']?> 元</small>
					<a href="?vip=buy&id=<?=$vip['id']?>&datas=<?=$vip['datas']?>&price=<?=$vip['price']?>&stock=<?=$vip['stock']?>&styles=<?=$vip['styles']?>" class="btn btn-xs btn-danger m-t-xs">立即购买</a>
				  </div>
				</div>
			  </section>
			</div>
		  <?php }}?>
		  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}peie where 1=1 order by id desc")){ foreach($rows as $peie){?>
			<div class="col-sm-3">
			  <section class="panel panel-info bg-<?=$peie['colour']?>">
				<div class="panel-body">
				  <a href="#" class="thumb pull-right m-l m-t-xs avatar">
					<img src="/ThinkPHP/Users/images/a4.png">
					<i class="on md b-white bottom"></i>
				  </a>
				  <div class="clear">
					<a href="#" class="text-info"><?=$peie['nums']?> 个配额 <i class="icon-twitter"></i></a>
					<small class="block text-muted">库存：<?=$peie['stock']?> / 价格：<?=$peie['price']?> 元</small>
					<a href="?peie=buy&id=<?=$peie['id']?>&nums=<?=$peie['nums']?>&price=<?=$peie['price']?>&stock=<?=$peie['stock']?>" class="btn btn-xs btn-danger m-t-xs">立即购买</a>
				  </div>
				</div>
			  </section>
			</div>
		  <?php }}?>
		  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}daili where 1=1 order by id desc")){ foreach($rows as $daili){?>
			<?php
			if($daili['styles']=='day'){
				$mus='天';
			}else if($daili['styles']=='week'){
				$mus='周';
			}else if($daili['styles']=='month'){
				$mus='个月';
			}else if($daili['styles']=='year'){
				$mus='年';
			}
			?>
			<div class="col-sm-3">
			  <section class="panel panel-info bg-<?=$daili['colour']?>">
				<div class="panel-body">
				  <a href="#" class="thumb pull-right m-l m-t-xs avatar">
					<img src="/ThinkPHP/Users/images/a4.png">
					<i class="on md b-white bottom"></i>
				  </a>
				  <div class="clear">
					<a href="#" class="text-info"><?=$daili['datas']?> <?=$mus?>代理 <i class="icon-twitter"></i></a>
					<small class="block text-muted">库存：<?=$daili['stock']?> / 价格：<?=$daili['price']?> 元</small>
					<a href="?daili=buy&id=<?=$daili['id']?>&datas=<?=$daili['datas']?>&price=<?=$daili['price']?>&stock=<?=$daili['stock']?>&styles=<?=$daili['styles']?>" class="btn btn-xs btn-danger m-t-xs">立即购买</a>
				  </div>
				</div>
			  </section>
			</div>
		  <?php }}?>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>