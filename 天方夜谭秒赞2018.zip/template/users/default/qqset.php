	<section id="content">
	  <section class="vbox">
		<section class="scrollable wrapper">              
		  <div class="row">
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-dark">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <div class="easypiechart" data-percent="75" data-line-width="5" data-bar-color="rgba(255, 255, 255, 0)" data-track-Color="rgba(255, 255, 255, 0)" data-scale-Color="false" data-size="134" data-line-cap='butt' data-animate="1000">
						<div class="thumb-lg">
						  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$qqset['qq']?>&s=160" class="img-circle">
						</div>
					  </div>
					  <div class="h4 m-t m-b-xs"><?=get_qqnick($qqset['qq'])?></div>
					  <small class="text-muted m-b"><?=$qqset['qq']?></small>
					</div>                      
				  </div>
				</div>
				<div class="list-group no-radius alt">
				  <li class="list-group-item">
					<span class="pull-right"><?php if($qqset['sidzt']){echo'<span class="text-danger" aria-hidden="true">&nbsp;[异常]</span>';}else{echo'<span class="text-success" aria-hidden="true">&nbsp;[正常]</span>';}?></span>
					S I D 状态：
				  </li>
				  <li class="list-group-item">
					<span class="pull-right"><?php if($qqset['skeyzt']){echo'<span class="text-danger" aria-hidden="true">&nbsp;[异常]</span>';}else{echo'<span class="text-success" aria-hidden="true">&nbsp;[正常]</span>';}?></span>
					SKEY状态：
				  </li>
				  <li class="list-group-item">
					<span class="pull-right"><span class="text-success" aria-hidden="true">&nbsp;[正常]</span></span>
					T S 引  擎：
				  </li>
				  <li class="list-group-item">
					<span class="pull-right"><span class="text-success" aria-hidden="true">&nbsp;[正常]</span></span>
					G T K协议：
				  </li>
				</div>
			  </section>
			  <section>
			  <div id="collapseTwo" class="panel-collapse collapse">
			  <a class="list-group-item" href="?del=qq&qid=<?=$qqset['qid']?>">
				<span class="badge bg-danger">点击删除</span>
				<i class="fa fa-archive icon-muted"></i> 
				删除挂机
			  </a>
			  <a class="list-group-item" href="#">
				<span class="badge bg-danger">点击认证</span>
				<i class="fa fa-user icon-muted"></i> 
				秒赞认证
			  </a>
			  </div>
			  <div class="m-b-sm">
				<div class="btn-group btn-group-justified">
				  <a data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo" class="btn btn-success">更多操作</a>
				</div>
			  </div>
			  </section>
			</div>
			<div class="col-lg-8">
			  <section class="panel panel-default">
				<header class="panel-heading bg-light">
				  <ul class="nav nav-tabs pull-right">
					<li class="active"><a href="#messages-1" data-toggle="tab"><i class="fa fa-star text-muted"></i> 功能工具</a></li>
					<li><a href="#profile-1" data-toggle="tab"><i class="fa fa-user text-muted"></i> 其他工具</a></li>
				  </ul>
				  <span class="hidden-sm">功能配置</span>
				</header>
				<div class="panel-body">
				  <div class="tab-content">              
					<div class="tab-pane active" id="messages-1">
					  <article class="media">
						<span class="pull-left thumb-sm"><i class="fa fa-thumbs-up fa-3x icon-muted text-dark"></i></span>
						<div class="media-body">
						  <div class="pull-right media-xs text-center text-muted">
							<a href="#modal" data-toggle="modal" class="btn btn-s-md btn-danger btn-rounded"><?=getzt($qqset[iszan])?></a>
						  </div>
						  <a href="#" class="h4 text-success">空间秒赞</a>
						  <small class="block"><a class="text-danger">运行时间：<?=zhtime($qqset['lastzan'])?></a></small>
						</div>
					  </article>
					</div>
					<div class="tab-pane" id="profile-1">
					  <article class="media">
						<span class="pull-left thumb-sm"><i class="fa fa-ticket fa-3x icon-muted text-dark"></i></span>
						<div class="media-body">
						  <div class="pull-right media-xs text-center text-muted">
							<a href="#" class="btn btn-s-md btn-danger btn-rounded">点击关闭</a>
						  </div>
						  <a href="#" class="h4 text-success">互赞名片</a>
						  <small class="block"><a href="#" class="text-danger">运行时间：<?=date('Y-m-d h:i:s',time());?></a></small>
						</div>
					  </article>
					</div>
				  </div>
				</div>
			  </section>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	  
		<div class="modal fade" id="modal">
		<div class="modal-dialog">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			  <h4 class="modal-title">QQ空间秒赞功能配置</h4>
			</div>
			<div class="list-group-item red">
			   <p><font color="red">若出现重复赞或不能赞,请及时更换协议</font></p>
			   <p>服务器速度越快漏赞越少,速度慢的在你好友越多时漏赞也越多。</p>
			</div>
			<div class="modal-body">
			 <form onsubmit="?" method="post">
			   <input type="hidden" name="ok" value="zan">
				<div class="form-group">
				  <label>秒赞协议</label>
				  <select name="is" class="form-control">
				    <option value="0" selected="">关闭</option>
					<option value="1" <?php if($qqset['iszan']==1) echo 'selected=""';?>>触屏版</option>
					<option value="2" <?php if($qqset['iszan']==2) echo 'selected=""';?>>电脑版(推荐)</option>
				  </select>
				</div>
				<div class="form-group">
				  <label>频率</label>
				  <select name="rate" class="form-control">
				    <option value ="60" <?php if($qqset[zanrate]==60) echo "selected='selected'";?>>1分钟</option>
					<option value ="120" <?php if($qqset[zanrate]==120) echo "selected='selected'";?>>2分钟</option>
					<option value ="180" <?php if($qqset[zanrate]==180) echo "selected='selected'";?>>3分钟</option>
					<option value ="240" <?php if($qqset[zanrate]==240) echo "selected='selected'";?>>4分钟</option>
					<option value ="300" <?php if($qqset[zanrate]==300) echo "selected='selected'";?>>5分钟</option>
					<option value ="360" <?php if($qqset[zanrate]==360) echo "selected='selected'";?>>6分钟</option>
					<option value ="420" <?php if($qqset[zanrate]==420) echo "selected='selected'";?>>7分钟</option>
					<option value ="480" <?php if($qqset[zanrate]==480) echo "selected='selected'";?>>8分钟</option>
					<option value ="540" <?php if($qqset[zanrate]==540) echo "selected='selected'";?>>9分钟</option>
					<option value ="600" <?php if($qqset[zanrate]==600) echo "selected='selected'";?>>10分钟</option>
					<option value ="660" <?php if($qqset[zanrate]==660) echo "selected='selected'";?>>11分钟</option>
					<option value ="720" <?php if($qqset[zanrate]==720) echo "selected='selected'";?>>12分钟</option>
					<option value ="780" <?php if($qqset[zanrate]==780) echo "selected='selected'";?>>13分钟</option>
					<option value ="840" <?php if($qqset[zanrate]==840) echo "selected='selected'";?>>14分钟</option>
					<option value ="900" <?php if($qqset[zanrate]==900) echo "selected='selected'";?>>15分钟</option>
				  </select>
				</div>
				<div class="form-group">
				  <label>频率</label>
				  <select name="net" class="form-control">
				    <?php
					$str="";
					for($i=1;$i<=TFYT_Data('TFYT_Server_Mz');$i++){
						$str.="<option value ='{$i}' ";
						if($qqset['zannet'] == $i){
							$str.="selected='selected'";
						}
						$str.=">{$i}号免费服务器(";
						$num=get_count('qq',"zannet='$i'",'qid');
						if($num>=TFYT_Data('TFYT_Server')){
							$str.="已满";
						}else{
							$str.="{$num}个";
						}
						$str.=")</option>";
					}
					echo $str;
					$str="";
					for($i=1;$i<=2;$i++){
						$str.="<option value ='".(TFYT_Data('TFYT_Server_Mz')+$i)."' ";
						if($qqset['zannet'] == (TFYT_Data('TFYT_Server_Mz')+$i)){
							$str.="selected='selected'";
						}
						$str.=">".(TFYT_Data('zannet')+$i)."号VIP极速服务器(";
						$num=get_count('qq',"zannet='".(TFYT_Data('zannet')+$i)."'",'qid');
						if($num>=TFYT_Data('TFYT_Server')){
							$str.="已满";
						}else{
							$str.="{$num}个";
						}
						$str.=")</option>";
					}
					echo $str;
				    ?>
				  </select>
				</div>
				<hr/>
				<div class="form-group">
					<input type="submit" name="submit" value="保存配置" class="btn btn-primary btn-block">
				</div>
			 </form>
			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">关闭</button>
			</div>
		  </div>
		</div>
	  </div>
    </section>