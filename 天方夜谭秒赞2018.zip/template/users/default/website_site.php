	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">网站设置 <?php if($output){?>[提示：<?=$output?>]<?php }?></h3>
		  </div>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  网站设置
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="site" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">网站名称</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Name" value="<?=TFYT_Data("TFYT_Name")?>" placeholder="请输入网站名称" class="form-control rounded">                        
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">网站域名</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Domain" value="<?=TFYT_Data("TFYT_Domain")?>" placeholder="请输入网站域名（不要加 http://）" class="form-control rounded">                        
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">网站关键字</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Keywords" value="<?=TFYT_Data("TFYT_Keywords")?>" placeholder="请输入网站搜索关键字（多个请用 ，隔开）" class="form-control rounded">                        
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">网站描述</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Description" value="<?=TFYT_Data("TFYT_Description")?>" placeholder="请输入网站描述" class="form-control rounded">                        
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">网站交流群</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Group" value="<?=TFYT_Data("TFYT_Group")?>" placeholder="请输入网站交流群" class="form-control rounded">                        
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">底部版本</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Foot" value="<?=TFYT_Data("TFYT_Foot")?>" placeholder="请输入网站底部版权" class="form-control rounded">                        
				  </div>
				</div>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  其他设置
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="site" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">用户激活</label>
				  <div class="col-sm-11">
					<select name="TFYT_User_Activate" class="form-control rounded">
						<option value="<?=TFYT_Data("TFYT_User_Activate")?>">当前：<?php if(TFYT_Data("TFYT_User_Activate")!=0){echo '开启';}else{echo '关闭';}?></option>
						<option value="0">关闭</option>
						<option value="1">开启</option>
					</select>
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">注册配额</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Reg_Peie" value="<?=TFYT_Data("TFYT_Reg_Peie")?>" placeholder="请输入用户注册送多少个配额" class="form-control rounded">
				  </div>
				</div>
				<div class="line line-dashed b-b line-lg pull-in"></div>
				<div class="form-group">
				  <label class="col-sm-1 control-label">注册余额</label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Reg_Money" value="<?=TFYT_Data("TFYT_Reg_Money")?>" placeholder="请输入用户注册送多少个余额" class="form-control rounded">
				  </div>
				</div>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  背景图片更换
			</header>
			<div class="panel-body">
			<p class="text-muted">输入背景图片链接地址后点击保存即可！</p>
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="site" value="update">
			   <?php for ($x=1; $x<=TFYT_Data("TFYT_Template_Tnum"); $x++) { ?>
				<div class="form-group">
				  <label class="col-sm-1 control-label">背景图片<?=$x?></label>
				  <div class="col-sm-11">
					<input type="text" name="TFYT_Template_Img<?=$x?>" placeholder="请输入背景图片<?=$x?>的链接地址" class="form-control rounded">
				  </div>
				</div>
				<?php } ?>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>