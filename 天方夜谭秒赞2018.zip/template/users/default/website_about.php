	<section id="content">
	  <section class="vbox">
        <header class="header bg-white b-b b-light">
          <p><strong>关于系统</strong></p>
        </header>
        <section class="scrollable wrapper">
          <div class="row">
            <div class="col-sm-6">
              <section class="panel panel-info portlet-item">
                <header class="panel-heading">
                  关于系统
                </header>
                <div class="list-group bg-white">
                  <a href="#" class="list-group-item">
                    <span class="text-danger">网站名称：</span><?=TFYT_Data("TFYT_Name")?>
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">网站域名：</span><?=TFYT_Data("TFYT_Domain")?>
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">系统版本：</span> V1.0 2018
                  </a>
                </div>
              </section>
              <section class="panel panel-info portlet-item">
                <header class="panel-heading">
                  关于天方
                </header>
                <div class="list-group bg-white">
                  <a href="#" class="list-group-item">
                    <span class="text-danger">程序名称：</span>天方夜谭秒赞
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">交 流 群：</span>614484460
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">程序作者：</span>Forever
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">作者 Q Q：</span>17404785
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="text-danger">最新版本：</span>V 1.0 2018
                  </a>
                </div>
              </section>
            </div>
          </div>
        </section>
      </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>