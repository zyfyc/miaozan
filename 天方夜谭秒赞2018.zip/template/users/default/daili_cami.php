        <section id="content">
          <section class="vbox">
            <section class="scrollable padder">
			  <section class="row m-b-md">
				<div class="col-sm-6">
				  <h3 class="m-b-xs text-black">卡密管理</h3>
				  <?php if($output){ ?><small>提示：<?=$output?></small><?php } ?>
				</div>
				<div class="col-sm-6 text-right text-left-xs m-t-md">
				  <div class="btn-group">
					<a class="btn btn-rounded btn-default b-2x dropdown-toggle" data-toggle="dropdown">选择 <span class="caret"></span></a>
					<ul class="dropdown-menu text-left pull-right">
					  <li><a href="?index=jhm">查看激活码</a></li>
					  <li><a href="?index=czk">查看充值卡</a></li>
					  <li><a href="?delll=km">清空全部卡密</a></li>
					  <li><a href="?dell=km">删除已用卡密</a></li>
					</ul>
				  </div>
				</div>
			  </section>
              <div class="row">
                <div class="col-sm-4">
                  <form action="?" method="post">
				   <input type="hidden" name="add" value="km">
                    <section class="panel panel-default">
                      <header class="panel-heading">
                        <span class="h4">添加卡密</span>
                      </header>
                      <div class="panel-body">
                        <p class="text-muted">在这里，你可以成生充值卡或激活码</p>
                        <div class="form-group">
                          <label>选择类型</label>
                          <select name="kind" class="form-control">
							<option>请选择类型</option>
							<option value="1">激活码</option>
							<option value="2">充值卡</option>
                          </select>
                        </div>
                       <div class="form-group">
                          <label>生成个数</label>
                          <input type="text" class="form-control" name="number" placeholder="请输入要生成的个数">
                        </div>
                        <div class="form-group">
                          <label>卡密余额</label>
                          <input type="text" class="form-control" name="money" placeholder="请输入卡密的余额">
                        </div>
                      </div>
                      <footer class="panel-footer text-right bg-light lter">
                        <button type="submit" class="btn btn-success btn-s-xs">点击生成</button>
                      </footer>
                    </section>
                  </form>
				  <?php if($index=='jhm'){?>
                  <div class="text-center">
                    <ul class="pagination pagination-lg">
					<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1&do=km">首页</a></li>
					<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>&do=km">&laquo;</a></li>
					<?php for($i=$p;$i<=$pp;$i++){?>
					<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>&do=km"><?=$i?></a></li>
					<?php }?>
					<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>&do=km">&raquo;</a></li>
					<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>&do=km">末页</a></li>
                    </ul>
                  </div>
				  <?php }else if($index=='czk'){?>
                  <div class="text-center">
                    <ul class="pagination pagination-lg">
					<li <?php if($p==1){echo'class="disabled"';}?>><a href="?index=2&p=1&do=km">首页</a></li>
					<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?index=2&p=<?=$prev?>&do=km">&laquo;</a></li>
					<?php for($i=$p;$i<=$pp;$i++){?>
					<li <?php if($i==$p){echo'class="active"';}?>><a href="?index=2&p=<?=$i?>&do=km"><?=$i?></a></li>
					<?php }?>
					<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?index=2&p=<?=$next?>&do=km">&raquo;</a></li>
					<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?index=2&p=<?=$pages?>&do=km">末页</a></li>
                    </ul>
                  </div>
				  <?php } ?>
                </div>
                <div class="col-sm-8">
                  <form data-validate="parsley">
                    <section class="panel panel-default">
					<?php if($index=='jhm'){ ?>
						<div class="table-responsive">
						  <table class="table table-striped b-t b-light">
							<thead>
							  <tr>
								<th>I D</th>
								<th>类型</th>
								<th>生成者</th>
								<th>卡密</th>
								<th>余额</th>
								<th>生成时间</th>
								<th>状态</th>
								<th>使用时间</th>
								<th>操作</th>
							  </tr>
							</thead>
							<tbody>
							<?php if($rows){foreach($rows as $km){?>
							<?php if($km['kind']==1){?>
							  <tr>
								<td><?=$km['id']?></td>
								<td><?php if($km['kind']==1){echo'激活码';}else if($km['kind']==2){echo'充值卡';}?></td>
								<td><?=$km['user']?></td>
								<td><?=$km['cami']?></td>
								<td><?=$km['money']?></td>
								<td><?=$km['addtime']?></td>
								<td><?php if($km['isuse']==1){echo '已被使用';}else{echo '未使用';}?></td>
								<td><?=$km['usetime']?></td>
								<td><a href="?del=km&id=<?=$km['id']?>">删除</a></td>
							  </tr>
							<?php }?>
							<?php } } ?>
							</tbody>
						  </table>
						</div>
					<?php }else if($index=='km'){ ?>
						<div class="table-responsive">
						  <table class="table table-striped b-t b-light">
							<thead>
							  <tr>
								<th>卡密</th>
							  </tr>
							</thead>
							<tbody>
								<?=$km?>
							</tbody>
						  </table>
						</div>
					<?php }else if($index=='czk'){ ?>
						<div class="table-responsive">
						  <table class="table table-striped b-t b-light">
							<thead>
							  <tr>
								<th>I D</th>
								<th>类型</th>
								<th>生成者</th>
								<th>卡密</th>
								<th>余额</th>
								<th>生成时间</th>
								<th>状态</th>
								<th>使用时间</th>
								<th>操作</th>
							  </tr>
							</thead>
							<tbody>
							<?php if($rows){foreach($rows as $km){?>
							<?php if($km['kind']==2){?>
							  <tr>
								<td><?=$km['id']?></td>
								<td><?php if($km['kind']==1){echo'激活码';}else if($km['kind']==2){echo'充值卡';}?></td>
								<td><?=$km['user']?></td>
								<td><?=$km['cami']?></td>
								<td><?=$km['money']?></td>
								<td><?=$km['addtime']?></td>
								<td><?php if($km['isuse']==1){echo '已被使用';}else{echo '未使用';}?></td>
								<td><?=$km['usetime']?></td>
								<td><a href="?index=czk&del=km&id=<?=$km['id']?>">删除</a></td>
							  </tr>
							<?php }?>
							<?php } } ?>
							</tbody>
						  </table>
						</div>
					<?php } ?>
                    </section>
                  </form>
                </div>
              </div>
            </section>
          </section>
          <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
        </section>