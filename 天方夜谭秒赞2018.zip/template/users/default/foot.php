    </section>
  </section>
  <script src="/ThinkPHP/Users/js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="/ThinkPHP/Users/js/bootstrap.js"></script>
  <!-- App -->
  <script src="/ThinkPHP/Users/js/app.js"></script>  
  <script src="/ThinkPHP/Users/js/slimscroll/jquery.slimscroll.min.js"></script>
  <script src="/ThinkPHP/Users/js/charts/easypiechart/jquery.easy-pie-chart.js"></script>
  <script src="/ThinkPHP/Users/js/charts/sparkline/jquery.sparkline.min.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.min.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.tooltip.min.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.spline.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.pie.min.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.resize.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/jquery.flot.grow.js"></script>
  <script src="/ThinkPHP/Users/js/charts/flot/demo.js"></script>
  <script src="/ThinkPHP/Users/js/calendar/bootstrap_calendar.js"></script>
  <script src="/ThinkPHP/Users/js/calendar/demo.js"></script>
  <script src="/ThinkPHP/Users/js/sortable/jquery.sortable.js"></script>
  <script src="/ThinkPHP/Users/js/app.plugin.js"></script>
</body>
</html>