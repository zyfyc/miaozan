	<section id="content">
	  <section class="vbox">
		<header class="header bg-white b-b b-light">
		  <p>挂机管理 <small>（共：<?=get_count('qq','uid='.$TFYT_User['uid'].'')?> 个）</small></p>
		</header>
		<section class="scrollable wrapper">              
		  <div class="row">
		  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}qq where uid={$TFYT_User['uid']} order by qid desc")){ foreach($rows as $qq){?>
			<div class="col-sm-4">
			  <section class="panel panel-info">
				<header class="panel-heading bg-light no-border">
				  <div class="clearfix">
					<a href="#" class="pull-left thumb-md avatar b-3x m-r">
					  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$qq['qq']?>&s=100">
					</a>
					<div class="clear">
					  <div class="h3 m-t-xs m-b-xs">
						<?=get_qqnick($qq['qq'])?>
						<i class="fa fa-circle text-success pull-right text-xs m-t-sm"></i>
					  </div>
					  <small class="text-muted"><?=$qq['qq']?> [<a href="qqset.php?qid=<?=$qq[qid]?>">点击管理</a>]</small>
					</div>
				  </div>
				</header>
				<div class="list-group no-radius alt">
				  <a class="list-group-item" href="#">
					<span class="badge bg-<?php if($qq['sidzt']){echo'danger';}else{echo'success';}?>"><?php if($qq['sidzt']){echo'异常';}else{echo'正常';}?></span>
					<i class="fa fa-check-square-o icon-muted"></i> 
					SID状态
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-<?php if($qq['skeyzt']){echo'danger';}else{echo'success';}?>"><?php if($qq['skeyzt']){echo'异常';}else{echo'正常';}?></span>
					<i class="fa fa-check-square-o icon-muted"></i> 
					SKEY状态
				  </a>
				</div>
				<div class="btn-group btn-group-justified">
				  <a class="list-group-item" href="#">
					<i class="fa fa-calendar-o icon-muted"></i> 
					添加时间：<?=$qq['addtime']?>
				  </a>
				</div>
			  </section>
			</div>
		  <?php }}?>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>