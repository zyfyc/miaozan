	<section id="content">
	  <section class="vbox">
		<section class="scrollable wrapper">
		  <div class="row">
			<div class="col-lg-4">
              <section class="panel panel-info portlet-item">
                <header class="panel-heading">
                  提示：[<?=$output?>]
                </header>
                <div class="list-group bg-white">
                  <a href="#" class="list-group-item">
                    这此聊天需要注意到以下几点
                  </a>
                  <a href="#" class="list-group-item">
                    1.不使用真实姓名身份,不轻率与陌生人见面
                  </a>
                  <a href="#" class="list-group-item">
                    2.不向人泄露个人信息,不要轻信网友的故事
                  </a>
                  <a href="#" class="list-group-item">
                    3.不要与网友有财产往来,不随意加陌生人好友
                  </a>
                  <a href="#" class="list-group-item">
                    当前聊天共：<?=get_count('chats',"id")?> 条消息。
                  </a>
                </div>
              </section>
			</div>
			<div class="col-lg-8">
			  <section class="panel panel-default">
				<header class="panel-heading">                    
				  <span class="label bg-dark">聊天窗口</span>
				</header>
				<section class="panel-body slim-scroll" data-height="500" data-size="10px">
				<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}chats where 1=1 order by id desc")){ foreach($rows as $chat){?>
				  <?php if($TFYT_User['uid']!=$chat['uid']){?>
				  <article id="chat-id-1" class="chat-item left">
					<a href="#" class="pull-left thumb-sm avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$chat['qqs']?>&s=100"></a>
					<section class="chat-body">
					  <div class="panel b-light text-sm m-b-none">
						<div class="panel-body">
						  <span class="arrow left"></span>
						  <p class="m-b-none"><?=$chat['con']?></p>
						</div>
					  </div>
					  <small class="text-muted"><i class="fa fa-ok text-success"></i><?=$chat['addtime']?></small>
					</section>
				  </article>
				  <?php }?>
				  <?php if($TFYT_User['uid']==$chat['uid']){?>
				  <article id="chat-id-1" class="chat-item right">
					<a href="#" class="pull-right thumb-sm avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$chat['qqs']?>&s=100" class="img-circle"></a>
					<section class="chat-body">                      
					  <div class="panel bg-light text-sm m-b-none">
						<div class="panel-body">
						  <span class="arrow right"></span>
						  <p class="m-b-none"><?=$chat['con']?></p>
						</div>
					  </div>
					  <small class="text-muted"><?=$chat['addtime']?></small>
					</section>
				  </article>
				  <?php }?>
				<?php }}?>
				</section>
				<footer class="panel-footer">
				  <!-- chat form -->
				  <article class="chat-item" id="chat-form">
					<a class="pull-left thumb-sm avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$TFYT_User['qq']?>&s=100" class="img-circle"></a>
					<section class="chat-body">
					  <form action="?" method="post" class="m-b-none">
					   <input type="hidden" name="ok" value="chat">
					   <input type="hidden" name="img" value="<?=$TFYT_User['qq']?>">
						<div class="input-group">
						  <input type="text" class="form-control" name="con" placeholder="说点什么吧....">
						  <span class="input-group-btn">
							<button class="btn btn-default" type="submit">发送</button>
						  </span>
						</div>
					  </form>
					</section>
				  </article>
				</footer>
			  </section>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>