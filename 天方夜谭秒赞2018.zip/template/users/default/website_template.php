	<section id="content">
	  <section class="vbox">
		<header class="header bg-light lt b-b b-light">
		  <p class="h4 font-thin pull-left m-r m-b-sm">模板更换</p>
		  <a class="btn btn-sm btn-info btn-rounded"><i class="i i-cloud-upload"></i> 下载更多</a>
		</header>
		<section class="scrollable wrapper">
		  <div class="row">
			<div class="col-md-12">
			  <div class="row row-sm">
			  <?php if($rows=$db->get_results("select * from {$TFYT_Mysql}template where 1=1 order by id desc")){ foreach($rows as $Template){?>
				<div class="col-xs-6 col-sm-4 col-md-3">
				  <div class="thumbnail">
					<a href="?update=template&tnum=<?=$Template['tnum']?>&template=<?=$Template['template']?>&home=<?=$Template['home']?>&login=<?=$Template['login']?>&enroll=<?=$Template['enroll']?>&back=<?=$Template['back']?>&user=<?=$Template['user']?>">
						<img src="<?=$Template['img']?>" alt="第<?=$Template['template']?>套模板">
					</a>
					<div class="caption">
					  <p class="text-ellipsis m-b-none"><?=$Template['name']?><?php if($Template['template']==TFYT_Data("TFYT_Template")){echo'[<font color="#179877">已设置</font>]';}else{echo'[<font color="red">未设置</font>]';}?></p>
					</div>
				  </div>
				</div>
			  <?php }}?>
			  </div>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>