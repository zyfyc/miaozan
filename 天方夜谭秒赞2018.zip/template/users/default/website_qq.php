	<section id="content">
	  <section class="vbox">
		<header class="header bg-light lt b-b b-light">
		  <p class="h4 font-thin pull-left m-r m-b-sm">挂机管理</p>
		  <a class="btn btn-sm btn-info btn-rounded"><i class="i i-user2"></i> 共；<?=get_count('qq','qid')?> 个</a>
		  <form action="?" method="GET" class="m-t-sm pull-right pull-none-xs input-s-lg m-b-sm">
		   <input type="hidden" name="do" value="search">
			<div class="input-group">
			<input type="text" name='s' class="input-sm form-control" placeholder="qid、QQ号">
			<span class="input-group-btn">
			  <button class="btn btn-sm btn-default" type="submit">Go!</button>
			</span>
			</div>
		  </form>
		</header>
		<section class="scrollable wrapper">
		  <div class="row">
		  <?php if($qq){foreach($qq as $qq){?>
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-dark">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <div class="easypiechart" data-percent="80" data-line-width="5" data-bar-color="#1aae88" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="139" data-line-cap='butt' data-animate="1000">
						<div class="thumb-lg">
						  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$qq['qq']){echo'10001';}else{echo''.$qq['qq'].'';}?>&s=160" class="img-circle">
						</div>
					  </div>
					  <div class="h4 m-t m-b-xs"><?=get_qqnick($qq['qq'])?></div>
					  <small class="text-muted m-b"><?=$qq['qq']?>（Qid：<?=$qq['qid']?>）</small>
					</div>                      
				  </div>
				</div>
				<div class="list-group no-radius alt">
				  <a class="list-group-item" href="#">
					<span class="badge bg-dark">用户</span>
					<?php $user=$db->get_row("select * from {$TFYT_Mysql}user where uid='".$qq['uid']."' limit 1"); echo $user['user']; ?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-<?php if($qq['sidzt']){echo'danger';}else{echo'success';}?>"><?php if($qq['sidzt']){echo'异常';}else{echo'正常';}?></span>
					<i class="fa fa-comment icon-muted"></i> 
					SID状态
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-<?php if($qq['skeyzt']){echo'danger';}else{echo'success';}?>"><?php if($qq['skeyzt']){echo'异常';}else{echo'正常';}?></span>
					<i class="fa fa-envelope icon-muted"></i> 
					SKEY状态
				  </a>
				</div>
				<div class="btn-group btn-group-justified">
				  <a href="?del=qq&qid=<?=$qq['qid']?>" class="btn btn-danger">点击删除</a>
				</div>
			  </section>
			</div>
			<?php }}?>
		  </div>
		  <?php if($pagedo!='seach'){?>
		  <div class="text-center">
			<ul class="pagination pagination">
			<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1">首页</a></li>
			<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>">&laquo;</a></li>
			<?php for($i=$p;$i<=$pp;$i++){?>
			<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
			<?php }?>
			<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>">&raquo;</a></li>
			<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>">末页</a></li>
			</ul>
		  </div>
		  <?php }?>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>