<?php if($index=="user"){?>
	<section id="content">
	  <section class="vbox">
		<header class="header bg-light lt b-b b-light">
		  <p class="h4 font-thin pull-left m-r m-b-sm">用户管理</p>
		  <a class="btn btn-sm btn-info btn-rounded"><i class="i i-user2"></i> 共；<?=get_count('user','uid')?> 个</a>
		  <form action="?" method="GET" class="m-t-sm pull-right pull-none-xs input-s-lg m-b-sm">
		   <input type="hidden" name="do" value="search">
			<div class="input-group">
			<input type="text" name='s' class="input-sm form-control" placeholder="用户uid、用户名">
			<span class="input-group-btn">
			  <button class="btn btn-sm btn-default" type="submit">Go!</button>
			</span>
			</div>
		  </form>
		</header>
		<section class="scrollable wrapper">
		  <div class="row">
		  <?php if($rows){foreach($rows as $TFYT_Usera){?>
<?php
/**
 * 计算VIP
 */
$vip_1 = date("Y-m-d");
$vip_2 = $TFYT_Usera['vipend'];
$data_1 = strtotime($vip_1);
$data_2 = strtotime($vip_2);
$outvips = round(($data_2-$data_1)/3600/24);

/**
 * 计算代理
 */
$dl_1 = date("Y-m-d");
$dl_2 = $TFYT_Usera['agentend'];
$data_1 = strtotime($dl_1);
$data_2 = strtotime($dl_2);
$outdls = round(($data_2-$data_1)/3600/24);
?>
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-dark">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <div class="easypiechart" data-percent="80" data-line-width="5" data-bar-color="#1aae88" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="139" data-line-cap='butt' data-animate="1000">
						<div class="thumb-lg">
						  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$TFYT_Usera['qq']){echo'10001';}else{echo''.$TFYT_Usera['qq'].'';}?>&s=160" class="img-circle">
						</div>
					  </div>
					  <div class="h4 m-t m-b-xs"><?php if(!$TFYT_Usera['name']){echo '新平台用户';}else{echo $TFYT_Usera['name'];}?></div>
					  <small class="text-muted m-b"><?=$TFYT_Usera['user']?> <?php if(TFYT_Data("TFYT_Usera_Activate")==1){ if($TFYT_Usera['activate']==1){ echo '[<font color="#006633">已激活</font>]'; }else{ echo '[<font color="red">未激活</font>]'; } } ?></small>
					</div>                      
				  </div>
				</div>
				<div class="list-group no-radius alt">
				  <a class="list-group-item" href="#">
					<span class="badge bg-danger">T A的Q Q</span>
					<?php if($TFYT_Usera['qq']!=''){echo $TFYT_Usera['qq'];}else{echo'10000';}?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-info">账户余额</span>
					<?=$TFYT_Usera['money']?> 元
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-dark">挂机配额</span>
					<?=get_count('qq','uid='.$TFYT_Usera['uid'].'')?>/<?=$TFYT_Usera['peie']?> 个
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-primary">平台代理</span>
					<?php if(get_isdl($TFYT_Usera['agent'],$TFYT_Usera['agentend'])){ echo "是（还有 ".$outdls." 天）";}else{echo"不是代理";}?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-success">当前身份</span>
					<?php if(get_isvip($TFYT_Usera['vip'],$TFYT_Usera['vipend'])){ echo "VIP用户（还有 ".$outvips." 天）";}else{echo"免费用户";}?>
				  </a>
				</div>
				<div id="<?=$TFYT_Usera['user']?>" class="panel-collapse collapse">
				<a class="list-group-item" href="#">
					<span class="badge bg-warning">TA的挂机</span>
					0个
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-info">登录 I P</span>
					<?=$TFYT_Usera['lastip']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-primary">注册 I P</span>
					<?=$TFYT_Usera['regip']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-danger">登录时间</span>
					<?=$TFYT_Usera['lasttime']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-warning">注册时间</span>
					<?=$TFYT_Usera['regtime']?>
				</a>
				</div>
				<div class="btn-group btn-group-justified">
				  <a data-toggle="collapse" data-parent="#accordion2" href="#<?=$TFYT_Usera['user']?>" class="btn btn-dark">查看更多</a>
				  <a href="?choice=user&uid=<?=$TFYT_Usera['uid']?>" class="btn btn-success">点击管理</a>
				  <?php if($TFYT_Usera['uid']!=1){?>
				  <a href="?del=user&uid=<?=$TFYT_Usera['uid']?>" class="btn btn-danger">点击删除</a>
				  <?php }?>
				</div>
			  </section>
			</div>
			<?php }}?>
		  </div>
		  <?php if($pagedo!='seach'){?>
		  <div class="text-center">
			<ul class="pagination pagination">
			<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1">首页</a></li>
			<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>">&laquo;</a></li>
			<?php for($i=$p;$i<=$pp;$i++){?>
			<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
			<?php }?>
			<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>">&raquo;</a></li>
			<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>">末页</a></li>
			</ul>
		  </div>
		  <?php }?>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php }else if($index=="uset"){?>
	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">我的资料【<a href="website_user.php">返回</a>】</h3>
		  </div>
		  <div class="row">
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-dark">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <div class="easypiechart" data-percent="80" data-line-width="5" data-bar-color="#1aae88" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="139" data-line-cap='butt' data-animate="1000">
						<div class="thumb-lg">
						  <img src="http://q1.qlogo.cn/g?b=qq&nk=<?php if(!$TFYT_Uset['qq']){echo'10001';}else{echo''.$TFYT_Uset['qq'].'';}?>&s=160" class="img-circle">
						</div>
					  </div>
					  <div class="h4 m-t m-b-xs"><?php if(!$TFYT_Uset['name']){echo '新平台用户';}else{echo $TFYT_Uset['name'];}?></div>
					  <small class="text-muted m-b"><?=$TFYT_Uset['user']?> <?php if(TFYT_Data("TFYT_Usera_Activate")==1){ if($TFYT_Uset['activate']==1){ echo '[<font color="#006633">已激活</font>]'; }else{ echo '[<font color="red">未激活</font>]'; } } ?></small>
					</div>                      
				  </div>
				</div>
				<div class="list-group no-radius alt">
				  <a class="list-group-item" href="#">
					<span class="badge bg-danger">T A的Q Q</span>
					<?php if($TFYT_Uset['qq']!=''){echo $TFYT_Uset['qq'];}else{echo'10000';}?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-info">账户余额</span>
					<?=$TFYT_Uset['money']?> 元
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-dark">挂机配额</span>
					<?=get_count('qq','uid='.$TFYT_Uset['uid'].'')?>/<?=$TFYT_Uset['peie']?> 个
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-primary">平台代理</span>
					<?php if(get_isdl($TFYT_Uset['agent'],$TFYT_Uset['agentend'])){ echo "是（还有 ".$outdls." 天）";}else{echo"不是代理";}?>
				  </a>
				  <a class="list-group-item" href="#">
					<span class="badge bg-success">当前身份</span>
					<?php if(get_isvip($TFYT_Uset['vip'],$TFYT_Uset['vipend'])){ echo "VIP用户（还有 ".$outvips." 天）";}else{echo"免费用户";}?>
				  </a>
				</div>
				<div id="<?=$TFYT_Uset['user']?>" class="panel-collapse collapse">
				<a class="list-group-item" href="#">
					<span class="badge bg-warning">TA的挂机</span>
					0个
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-info">登录 I P</span>
					<?=$TFYT_Uset['lastip']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-primary">注册 I P</span>
					<?=$TFYT_Uset['regip']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-danger">登录时间</span>
					<?=$TFYT_Uset['lasttime']?>
				</a>
				<a class="list-group-item" href="#">
					<span class="badge bg-warning">注册时间</span>
					<?=$TFYT_Uset['regtime']?>
				</a>
				</div>
				<div class="btn-group btn-group-justified">
				  <a data-toggle="collapse" data-parent="#accordion2" href="#<?=$TFYT_Uset['user']?>" class="btn btn-dark">查看更多</a>
				  <a href="#collapseTwo" class="btn btn-success">点击管理</a>
				  <?php if($TFYT_Uset['uid']!=1){?>
				  <a href="?del=user&uid=<?=$TFYT_Uset['uid']?>" class="btn btn-danger">点击删除</a>
				  <?php }?>
				</div>
			  </section>
			  <?php if(TFYT_Data("TFYT_Usera_Activate")==1){?>
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="uset" value="activate">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">用户激活</span>
				  </header>
				  <div class="panel-body">
					<div class="form-group">
					<label>用户激活：</label>
					<select name="activate" class="form-control m-t">
						<option value="<?=$TFYT_Uset['activate']?>">当前状态：<?php if(TFYT_Data("TFYT_Usera_Activate")==1){ if($TFYT_Uset['activate']==1){ echo '[<font color="#006633">已激活</font>]'; }else{ echo '[<font color="red">未激活</font>]'; } } ?></option>
						<option value="1">设为激活</option>
						<option value="0">取消激活</option>
					</select>
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			  <?php }?>
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="uset" value="money">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">用户充值</span>
				  </header>
				  <div class="panel-body">
					<div class="form-group">
					<label>选择类型：</label>
					<select name="style" class="form-control m-t">
						<option value="0">扣除</option>
						<option value="1">充值</option>
					</select>
					</div>
					<div class="form-group">
					<label>填写金额：</label>
						<input type="number" name="money" class="form-control" placeholder="请填写金额">
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="uset" value="peie">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">充值配额</span>
				  </header>
				  <div class="panel-body">
					<div class="form-group">
					<label>选择类型：</label>
					<select name="style" class="form-control m-t">
						<option value="0">扣除</option>
						<option value="1">充值</option>
					</select>
					</div>
					<div class="form-group">
					<label>填写配额：</label>
						<input type="number" name="peie" class="form-control" placeholder="请填写配额">
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			</div>
			<div class="col-sm-8">
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="update" value="uset">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">资料修改</span>
				  </header>
				  <div class="panel-body">
					<p class="text-muted">在这里，你可以修改你的个人信息</p>
					<div class="form-group">
					<label>用户UID：</label>
						<input type="text" value="<?=$TFYT_Uset['uid']?>" class="form-control" readonly>
					</div>
					<div class="form-group">
					<label>用户名：</label>
						<input type="text" value="<?=$TFYT_Uset['user']?>" class="form-control" readonly>
					</div>
					<div class="form-group">
					<label>名  称：</label>
						<input type="text" name="name" value="<?=$TFYT_Uset['name']?>" class="form-control" placeholder="请输入你的称呼">
					</div>
					<div class="form-group">
					<label>Q Q 号：</label>
						<input type="text" name="qq"  value="<?=$TFYT_Uset['qq']?>" class="form-control" placeholder="请输入你的QQ账号">
					</div>
					<div class="form-group">
					<label>新密码：</label>
						<input type="text" name="password" class="form-control" placeholder="不修改请留空">
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="uset" value="vip">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">充值VIP</span>
				  </header>
				  <div class="panel-body">
					<div class="form-group">
					<label>开通会员：</label>
					<select name="vip" class="form-control m-t">
						<option value="<?=$TFYT_Uset['vip']?>">当前状态：<?php if($TFYT_Uset['vip']==1){echo '[<font color="#006633">VIP用户</font>]';}else{echo '[<font color="red">不是VIP</font>]';}?></option>
						<option value="1">设为VIP</option>
						<option value="0">取消VIP</option>
					</select>
					</div>
					<div class="form-group">
					<label>充值月数（单位：天）</label>
						<input type="text" name="datas" placeholder="要充值多少" class="form-control">
					</div>
					<div class="form-group">
					<label>选择单位：</label>
					<select name="styles" class="form-control m-t">
						<option value="day">天</option>
						<option value="week">周</option>
						<option value="month">月</option>
						<option value="year">年</option>
					</select>
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="uset" value="daili">
			   <input type="hidden" name="uid" value="<?=$TFYT_Uset['uid']?>">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">开通代理</span>
				  </header>
				  <div class="panel-body">
					<div class="form-group">
					<label>平台代理</label>
					<select name="agent" class="form-control m-t">
						<option value="<?=$TFYT_Uset['agent']?>">当前状态：<?php if($TFYT_Uset['agent']==1){echo '[<font color="#006633">平台代理</font>]';}else{echo '[<font color="red">不是代理</font>]';}?></option>
						<option value="1">设为代理</option>
						<option value="0">取消代理</option>
					</select>
					</div>
					<div class="form-group">
					<label>开通日期</label>
						<input type="text" name="datas" placeholder="要开通多久" class="form-control">
					</div>
					<div class="form-group">
					<label>选择单位：</label>
					<select name="styles" class="form-control m-t">
						<option value="day">天</option>
						<option value="week">周</option>
						<option value="month">月</option>
						<option value="year">年</option>
					</select>
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				  </footer>
				</section>
			  </form>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php }?>