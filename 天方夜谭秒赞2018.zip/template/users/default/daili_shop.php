<?php if($add=="Home"){?>
	<section id="content">
	  <section class="vbox">
		<header class="header bg-white b-b b-light">
		  <p>添加商品</p>
		</header>
		<section class="scrollable wrapper">              
		  <div class="row">
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-info">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <i class="fa fa-vimeo-square fa fa-5x m-t m-b text-white"></i>
					  <div class="h4 m-t m-b-xs">VIP 会员</div>
					  <small class="text-muted m-b">共：<?=get_count('vip','id')?> 件</small>
					</div>                      
				  </div>
				</div>
				<div class="btn-group btn-group-justified">
				  <a href="?add=Vip" class="btn btn-info">点击添加</a>
				</div>
			  </section>
			</div>
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-danger">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <i class="fa fa-plus-square fa fa-5x m-t m-b text-white"></i>
					  <div class="h4 m-t m-b-xs">挂机配额</div>
					  <small class="text-muted m-b">共：<?=get_count('peie','id')?> 件</small>
					</div>                      
				  </div>
				</div>
				<div class="btn-group btn-group-justified">
				  <a href="?add=Peie" class="btn btn-danger">点击添加</a>
				</div>
			  </section>
			</div>
			<div class="col-sm-4">
			  <section class="panel panel-default">
				<div class="panel-body bg-success">
				  <div class="clearfix text-center m-t">
					<div class="inline">
					  <i class="fa fa-users fa fa-5x m-t m-b text-white"></i>
					  <div class="h4 m-t m-b-xs">平台代理</div>
					  <small class="text-muted m-b">共：<?=get_count('daili','id')?> 件</small>
					</div>                      
				  </div>
				</div>
				<div class="btn-group btn-group-justified">
				  <a href="?add=Daili" class="btn btn-success">点击添加</a>
				</div>
			  </section>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php }else if($add=="Vip"){ ?>
	<section id="content">
	  <section class="hbox stretch">
		<!-- .aside -->
		<aside class="aside-lg bg-white b-r" id="aside">
		  <div class="wrapper">
			<h4 class="m-t-none"><a href="website_shop.php">返回</a> - 添加商品</h4>
			<p>提示：<?php if($output){?>[<?=$output?>]<?php }?></p>
			<hr/>
			<?php if($index==1){ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="edit" value="ok">
			 <input type="hidden" name="id" value="<?=$id?>">
			  <div class="form-group">
				<label>开通时间</label>
				<input type="number" name="datas" value="<?=$datas?>" placeholder="要开通多久" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" value="<?=$price?>" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" value="<?=$stock?>" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>选择单位：</label>
				<select name="styles" class="input-sm form-control">
					<option value="<?=$styles?>">当前：<?=$styles?></option>
					<option value="day">天</option>
					<option value="week">周</option>
					<option value="month">月</option>
					<option value="year">年</option>
				</select>
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击保存</button>
			  </div>
			</form>
			<?php }else{ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="ok" value="addvip">
			  <div class="form-group">
				<label>开通时间</label>
				<input type="number" name="datas" placeholder="要开通多久" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>选择单位：</label>
				<select name="styles" class="input-sm form-control">
					<option value="day">天</option>
					<option value="week">周</option>
					<option value="month">月</option>
					<option value="year">年</option>
				</select>
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击添加</button>
			  </div>
			</form>
			<?php } ?>
		  </div>
		</aside>
		<!-- /.aside -->
		<!-- .aside -->
		<aside>
		  <section class="vbox">
			<section class="scrollable">
			<div class="table-responsive">
			  <table class="table table-striped b-t b-light">
				<thead>
				  <tr>
					<th>商品 I D</th>
					<th>开通时间</th>
					<th>商品价格</th>
					<th>商品库存</th>
					<th>添加时间</th>
					<th>商品操作</th>
				  </tr>
				</thead>
				<tbody>
				<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}vip where 1=1 order by id desc")){ foreach($rows as $vip){?>
				<?php
				if($vip['styles']=='day'){
					$mus='天';
				}else if($vip['styles']=='week'){
					$mus='周';
				}else if($vip['styles']=='month'){
					$mus='个月';
				}else if($vip['styles']=='year'){
					$mus='年';
				}
				?>
				  <tr>
					<td><?=$vip['id']?></td>
					<td><?=$vip['datas']?> <?=$mus?></td>
					<td><?=$vip['price']?> 元</td>
					<td><?=$vip['stock']?> 件</td>
					<td><?=$vip['addtime']?></td>
					<td><a href="?add=Vip&edit=vip&id=<?=$vip['id']?>">编辑</a> / <a href="?add=Vip&del=vip&id=<?=$vip['id']?>">删除</a></td>
				  </tr>
				<?php }}?>
				</tbody>
			  </table>
			</div>
			</section>
		  </section>
		</aside>
		<!-- /.aside -->            
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php }else if($add=="Peie"){ ?>
	<section id="content">
	  <section class="hbox stretch">
		<!-- .aside -->
		<aside class="aside-lg bg-white b-r" id="aside">
		  <div class="wrapper">
			<h4 class="m-t-none"><a href="website_shop.php">返回</a> - 添加商品</h4>
			<p>提示：<?php if($output){?>[<?=$output?>]<?php }?></p>
			<hr/>
			<?php if($index==1){ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="edit" value="ok">
			 <input type="hidden" name="id" value="<?=$id?>">
			  <div class="form-group">
				<label>挂机配额（单位：个）</label>
				<input type="number" name="nums" max="127" value="<?=$nums?>" placeholder="要充值多少个配额" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" value="<?=$price?>" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" value="<?=$stock?>" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击保存</button>
			  </div>
			</form>
			<?php }else{ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="ok" value="addpeie">
			  <div class="form-group">
				<label>挂机配额（单位：个）</label>
				<input type="number" name="nums" max="127" placeholder="要充值多少个配额" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击添加</button>
			  </div>
			</form>
			<?php } ?>
		  </div>
		</aside>
		<!-- /.aside -->
		<!-- .aside -->
		<aside>
		  <section class="vbox">
			<section class="scrollable">
			<div class="table-responsive">
			  <table class="table table-striped b-t b-light">
				<thead>
				  <tr>
					<th>商品 I D</th>
					<th>挂机配额</th>
					<th>商品价格</th>
					<th>商品库存</th>
					<th>添加时间</th>
					<th>商品操作</th>
				  </tr>
				</thead>
				<tbody>
				<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}peie where 1=1 order by id desc")){ foreach($rows as $peie){?>
				  <tr>
					<td><?=$peie['id']?></td>
					<td><?=$peie['nums']?> 个</td>
					<td><?=$peie['price']?> 元</td>
					<td><?=$peie['stock']?> 件</td>
					<td><?=$peie['addtime']?></td>
					<td><a href="?add=Peie&edit=peie&id=<?=$peie['id']?>">编辑</a> / <a href="?add=Peie&del=peie&id=<?=$peie['id']?>">删除</a></td>
				  </tr>
				<?php }}?>
				</tbody>
			  </table>
			</div>
			</section>
		  </section>
		</aside>
		<!-- /.aside -->            
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php }else if($add=="Daili"){ ?>
	<section id="content">
	  <section class="hbox stretch">
		<!-- .aside -->
		<aside class="aside-lg bg-white b-r" id="aside">
		  <div class="wrapper">
			<h4 class="m-t-none"><a href="website_shop.php">返回</a> - 添加商品</h4>
			<p>提示：<?php if($output){?>[<?=$output?>]<?php }?></p>
			<hr/>
			<?php if($index==1){ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="edit" value="ok">
			 <input type="hidden" name="id" value="<?=$id?>">
			  <div class="form-group">
				<label>开通时间</label>
				<input type="number" name="datas" value="<?=$datas?>" placeholder="要开通多久" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" value="<?=$price?>" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" value="<?=$stock?>" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>选择单位：</label>
				<select name="styles" class="input-sm form-control">
					<option value="<?=$styles?>">当前：<?=$styles?></option>
					<option value="day">天</option>
					<option value="week">周</option>
					<option value="month">月</option>
					<option value="year">年</option>
				</select>
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击保存</button>
			  </div>
			</form>
			<?php }else{ ?>
			<form onsubmit="?" method="post">
			 <input type="hidden" name="ok" value="adddaili">
			  <div class="form-group">
				<label>开通时间</label>
				<input type="number" name="datas" placeholder="要开通多久" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品单价（单位：元）</label>
				<input type="number" name="price" placeholder="请输入单价" class="datepicker input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>商品库存（单位：件）</label>
				<input type="number" name="stock" placeholder="请输入库存" class="input-sm form-control">
			  </div>
			  <div class="form-group">
				<label>选择单位：</label>
				<select name="styles" class="input-sm form-control">
					<option value="day">天</option>
					<option value="week">周</option>
					<option value="month">月</option>
					<option value="year">年</option>
				</select>
			  </div>
			  <div class="m-t-lg">
				<button type="submit" class="btn btn-sm btn-default">点击添加</button>
			  </div>
			</form>
			<?php } ?>
		  </div>
		</aside>
		<!-- /.aside -->
		<!-- .aside -->
		<aside>
		  <section class="vbox">
			<section class="scrollable">
			<div class="table-responsive">
			  <table class="table table-striped b-t b-light">
				<thead>
				  <tr>
					<th>商品 I D</th>
					<th>开通时间</th>
					<th>商品价格</th>
					<th>商品库存</th>
					<th>添加时间</th>
					<th>商品操作</th>
				  </tr>
				</thead>
				<tbody>
				<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}daili where 1=1 order by id desc")){ foreach($rows as $daili){?>
				<?php
				if($daili['styles']=='day'){
					$mus='天';
				}else if($daili['styles']=='week'){
					$mus='周';
				}else if($daili['styles']=='month'){
					$mus='个月';
				}else if($daili['styles']=='year'){
					$mus='年';
				}
				?>
				  <tr>
					<td><?=$daili['id']?></td>
					<td><?=$daili['datas']?> <?=$mus?></td>
					<td><?=$daili['price']?> 元</td>
					<td><?=$daili['stock']?> 件</td>
					<td><?=$daili['addtime']?></td>
					<td><a href="?add=Daili&edit=daili&id=<?=$daili['id']?>">编辑</a> / <a href="?add=Daili&del=daili&id=<?=$daili['id']?>">删除</a></td>
				  </tr>
				<?php }}?>
				</tbody>
			  </table>
			</div>
			</section>
		  </section>
		</aside>
		<!-- /.aside -->            
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>
<?php } ?>