	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">公告设置 <?php if($output){?>[提示：<?=$output?>]<?php }?></h3>
		  </div>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  用户中心公告
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="notice" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">用户中心</label>
				  <div class="col-sm-11">
					<textarea class="form-control parsley-validated" rows="6" name="TFYT_Notice_User" placeholder="请输入用户中心公告内容..."><?=TFYT_Data("TFYT_Notice_User")?></textarea>
				  </div>
				</div>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		  <section class="panel panel-default">
			<header class="panel-heading font-bold">
			  用户充值公告
			</header>
			<div class="panel-body">
			  <form class="form-horizontal" action="?" method="post">
			   <input type="hidden" name="notice" value="update">
				<div class="form-group">
				  <label class="col-sm-1 control-label">用户充值</label>
				  <div class="col-sm-11">
					<textarea class="form-control parsley-validated" rows="6" name="TFYT_Notice_Cami" placeholder="请输入用户充值公告内容..."><?=TFYT_Data("TFYT_Notice_Cami")?></textarea>                  
				  </div>
				</div>
				<footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击保存</button>
				</footer>
			  </form>
			</div>
		  </section>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>