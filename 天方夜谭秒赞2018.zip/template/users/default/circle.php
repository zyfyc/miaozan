	<section id="content">
	  <section class="vbox">
		<section class="scrollable padder">
		  <div class="m-b-md">
			<h3 class="m-b-none">圈圈99+</h3>
		  </div>
		  <div class="row">
			<div class="col-sm-12">
			  <form onsubmit="?" method="post">
			   <input type="hidden" name="ok" value="qqzan">
				<section class="panel panel-default">
				  <header class="panel-heading">
					<span class="h4">圈圈99+</span>
				  </header>
				  <div class="panel-body">
					<p class="text-muted">在这里，可以刷爆你名片的圈圈</p>
					<div class="form-group">
					  <label>请选择要刷的QQ</label>
						<select name="qq" class="form-control">
						<?php if($rows=$db->get_results("select * from {$TFYT_Mysql}qq where uid={$TFYT_User['uid']} order by qid desc")){ foreach($rows as $qq){?>
							<option value="<?=$qq['qq']?>">QQ：<?=$qq['qq']?></option>
						<?php }}?>
						</select>
					</div>
				  </div>
				  <footer class="panel-footer text-right bg-light lter">
					<button type="submit" class="btn btn-success btn-s-xs">点击提交</button>
				  </footer>
				</section>
			  </form>
			</div>
		  </div>
		</section>
	  </section>
	  <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
	</section>