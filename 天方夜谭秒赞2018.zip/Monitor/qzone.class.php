<?php
/*
 *QQ空间多功能操作类
 *Author：消失的彩虹海 & 快乐是福 & 云上的影子
*/
class qzone{
	public $msg;
	public $delend;
	private $qzonetoken = null;
	public function __construct($uin,$sid=null,$skey=null,$pskey=null,$superkey=null){
		$this->uin=$uin;
		$this->sid=$sid;
		$this->pskey=$pskey;
		$this->gtk=$this->getGTK($skey);
		$this->gtk2=$this->getGTK($pskey);
		if($pskey==null)
			$this->cookie='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.';';
		else{
			$this->cookie='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.'; p_skey='.$pskey.'; p_uin=o0'.$uin.';';
			$this->cookie2='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.';';
		}
	}
	public function cplike($uin,$appid,$unikey,$curkey){
		$post='opuin='.$uin.'&unikey='.$unikey.'&curkey='.$curkey.'&appid='.$appid.'&opr_type=like&format=purejson';
		$url='http://h5.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk='.$this->gtk2;
		$json=$this->get_curl($url,$post,1,$this->cookie);
		if($json){
			$arr=json_decode($json,true);
			if(@array_key_exists('ret',$arr) && $arr['ret']==0){
				$this->msg[]='赞 '.$uin.' 的说说成功[CP]';
			}elseif($arr['ret']==-3000){
				$this->skeyzts=1;
				$this->msg[]='赞'.$uin.'的说说失败[CP]！原因:SKEY已失效';
			}elseif(@array_key_exists('msg',$arr)){
				$this->msg[]='赞 '.$uin.' 的说说失败[CP]！原因:'.$arr['msg'];
			}else{
				$this->msg[]='赞 '.$uin.' 的说说失败[CP]！原因:'.$json;
			}
		}else{
			$this->msg[]='获取赞'.$uin.'的说说结果失败[CP]！';
		}
	}
	public function pclike($uin,$curkey,$unikey,$from,$appid,$typeid,$abstime,$fid){
		$post='qzreferrer=http%3A%2F%2Fuser.qzone.qq.com%2F'.$this->uin.'&opuin='.$this->uin.'&unikey='.$unikey.'&curkey='.$curkey.'&from='.$from.'&appid='.$appid.'&typeid='.$typeid.'&abstime='.$abstime.'&fid='.$fid.'&active=0&fupdate=1';
		$randserver = array('w.cnc.','w.');
		$url='http://'.$randserver[rand(0,1)].'qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk='.$this->gtk2;
		$ua='Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.69 Safari/537.36 QQBrowser/9.1.4060.400';
		$get=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin,$this->cookie,0,$ua);
		preg_match('/callback\((.*?)\)\;/is',$get,$json);
		if($json=$json[1]){
			$arr=json_decode($json,true);
			if($arr['message']=='succ' || $arr['msg']=='succ'){
				$this->msg[]='赞 '.$uin.' 的说说成功[PC]';
			}elseif($arr['code']==-3000){
				$this->skeyzts=1;
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:SKEY已失效';
			}elseif(@array_key_exists('message',$arr)){
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:'.$arr['message'];
			}else{
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:'.$json;
			}
		}else{
			$this->msg[]='获取赞'.$uin.'的说说结果失败[PC]';
		}
	}
	public function newpclike($forbid=array(),$sleep=0)
	{
		$randserver=array('s1','s2','s5','s6','s7','s8','s11','s12');
		$url = 'http://ic2.'.$randserver[rand(0,7)].'.qzone.qq.com/cgi-bin/feeds/feeds3_html_more?format=json&begintime=' . time() . '&count=20&uin=' . $this->uin . '&g_tk=' . $this->gtk2;
		$json = $this->get_curl($url, 0, 'http://user.qzone.qq.com/'.$this->uin, $this->cookie);
		$arr = json_decode($json, true);

		if ($arr[code] == -3000) {
			$this->skeyzt = 1;
			$this->msg[] = $this->uin . '获取说说列表失败，原因:SKEY过期！[PC]';
		}
		elseif(strpos($json,'"code":0')) {
			$this->msg[] = $this->uin . '获取说说列表成功[PC]';
			$json = str_replace(array("\\x22", "\\x3C", "\/"), array('"', '<', '/'), $json);
			$i=0;

			if(preg_match_all('/appid:\'(\d+)\',typeid:\'(\d+)\',key:\'([0-9A-Za-z]+)\'.*?,abstime:\'(\d+)\'.*?,uin:\'(\d+)\'.*?,html:\'(.*?)\'/i', $json, $arr)) {
				foreach ($arr[1] as $k => $row ) {
					if(preg_match('/data\-unikey="([0-9A-Za-z\.\-\_\/\:]+)" data\-curkey="([0-9A-Za-z\.\-\_\/\:]+)" data\-clicklog="like" href="javascript\:\;"><i class="fui\-icon icon\-op\-praise"><\/i>/i',$arr[6][$k],$match)){
						$appid = $arr[1][$k];
						$typeid = $arr[2][$k];
						$fid = $arr[3][$k];
						$abstime = $arr[4][$k];
						$touin = $arr[5][$k];
						$unikey = urlencode($match[1]);
						$curkey = urlencode($match[2]);

						if(!in_array($touin,$forbid))
						$this->pclike($touin, $curkey, $unikey, 1, $appid, $typeid, $abstime, $fid);
						++$i;if($i>=8)break;

						if ($this->skeyzt) break;
						if($sleep)sleep($sleep);
						else usleep(100000);
					}
				}
			}
			else {
				$this->msg[] = $this->uin . '没有要赞的说说[PC]';
			}
		}else{
			//$this->msg[] = $this->uin . '没有要赞的说说[PC]';
			$this->like(1,$forbid,$sleep);
		}
	}
	public function like($do=0,$forbid=array(),$sleep=0){
		if ($do==2) {
			$this->newpclike($forbid,$sleep);
		}
		elseif($shuos=$this->getnew()){
			$i=0;$e=0;
			foreach($shuos as $shuo){
				$like=$shuo['like']['isliked'];
				if($like==0 && !in_array($shuo['userinfo']['user']['uin'],$forbid)){
					$appid=$shuo['comm']['appid'];
					$typeid=$shuo['comm']['feedstype'];
					$curkey=urlencode($shuo['comm']['curlikekey']);
					$uinkey=urlencode($shuo['comm']['orglikekey']);
					$uin=$shuo['userinfo']['user']['uin'];
					$from=$shuo['userinfo']['user']['from'];
					$abstime=$shuo['comm']['time'];
					$cellid=$shuo['id']['cellid'];
					if($do){

						$this->pclike($uin,$curkey,$uinkey,$from,$appid,$typeid,$abstime,$cellid);
					}else{
						$this->cplike($uin,$appid,$uinkey,$curkey);
					}
					if($this->skeyzts) ++$e;
					$this->skeyzts=false;
					++$i;if($i>=8)break;
					if($sleep)sleep($sleep);
					else usleep(100000);
				}
			}
			if($e>1 && $e==$i)$this->skeyzt=1;
			if($i==0)$this->msg[] = '没有要赞的说说';
		}
	}

	public function getnew($do='',$time=0){
		if($do=='my'){
			$url="http://mobile.qzone.qq.com/list?g_tk=".$this->gtk2."&res_attach=&format=json&list_type=shuoshuo&action=0&res_uin=".$this->uin."&count=20";
			$json=$this->get_curl($url,0,1,$this->cookie);
		}else{
			$url="http://h5.qzone.qq.com/webapp/json/mqzone_feeds/getActiveFeeds?g_tk=".$this->gtk2;
			$post='res_type=0&res_attach=&refresh_type=2&format=json&attach_info=';
			$json=$this->get_curl($url,$post,1,$this->cookie);
		}
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='获取说说列表成功！';
			if(isset($arr['data']['vFeeds']))
				return $arr['data']['vFeeds'];
			else
				return $arr['data']['feeds']['vFeeds'];
		}elseif(strpos($arr['message'],'务器繁忙')){
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}elseif(strpos($arr['message'],'登录') || strpos($arr['message'],'统繁忙')){
			if($time==0){
				return $this->getnew($do,1);
			}else{
			$this->skeyzt=1;
			$this->msg[]='获取最新说说失败！原因:SKEY已失效';
			return false;
			}
		}else{
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}	
	}

	public function getmynew($uin=null){
		if(empty($uin))$uin=$this->uin;
		$url='http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin='.$uin.'&ftype=0&sort=0&pos=0&num=10&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk='.$this->gtk;
		$json=$this->get_curl($url,0,0,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='获取说说列表成功！';
			return $arr['msglist'];
		}else{
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}
	}
	private function getToken($url = 'https://h5.qzone.qq.com/mqzone/index', $pc = false){
		if($this->qzonetoken)return $this->qzonetoken;
		$filename = ROOT.'qq/temp/'.md5($this->uin.$this->pskey.$url).'.txt';
		if(file_exists($filename)){
			$result=file_get_contents($filename);
			$this->qzonetoken=$result;
			return $this->qzonetoken;
		}
		if($pc){
			$ua='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36';
		}else{
			$ua='Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1';
		}
		$json=$this->get_curl($url,0,0,$this->cookie,0,$ua);
		preg_match('/\(function\(\){ try{*.return (.*?);} catch\(e\)/i',$json,$match);
		if($data=$match[1]){
			$word=array('([]+[][(![]+[])[!+[]+!![]+!![]]+([]+{})[+!![]]+(!![]+[])[+!![]]+(!![]+[])[+[]]][([]+{})[!+[]+!![]+!![]+!![]+!![]]+([]+{})[+!![]]+([][[]]+[])[+!![]]+(![]+[])[!+[]+!![]+!![]]+(!![]+[])[+[]]+(!![]+[])[+!![]]+([][[]]+[])[+[]]+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(!![]+[])[+[]]+([]+{})[+!![]]+(!![]+[])[+!![]]]((!![]+[])[+!![]]+([][[]]+[])[!+[]+!![]+!![]]+(!![]+[])[+[]]+([][[]]+[])[+[]]+(!![]+[])[+!![]]+([][[]]+[])[+!![]]+([]+{})[!+[]+!![]+!![]+!![]+!![]+!![]+!![]]+(![]+[])[!+[]+!![]]+([]+{})[+!![]]+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(+{}+[])[+!![]]+(!![]+[])[+[]]+([][[]]+[])[!+[]+!![]+!![]+!![]+!![]]+([]+{})[+!![]]+([][[]]+[])[+!![]])())'=>'https','([][[]]+[])'=>'undefined','([]+{})'=>'[object Object]','(+{}+[])'=>'NaN','(![]+[])'=>'false','(!![]+[])'=>'true');
			$words=array();$i=0;
			foreach($word as $k=>$v){
				$words[$i]=$v;
				$data=str_replace($k,'$words['.$i.']',$data);
				$i++;
			}
			$data=str_replace(array('!+[]','+!![]','+[]'),array('+1','+1','+0'),$data);
			$data=str_replace(array('+(','+$'),array('.(','.$'),$data);
			eval('$result='.$data.';');
			if(!$result){
				$this->msg[]='计算qzonetoken失败！';
				return false;
			}
			file_put_contents($filename,$result);
			$this->qzonetoken=$result;
			return $this->qzonetoken;
		}else{
			$this->msg[]='获取qzonetoken失败！';
			return false;
		}
    }
	public function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://h5.qzone.qq.com/mqzone/index');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch,CURLOPT_TIMEOUT,10);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
	public function openu($url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:*/*";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		curl_setopt($ch, CURLOPT_REFERER, $url);
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36');
		curl_setopt($ch,CURLOPT_TIMEOUT,10);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
	private function getGTK($skey){
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
	private function getGTK2($skey){
		$salt = 5381;
		$md5key = 'tencentQQVIP123443safde&!%^%1282';
		$hash = array();
		$hash[] = ($salt << 5);
		$len = strlen($skey);
		for($i = 0; $i < $len; $i ++)
		{
			$ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
			$ASCIICode = hexdec(bin2hex($ASCIICode));
			$hash[] = (($salt << 5) + $ASCIICode);
			$salt = $ASCIICode;
		}
		$md5str = md5(implode($hash) . $md5key);
		return $md5str;
	}
	private function is_comment($uin,$arrs){
        if($arrs){
	    	foreach($arrs as $arr){
    	   		if($arr['user']['uin'] == $uin){
        			return false;
            		break;
        		}
    		}
        	return true; 
        }else{
        	return true; 
        }
	}
	private function array_str($array){
    	$str='';
        if($array[-100]){
	        $array100=explode(' ',trim($array[-100]));
    	    $new100=implode('+',$array100);
            $array[-100]=$new100;
        }
 		foreach($array as $k=>$v){
            if($k!='-100'){
	    		$str=$str.$k.'='.$v.'&';
            }
 		}
        $str=urlencode($str.'-100=').$array[-100].'+';
        $str=str_replace(':','%3A',$str);
    	return $str;
    }
	public function getgroupinfo(){
		$ua='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
		$url='http://r.qzone.qq.com/cgi-bin/tfriend/friend_getgroupinfo.cgi?uin='.$this->uin.'&fuin=&rd=0.808466'.time().'&fupdate=1&format=json&g_tk='.$this->gtk2.'&qzonetoken='.$this->getToken('https://user.qzone.qq.com/'.$this->uin.'/311',1);
		$return=$this->get_curl($url,0,'http://user.qzone.qq.com/'.$this->uin.'/myhome/friends/ofpmd',$this->cookie,0,$ua);
		$arr=json_decode($return,true);
		return $arr;
	}
	public function addfriend($touin, $groupid=0){
		$ua='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
		$url='http://w.qzone.qq.com/cgi-bin/tfriend/friend_addfriend.cgi?g_tk='.$this->gtk2.'&qzonetoken='.$this->getToken('https://user.qzone.qq.com/'.$this->uin.'/311',1);
		$post='sid=0&ouin='.$touin.'&uin='.$this->uin.'&fupdate=1&rd=0.017492896'.time().'&fuin='.$touin.'&groupId='.$groupid.'&realname=&flag=&chat=&key=&im=0&from=9&from_source=11&format=json&qzreferrer=http://user.qzone.qq.com/'.$this->uin.'/myhome/friends/ofpmd';
		$return=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin.'/myhome/friends/ofpmd',$this->cookie,0,$ua);
		$arr=json_decode($return,true);
		return $arr;
	}
}