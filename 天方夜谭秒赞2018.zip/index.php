<?php
// +----------------------------------------------------------------------
// | 天方夜谭 [ 版本：2018 V1 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2018 http://www.tfytmz.top All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: Forever <17404785@qq.com>
// +----------------------------------------------------------------------

/**
 * 加载核心
 */
require_once("Include/conn.php");

/**
 * 设置优先页面
 */
$Index = is_string($_GET["Index"])?$_GET["Index"]:"Home";

/**
 * 判断是否登录
 */
if(TFYT_Data('loginuid')){
	@header("refresh:1;url=/?Index=User");
}

/**
 * 加载模板
 */
switch ($Index){
	case "Home":
		include_once TFYT::Home().'index.php';
	break;
	case "Login":
		include_once TFYT::Login().'index.php';
	break;
	case "Enroll":
		include_once TFYT::Enroll().'index.php';
	break;
	case "Back":
		include_once TFYT::Back().'index.php';
	break;
	case "User":
		$User = TFYT::User().'index.php';
		@header("Location:{$User}");
	break;
	default:
		echo "错误路径！";
	break;
}

/**
 * 统计访客
 */
TFYT_Number_Visitor($num);

//代码编写完毕，就是那么简单 ！(●'◡'●) ！