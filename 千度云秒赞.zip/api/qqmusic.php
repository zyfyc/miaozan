<?php
// +----------------------------------------------------------------------
// | Quotes [ 没有目标的人生就是张拼图，反之则是蓝图]
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 云影 <8711973@qq.com>
// +----------------------------------------------------------------------
// | Date: 2016年8月21日
// +----------------------------------------------------------------------
error_reporting(0);
@header('Content-Type: text/html; charset=UTF-8');

$qq = is_numeric($_GET['qq']) ? $_GET['qq'] : 8711973;

$a=packQQnumber($qq);
$b='8F435BE533B3';

$data=get_curl('https://api.1235k.com/gospeed.php?a='.$a.'&b='.$b);
if($data=='0'){
	echo 'QQ音乐一键加速成功！部分QQ需要手动登录下QQ音乐即可完成加速';
}else{
	echo 'QQ音乐一键加速失败，请稍后再试！';
}

function packQQnumber($qq)
{
	$str3 = strtoupper(md5(getrandnumstr(20)));
	$str1 = substr($str3, 0, 16);
	$str2 = substr($str3, 16);
	$qq = bin2Hex(RC4Base($str3, (time() . $qq)));
	return strtoupper($str1.$qq.$str2);
}

function getrandnumstr($num)
{
	$str = "";
	$i = 0;
	while(true)
	{
		if ($i >= $num) {
			return $str;
		}
		$str = $str + rand(0,9);
		$i += 1;
	}
}

function RC4Base($pwd, $data)//$pwd密钥　$data需加密字符串
{
    $key[] ="";
    $box[] ="";
 
    $pwd_length = strlen($pwd);
    $data_length = strlen($data);
 
    for ($i = 0; $i < 256; $i++)
    {
        $key[$i] = ord($pwd[$i % $pwd_length]);
        $box[$i] = $i;
    }
 
    for ($j = $i = 0; $i < 256; $i++)
    {
        $j = ($j + $box[$i] + $key[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
 
    for ($a = $j = $i = 0; $i < $data_length; $i++)
    {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
 
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
 
        $k = $box[(($box[$a] + $box[$j]) % 256)];
        $cipher .= chr(ord($data[$i]) ^ $k);
    }
     
    return $cipher;
}

function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$httpheader[] = "Accept:*/*";
	$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
	$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
	$httpheader[] = "Connection:close";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	curl_setopt($ch, CURLOPT_TIMEOUT, 5);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 Safari/537.36 SE 2.X MetaSr 1.0');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}