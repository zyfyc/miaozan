<?php
error_reporting(0);
function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
        $hash&=0x7fffffff;
    }
    return $hash & 0x7fffffff; //计算g_tk
}
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
    $header2 = array(
        'Accept: application/json',
        'Connection: keep-alive',
    );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, 1);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, "http://m.qzone.com/infocenter?g_f=");
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X; en-us) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header2);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}

@header("Content-Type: text/html; charset=UTF-8");
$uin = $_POST["uin"];
$skey = $_POST["skey"];
$pskey = $_POST["p_skey"];
$touin = $_POST["touin"];
if(!$uin||!$skey||!$touin)exit;

$gtk=getGTK($pskey);

$cookie = 'uin=o0' . $uin . '; skey=' . $skey . '; p_skey=' . $pskey . ';';

$url = "http://client.show.qq.com/cgi-bin/qqshow_client_showinfo?g_tk={$gtk}&omode=4&uin={$uin}&touin={$touin}&cmd=10413";
$data = get_curl($url, 0, "http://client.show.qq.com/?opuin={$uin}&ptlang=2052&page=home&status=guest&guestuin={$touin}&gueststyle=1&guestsex=M&uin={$uin}&sex=M", $cookie);
$arr = json_decode($data,true);
if ($arr['code'] == - 3000) {
    exit('{"code":-1,"msg":"Cookies状态失效"}');
}
if ($arr['code'] == '-1')
{
    $result=array('touin'=>$touin,'is'=>'0');
} else {
    $result=array('touin'=>$touin,'is'=>'1');
}

$result['code'] = 0;
exit(json_encode($result));
?>
