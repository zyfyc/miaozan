ALTER TABLE `cloud_weblist`
ADD COLUMN  `epay_api` varchar(255) DEFAULT NULL,
ADD COLUMN  `chose` varchar(255) DEFAULT NULL;
