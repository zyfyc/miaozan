<?php
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 消失的彩虹海 <admin@cccyun.cc>
// +----------------------------------------------------------------------
// | Date: 2016/5/27
// +----------------------------------------------------------------------

$mysql = require_once __DIR__ . '/../../includes/index/database.php';
try{
    $db=new PDO("mysql:host=".$mysql['hostname'].";dbname=".$mysql['database'].";port=".$mysql['hostport'],$mysql['username'],$mysql['password']);
}catch(Exception $e){
    $errorMsg='链接数据库失败:'.$e->getMessage();
}

$db->exec("set sql_mode = ''");
$db->exec("set names utf8");
$sqls=file_get_contents('update.sql');
$sqls=explode(';', $sqls);
$success=0;$error=0;$errorMsg=null;
foreach ($sqls as $value) {
    $value=trim($value);
    if(!empty($value)){
        if($db->exec($value)===false){
            $error++;
            $dberror=$db->errorInfo();
            $errorMsg.=$dberror[2]."<br>";
        }else{
            $success++;
        }
    }
}
echo "成功{$success}条，失败{$error}条！";
//@unlink('update.sql');