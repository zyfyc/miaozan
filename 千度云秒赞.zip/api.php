<?php
function daddslashes($string, $force = 0, $strip = FALSE)
{
    !defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
    if (!MAGIC_QUOTES_GPC || $force) {
        if (is_array($string)) {
            foreach ($string as $key => $val) {
                $string[$key] = daddslashes($val, $force, $strip);
            }
        } else {
            $string = addslashes($strip ? stripslashes($string) : $string);
        }
    }
    return $string;
}
$mod = "Api";
require("./cron/conn.php");
require("./api/getsid/login.class.php");
require("./api/chaoren.class.php");
$my = $_GET['my'];
if($my == "siderr"){
	$qq = 	$_GET['qq'] ? daddslashes($_GET['qq']) : exit("NOT QQ");
	$err = daddslashes($_GET['err']);
	if(!$row = $pdo->query("select * from `".$mysql['prefix']."qqs` where `qq` = '{$qq}' limit 1")->fetch()){
		exit("QQ Not Find");
	}else{
		$qzone = new qzone();
		$qid = $row['qid'];
		if($err == 'sid'){
			$qzone->sidzt = 1;
		} else {
			$qzone->skeyzt = 1;	
		}
		include_once "./cron/mail.php";
	}
} else if ($my == 'autoupcron'){
    if ($_GET['key'] != $configs['cronkey'])
    {
        die('Key Error');
    }
    $list = $pdo->query("SELECT * FROM `".$mysql['prefix']."qqs` WHERE `cookiezt`=1 ORDER BY `lastauto` ASC,`zid` ASC LIMIT 10")->fetchAll();
    if (count($list) == 0){
        exit('No qq should update!');
    }
    foreach ($list as $qqs)
    {
        $qid = $qqs['qid'];
        @$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `lastauto`='{$now}' WHERE `qid`='{$qid}'");
        $uin = $qqs["qq"];
        $pwd = $qqs['pwd'];
        $login = new qq_login();
        $check = $login->checkvc($uin);
        if ($check['saveOK'] == 0) {
            $vcode = $check['vcode'];
            $pt_verifysession = $check['pt_verifysession'];
        } else {
            $myrow = $pdo->query("SELECT * FROM `".$mysql['prefix']."users` WHERE `uid`='{$qqs['uid']}' LIMIT 1")->fetch();
            if ($configs['dm_chaoren_on'] == 1 && isvip($myrow['vipenddate']) || $configs['dm_chaoren_on'] == 2) {
                $sess = '';
                $chaoren = new Chaorendama($configs['dm_chaoren_account'], $configs['dm_chaoren_pass']);
                $array = $login->getvc($uin, $check['sig'],$sess);
                if ($array['saveOK'] == 0) {
                    $sess = $array['sess'];
                    $bin = $login->getvcpic($uin, $array['vc'],$sess);
                    $dama_arr = $chaoren->recv_byte(bin2hex($bin));
                    $array = $login->dovc($uin, $array['vc'], $dama_arr['result'],$check['sig'],$sess);
                    if($array['rcode']==0){ //验证码正确
        				$vcode=$array['randstr'];
        				$pt_verifysession=$array['sig'];
        			} elseif ($array['rcode']==50){ //验证码错误
        				$chaoren->report_err($dama_arr['imgId']);
        				echo $uin.' Dama Error!<br/>';
        			}
                } else {
                    echo $uin . ' GetVC Error!<br/>';
                }
            } else {
                echo $uin."Need Code!<br/>";
            }
        }
        if (isset($vcode)) {
            
            $p = curl_get('http://encode.qqzzz.net/?uin=' . $uin . '&pwd=' . strtoupper($pwd) . '&vcode=' . strtoupper($vcode));
            if ($p == 'error' || $p == '') {
                exit($uin . ' getp failed!<br/>');
            }
            $arr = $login->qqlogin($uin, $pwd, $p, $vcode, $pt_verifysession);
            if (is_array($arr) && $arr['saveOK'] == 0) {
                $sid = $arr['sid'];
                $skey = $arr['skey'];
                $pskey = $arr['pskey'];
                $superkey = $arr['superkey'];
                $cookie = "uin=o0".$uin."; skey=".$skey."; p_skey=".$pskey."; superkey=".$superkey."; sid=".$sid."; pt2gguin=o0" . $uin . "; p_uin=o0" . $uin . "; ";
                @$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `cookie`='{$cookie}' , `cookiezt`=0 WHERE qid='$qid'");
                echo $uin . ' Update Success!<br/>';
            } else {
                @$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `cookiezt`=2 WHERE qid='$qid'");
                echo $uin . ' Update failed!<br/>';
            }
            
        }
            unset($vcode);
            unset($pt_verifysession);
        
    }
}
function isvip($enddate = null)
{
    if ($enddate >= date("Y-m-d")) {
        return true;
    } else {
        return false;
    }
}
class qzone{
	public $sidzt;
	public $skeyzt;	
} 