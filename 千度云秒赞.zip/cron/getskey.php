<?php
if (!class_exists('qq_login')){
require("../api/getsid/login.class.php");
require("../api/chaoren.class.php");
}
$uin = $row["qq"];
$pwd = $row['pwd'];//(md5(authcode($row['pwd'],"DECODE","8711973"));
$qid = $row['qid'];
$login = new qq_login();
$check = $login->checkvc($uin);
@$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `lastauto`='{$now}' WHERE `qid`='{$qid}'");
if ($check['saveOK'] == 0) {
    $vcode = $check['vcode'];
    $pt_verifysession = $check['pt_verifysession'];
} else {
    $myrow = $pdo->query("SELECT * FROM `".$mysql['prefix']."users` WHERE `uid`='{$qqs['uid']}' LIMIT 1")->fetch();
    if ($configs['dm_chaoren_on'] == 1 && isvip($myrow['vipenddate']) || $configs['dm_chaoren_on'] == 2) {
        $sess = '';
        $chaoren = new Chaorendama($configs['dm_chaoren_account'], $configs['dm_chaoren_pass']);
        $array = $login->getvc($uin, $check['sig'],$sess);
        if ($array['saveOK'] == 0) {
            $sess = $array['sess'];
            $bin = $login->getvcpic($uin, $array['vc'],$sess);
            $dama_arr = $chaoren->recv_byte(bin2hex($bin));
            $array = $login->dovc($uin, $array['vc'], $dama_arr['result'],$check['sig'],$sess);
            if($array['rcode']==0){ //验证码正确
            				$vcode=$array['randstr'];
            				$pt_verifysession=$array['sig'];
            } elseif ($array['rcode']==50){ //验证码错误
            				$chaoren->report_err($dama_arr['imgId']);
            				echo $uin.' Dama Error!<br/>';
            }
        } else {
            echo $uin . ' GetVC Error!<br/>';
        }
    } else {
        echo $uin."Need Code!<br/>";
    }
}
if (isset($vcode)) {

    $p = curl_get('http://encode.qqzzz.net/?uin=' . $uin . '&pwd=' . strtoupper($pwd) . '&vcode=' . strtoupper($vcode));
    if ($p == 'error' || $p == '') {
        exit($uin . ' getp failed!<br/>');
    }
    $arr = $login->qqlogin($uin, $pwd, $p, $vcode, $pt_verifysession);
    if (is_array($arr) && $arr['saveOK'] == 0) {
        $sid = $arr['sid'];
        $skey = $arr['skey'];
        $pskey = $arr['pskey'];
        $superkey = $arr['superkey'];
        $cookie = "uin=o0".$uin."; skey=".$skey."; p_skey=".$pskey."; superkey=".$superkey."; sid=".$sid."; pt2gguin=o0" . $uin . "; p_uin=o0" . $uin . "; ";
        @$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `cookie`='{$cookie}' , `cookiezt`=0 WHERE qid='$qid'");
        exit($uin . ' Update Success!<br/>');
    } else {
        @$pdo->exec("UPDATE `".$mysql['prefix']."qqs` SET `cookiezt`=2 WHERE qid='$qid'");
        echo $uin . ' Update failed!<br/>';
    }

}
unset($vcode);
unset($pt_verifysession);
?>
