<?php
@header("Content-Type: text/html;charset=utf-8");
header("refresh:3;url=/index");
print('正在加载，请稍等...<br>三秒后自动跳转到主页..');
?>