<?php
require("conn.php");
$qid=is_numeric($_GET['qid'])?$_GET['qid']:exit('No Qid!');
$result = $pdo->query("select * from `".$mysql['prefix']."qqs` where `qid`='{$qid}' and `checkin`>0 and `cookiezt`=0  limit 1");
if($row = $result->fetch()){
	$next = date("Y-m-d H:i:s",time()+60*60*8);
	include_once "qqsign.class.php";
	$qzone = new qqsign($row['qq'],$row['cookie']);
	$qzone->gameqd();
	$pdo->exec("update `".$mysql['prefix']."qqs` set `lastcheckin`='{$now}' , `nextcheckin`='{$next}' where `qid`='{$qid}' limit 1");
	include_once "mail.php";
	foreach($qzone->msg as $result){
	echo $result.'<br/>';
	}
}else{
	exit("Fun No Open");	
}