<?php
require("conn.php");
$qid=is_numeric($_GET['qid'])?$_GET['qid']:exit('No Qid!');
$result = $pdo->query("select * from `".$mysql['prefix']."qqs` where `qid`='{$qid}' and `shuo`>0 and `cookiezt`=0  limit 1");
if($row = $result->fetch()){
	$con=get_con($row['shuocon']);
	$pic=urlencode($row['shuoimg']);
	$do = $row['shuo'];
	if($row['shuoaite']){
		$uins = $row['shuoaite'];
		$uins = explode('|',$uins);	
		$Uins = "";
		foreach($uins as $uin){
			$Uins .= "@{uin:".$uin.",nick:云影} "; 	
		}
		$con = $con.$Uins;
	}
	$next = date("Y-m-d H:i:s",time()+$row['shuorate']*60);
	include_once "qzone.class.php";
	$qzone = new qzone($row['qq'],$row['cookie']);
	if($pic==1){
		$row=file('other/data/pic.txt');
		shuffle($row);
		$pic = $row[0];
	}else{
		$type=stripos('z'.$pic,'http')?0:1;	
	}
	$pic=trim($pic);
	if($do==2){
		$qzone->shuo('pc',$con,$pic,$type);
	}else{
		$qzone->shuo(0,$con,$pic,$type);
	}
	
	$pdo->exec("update `".$mysql['prefix']."qqs` set `lastshuo`='{$now}' , `nextshuo`='{$next}' where `qid`='{$qid}' limit 1");
	include_once "mail.php";
	foreach($qzone->msg as $result){
	echo $result.'<br/>';
	}
}else{
	exit("Fun No Open");	
}