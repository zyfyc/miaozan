<?php
require("conn.php");
$qid=is_numeric($_GET['qid'])?$_GET['qid']:exit('No Qid!');
$result = $pdo->query("select * from `".$mysql['prefix']."qqs` where `qid`='{$qid}' and `qunqd`>0 and `cookiezt`=0  limit 1");
if($row = $result->fetch()){
	require_once 'qqsign.class.php';
	$qzone = new qqsign($row['qq'],$row['cookie']);
	$qzone->qunqd();
	$next = date('Y-m-d H:i:s', time() + 900);
	$pdo->exec("update `".$mysql['prefix']."qqs` set `lastqunqd`='{$now}' , `nextqunqd` = '{$next}' where `qid`='{$qid}' limit 1");
	include_once "mail.php";
	foreach($qzone->msg as $result){
	echo $result.'<br/>';
	}
}else{
	exit("Fun No Open");	
}