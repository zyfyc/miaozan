<?php
require("conn.php");
$net = is_numeric($_GET['net']) ? $_GET['net'] : exit("No Net");
$query = $pdo->query("select * from `".$mysql['prefix']."qqs` where `reply` > 0 and `cookiezt` = 0 and `replynet` = '{$net}' and (`nextreply`< NOW() or `nextreply` IS NULL) order by lastreply asc limit 50");
$i = 0;
while($row = $query->fetch()){
	if($configs['cronapi']){
		$qid = $row['qid'];
		$con=get_con($row['replycon']);
		$pic=$row['replyimg'];
		$do = $row['reply'] + 1;
		$qq = $row['qq'];
		if($row['replyaite']){
			$uins = $row['replyaite'];
			$uins = explode('|',$uins);	
			$Uins = "";
			foreach($uins as $uin){
				$Uins .= "@{uin:".$uin.",nick:千度} "; 	
			}
			$con = $con.$Uins;
		}
                $con = urlencode($con);
		$next = date("Y-m-d H:i:s",time()+$row['replyrate']*60);
		$arr = get_info($row['cookie']);
		if($pic==1){
			$row=file('other/data/pic.txt');
			shuffle($row);
			$pic = $row[0];
		}else{
			$type=stripos('z'.$pic,'http')?0:1;	
		}
		$pic=trim($pic);
		$urls[] = $configs['cronapi']."qq/pl.php?qq={$qq}&sid={$arr['sid']}&skey={$arr['skey']}&pskey={$arr['pskey']}&img={$pic}&content={$con}&method={$do}";
		$pdo->exec("update `".$mysql['prefix']."qqs` set `lastreply`='{$now}' , `nextreply`='{$next}' where `qid`='{$qid}' limit 1");
	}else{
		$urls[] = "{$nurl}reply.run.php?key=".$_GET['key']."&qid={$row['qid']}";
	}
	$i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit(date("H:i:s") . '_' . $i . '_' . $net);