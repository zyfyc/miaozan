<?php
require("conn.php");
$net = is_numeric($_GET['net']) ? $_GET['net'] : exit("No Net");
$query = $pdo->query("select * from `".$mysql['prefix']."qqs` where `shuo` > 0 and `cookiezt` = 0  and `shuonet` = '{$net}' and (`nextshuo`< NOW() or `nextshuo` IS NULL) order by lastshuo asc limit 50");
$i = 0;
while($row = $query->fetch()){
	if($configs['cronapi']){
		$qid = $row['qid'];
		$con=urlencode(get_con($row['shuocon']));
		$pic=urlencode($row['shuoimg']);
		$do = $row['shuo'];
		$qq = $row['qq'];
		if($row['shuoaite']){
			$uins = $row['shuoaite'];
			$uins = explode('|',$uins);	
			$Uins = "";
			foreach($uins as $uin){
				$Uins .= "@{uin:".$uin.",nick:云影} "; 	
			}
			$con = $con.$Uins;
		}
		$next = date("Y-m-d H:i:s",time()+$row['shuorate']*60);
		$arr = get_info($row['cookie']);
		if($pic==1){
			$row=file('other/data/pic.txt');
			shuffle($row);
			$pic = $row[0];
		}else{
			$type=stripos('z'.$pic,'http')?0:1;	
		}
		$pic=trim($pic);
		$urls[] = $configs['cronapi']."qq/shuo.php?qq={$qq}&sid={$arr['sid']}&skey={$arr['skey']}&pskey={$arr['pskey']}&img={$pic}&content={$con}&method={$do}";
		$pdo->exec("update `".$mysql['prefix']."qqs` set `lastshuo`='{$now}' , `nextshuo`='{$next}' where `qid`='{$qid}' limit 1");
	}else{
		$urls[] = "{$nurl}shuo.run.php?key=".$_GET['key']."&qid={$row['qid']}";
	}
	$i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit(date("H:i:s") . '_' . $i . '_' . $net);