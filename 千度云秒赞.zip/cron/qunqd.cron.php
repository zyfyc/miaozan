<?php
require("conn.php");
$query = $pdo->query("select * from `".$mysql['prefix']."qqs` where `qunqd`>0 and `cookiezt`=0 and (`nextqunqd` < NOW() OR `nextqunqd` IS NULL) order by lastqunqd asc limit 50");
$i = 0;
while($row = $query->fetch()){
	if($configs['cronapi']){
		$qid = $row['qid'];
		$arr = get_info($row['cookie']);
		$next = date('Y-m-d H:i:s', time() + 900);
		$urls[] = $configs['cronapi']."/qq/qunqd.php?qq={$row['qq']}&sid={$arr['sid']}&skey={$arr['skey']}";
		$pdo->exec("update `".$mysql['prefix']."qqs` set `lastqunqd`='{$now}' , `nextqunqd` = '{$next}' where `qid`='{$qid}' limit 1");
	}else{
		$urls[] = "{$nurl}qunqd.run.php?key=".$_GET['key']."&qid={$row['qid']}";
	}
	$i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit(date("H:i:s") . '_' . $i . '_' . 0);