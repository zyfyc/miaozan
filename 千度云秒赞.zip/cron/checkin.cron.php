<?php
require("conn.php");
$query = $pdo->query("select * from ".$mysql['prefix']."qqs where checkin>0 and cookiezt=0 and (`nextcheckin`<NOW() or `nextcheckin` IS NULL) order by lastcheckin asc limit 50");
$i = 0;
while($row = $query->fetch()){
	if($configs['cronapi']){
		$qid = $row['qid'];
		$arr = get_info($row['cookie']);
		$urls[] = $configs['cronapi']."/qq/checkin.php?qq={$row['qq']}&sid={$arr['sid']}&skey={$arr['skey']}";
		$next = date("Y-m-d H:i:s",time()+60*60*8);
		$pdo->exec("update `".$mysql['prefix']."qqs` set `lastcheckin`='{$now}' , `nextcheckin`='{$next}' where `qid`='{$qid}' limit 1");
	} else{
		$urls[] = "{$nurl}checkin.run.php?key=".$_GET['key']."&qid={$row['qid']}";
	}
	$i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit(date("H:i:s") . '_' . $i . '_' . 0);