<?php
@header('Content-Type: text/html; charset=UTF-8');
error_reporting(0);
date_default_timezone_set('PRC');
@ignore_user_abort(true);
@set_time_limit(0);

/* 函数部分 */
function get_con($con=0){
	$row=file('other/data/content.txt');
	shuffle($row);
	if($con){
		$arr=explode('|',$con);
		shuffle($arr);
		$con=$arr[0];
		return str_replace(array('[时间]','[语录]','[表情]'),array(date("Y-m-d H:i:s"),$row[1],'[em]e'.rand(100,204).'[/em]'),$con);
	}else{
		return $row[0];
	}
}

/*
 * 获取QQ对应提交信息
 */
function get_info($cookies,$return = NULL){
    preg_match('/skey=@(.{9});/',$cookies,$skey);
    preg_match('/superkey=(.*?);/',$cookies,$superkey);
    preg_match('/sid=(.*?);/',$cookies,$sid);
    preg_match('/p_skey=(.{44});/', $cookies, $p_skey);
    $skey = "@".$skey[1];
    $pskey = $p_skey[1];
    $sid = $sid[1];
    $superkey = $superkey[1];
    $arr = array('skey'=>$skey,'pskey'=>$pskey,'sid'=>$sid,'superkey'=>$superkey);
	if($return){
    	return $arr["{$return}"];
	} else {
		return $arr;
	}
}

function curl_get($url)
{
$ch=curl_init($url."&backurl=".urlencode("http://".$_SERVER['HTTP_HOST']."/"));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$content=curl_exec($ch);
curl_close($ch);
return($content);
}

function curl($url1){
	$curl=curl_init();
	curl_setopt($curl,CURLOPT_URL,$url1."&backurl=".urlencode("http://".$_SERVER['HTTP_HOST']."/"));
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,5);
	curl_setopt($curl,CURLOPT_TIMEOUT,1);
	curl_setopt($curl,CURLOPT_NOBODY,1);
	curl_setopt($curl,CURLOPT_NOSIGNAL,true);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_AUTOREFERER,1);
	curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,false);
	curl_exec($curl);
	curl_close($curl);
}

function e($parm){
	echo $parm;
}

/**
 * 虚拟多线程Curl
 * @param $urls array 网址列表
 * @return array
 */
function duo_curl($urls) {
    $ua = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.93 Safari/537.36';
    $queue = curl_multi_init();
    $map = [];
    foreach ($urls as $url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url."&backurl=".urlencode("http://".$_SERVER['HTTP_HOST']."/"));
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOSIGNAL, true);
        curl_multi_add_handle($queue, $ch);
        $map[(string)$ch] = $url;
    }
    $responses = [];
    do {
        while (($code = curl_multi_exec($queue, $active)) == CURLM_CALL_MULTI_PERFORM) ;
        if ($code != CURLM_OK) {
            break;
        }
        while ($done = curl_multi_info_read($queue)) {
            $info = curl_getinfo($done['handle']);
            $error = curl_error($done['handle']);
            $results = curl_multi_getcontent($done['handle']);//返回内容
            $responses[$map[(string)$done['handle']]] = compact('info', 'error', 'results');
            curl_multi_remove_handle($queue, $done['handle']);
            curl_close($done['handle']);
        }
        if ($active > 0) {
            curl_multi_select($queue, 0.5);
        }
    } while ($active);
    curl_multi_close($queue);
    return $responses;
}

function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $head = 0, $ua = 0, $nobaody = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $header[] = "Accept:application/json";
    $header[] = "Accept-Encoding:gzip,deflate,sdch";
    $header[] = "Accept-Language:zh-CN,zh;q=0.8";
    $header[] = "Connection:keep-alive";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($head) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, "https://m.qzone.com/");
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    $ret = mb_convert_encoding($ret, "UTF-8", "UTF-8");
    return $ret;
}

/*
 * 获取当前网址
 * */
function get_nurl() {
    $nurl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
    preg_match('/(.*?\/)([a-zA-Z0-9]+\.)+php/i', $nurl, $arr);
    return $arr[1];
}


$mysql = require_once __DIR__ . '/../includes/index/database.php';
try {
    $pdo = new PDO("mysql:host={$mysql['hostname']};dbname={$mysql['database']};port={$mysql['hostport']}",$mysql['username'],$mysql['password']);
}catch(Exception $e){
    exit('链接数据库失败:'.$e->getMessage());
}
$pdo->exec("set names utf8");
$stmt = $pdo->query("select * from ".$mysql['prefix']."configs");
while($Row = $stmt->fetch()){
	$configs[$Row['k']] = $Row['v'];
}
$test = false;
if($_GET['type'] == '1' && $_GET['qq'] && $_GET['qid']){
    if(trim($_GET['code']) != md5(md5('8711973').md5($_GET['qq']).$_GET['qid'])){
        exit('Code Error');
    }
    $test = true;
}
if($_GET['key'] != $configs['cronkey'] && $mod != "Api" && $test == false){
	exit("Key Error");	
}
//设置常用变量
$nurl = get_nurl() ? : "http://".$_SERVER['HTTP_HOST'].trim(dirname($_SERVER['SCRIPT_NAME']))."/";
$look = isset($_GET['get']) ? '&get=1' : null;
$now = date("Y-m-d H:i:s"); // 当前执行时间
$next = date("Y-m-d H:i:s", time() + 60); // 1分钟的频率
$next_15min = date('Y-m-d H:i:s', time() + 900); // 15分钟的频率
$next_30min = date("Y-m-d H:i:s", time() + 1800); // 30分钟的频率
$next_day = date('Y-m-d 00:12:00', strtotime('+0 day')); // 隔天的05分开始执行