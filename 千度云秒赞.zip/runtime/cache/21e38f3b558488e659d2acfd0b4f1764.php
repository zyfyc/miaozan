<?php
//000000003600a:3:{s:11:"index/hello";a:2:{i:0;a:3:{i:0;s:9:"hello/:id";i:1;a:1:{s:2:"id";i:1;}i:2;a:0:{}}i:1;a:3:{i:0;s:11:"hello/:name";i:1;a:1:{s:4:"name";i:1;}i:2;a:0:{}}}s:19:"Index/Main/mzqqwall";a:1:{i:0;a:3:{i:0;s:8:"mzqqwall";i:1;a:0:{}i:2;a:0:{}}}s:17:"Index/Main/mzauth";a:1:{i:0;a:3:{i:0;s:6:"mzauth";i:1;a:0:{}i:2;a:0:{}}}}
?>