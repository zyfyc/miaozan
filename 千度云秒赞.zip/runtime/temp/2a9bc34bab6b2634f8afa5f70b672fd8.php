<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:26:"default/admin\runtime.html";i:1512560078;s:26:"default/common\common.html";i:1513733841;}*/ ?>
<!--
Name: 千度云秒赞默认模板
Version: 1.0.0.0
Author: 千度云官方团队
Website: http://auth.95ki.cn/
Alias: default
Tip: AppUI响应式后台管理模板基于Bootstrap3.3.7制作，兼容PC端和移动端，全套模板，包括仪表盘、注册、登录、窗口小部件、网格、排版、按钮和下拉列表、导航、进度和加载、表格、表单、画廊、日历、统计图表、动画、媒体盒等49个后台模板页面。
-->
<!DOCTYPE html>
<!--[if IE 9]>
<html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js"> <!--<![endif]--><head>
    <meta charset="utf-8">
   <title><?php echo config('web_webname'); ?>-清除系统缓存</title>
    
    <meta name="keywords" content="<?php echo config('web_keywords'); ?>"/>
    <meta name="description" content="<?php echo config('web_description'); ?>">
    <meta name="author" content="QianDa_QQ:610138382">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Stylesheets -->
    <!-- Bootstrap is included in its original form, unaltered -->
    <link rel="stylesheet" href="<?php echo config('web_cdnapi'); ?>static/user_style/css/bootstrap.min.css">

    <!-- Related styles of various icon packs and plugins -->
    <link rel="stylesheet" href="<?php echo config('web_cdnapi'); ?>static/user_style/css/plugins.css">

    <!-- The main stylesheet of this template. All Bootstrap overwrites are defined in here -->
    <link rel="stylesheet" href="<?php echo config('web_cdnapi'); ?>static/user_style/css/main.css">

    <!-- Include a specific file here from css/themes/ folder to alter the default theme of the template -->

    <!-- The themes stylesheet of this template (for using specific theme color in individual elements - must included last) -->
    <link rel="stylesheet" href="<?php echo config('web_cdnapi'); ?>static/user_style/css/themes.css">
    <!-- sweetalert -->
	<link id="theme-link" rel="stylesheet" href="<?php echo config('web_cdnapi'); ?>css/themes/flat-2.4.css">
    <link rel="stylesheet" type="text/css" href="<?php echo config('web_cdnapi'); ?>static/sweetalert/sweetalert.css"/>
    <!-- END Stylesheets -->

    <!-- Modernizr (browser feature detection library) -->
    <script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/vendor/modernizr-2.8.3.min.js"></script>
    <script>
        var _hmt = _hmt || [];
        (function () {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?40b758abd81264c7adc13c09d695584c";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

</head>
<body>
<!-- Page Wrapper -->
<div id="page-wrapper" class="page-loading-off">
    <!-- Preloader -->
    <!-- Preloader functionality (initialized in js/app.js) - pageLoading() -->
    <!-- Used only if page preloader enabled from inc/config (PHP version) or the class 'page-loading' is added in #page-wrapper element (HTML version) -->
    <div class="preloader">
        <div class="inner">
            <!-- Animation spinner for all modern browsers -->
            <div class="preloader-spinner themed-background hidden-lt-ie10"></div>

            <!-- Text for IE9 -->
            <h3 class="text-primary visible-lt-ie10"><strong>Loading..</strong></h3>
        </div>
    </div>
    <!-- END Preloader -->

    <!-- Page Container -->
        <!-- Page Container -->
<div id="page-container" class="header-fixed-top sidebar-visible-lg-full animation-fadeInQuick2 enable-cookies sidebar-alt-visible-lg sidebar-alt-visible-xs sidebar-light">
        <!-- Main Sidebar -->
        <div id="sidebar">
            <!-- Sidebar Brand -->
            <div id="sidebar-brand" class="themed-background">
                <a href="/" class="sidebar-title">
                    <i class="fa fa-cloud"></i> <span class="sidebar-nav-mini-hide"><?php echo config('web_webname'); ?></span>
                </a>
            </div>
            <!-- END Sidebar Brand -->

            <!-- Wrapper for scrolling functionality -->
            <div id="sidebar-scroll">
                <!-- Sidebar Content -->
                <div class="sidebar-content">
                    <!-- Sidebar Navigation -->
                    <ul class="sidebar-nav">
                        <li>
                            <a href="<?php echo url('index'); ?>" id="index"><i class="gi gi-compass sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">管理中心</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('webset'); ?>" id="set-web"><i class="fa fa-pencil sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">网站信息配置</span></a>
                        </li>
						 <?php if(ZID == 1): ?>
                        <li>
                            <a href="<?php echo url('zzset'); ?>" id="set-zz"><i class="fa fa-internet-explorer sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">主站基本配置</span></a>
                        </li><?php endif; ?>
						                        <li>
                            <a href="<?php echo url('addgg'); ?>" id="set-gg"><i class="fa fa-exclamation-circle sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">网站公告设置</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('orderlist'); ?>" id="set-netnum"><i class="fa fa-tv sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">站点交易记录</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('goodslist'); ?>" id="ad"><i class="fa fa-adn sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">发卡系统商品</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('payset'); ?>" id="set-pay"><i class="fa fa-rmb sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">在线支付设置</span></a>
                        </li>
                        <li class="sidebar-separator">
                            <i class="fa fa-ellipsis-h"></i>
                        </li>
                        <li>
                            <a href="javascript:void(0)" id="datalist" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-users sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">数据列表</span></a>
                            <ul>
                                <li>
                                    <a href="<?php echo url('qqlist'); ?>">QQ列表</a>
                                </li>
                                <li>
                                    <a href="<?php echo url('ulist'); ?>">用户列表</a>
                                </li>
                                <li>
                                    <a href="<?php echo url('kmlist'); ?>">卡密列表</a>
                                </li>
								                                <li>
                                    <a href="<?php echo url('epayorders'); ?>">订单查询</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)" id="del" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-recycle sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">消息通知</span></a>
                            <ul>
                                <li>
                                    <a href="<?php echo url('addmsg'); ?>">推送消息</a>
                                </li>
                                <li>
                                    <a href="<?php echo url('msglist'); ?>" >消息列表</a>
                                </li>
								   <?php if(ZID == 1): ?>
								  <li>
                                    <a href="<?php echo url('msglist',['type'=>'all']); ?>" >消息列表(全)</a>
                                </li><?php endif; ?>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)" id="daili" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-coffee sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">代理设置</span></a>
                            <ul>
                                <li>
                                    <a href="<?php echo url('a_level'); ?>">代理级别设置</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)" id="fz" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-sitemap sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">分站设置</span></a>
                            <ul>
                                <li>
                                    <a href="<?php echo url('addweb'); ?>">创建分站</a>
                                    <a href="<?php echo url('weblist'); ?>">分站列表</a>
									    <?php if(ZID == 1): ?>
									 <a href="<?php echo url('adminlist'); ?>">分站列表(全)</a>
									 <?php endif; ?>
                                </li>
                            </ul>
                        </li>
																		            <li>
                            <a href="javascript:void(0)" id="zzlist" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-check-square sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">站长工具</span></a>
                            <ul>
							                                <li>
                                    <a href="<?php echo url('api'); ?>">API插件中心</a>
                                </li>
                                <li>
                                    <a href="<?php echo url('PHPjm'); ?>">PHP文件加密</a>
                                </li>
							
								                      <li>
                                    <a href="<?php echo url('runtime'); ?>">清除系统缓存</a>
                                </li>
										   <li>
                                    <a href="<?php echo url('bese64'); ?>">bese64加密&解密</a>
                                </li>
							
                            </ul>
                        </li>
						<?php if(ZID == 1): ?>
												            <li>
                            <a href="javascript:void(0)" id="kmlist" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i
                                    class="fa fa-credit-card sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">运行/维护</span></a>
                            <ul>
							
                                <li>
                                    <a href="<?php echo url('cronlist'); ?>">监控列表</a>
                                </li>
								   <li>
                                    <a href="<?php echo url('update'); ?>">程序更新</a>
                                </li>
								
								   <li>
                                    <a href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/public/update/update.php">SQL更新</a>
                                </li>
                            </ul>
                        </li>
						<?php endif; ?>
                        <li class="sidebar-separator">
                            <i class="fa fa-ellipsis-h"></i>
                        </li>
					 
                        <li>
                            <a href="<?php echo url('main/index'); ?>"><i class="fa fa-user sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">返回用户中心</span></a>
                        </li>
                        <li>
                            <a href="<?php echo url('main/logout'); ?>"><i class="fa fa-sign-out sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">退出登录</span></a>
                        </li>
                    </ul>
                    <!-- END Sidebar Navigation -->

                </div>
                <!-- END Sidebar Content -->
            </div>
            <!-- END Wrapper for scrolling functionality -->

            <!-- Sidebar Extra Info -->
            <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                <div class="progress progress-mini push-bit">
                    <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                </div>
                <div class="text-center">
                    <small><a href="/" target="_blank">站长QQ：<?php echo config('web_kfqq'); ?></a></small>
                    <br>
                    <small><span id="year-copy"></span> &copy; <a href="/" target="_blank"> <?php echo config('web_webname'); ?></a> <i class="fa fa-heart text-danger"></i></small>
                </div>
            </div>
            <!-- END Sidebar Extra Info -->
        </div>
        <!-- END Main Sidebar -->

        <!-- Main Container -->
        <div id="main-container">
            <!-- Header -->
            <header class="navbar navbar-inverse navbar-fixed-top">
                <!-- Left Header Navigation -->
                <ul class="nav navbar-nav-custom">
                    <!-- Main Sidebar Toggle Button -->
                    <li>
                        <a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');this.blur();">
                            <i class="fa fa-ellipsis-v fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
                            <i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>
                        </a>
                    </li>
                    <!-- END Main Sidebar Toggle Button -->

                    <!-- Header Link -->
                    <li class="animation-fadeInQuick">
                        <a href="<?php echo url('main/index'); ?>"><strong>返回用户中心</strong></a>
                    </li>
                    <!-- END Header Link -->
                </ul>
                <!-- END Left Header Navigation -->

            </header>
            <!-- END Header -->
            <!-- Page content -->
         
<div id="page-content">
	<!-- Widgets Header -->
	<div class="content-header">
		<div class="row">
			<div class="col-sm-6">
				<div class="header-section">
					<h1>清除缓存</h1>
				</div>
			</div>
			<div class="col-sm-6 hidden-xs">
				<div class="header-section">
					<ul class="breadcrumb breadcrumb-top">
						<li><a href="<?php echo url('admin/index'); ?>">管理后台</a></li>
						<li>清除系统缓存</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">系统运行缓存有助于减轻服务器压力和运行速度,但是可能会影响一些界面更新,建议1-7天清理一次.</h3>
		</div>
                        <form method="post">
                            <input type="hidden" name="action" value="deltemp">
							<button class="btn btn-block btn-success">点击清理系统缓存</button>
						
                        <form method="post">
                           
                        </form>
                    </div>
	<!-- End Content -->

            <!-- END Page Content -->
        </div>
        <!-- END Main Container -->
    </div>
    <!-- END Page Container -->
</div>
<!-- END Page Wrapper -->

<!-- jQuery, Bootstrap, jQuery plugins and Custom JS code -->
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/vendor/jquery-2.2.0.min.js"></script>
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/vendor/bootstrap.min.js"></script>
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/plugins.js"></script>
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/app.js"></script>
<script src="<?php echo config('web_cdnapi'); ?>static/sweetalert/sweetalert.min.js"></script>
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/pages/compGallery.js"></script>
<script type="text/javascript">
$(document).pjax('a[target!=_blank][pjax!=no][href!=#]', '.pjaxmain', {fragment:'.pjaxmain', timeout:5000});
$(document).on('pjax:send', function() { //pjax链接点击后显示加载动画；
    $(".colorful_loading_frame,.colorful_loading").css("display", "block");
});
$(document).on('pjax:complete', function() { //pjax链接加载完成后隐藏加载动画；
    $(".colorful_loading_frame,.colorful_loading").css("display", "none");
	$('#qqjob').modal('hide');
	$('#bind').modal('hide');
});
</script>
<script src="<?php echo config('web_cdnapi'); ?>static/user_style/js/pages/compGallery.js"></script>
<script>$(function(){ CompGallery.init(); });</script>
<script type="text/javascript">
  +function ($) {
	$(function(){
	  // class
	  $(document).on('click', '[data-toggle^="class"]', function(e){
		e && e.preventDefault();
		console.log('abc');
		var $this = $(e.target), $class , $target, $tmp, $classes, $targets;
		!$this.data('toggle') && ($this = $this.closest('[data-toggle^="class"]'));
		$class = $this.data()['toggle'];
		$target = $this.data('target') || $this.attr('href');
		$class && ($tmp = $class.split(':')[1]) && ($classes = $tmp.split(','));
		$target && ($targets = $target.split(','));
		$classes && $classes.length && $.each($targets, function( index, value ) {
		  if ( $classes[index].indexOf( '*' ) !== -1 ) {
			var patt = new RegExp( '\\s' + 
				$classes[index].
				  replace( /\*/g, '[A-Za-z0-9-_]+' ).
				  split( ' ' ).
				  join( '\\s|\\s' ) + 
				'\\s', 'g' );
			$($this).each( function ( i, it ) {
			  var cn = ' ' + it.className + ' ';
			  while ( patt.test( cn ) ) {
				cn = cn.replace( patt, ' ' );
			  }
			  it.className = $.trim( cn );
			});
		  }
		  ($targets[index] !='#') && $($targets[index]).toggleClass($classes[index]) || $this.toggleClass($classes[index]);
		});
		$this.toggleClass('active');
	  });

	  // collapse nav
	  $(document).on('click', 'nav a', function (e) {
		var $this = $(e.target), $active;
		$this.is('a') || ($this = $this.closest('a'));
		
		$active = $this.parent().siblings( ".active" );
		$active && $active.toggleClass('active').find('> ul:visible').slideUp(200);
		
		($this.parent().hasClass('active') && $this.next().slideUp(200)) || $this.next().slideDown(200);
		$this.parent().toggleClass('active');
		
		$this.next().is('ul') && e.preventDefault();

		setTimeout(function(){ $(document).trigger('updateNav'); }, 300);      
	  });
	});
  }(jQuery);
  </script>


<script><?php echo $alert; ?></script>
</body>
</html>