<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 异常错误报错级别,
error_reporting(E_ERROR | E_PARSE );

// 应用公共文件
require 'functions.php';
//授权码
include './includes/authcode.php';
//反腾讯屏蔽
require_once 'txprotect.php';

require_once './htk/common.php';