<?php
// +----------------------------------------------------------------------
// | Quotes [ 没有目标的人生就是张拼图，反之则是蓝图]
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 云影 <8711973@qq.com>
// +----------------------------------------------------------------------
// | Date: 2016年8月14日
// +----------------------------------------------------------------------
namespace app\index\controller;
use think\Db;
class Tool extends Common
{

    protected $arr;

    protected $all;

    protected $zan_arr;

    protected $zan_all;

    function __construct()
    {
        parent::__construct();
        if (empty($this->userInfo)) {
            $this->assign('alert', sweetAlert('未登录', '请先登录！', 'warning', url('index/login')));
            exit($this->fetch('common/sweetalert'));
        }
        if (config('web_hushua') == 0){
            $this->assign('alert',sweetAlert('警告','你的站点没有开启互刷功能，请联系管理员开启！','error',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        $this->arr = Db::name('qqs')->alias('a')
            ->field('qid,qq')
            ->join('weblist b', 'a.zid = b.zid')
            ->where('b.hushua=1 AND a.cookiezt=0')
            ->order('rand()')
            ->limit(10)
            ->select();
        $this->zan_arr = Db::name('qqs')->alias('a')
            ->field('qid,qq')
            ->join('weblist b', 'a.zid = b.zid')
            ->where('b.hushua=1 AND a.cookiezt=0')
            ->order('rand()')
            ->limit(30)
            ->select();
        $this->all = count($this->arr);
        $this->zan_all = count($this->zan_arr);
    }

    public function shuo()
    {
        $cell = input('get.shuoid');
        $content = input('get.content');
        $qq = input('get.qq/d');
        if (! Db::name('qqs')->where([
            'qq' => $qq
        ])->find()) {
            $this->assign('alert', sweetAlert('警告', 'QQ不存在！', 'warning', url('Main/qqlist')));
            exit($this->fetch('common/sweetalert'));
        }
        $str = <<<HTML
        <script src="/assets/Main/js/jquery-1.11.1.min.js"></script>
        <ul class="list-group" style="list-style:none;">
        <li class='list-group-item alert-info'>平台总共<span id="hyall">$this->all<span>个QQ,有<span id="liked"></span>个已成功刷队形！</li>
        <li class='list-group-item' id="load">等待开启</li>
HTML;
        $liked = 0;
        foreach ($this->arr as $k => $row) {
            if (session('?r_' . $cell . '.' . $row['qq'])) {
                if (session('r_' . $cell . '.' . $row['qq']) == 1) {
                    $liked = $liked + 1;
                    $str .= '<header class="panel-heading">
                             ' . $row['qq'] . '已评论
                          </header>';
                } else {
                    $str .= '<li class="list-group-item">' . $row['qq'] . '<span style="float:right;" qid="' . $row['qid'] . '" class="nozan"><font color="red">失败</font></span></li>';
                }
            } else {
                $str .= '<li class="list-group-item">' . $row['qq'] . '<span style="float:right;" qid="' . $row['qid'] . '" class="nostart">未开启</span></li>';
            }
        }
        $str .= "<script>$('#liked').html('{$liked}');</script>";
        $str .= '</ul>';
        $url = url('dxreply');
        $str .= <<<HTML
        <script>
        
        var efar={
				  postData: function(url, parameter, callback, dataType, ajaxType) {
					  if(!dataType) dataType='JSON';
					  $.ajax({
						  type: "POST",
						  url: url,
						  async: true,
						  dataType: dataType,
						  json: "callback",
						  data: parameter,
						  success: function(data) {
							  if (callback == null) {
								  return;
							  } 
							  callback(data);
						  },
						  error: function(error) {
							  alert('创建连接失败');
						  }
					  });
				  }
			  }
$(document).ready(function() {
    
	$('#load').html('检测中');
	var shuoid='$cell';
	var touin,num=0;
	$(".nostart").each(function(){
		var checkself=$(this),
			qid=checkself.attr('qid');
		checkself.html("<img src='/assets/Main/images/loaders/loader6.gif' height=25>")
		var url="$url";
		efar.postData(url,'uin=$qq&content=$content&cell='+shuoid+'&qid='+qid, function(d) {
			if(d.code ==0){
				checkself.removeClass('nostart');
				checkself.html("<font color='green'>已评论</font>");
				$('#load').html(d.msg);
				num = $('#liked').text();
				num=parseInt(num);
				num++;
				$('#liked').text(num);
			}else if(d.code ==-2){
				checkself.html("<font color='yellow'>频繁</font>");
				$('#load').html(d.msg);
			}else if(d.code ==-3){
				checkself.removeClass('nostart');
				checkself.html("<font color='red'>SID过期</font>");
				$('#load').html(d.msg);
			}else{
				checkself.html("<font color='red'>失败</font>");
				alert(d.msg);
			}
		});
		num++;
		//return false;
	});
	if(num<1) $('#load').html('没有待可评论的QQ');
});
</script>
HTML;
        return $str;
    }

    public function dxreply()
    {
        $uin = input('post.uin/d') ?  : exit('{"code":-1,"msg":"uin不能为空"}');
        $content = input('post.content');
        $cell = input('post.cell');
        $qid = input('post.qid/d') ?  : exit('{"code":-1,"msg":"QID不能为空"}');
        if (! Db::name('qqs')->where([
            'qq' => $uin
        ])->find()) {
            exit('{"code":-1,"msg":"你只能操作自己的QQ哦！"}');
        }
        if (! $row = Db::name('qqs')->where([
            'qid' => $qid
        ])->find()) {
            exit('{"code":-1,"msg":"QID' . $qid . '不存在"}');
        }
        include_once "./cron/qzone.class.php";
        $curkey = urlencode('http://user.qzone.qq.com/' . $uin . '/mood/' . $cell);
        $param = urlencode('4=&5=' . $curkey . '&6=' . $curkey . '&16=0&23=0&30=1&48=0&52=&-100=appid%3A311+typeid%3A0+feedtype%3A0+hostuin%3A' . $row['qq'] . '+feedskey%3A' . $cell . '+');
        $qzone = new \qzone($row['qq'], $row['cookie']);
        $qzone->pcreply($content, $uin, $cell, '1');
        if (isset($qzone->skeyzt) && $qzone->skeyzt) {
            session('r_' . $cell . '.' . $row['qq'], 0);
            Db::name('qqs')->where([
                'qq' => $row['qq']
            ])->update([
                'cookiezt' => 1
            ]);
            exit('{"code":-3,"msg":"' . $row['qq'] . '的Cookie状态已过期！"}');
        }
        session('r_' . $cell . '.' . $row['qq'], 1);
        $replycount = session('replycount');
        ++ $replycount;
        session('replycount', $replycount);
        exit('{"code":0,"msg":"' . $row['qq'] . '评论成功！"}');
    }

    public function zan()
    {
        $cell = input('get.shuoid');
        $qq = input('get.qq/d');
        if (! Db::name('qqs')->where([
            'qq' => $qq
        ])->find()) {
            $this->assign('alert', sweetAlert('警告', 'QQ不存在！', 'warning', url('Main/qqlist')));
            exit($this->fetch('common/sweetalert'));
        }
        $str = <<<HTML
        <script src="/assets/Main/js/jquery-1.11.1.min.js"></script>
        <ul class="list-group" style="list-style:none;">
        <li class='list-group-item alert-info'>平台总共<span id="hyall">$this->zan_all<span>个QQ,有<span id="liked"></span>个已成功给您刷赞！</li>
        <li class='list-group-item' id="load">等待开启</li>
HTML;
        $liked = 0;
        foreach ($this->zan_arr as $k => $row) {
            if (session('?z_' . $cell . '.' . $row['qq'])) {
                if (session('z_' . $cell . '.' . $row['qq']) == 1) {
                    $liked = $liked + 1;
                    $str .= '<header class="panel-heading">
                             ' . $row['qq'] . '已赞
                          </header>';
                } else {
                    $str .= '<li class="list-group-item">' . $row['qq'] . '<span style="float:right;" qid="' . $row['qid'] . '" class="nozan"><font color="red">失败</font></span></li>';
                }
            } else {
                $str .= '<li class="list-group-item">' . $row['qq'] . '<span style="float:right;" qid="' . $row['qid'] . '" class="nostart">未开启</span></li>';
            }
        }
        $str .= "<script>$('#liked').html('{$liked}');</script>";
        $str .= '</ul>';
        $url = url('dxzan');
        $str .= <<<HTML
        <script>
        
        var efar={
				  postData: function(url, parameter, callback, dataType, ajaxType) {
					  if(!dataType) dataType='JSON';
					  $.ajax({
						  type: "POST",
						  url: url,
						  async: true,
						  dataType: dataType,
						  json: "callback",
						  data: parameter,
						  success: function(data) {
							  if (callback == null) {
								  return;
							  }
							  callback(data);
						  },
						  error: function(error) {
							  alert('创建连接失败');
						  }
					  });
				  }
			  }
$(document).ready(function() {
        
	$('#load').html('检测中');
	var shuoid='$cell';
	var touin,num=0;
	$(".nostart").each(function(){
		var checkself=$(this),
			qid=checkself.attr('qid');
		checkself.html("<img src='/assets/Main/images/loaders/loader6.gif' height=25>")
		var url="$url";
		efar.postData(url,'uin=$qq&cell='+shuoid+'&qid='+qid, function(d) {
			if(d.code ==0){
				checkself.removeClass('nostart');
				checkself.html("<font color='green'>已赞</font>");
				$('#load').html(d.msg);
				num = $('#liked').text();
				num=parseInt(num);
				num++;
				$('#liked').text(num);
			}else if(d.code ==-2){
				checkself.html("<font color='yellow'>频繁</font>");
				$('#load').html(d.msg);
			}else if(d.code ==-3){
				checkself.removeClass('nostart');
				checkself.html("<font color='red'>SID过期</font>");
				$('#load').html(d.msg);
			}else{
				checkself.html("<font color='red'>失败</font>");
				alert(d.msg);
			}
		});
		num++;
		//return false;
	});
	if(num<1) $('#load').html('没有待可赞的QQ');
});
</script>
HTML;
        return $str;
    }

    public function dxzan()
    {
        $uin = input('post.uin/d') ?  : exit('{"code":-1,"msg":"uin不能为空"}');
        $cell = input('post.cell');
        $qid = input('post.qid/d') ?  : exit('{"code":-1,"msg":"QID不能为空"}');
        if (! Db::name('qqs')->where([
            'qq' => $uin
        ])->find()) {
            exit('{"code":-1,"msg":"你只能操作自己的QQ哦！"}');
        }
        if (! $row = Db::name('qqs')->where([
            'qid' => $qid
        ])->find()) {
            exit('{"code":-1,"msg":"QID' . $qid . '不存在"}');
        }
        include_once "./cron/qzone.class.php";
        $appid = '311';
        $typeid = '0';
        $curkey = urlencode('http://user.qzone.qq.com/' . $uin . '/mood/' . $cell);
        $uinkey = urlencode('http://user.qzone.qq.com/' . $uin . '/mood/' . $cell);
        $from = '1';
        $abstime = time();
        $cellid = $cell;
        $qzone = new \qzone($row['qq'], $row['cookie']);
        $qzone->pclike($curkey, $uinkey, $from, $appid, $typeid, $abstime, $cellid);
        if (isset($qzone->skeyzt) && $qzone->skeyzt) {
            session('z_' . $cell . '.' . $row['qq'], 0);
            Db::name('qqs')->where([
                'qq' => $row['qq']
            ])->update([
                'cookiezt' => 1
            ]);
            exit('{"code":-3,"msg":"' . $row['qq'] . '的Cookie状态已过期！"}');
        }
        session('z_' . $cell . '.' . $row['qq'], 1);
        $replycount = session('replycount');
        ++ $replycount;
        session('zancount', $replycount);
        exit('{"code":0,"msg":"' . $row['qq'] . '点赞成功！"}');
    }
}