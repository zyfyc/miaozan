<?php
namespace app\index\controller;
use think\Db;

class Index extends Common
{
   public function zbyz()
    {
        $msg = '';
        $query = input('get.query',0,'daddslashes');
        $type = input('type');
        if ($type == 'zbyz')
        {
            if (!$URow = Db::name('users')->alias('a')->join('weblist b','a.uid=b.uid')->where(['a.qq'=>$query,'a.power'=>9])->find())
            {
                $msg = '此QQ并非站点客服QQ，请结束交易';
            } else {
                $msg = '此QQ是站点客服QQ，所属站点名称:<a href="http://' . $URow['domain'] . '" style="color:blue;">' . $URow['webname'] . '</a>';
            }
        }
        $this->assign('msg',$msg);
        return $this->fetch();
    }
    
    
    public function dlyz()
    {
        $msg = '';
        $query = input('get.query',0,'daddslashes');
        $type = input('type');
        if ($type == 'dlyz'){
            if (!$URow = Db::name('users')->whereOr(['qq'=>$query,'user'=>$query])->where(['zid'=>ZID])->find())
            {
                $msg = "此用户不存在，切勿相信骗子";
            } else if (Check_Daili($URow['daili']) == false || $URow['daili'] == 0)
            {
                $msg = "此用户不是本站代理，请谨慎交易";
            } else {
                $msg = "此用户是本站代理，可放心交易";
            }
        }
        $this->assign('msg',$msg);
        return $this->fetch();
    }
        public function help()
    {
        return $this->fetch();
    }
	        public function faq()
    {
        return $this->fetch();
	}
		        public function price()
    {
        return $this->fetch();
	}
	
    public function index()
    {
        $qqs = Db::name('qqs')->order("addtime DESC")->limit(27)->select();
        $this->assign('qqs',$qqs);
         if(isMobile()&&config('web_wap')== 1){
            return $this->fetch('wapindex');
        } else{
            $bgurl = "/assets/Index/images/banner".ZID.".png";
            if (!file_exists(__DIR__ . "/../../.." . $bgurl)){
                $bgurl = "/assets/Index/images/banner1.jpg";
            }
            $this->assign('bgurl',$bgurl);
            return $this->fetch();
        }
    }
    public function login(){
          if(isMobile()&&config('web_wap')== 1){
            return $this->fetch('waplogin');
			 }
        if(IS_POST){
            $user = daddslashes(input('post.user'));
            $pass = daddslashes(input('post.pass'));
            if($user = Db::name('users')->where(array('user'=>$user,'pass'=>$pass))->find()){
                $sid = getSid();
                cookie('usersid', $sid);
                Db::name('users')->where(array('uid'=>$user['uid']))->update(array('sid'=>$sid));
                 $this->assign('alert',sweetAlert('登录成功','进入用户中心！','success',url("/index/main/index")));
            } else {
               $this->assign('alert',sweetAlert('登录失败','用户名或密码错误','error'));
            }
        }
        return $this->fetch();
    }

	    public function waplogin(){
          
        if(IS_POST){
            $user = daddslashes(input('post.user'));
            $pass = daddslashes(input('post.pass'));
            if($user = Db::name('users')->where(array('user'=>$user,'pass'=>$pass))->find()){
                $sid = getSid();
                cookie('usersid', $sid);
                Db::name('users')->where(array('uid'=>$user['uid']))->update(array('sid'=>$sid));
                $this->assign('alert',sweetAlert('登录成功','进入用户中心！','success',url("/index/main/index")));
            } else {
             $this->assign('alert',sweetAlert('登录失败','用户名或密码错误','error'));
            }
        }
        return $this->fetch();
    }
		    public function user(){
          
        if(IS_POST){
            $user = daddslashes(input('post.user'));
            $pass = daddslashes(input('post.pass'));
            if($user = Db::name('users')->where(array('user'=>$user,'pass'=>$pass))->find()){
                $sid = getSid();
                cookie('usersid', $sid);
                Db::name('users')->where(array('uid'=>$user['uid']))->update(array('sid'=>$sid));
                $this->assign('alert',sweetAlert('登录成功','进入用户中心！','success',url("/index/main/index")));
            } else {
             $this->assign('alert',sweetAlert('登录失败','用户名或密码错误','error'));
            }
        }
        return $this->fetch();
    }
	    /**
     * 滑动解锁验证
     * @return bool|string
     */
	     public function yz() {
        if (request()->isAjax()) {
            session('vc_code', input('get.k'));
            return 'success';
        }
        return false;
    }
    public function reg() {
		       if(isMobile()&&config('web_wap')== 1){
            return $this->fetch('wapreg');
			 }   
        if(IS_POST){
            //session_start();
            $user = daddslashes(input('post.user'));
            $pass = daddslashes(input('post.pass'));
            $qq = daddslashes(input('post.qq'));
			$vcode = input('get.k');
            $ip = getIP();
            if($vcode != session('vc_code')){
                $this->assign('alert',sweetAlert('温馨提示', '请拖动滑块进行验证后再提交注册！', 'error'));
            } else if(strlen($user) < 5){
                $this->assign('alert',sweetAlert('温馨提示', '用户名太短', 'error'));
            } else if(strlen($pass) < 6){
                $this->assign('alert',sweetAlert('温馨提示', '密码太短', 'error'));
            } else if(Db::name('users')->where(array('user'=>$user))->find()){
                $this->assign('alert',sweetAlert('温馨提示', '此用户已存在', 'error'));
            } else if(!preg_match('/^[1-9][0-9]{4,9}$/', $qq)){
                $this->assign('alert',sweetAlert('温馨提示','QQ号码格式错误','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['qq'=>$qq])->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的QQ已被别人绑定了','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['mail'=>$mail])->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的邮箱地址已被别人绑定了','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else {
               $data['user'] = $user;
               $data['pass'] = $pass;
               $data['regip'] = $ip;
               $data['zid'] = ZID;
               $data['qq'] = $qq;
               $data['regtime'] = date('Y-m-d H:i:s');
               if(Db::name('users')->insert($data)){
                   $this->assign('alert',sweetAlert('温馨提示', '注册成功!前往登录', 'success', url('login')));
               } else {
                   $this->assign('alert',sweetAlert('温馨提示', '注册失败,请稍后再试', 'error'));
               }
                
                
            }
            session('vc_code',null);
        }
        /*$verify = new Verify();
        var_dump($verify->entry());*/
        return $this->fetch();
    }
	    public function wapreg() {
		         
        if(IS_POST){
            //session_start();
            $user = daddslashes(input('post.user'));
            $pass = daddslashes(input('post.pass'));
            $qq = daddslashes(input('post.qq'));
            $vcode = input('post.code/d');
            $ip = getIP();
            if($vcode != session('vc_code')){
                $this->assign('alert',sweetAlert('温馨提示', '验证码错误', 'error'));
            } else if(strlen($user) < 5){
                $this->assign('alert',sweetAlert('温馨提示', '用户名太短', 'error'));
            } else if(strlen($pass) < 6){
                $this->assign('alert',sweetAlert('温馨提示', '密码太短', 'error'));
            } else if(Db::name('users')->where(array('user'=>$user))->find()){
                $this->assign('alert',sweetAlert('温馨提示', '此用户已存在', 'error'));
            } else if(!preg_match('/^[1-9][0-9]{4,9}$/', $qq)){
                $this->assign('alert',sweetAlert('温馨提示','QQ号码格式错误','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['qq'=>$qq])->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的QQ已被别人绑定了','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['mail'=>$mail])->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的邮箱地址已被别人绑定了','error',url()));
                exit($this->fetch('common/sweetalert'));
            } else {
               $data['user'] = $user;
               $data['pass'] = $pass;
               $data['regip'] = $ip;
               $data['zid'] = ZID;
               $data['qq'] = $qq;
               $data['regtime'] = date('Y-m-d H:i:s');
               if(Db::name('users')->insert($data)){
                   $this->assign('alert',sweetAlert('温馨提示', '注册成功!前往登录', 'success', url('login')));
               } else {
                   $this->assign('alert',sweetAlert('温馨提示', '注册失败,请稍后再试', 'error'));
               }
                
                
            }
            session('vc_code',null);
        }
        /*$verify = new Verify();
        var_dump($verify->entry());*/
        return $this->fetch();
    }
    public function findp() {
        return $this->fetch();
    }
    private function login_sig(){
		$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=手机QQ空间&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
		$ret = $this->get_curl($url,0,1,0,1);
		preg_match('/pt_login_sig=(.*?);/',$ret,$match);
		return $match[1];
	}
	private function getqrpic(){
		$url='http://ptlogin2.qq.com/ptqrshow?appid=549000912&e=2&l=M&s=3&d=72&v=4&t=0.5409099'.time().'&daid=5';
		$arr=$this->get_curl($url,0,0,0,1,0,0,1);
		$arr['header'];
		preg_match('/qrsig=(.*?);/',$arr['header'],$match);
		if($qrsig=$match[1])
			exit('{"saveOK":0,"qrsig":"'.$qrsig.'","data":"'.base64_encode($arr['body']).'"}');
		else
			exit('{"saveOK":1,"msg":"二维码获取失败"}');
	}
	private function qqlogin(){
		$qrsig=empty(input('get.qrsig'))?exit('{"saveOK":-1,"msg":"qrsig不能为空"}'):input('get.qrsig');
		$sig=$this->login_sig();
		$url='http://ptlogin2.qq.com/ptqrlogin?u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-'.time().'7886&js_ver=10034&js_type=1&login_sig='.$sig.'&pt_uistyle=32&aid=549000912&daid=5&pt_qzone_sig=1&';
		$ret = $this->get_curl($url,0,0,'qrsig='.$qrsig.'; ',1);
		$uin = '';
		if(preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr)){
			$r=explode("','",str_replace("', '","','",$arr[1]));
			if($r[0]==0){
				preg_match('/Set-Cookie: u_(.*?)=/',$ret,$uin);
				$uin=$uin[1];
				/*if($urow = Db::name('users')->where(['qq'=>$uin])->find() || $urow = Db::name('qqs')->field('uid')->where(['qq'=>$uin])->find()){
				    var_dump($urow);
				    exit('ptuiCB("0","0","Uid:'.$urow['uid'].'的用户的密码已被重置为123456");');
				}else{
				     exit('ptuiCB("6","0","该QQ没有绑定用户");');
				}*/
				if(!$urow = Db::name('users')->where(['qq'=>$uin])->find()){
				    if(!$urow = Db::name('qqs')->field('uid')->where(['qq'=>$uin])->find()){
				        exit('ptuiCB("6","0","该QQ不在我们的网站里");');
				    }else{
				        $new_pass = rand(100000,999999);
				        Db::name('users')->where(['uid'=>$urow['uid']])->update(['pass'=>$new_pass]);
				        exit('ptuiCB("0","0","Uid:'.$urow['uid'].'的用户的密码已被重置为'.$new_pass.'");');
				    }
				}else{
				   exit('ptuiCB("6","0","该QQ没有绑定用户");');
				}
				
				   
				
			}elseif($r[0]==65){
				exit('ptuiCB("1","'.$uin.'","二维码已失效。");');
			}elseif($r[0]==66){
				exit('ptuiCB("2","'.$uin.'","二维码未失效。");');
			}elseif($r[0]==67){
				exit('ptuiCB("3","'.$uin.'","正在验证二维码。");');
			}else{
				exit('ptuiCB("6","'.$uin.'","'.str_replace('"','\'',$r[4]).'");');
			}
		}else{
			exit('{"saveOK":6,"msg":"'.$ret.'"}');
		}
	}
	private function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0,$split=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			curl_setopt($ch, CURLOPT_REFERER, "http://ptlogin2.qq.com/");
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);

		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		if ($split) {
			$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
			$header = substr($ret, 0, $headerSize);
			$body = substr($ret, $headerSize);
			$ret=array();
			$ret['header']=$header;
			$ret['body']=$body;
		}
		curl_close($ch);
		return $ret;
	}
	public function qrlogin(){
	    $do = input('get.do');
	    if($do == "qqlogin"){
	        $this->qqlogin();
	    } 
	    if($do == "getqrpic"){
	        $this->getqrpic();
	    }
	}
}
