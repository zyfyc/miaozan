<?php 
// +----------------------------------------------------------------------
// | Quotes [ 没有目标的人生就是张拼图，反之则是蓝图]
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 云影 & 消失的千度云 
// +----------------------------------------------------------------------
// | Date: 2017年10月4日
// +----------------------------------------------------------------------
namespace app\index\controller;
use app\util\Qzone;
use think\Db;
use think\response\Json;

class Main extends Common{
    

    public function helpdama()
    {
        $act = input('act');
        $dm = false;
        if ($act == 'dm')
        {
            $qid = input('qid/d');
            if (!$row = Db::name('qqs')->where(['qid'=>$qid])->find())
            {
                $this->assign('alert',sweetAlert('警告','该QQ不存在','warning',url()));
                exit($this->fetch('common/sweetalert'));
            } else if ($row['cookiezt'] != 1)
            {
                $this->assign('alert',sweetAlert('警告','该QQ的cookie未失效','warning',url()));
                exit($this->fetch('common/sweetalert'));
            }
            
            //成功打码奖励
            $reward = config('zz_reward_xzdm') ? : 0.1 ;
            $this->assign('row',$row);
            $dm = true;
            require ROOT_PATH . '/api/getsid/login.class.php';
            $login=new \qq_login();
            $check_result=$login->checkvc($row['qq']);
            $sess = input('post.sess','');
            if (!IS_POST){
                if ($check_result['saveOK'] != 0 && !$check_result['pt_verifysession']){
                    $getvc_result=$login->getvc($row['qq'],$check_result['sig'],$sess);
                    $this->assign('sig',$getvc_result['vc']);
                    $this->assign('cap_cd',$check_result['sig']);
                    $this->assign('sess',$getvc_result['sess']);
                } else {
                    $p = file_get_contents("http://encode.qqzzz.net/?uin={$row['qq']}&pwd=" . strtoupper(md5($row['pwd'])) . "&vcode=" . strtoupper($check_result['vcode']));
                    $login_result=$login->qqlogin($row['qq'],$row['pwd'],$p,$check_result['vcode'],$check_result['pt_verifysession']);
                    $cookie = "uin=o0".$row['qq']."; skey=".$login_result['skey']."; p_skey=".$login_result['pskey']."; superkey=".$login_result['superkey']."; sid=".$login_result['sid']."; pt2gguin=o0" . $row['qq'] . "; p_uin=o0" . $row['qq'] . "; ";
                    if ($login_result['saveOK'] == 0){
                        Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>0,'cookie'=>$cookie]);
                        Db::name('users')->where(['uid'=>$this->uid])->setInc('money',$reward);
                        exit("<script>alert('恭喜您，真幸运,直接打码成功!系统奖励您{$reward}元并已自动加到您的账户中!');window.location.href='" . url() . "';</script>");
                    } else {
                        if ($login_result['saveOK'] != 4)
                        {
                            Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>2]);
                        }
                        $this->assign('alert',sweetAlert('温馨提示',$login_result['msg'],'warning',url()));
                        exit($this->fetch('common/sweetalert'));
                    }
                }
            }
            if (IS_POST)
            {
                $sig = input('post.sig');
                $code = input('post.code');
                $cap_cd = input('post.cap_cd');
                $dovc_result=$login->dovc($row['qq'],$sig,$code,$cap_cd,$sess);
                if ($dovc_result['rcode'] == 0)
                {
                    $vcode = strtoupper($dovc_result['randstr']);
                    $sig = $dovc_result['sig'];
                    $p = file_get_contents("http://encode.qqzzz.net/?uin={$row['qq']}&pwd=" . strtoupper(md5($row['pwd'])) . "&vcode=" . $vcode);
                    $login_result=$login->qqlogin($row['qq'],$row['pwd'],$p,$vcode,$sig);
                    $cookie = "uin=o0".$row['qq']."; skey=".$login_result['skey']."; p_skey=".$login_result['pskey']."; superkey=".$login_result['superkey']."; sid=".$login_result['sid']."; pt2gguin=o0" . $row['qq'] . "; p_uin=o0" . $row['qq'] . "; ";
                    if ($login_result['saveOK'] == 0){
                        Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>0,'cookie'=>$cookie]);
                        Db::name('users')->where(['uid'=>$this->uid])->setInc('money',$reward);
                        $this->assign('alert',sweetAlert('温馨提示','恭喜您，打码成功!系统奖励您'. $reward .'元并已自动加到您的账户中!','success',url()));
                        exit($this->fetch('common/sweetalert'));
                    } else {
                        if ($login_result['saveOK'] != 4 && $login_result != -1)
                        {
                            Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>2]);
                        }
                        $this->assign('alert',sweetAlert('温馨提示',$login_result['msg'],'warning',url()));
                        exit($this->fetch('common/sweetalert'));
                    }
                } else {
                    $this->assign('alert',sweetAlert('温馨提示',$dovc_result['errmsg'],'warning',url('',['act'=>'dm','qid'=>$row['qid']])));
                    exit($this->fetch('common/sweetalert'));
                }
            }
            if (input('getpic'))
            {
                header('content-type:image/jpeg');
                echo $login->getvcpic(input('get.qq'),input('get.sig'),input('get.cap_cd'),input('get.sess'));
                exit;
            }
            
        }
        
        
        $list = Db::name('qqs')->where(['cookiezt'=>1])->order('`addtime` DESC')->paginate(10);
        $this->assign('list',$list);
        $this->assign('dm',$dm);
        $this->assign('active','helpdama');
        return $this->fetch();
    }
	
	//PHP加密
		    public function PHPjm()
    {
      
        return $this->fetch();
    }
		//bese文字加密
		    public function bese64()
    {
        
        return $this->fetch();
    }
			//淘宝金币助手
		    public function tjb()
    {
        
        return $this->fetch();
    }
			    public function wh()
    {
        
        return $this->fetch();
    }
						
    public function index() {
		  if(ZZ_Defender == 0){
			            $this->assign('alert',sweetAlert('警告','站点维护中，暂时无法使用','error',url('wh')));
                    exit($this->fetch('common/sweetalert'));
                }
        $web_qq_num = Db::name('qqs')->where(['zid'=>ZID])->count();
       // $web_user_num = count(Db::name('users')->where(['zid'=>ZID])->select());
        $my_qq_num = Db::name('qqs')->where(['uid'=>$this->uid])->count();
        $this->assign('active','index');
        $this->assign('web_qq_num',$web_qq_num);
        //$this->assign('web_user_num',$web_user_num);
        $this->assign('my_qq_num',$my_qq_num);
        $this->assign('my_vip_info',$data=['vip'=>$this->vip,'vipenddate'=>$this->userInfo['vipenddate']]);
        return $this->fetch();
    }
	
    public function qqlist(){
        
        $search = '';
        $act = input('do');
        if($act == "del"){
            $uin = daddslashes(input('uin'));
            if(Db::name('qqs')->where(array('qq'=>$uin,'uid'=>$this->uid))->delete()){
                $this->assign('alert',sweetAlert('温馨提示', 'QQ删除成功', 'success'));
            } else {
                $this->assign('alert',sweetAlert('温馨提示', 'QQ删除失败', 'warning'));
            }
        } else if ($act == "search"){
            $search = ['qq|qid'=>['like','%'.input('get.query').'%']];
        }

        $qqlist = Db::name('qqs')->where(['uid'=>$this->uid])->where($search)->order('qid DESC')->paginate(10);
        $this->assign('qqlist',$qqlist);
        $this->assign('active','qqlist');
        return $this->fetch();
    }
    public function addqq($uin = null){
        if($uin){
            $qqInfo = Db::name('qqs')->where(array('qq'=>$uin,'uid'=>$this->uid))->find();
            $this->assign('qqInfo',$qqInfo);
        }
        session('url',url('Ajax/qqLogin'));
        $this->assign('active','addqq');
        return $this->fetch();
    }
	public function saoma($uin = null){
        if($uin){
            $qqInfo = Db::name('qqs')->where(array('qq'=>$uin,'uid'=>$this->uid))->find();
            $this->assign('qqInfo',$qqInfo);
        }
        session('url',url('Ajax/qqLogin'));
        $this->assign('active','saoma');
        return $this->fetch();
    }
    public function qqset($uin = null, $do = null, $name = null, $zt = null){
        
        if(!$uin){
            $this->assign('alert',sweetAlert('警告','非法参数','warning',url('qqlist')));
            exit($this->fetch('common/sweetalert'));
        } else {
            if(!$row = Db::name('qqs')->where(['qq'=>$uin,'uid'=>$this->uid])->find()){
                $this->assign('alert',sweetAlert('警告','QQ不存在','warning',url('qqlist')));
                exit($this->fetch('common/sweetalert'));
            } else {
                if (IS_POST)
                {
                    if (input('act') == 'end')
                    {
                        $date = input('post.date');
                        if ($date <= date("Y-m-d"))
                        {
                            $this->assign('alert',sweetAlert('警告','你想穿越吗','warning',url('qqset',['uin'=>$row['qq']])));
                            exit($this->fetch('common/sweetalert'));
                        } else {
                            Db::name('qqs')->where(['qid'=>$row['qid']])->update(['enddate'=>$date]);
                            $this->assign('alert',sweetAlert('温馨提示','操作成功','success',url('qqset',['uin'=>$row['qq']])));
                        }
                        
                    }
                }
			   if(config('web_xzvip') == 0 && $this->vip != true){
                    $this->assign('alert',sweetAlert('警告','您不是VIP，无法使用该功能','error',url('shop')));
                    exit($this->fetch('common/sweetalert'));
                }
                $this->assign('qqInfo',$row);
                if($do == "funsave"){
                    $data[$name] = $zt;
                    Db::name('qqs')->where(['qid'=>$row['qid']])->update($data);
                    $this->assign('alert',sweetAlert('温馨提示','更改成功','success', url('qqset',['uin'=>$row['qq']])));

                }
            }
        }
        $this->assign('active','');
        return $this->fetch();
    }
    public function logout(){
        cookie('usersid', null);
        $this->assign('alert',sweetAlert('温馨提示','注销成功,感谢您的使用！','success',url('index/index')));
        exit($this->fetch('common/sweetalert'));
    }
    
    public function myinfo(){
        if(IS_POST && input('do') == "save"){
            $qq = daddslashes(input('post.qq'));
            $mail = daddslashes(input('post.mail'));
            if(!preg_match('/^[1-9][0-9]{4,9}$/', $qq)){
                $this->assign('alert',sweetAlert('温馨提示','QQ号码格式错误','error',url('myinfo')));
                exit($this->fetch('common/sweetalert'));
            } else if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
                $this->assign('alert',sweetAlert('温馨提示','邮箱地址格式错误','error',url('myinfo')));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['qq'=>$qq])->where('uid','<>',$this->uid)->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的QQ已被别人绑定了','error',url('myinfo')));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('users')->where(['mail'=>$mail])->where('uid','<>',$this->uid)->find()){
                $this->assign('alert',sweetAlert('温馨提示','您输入的邮箱地址已被别人绑定了','error',url('myinfo')));
                exit($this->fetch('common/sweetalert'));
            }
            if(Db::name('users')->where(['uid'=>$this->uid])->update(['qq'=>$qq,'mail'=>$mail])){
                $this->assign('alert',sweetAlert('温馨提示','修改成功','success',url('myinfo')));
            }else{
                $this->assign('alert',sweetAlert('温馨提示','修改失败','error',url('myinfo')));
            }
        }
        return $this->fetch();
    }
    public function uppwd(){
        if(IS_POST){
            $OldPwd = input('post.oldpwd');
            $NewPwd = input('post.newpwd');
            if ($OldPwd != $this->userInfo['pass']){
                $this->assign('alert',sweetAlert('温馨提示','旧密码错误','error'));
                exit($this->fetch('common/sweetalert'));
            } else if($NewPwd == $this->userInfo['pass']){
                $this->assign('alert',sweetAlert('温馨提示','新密码不能与当前密码相同','error'));
                exit($this->fetch('common/sweetalert'));
            } else {
				//测试站请删除下面三行,去掉第四行的注释,不懂就别乱改了
				Db::name('users')->where(['uid'=>$this->uid])->update(['pass'=>$NewPwd]);
                cookie('usersid', null);
                $this->assign('alert',sweetAlert('温馨提示','修改密码成功,请重新登录','success', url('index/login')));
                //$this->assign('alert', sweetAlert('温馨提示', '测试站点禁止修改密码！', 'error'));
            }
            
        }
        return $this->fetch();
    }
    public function qqfunset(){
        $uin = daddslashes(input('uin'));
        $name = input('name');
        if (!$row = Db::name('qqs')->where(['qq'=>$uin,'uid'=>$this->uid])->find()){
            $this->assign('alert',sweetAlert('警告','QQ不存在','warning',url('qqlist')));
            exit($this->fetch('common/sweetalert'));
        } else {
            $this->assign('qqInfo',$row);
            if(IS_POST){
                if(config('web_xzvip') == 0 && $this->vip != true){
                    $this->assign('alert',sweetAlert('警告','您不是VIP，无法使用该功能','warning',url('qqlist')));
                    exit($this->fetch('common/sweetalert'));
                }
                if($name == 'zan'){
                    $xy = input('post.zan/d');
                    $net = input('post.zannet/d');
                    if(get_net_count('zan',$net) >= config('zz_server_end_num')){
                        $this->assign('alert',sweetAlert('警告','该服务器已经满啦!','warning',url('qqlist')));
                        exit($this->fetch('common/sweetalert'));
                    }
                    Db::name('qqs')->where(['qid'=>$row['qid']])->update(['zan'=>$xy,'zannet'=>$net]);
                    $this->assign('alert',sweetAlert('温馨提示','更改成功','success',url('qqset',['uin'=>$row['qq']])));
                } else if($name == 'shuo'){
                    $xy = input('post.shuo/d');
                    $con = daddslashes(input('post.con'));
                    $rate = input('post.rate/d');
                    $aite = input('post.shuoaite');
                    $img = input('post.img');
                    $net = input('post.shuonet/d');
                    if(get_net_count('shuo',$net) >= config('zz_server_end_num')){
                        $this->assign('alert',sweetAlert('警告','该服务器已经满啦!','warning',url('qqlist')));
                        exit($this->fetch('common/sweetalert'));
                    }
                    Db::name('qqs')->where(['qid'=>$row['qid']])->update(['shuo'=>$xy,'shuocon'=>$con,'shuorate'=>$rate,'shuoaite'=>$aite,'shuoimg'=>$img,'shuonet'=>$net]);
                    $this->assign('alert',sweetAlert('温馨提示','更改成功','success',url('qqset',['uin'=>$row['qq']])));
                } else if($name == 'reply'){
                    $xy = input('post.reply/d');
                    $con = daddslashes(input('post.con'));
                    $rate = input('post.rate/d');
                    $aite = input('post.replyaite');
                    $img = input('post.img');
                    $net = input("post.replynet/d");
                    if(get_net_count('reply',$net) >= config('zz_server_end_num')){
                        $this->assign('alert',sweetAlert('警告','该服务器已经满啦!','warning',url('qqlist')));
                        exit($this->fetch('common/sweetalert'));
                    }
                    Db::name('qqs')->where(['qid'=>$row['qid']])->update(['reply'=>$xy,'replycon'=>$con,'replyrate'=>$rate,'replyaite'=>$aite,'replyimg'=>$img,'replynet'=>$net]);
                    $this->assign('alert',sweetAlert('温馨提示','更改成功','success',url('qqset',['uin'=>$row['qq']])));
                } else if($name == 'zf'){
                    $xy = input('post.zf/d');
                    $con = daddslashes(input('post.con'));
                    $zfqqs = input('post.zfqqs');
                    $aite = input('post.zfaite');
                    $net = input('post.zfnet/d');
                    if(get_net_count('zf',$net) >= config('zz_server_end_num')){
                        $this->assign('alert',sweetAlert('警告','该服务器已经满啦!','warning',url('qqlist')));
                        exit($this->fetch('common/sweetalert'));
                    }
                    Db::name('qqs')->where(['qid'=>$row['qid']])->update(['zf'=>$xy,'zfcon'=>$con,'zfqqs'=>$zfqqs,'zfaite'=>$aite,'zfnet'=>$net]);
                    $this->assign('alert',sweetAlert('温馨提示','更改成功','success',url('qqset',['uin'=>$row['qq']])));
                } else if($name == "upload"){
                    if($file = request()->file('image')){
                        if(!$file->check(['ext'=>'png,jpg,gif,jpeg,pjpeg'])){
                            $this->assign('alert',sweetAlert('温馨提示','图片格式错误','warning',url('qqfunset',['uin'=>$row['qq'],'name'=>'shuo'])));
                            exit($this->fetch('common/sweetalert'));
                        }
                        $f = $file->getInfo();
                        $file_name = $f['tmp_name'];
                        $image = file_get_contents($file_name);
                        $pskey = get_info($row['cookie'],'pskey');
                        $upload=uploadimg($row['qq'],$pskey,$image,0,$row['cookie']);
                        if(!stripos('z'.$upload,'图片')){
                            $row['shuoimg'] = $upload;
                            $this->assign('qqInfo',$row);
                        } else {
                            $this->assign('alert',sweetAlert('温馨提示','图片上传失败，原因'.str_replace(array("\r\n", "\r", "\n"), "", $upload),'warning',url('qqfunset',['uin'=>$row['qq'],'name'=>'shuo'])));
                            exit($this->fetch('common/sweetalert'));
                        }
                    } 
                }
                
                
            }
        }
        $this->assign('active','');
        return $this->fetch();
    }
    public function kmcz(){
        $do = input('do');
        $type = input('type/d');
        $where = ['zid'=>ZID];
        if (config('zz_km_useall'))
        {
            $where = '';
        }
        if($do == "cz"){
            $km = daddslashes(input('post.km'));
            if(!$kmrow = Db::name('kms')->where(['km'=>$km])->where($where)->find()){
                $this->assign('alert',sweetAlert('警告','卡密不存在','warning',url('kmcz')));
                exit($this->fetch('common/sweetalert'));
            } else if($kmrow['useid'] >0){
                $this->assign('alert',sweetAlert('警告','卡密已被使用','warning',url('kmcz')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $type = $kmrow['type'];
                if ($type == 1)
                {
                    $update = [
                        'money' =>  ($this->userInfo['money'] + $kmrow['value']),
                    ];
                    $msg = "成功充值{$kmrow['value']}元余额";
                } else if ($type == 2)
                {
                    $update = [
                        'peie' =>  ($this->userInfo['peie'] + $kmrow['value']),
                    ];
                    $msg = "成功增加{$kmrow['value']}个挂机配额";
                } else if ($type == 3)
                {

                    if($this->userInfo['vipenddate'] == NULL || $this->userInfo['vipenddate'] < date("Y-m-d")){
                        $enddate = date("Y-m-d");
                    } else {
                        $enddate = $this->userInfo['vipenddate'];
                    }
                    $vipenddate = date("Y-m-d",strtotime("+ {$kmrow['value']} months",strtotime($enddate)));
                    $update = [
                        'vipenddate'    =>  $vipenddate,
                    ];
                    $msg = "成功开通{$kmrow['value']}个月VIP使用权限";
                } else {
                    if($this->userInfo['vipenddate'] == NULL || $this->userInfo['vipenddate'] < date("Y-m-d")){
                        $enddate = date("Y-m-d");
                    } else {
                        $enddate = $this->userInfo['vipenddate'];
                    }
                    $vipenddate = date("Y-m-d",strtotime("+ {$kmrow['value']} days",strtotime($enddate)));
                    $update = [
                        'vipenddate'    =>  $vipenddate,
                    ];
                    $msg = "成功开通{$kmrow['value']}天VIP使用权限";
                }
                Db::name('kms')->where(['kid'=>$kmrow['kid']])->update(['useid'=>$this->uid,'usetime'=>date('Y-m-d H:i:s')]);
                Db::name('users')->where(['uid'=>$this->uid])->update($update);
                $this->assign('alert',sweetAlert('温馨提示',$msg,'success',url('index')));
            }
        }
        $this->assign('active','kmcz');
        return $this->fetch();
    }
    public function shop(){
        $payname = input('payname');
        $num = input('get.num/d');
        if($num <= 0) $num = 1;
        if($payname == "1peie"){
            $need_money = config('web_price_1peie') * $num;
            if($this->userInfo['money'] < $need_money){
                $this->assign('alert',sweetAlert('警告','余额不足，请充值','warning',url('zxcz')));
                exit($this->fetch('common/sweetalert'));
            }
            Db::name('users')->where(['uid'=>$this->uid])->update(['money'=>$this->userInfo['money']-$need_money,'peie'=>$this->userInfo['peie']+$num]);
            $this->assign('alert',sweetAlert('温馨提示','购买' . $num . '个配额成功','success',url('index')));
        } else if($payname == "1vip"){
            $need_money = config('web_price_1vip') * $num;
            if($this->userInfo['money'] < $need_money){
                $this->assign('alert',sweetAlert('警告','余额不足，请充值','warning',url('zxcz')));
                exit($this->fetch('common/sweetalert'));
            }
            if($this->userInfo['vipenddate'] == NULL || $this->userInfo['vipenddate'] < date("Y-m-d")){
                $enddate = date("Y-m-d");
            } else {
                $enddate = $this->userInfo['vipenddate'];
            }
            $vipenddate = date("Y-m-d",strtotime("+ {$num} months",strtotime($enddate)));
            Db::name('users')->where(['uid'=>$this->uid])->update(['money'=>$this->userInfo['money']-$need_money,'vipenddate'=>$vipenddate]);
            $this->assign('alert',sweetAlert('温馨提示','购买' . $num .'个月VIP会员成功','success',url('index')));
        }
		       return $this->fetch();
    }
	 public function zxcz(){
		   
        if (config('web_payapi') == 2){
            $PayTypeArr = [
                'alipay',
                'qqpay',
                'wxpay'
            ];
        } else {
                $this->assign('alert',sweetAlert('警告','该站点未开启在线支付充值','error',url('kmcz')));
                exit($this->fetch('common/sweetalert'));
            }
        
        if(input('do') == "pay" && input('money') != NULL && config('web_payapi') > 0){
            Vendor('Alipay.Alimd5function');
            Vendor('Alipay.Corefunction');
            if (config('web_paypai') == 1){
                Vendor('Alipay.Alipayconfig');
                Vendor('Alipay.Alinotify');
                Vendor('Alipay.Alisubmit');
            }   else if (config('web_payapi') == 2){
                Vendor('Epay.Epayconfig');
                Vendor('Epay.Epaynotify');
                Vendor('Epay.Epaysubmit');
            }
            //$type = ['1'=>'alipay','2'=>'epay'];
            $money = daddslashes(input('money'));
            if(!is_numeric($money) || $money <= 0){
                $this->assign('alert',sweetAlert('警告','参数错误','warning',url('shop')));
                exit($this->fetch('common/sweetalert'));
            }
            $PayType = input('?post.type') ? input('post.type') : "alipay";
            if (!empty($PayType)){
                if (!in_array($PayType,$PayTypeArr)){
                    $this->assign('alert',sweetAlert('警告','参数错误','warning',url('shop')));
                    exit($this->fetch('common/sweetalert'));
                } 
            }
            $mtype = input('post.mtype/d',0);
            if ($mtype < 0 || $mtype > 1)
            {
                $mtype = 0;
            }
            
            $mtype == 1 ? $msg = S_YB : $msg = "余额";
            $orderid=date("YmdHis").rand(111,999);
            $PayRow = [
                'name'=>config('web_webname').'-用户ID:'.$this->uid.'充值'.$money."元" . $msg,
                'money'=>$money
            ];
            $data = [
                  'uid'=>$this->uid,
                  'type'=>$PayType,
                  'orderid'=>$orderid,
                  'addtime'=>date("Y-m-d H:i:s"),
                  'name'=>$PayRow['name'],
                  'money'=>$PayRow['money'],
                  'status'=>0,
                  'zid'=>ZID,
                  'mtype'=>$mtype,
            ];
            if(Db::name('pay')->insert($data)){
                /*if ($PayType == 'qqpay'){
                    $PayType = 'tenpay';
                }*/
                exit(pay($orderid,$PayRow['name'],$PayRow['money'],$PayType,$mtype));
            } else {
                $this->assign('alert',sweetAlert('警告','订单生成失败','warning',url('shop')));
                exit($this->fetch('common/sweetalert'));
            }
            
            
        }
        $this->assign('paytype',$PayTypeArr);
        $this->assign('paytypename',['alipay'=>'支付宝','qqpay'=>'QQ钱包','wxpay'=>'微信']);
        $this->assign('active','shop');
        return $this->fetch();
    }
	
	public function ds(){
	
       return $this->fetch();
    }	
    public function paylist(){
        $list = Db::name('pay')->where(['uid'=>$this->uid])->order('id DESC')->paginate(10);
        $this->assign('list',$list);
        $this->assign('zt',$zt = ['2'=>'<font color=green>交易成功</font>','1'=>'<font color=green>交易成功</font>','0'=>'<font color=red>交易失败</font>']);
        $this->assign('active','paylist');
        return $this->fetch();
    }
	
	 public function ktfz(){

	 
	return $this->fetch();
	 }
    public function web(){
        if (!config('zz_fzhz'))
        {
            $this->assign('alert',sweetAlert('警告','该站点没有配置好信息，无法开通!详细请联系管理员','error',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        if($this->userInfo['power'] == 9){
            $this->assign('alert',sweetAlert('警告','您已经是站长了，无需重复开通','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        if(ZID != 1 && $this->all_fz >= config('web_fzpeie')){
            $this->assign('alert',sweetAlert('警告','该站的分站配额已达上限，请联系管理员扩展','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        if(IS_POST){
            $month = input('post.month/d') ? daddslashes(input('post.month/d')) : 1;
            if ($month < 1)
            {
                $this->assign('alert',sweetAlert('警告','参数错误','error',url('ktfz')));
                exit($this->fetch('common/sweetalert'));
            }
            $qz = daddslashes(input('post.fzqz'));
            $name = daddslashes(input('post.name'));
            $qq = daddslashes(input('post.qq'));
            $url = $qz.".".config('zz_fzhz');
            $money = $month * (config('zz_fzprice_month') + config('web_fzprice'));
            if($this->userInfo['money'] < $money){
                $this->assign('alert',sweetAlert('警告','余额不足','error',url('shop')));
                exit($this->fetch('common/sweetalert'));
            } else if($qz == NUll || $name == NULL || $qq == NULL){
                $this->assign('alert',sweetAlert('警告','参数错误','error',url('ktfz')));
                exit($this->fetch('common/sweetalert'));
            } else if(!preg_match('/^[1-9][0-9]{4,9}$/', $qq)){
                $this->assign('alert',sweetAlert('警告','QQ号格式错误','error',url('ktfz')));
                exit($this->fetch('common/sweetalert'));
            } else if(Db::name('weblist')->whereor(['domain'=>$url,'domain2'=>$url])->find()){
                $this->assign('alert',sweetAlert('警告','前缀已被他人使用','error',url('ktfz')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $enddate = date("Y-m-d",strtotime("+ {$month} months",time()));
                config('zz_peie') ? $peie = config('zz_peie') : $peie = 200;
                config('zz_fzpeie') ? $fzpeie = config('zz_fzpeie') : $fzpeie = 50;
                $data = [
                    'domain'=>$url,
                    'webname'=>$name,
                    'kfqq'=>$qq,
                    'adddate'=>date("Y-m-d"),
                    'enddate'=>$enddate,
                    'upzid'=>ZID,
                    'uid'=>$this->uid,
                    'peie'=>$peie,
                    'fzpeie'=>$fzpeie
                    
                ];
                if(Db::name('weblist')->insert($data)){
                    $zid = Db::getLastInsID();
                    Db::name('users')->where(['uid'=>$this->uid])->update([
                        'yb'=>$this->userInfo['yb']-$money,
                        'power'=>9,
                        'daili'=>0,
                        'zid'=>$zid
                        
                    ]);
                    $this->assign('alert',sweetAlert('温馨提示','开通成功','success',"http://".$url));
                } else {
                    $this->assign('alert',sweetAlert('警告','开通失败，请联系管理员','error',url('ktfz')));
                    exit($this->fetch('common/sweetalert'));
                }
            }
           
        }
        return $this->fetch();
    }
    
    public function qzonemusic(){
        
        if(IS_GET && $uin = input('get.qq')){
            $Cookies = Db::name('qqs')->field('cookie,qid')->where(['cookiezt'=>0])->order('RAND()')->order('`addtime` DESC')->find();
            $url = get_curl("http://qzone-music.qq.com/fcg-bin/cgi_playlist_xml.fcg?json=1&uin={$uin}&g_tk=5381",0,0,$Cookies['cookie']);
            $url = mb_convert_encoding($url, "UTF-8", "GB2312");
            if (strpos($url, 'code:1000') != false)
            {
                Db::name('qqs')->where(['qid'=>$Cookies['qid']])->update(['cookiezt'=>1]);
                $this->assign('alert',sweetAlert('警告','获取失败，请稍后再试','warning',url()));
                exit($this->fetch('common/sweetalert'));
            }
            preg_match_all('@{xqusic_id\:(.*)\,.*xsong_name\:\"(.*)\".*xsinger_name\:\"(.*)\"@Ui',$url,$arr);
            $this->assign('songs',$arr);
        }
        return $this->fetch();
    }
    
    public function dxjc(){
        $qqlist = Db::name('qqs')->where(array('uid'=>$this->uid))->order('qid DESC')->select();
        $this->assign('qqlist',$qqlist);
        if(IS_GET && $qid = input('get.qid')){
            if(!$qqrow = Db::name('qqs')->where(['qid'=>$qid,'uid'=>$this->uid])->find()){
                $this->assign('alert',sweetAlert('警告','QQ不存在','warning',url('qqlist')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $info_arr = get_info($qqrow['cookie']);
                $gtk=getg_tk($info_arr['pskey']);
                $url = 'http://mobile.qzone.qq.com/friend/mfriend_list?g_tk='.$gtk.'&res_uin='.$qqrow['qq'].'&res_type=normal&format=json&count_per_page=10&page_index=0&page_type=0&mayknowuin=&qqmailstat=';
                $json = get_curl($url,0,1,$qqrow['cookie']);
        		$json=mb_convert_encoding($json, "UTF-8", "UTF-8");
        		$arr = json_decode($json, true);
        		if($arr['code']==-3000){
        		    Db::name('qqs')->where(['uid'=>$this->uid,'qid'=>$qid])->update(['cookiezt'=>1]);
        		    $this->assign('alert',sweetAlert('警告','Cookie过期了','warning',url('addqq',['uin'=>$qqrow['qq']])));
        		    exit($this->fetch('common/sweetalert'));
        		}
        		$friends = $arr["data"]["list"];
        		$gpnames = $arr["data"]["gpnames"];
        		$this->assign('lists',$friends);
        		$this->assign('fenzulist',$gpnames);
        		$this->assign('info_arr',$info_arr);
        		$this->assign('qqrow',$qqrow);

            }
        }
        return $this->fetch();
    }
    public function chat()
    {
        if (IS_POST) {
            $action = input("post.action");
            if ($action == 'send') {
                $message = strip_tags(input("post.message"));
				//$timelimits=date("Y-m-d H:i:s",time()+$timelimit);
				//$ipcount=$this->pdo->getCount("SELECT id FROM pre_chats WHERE `addtime`<:time limit ".$iplimit);
                if (strlen($message) < 3) {
                    $this->assign('alert', sweetAlert('发送失败', '聊天内容太短！', 'warning'));
                } elseif (!$this->checkChat($message)) {
                    $this->assign('alert', sweetAlert('发送失败', '对不起，你的聊天内容含有敏感词汇！', 'warning'));
                } else {
                    if (!$this->pdo->execute("INSERT INTO `pre_chats` (`zid`, `user`, `qq`, `message`, `addtime`) VALUES (:zid, :user, :qq, :message, NOW())", array(':zid' => ZID, ':user' => $this->userInfo['user'], ':qq' => $this->userInfo['qq'], ':message' => $message))) {
                        $this->assign('alert', sweetAlert('发送失败', '发送失败，请稍后再试！', 'warning'));
                    }
                }

            }
        }
        
		if(!$lastchat=@$chatList[0]['id']) $lastchat=0;
		$chatList = array_reverse($chatList);
		if(!$startchat=@$chatList[0]['id']) $startchat=1;
        $this->assign('chatList', $chatList);
		$this->assign('lastchat', $lastchat);
		$this->assign('startchat', $startchat);
        $this->assign('webTitle', "公共聊天室");
        return $this->fetch();
    }
    public function mzjc(){
        $qqlist = Db::name('qqs')->where(array('uid'=>$this->uid))->order('qid DESC')->select();
        $this->assign('qqlist',$qqlist);
        if(IS_GET && $qid = input('get.qid')){
            if(!$qqrow = Db::name('qqs')->where(['qid'=>$qid,'uid'=>$this->uid])->find()){
                $this->assign('alert',sweetAlert('警告','QQ不存在','warning',url('qqlist')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $info_arr = get_info($qqrow['cookie']);
                $gtk=getg_tk($info_arr['skey']);
                $json = get_curl("http://mzapi.odata.cc/api/mzjc.php?qq={$qqrow['qq']}&sid={$info_arr['sid']}&skey={$info_arr['skey']}&pskey={$info_arr['pskey']}");
                $arr = json_decode($json,true);
                if($arr['code']!=0){
                    Db::name('qqs')->where(['uid'=>$this->uid,'qid'=>$qid])->update(['cookiezt'=>1]);
                    $this->assign('alert',sweetAlert('警告','Cookie过期了','warning',url('addqq',['uin'=>$qqrow['qq']])));
                    exit($this->fetch('common/sweetalert'));
                }
                $this->assign('info_arr',$info_arr);
                $this->assign('fenzulist',$arr['gpnames']);
                $this->assign('lists',$arr);
                $this->assign('qqrow',$qqrow);
        
            }
        }
        return $this->fetch();
    }
    
    public function qiandao()
    {
        
        if (!config('web_qdcon') || !config('web_qdcon'))
        {
            $this->assign('alert', sweetAlert('温馨提示', "抱歉，站长没有配置好签到信息，无法进行签到.", 'error', url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        $isQd = false;
        if ($qdRow = Db::name('qiandaos')->where(['uid'=>$this->uid])->where('TO_DAYS(qdtime)=TO_DAYS(NOW())')->find()) {
            $isQd = true;
        }
        if ($row = Db::name('qiandaos')->where(['uid'=>$this->uid])->where('TO_DAYS(NOW()) - TO_DAYS(qdtime) = 1')->order('id')->limit(1)->find()) {
            $day = $row['num'];
        } else {
            $day = 0;
        }
        if ($isQd) $day = $qdRow['num'];
        $this->assign('day', $day);
        $rule = $this->qdRule();
        $num = config('zz_qiandao_num') ? config('zz_qiandao_num') : 999999;
        $this->assign('rule', $rule);
        $this->assign('num', $num);
        $this->assign('day', $day);
        if (IS_POST) {
            if ($isQd) {
                $this->assign('alert', sweetAlert('温馨提示', "你今天已经签过到了！", 'error', url('qiandao')));
            } else {
                $qid = input('post.qid/d');
                if(!$qqrow = Db::name('qqs')->where(['qid'=>$qid,'uid'=>$this->uid])->find()){
                    $this->assign('alert', sweetAlert('温馨提示', "QQ不存在", 'error', url('qiandao')));
                    exit($this->fetch('common/sweetalert'));
                } else if($qqrow['cookiezt'] > 0){
                    $this->assign('alert', sweetAlert('温馨提示', "QQ状态失效了", 'error', url('qiandao')));
                    exit($this->fetch('common/sweetalert'));
                } else {
                    $qzone = new \app\model\Qzone($qqrow['qq'],get_info($qqrow['cookie']));
                    if($qzone->shuo(config('zz_qd_shuo_xy') - 1,config('web_qdcon'),config('web_qdimg')) != true){
                        dump($qzone->msg);
                        echo "<br/><a href='".url('qiandao')."'>返回上一页</a>";
                        $this->assign('alert', sweetAlert('温馨提示', "签到失败!发布签到说说失败！原因:".$qzone->msg[0], 'warning', url('qiandao')));
                        exit($this->fetch('common/sweetalert'));
                    }
                }
                $day++;
                $max = isset($rule['max']) ? $rule['max'] : 0;
                if ($day > $max) {
                    $point = $rule[$max];
                } else {
                    $point = $rule[$day];
                }
                $count = Db::name('qiandaos')->field('id')->where("TO_DAYS(qdtime)=TO_DAYS(NOW())")->count();
                Db::name('qiandaos')->insert([
                    'uid'   =>  $this->uid,
                    'num'   =>  $day,
                    'qdtime'    =>  date("Y-m-d H:i:s")
                ]);
                
                if ($count < $num) {
                    $count++;
                    Db::name('users')->where(['uid'=>$this->uid])->update(['money'=>$this->userInfo['money'] + $point]);
                    $this->assign('alert', sweetAlert('签到成功', "你已连续签到{$day}天。恭喜你，你是今天第{$count}个签到的用户，官方决定奖励你{$point}元！", 'success', url('qiandao')));
                } else {
                    $this->assign('alert', sweetAlert('签到成功', "你已连续签到{$day}天。很遗憾，你今天来晚了，没能领到奖励！", 'error', url('qiandao')));
                }
            }
        }
        $this->assign('qdList', Db::name('qiandaos')->alias('a')->join('users b','b.uid = a.uid')->order('a.id DESC')->limit(10)->select());
        $this->assign('qqlist',Db::name('qqs')->field('qid,qq')->where(['uid'=>$this->uid,'cookiezt'=>0])->select());
        $this->assign('isQd', $isQd);
        return $this->fetch();
    }
    
    private function qdRule()
    {
        if ($rows = explode(',', config('zz_qiandao_rule'))) {
            $array = array();
            foreach ($rows as $row) {
                if ($arr = explode(':', $row)) {
                    $key = trim($arr[0]);
                    $array["$key"] = trim($arr[1]);
                    $max = $key;
                }
            }
    
            if ($array) {
                $narr = array();
                $jf = 0;
                for ($i = 1; $i <= $max; $i++) {
                    if (isset($array[$i]) && $num = $array[$i]) {
                        $narr[$i] = $num;
                        $jf = $num;
                    } else {
                        $narr[$i] = $jf;
                    }
                }
                $narr['max'] = $max;
                return $narr;
            } else {
                return array(0, 1);
            }
        } else {
            return array(0, 1);
        }
    }
    
    public function msglist()
    {
        $title = '消息列表';
        $msgrow = NULL;
        if ($id = input('look/d')){
            $title = '查看消息';
            if (!$msgrow = Db::name('msglist')->where(['uid'=>$this->userInfo['uid'],'id'=>$id])->find()){
                $this->assign('alert', sweetAlert('不存在', '此消息不存在', 'warning', url('msglist')));
                exit($this->fetch('common/sweetalert'));
            }
            $act = input('act');
            if ($act == "read"){
                Db::name('msglist')->where(['id'=>$id])->update(['zt'=>1]);
                $this->assign('alert', sweetAlert('温馨提示', '标记为已读成功', 'success', url('msglist')));
                exit($this->fetch('common/sweetalert'));
            } else if ($act == "del"){
                Db::name('msglist')->where(['id'=>$id])->delete();
                $this->assign('alert', sweetAlert('温馨提示', '删除成功', 'success', url('msglist')));
                exit($this->fetch('common/sweetalert'));
            }
        }
        //获取消息列表
        $list = Db::name('msglist')->where(['uid'=>$this->userInfo['uid']])->order("addtime DESC")->paginate(15);
        $this->assign(['msglist'=>$list,'msg_num'=>$list->total(),'zt'=>['0'=>'未读','1'=>'已读']]);
        $this->assign('title',$title);
        $this->assign('msgrow',$msgrow);
        return $this->fetch();
    }
    
    public function mzqqwall()
    {
        $act = input('do');
        $where = '';
        if ($act == "search")
        {
            $qq = input('get.query');
            $fwq = input('get.server/d',0);
            $where = ['qq'=>['like','%' . $qq . '%']];
            if ($fwq)
            {
                $where = ['qq'=>['like','%' . $qq . '%'],'zannet'=>$fwq];
            }
        }
        session('mzwall_glqq',null);
        $list = Db::name('qqs')->field('qq,zannet,addtime')->where(['cookiezt'=>0])->where('zan','gt','0')->where($where)->order("addtime DESC")->limit(10)->select();
        session('mzwall_glqq',$list);
        $this->assign('list',$list);
        $this->assign('active','mzqqwall');
        return $this->fetch();
    }
    
    public function mzauth($uin = 0)
    {
        if (!$qqrow = Db::name('qqs')->where(['qq'=>$uin])->find()){
            $this->assign('alert', sweetAlert('温馨提示', 'QQ不存在', 'warning', url()));
            exit($this->fetch('common/sweetalert'));
        }
        $this->assign('qqrow',$qqrow);
        return $this->fetch();
    }
    
    
    public function ssdx()
    {
        if($this->vip != true){
            $this->assign('alert',sweetAlert('警告','您不是VIP，无法使用该功能','warning',url('shop')));
            exit($this->fetch('common/sweetalert'));
        }
        if (config('web_hushua') == 0){
            $this->assign('alert',sweetAlert('警告','你的站点没有开启互刷功能，请联系管理员开启！','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        if(!session('?replycount')){
            session('replycount',0);
        }
        if(session('replycount') >= config('zz_ssdx_num') && $this->userInfo['power'] != 9) {
            $this->assign('alert',sweetAlert('警告','你的刷说说队形次数已超配额，请明天再来！','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        $qqrow = NULL;
        $qqlist = Db::name('qqs')->where(array('uid'=>$this->uid))->order('qid DESC')->select();
        $this->assign('qqlist',$qqlist);
        if(IS_GET && $qid = input('get.qid')){
            if(!$qqrow = Db::name('qqs')->where(['qid'=>$qid,'uid'=>$this->uid])->find()){
                $this->assign('alert',sweetAlert('警告','QQ不存在','error',url('qqlist')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $info_arr = get_info($qqrow['cookie']);
                $gtk=getg_tk($info_arr['skey']);
                $url="http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin={$qqrow['qq']}&ftype=0&sort=0&pos=0&num=4&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk=".$gtk;
                $json = get_curl($url,0,0,$qqrow['cookie']);
                $json=mb_convert_encoding($json, "UTF-8", "UTF-8");
                $arr=json_decode($json,true);
                if($arr['code']!=0){
                    Db::name('qqs')->where(['uid'=>$this->uid,'qid'=>$qid])->update(['cookiezt'=>1]);
                    $this->assign('alert',sweetAlert('警告','Cookie过期了','warning',url('addqq',['uin'=>$qqrow['qq']])));
                    exit($this->fetch('common/sweetalert'));
                }
                
                if (@array_key_exists('code',$arr) && $arr['code']==0){
                    $shuolist=$arr['msglist'];
                } else {
                    $this->assign('alert',sweetAlert('警告','获取说说列表失败,请稍后再试','warning',url('ssdx')));
                    exit($this->fetch('common/sweetalert'));
                }
                $this->assign('info_arr',$info_arr);
                $this->assign('shuolist',$shuolist);
                $this->assign('qqrow',$qqrow);
            }
        }
        $this->assign('qqrow',$qqrow);
        return $this->fetch();
    }
        public function gongdan()
    {
		if (IS_POST) {
			$uid =$this->uid;
			$state = '0';
			$type = input('post.type');
			$title = input('post.title');
			$text = input('post.msg');
			if ($this->pdo->execute("INSERT INTO `pre_gongdan` (`uid`, `state`, `title`, `text`, `type`, `addtime`) VALUES (:uid, :state, :title, :text, :type, NOW())", array(':uid' => $uid, ':state' => $state, ':title' => $title, ':text' => $text, ':type' => $type))){
				$this->assign('alert', sweetAlert('温馨提示', '提交工单成功 ，请耐心等待客服处理！', 'success'));
			}else{
				$this->assign('alert', sweetAlert('温馨提示', '提交失败 ，请稍后再试！', 'warning'));
			}
        }

		$pageList = new Page($this->pdo->getCount("select id from pre_gongdan where uid=:uid", array(':uid' => $this->uid)), 10);
		$gdList = $this->pdo->selectAll("select * from pre_gongdan where uid=:uid order by id desc " . $pageList->limit, array(':uid' => $this->uid));

		$this->assign('pageList', $pageList);
		$this->assign('gdList', $gdList);
		$this->assign('webTitle', "工单系统");
        return $this->fetch();
    }
    public function shuozan()
    {
        if($this->vip != true){
            $this->assign('alert',sweetAlert('警告','您不是VIP，无法使用该功能','error',url('shop')));
            exit($this->fetch('common/sweetalert'));
        }
        if (config('web_hushua') == 0){
            $this->assign('alert',sweetAlert('警告','你的站点没有开启互刷功能，请联系管理员开启！','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        if(!session('?zancount')){
            session('zancount',0);
        }
        if(session('zancount') >= config('zz_shuozan_num') && $this->userInfo['power'] != 9) {
            $this->assign('alert',sweetAlert('警告','你的刷说说队形次数已超配额，请明天再来！','warning',url('index')));
            exit($this->fetch('common/sweetalert'));
        }
        $qqrow = NULL;
        $qqlist = Db::name('qqs')->where(array('uid'=>$this->uid))->order('qid DESC')->select();
        $this->assign('qqlist',$qqlist);
        if(IS_GET && $qid = input('get.qid')){
            if(!$qqrow = Db::name('qqs')->where(['qid'=>$qid,'uid'=>$this->uid])->find()){
                $this->assign('alert',sweetAlert('警告','QQ不存在','error',url('qqlist')));
                exit($this->fetch('common/sweetalert'));
            } else {
                $info_arr = get_info($qqrow['cookie']);
                $gtk=getg_tk($info_arr['skey']);
                $url="http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin={$qqrow['qq']}&ftype=0&sort=0&pos=0&num=4&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk=".$gtk;
                $json = get_curl($url,0,0,$qqrow['cookie']);
                $json=mb_convert_encoding($json, "UTF-8", "UTF-8");
                $arr=json_decode($json,true);
                if($arr['code']!=0){
                    Db::name('qqs')->where(['uid'=>$this->uid,'qid'=>$qid])->update(['cookiezt'=>1]);
                    $this->assign('alert',sweetAlert('警告','Cookie过期了','warning',url('addqq',['uin'=>$qqrow['qq']])));
                    exit($this->fetch('common/sweetalert'));
                }
        
                if (@array_key_exists('code',$arr) && $arr['code']==0){
                    $shuolist=$arr['msglist'];
                } else {
                    $this->assign('alert',sweetAlert('警告','获取说说列表失败,请稍后再试','warning',url('ssdx')));
                    exit($this->fetch('common/sweetalert'));
                }
                $this->assign('info_arr',$info_arr);
                $this->assign('shuolist',$shuolist);
                $this->assign('qqrow',$qqrow);
            }
        }
        $this->assign('qqrow',$qqrow);
        return $this->fetch();
    }
	 //特色商品
    public function kmbuy()
    {
        $kmmsg = '';
        if (IS_POST){
            $num = input('post.num/d',1);
            $gid = input('post.gid/d',0);
            if (!$GoodsRow = Db::name('goods')->where(['zid'=>ZID,'id'=>$gid])->find()){
                $this->assign('alert', sweetAlert('温馨提示', '站长没有上架商品！', 'warning',url()));
                exit($this->fetch('common/sweetalert'));
            } else if ($GoodsRow['zid'] != $this->userInfo['zid'] && $this->uid != 1){
                $this->assign('alert', sweetAlert('温馨提示', '你不能购买本站的商品，请到你的站点购买~', 'warning',url()));
                exit($this->fetch('common/sweetalert'));
            }
            $need = $GoodsRow['price'] * $num;
            if ($need < 0){
                $need = 999;
            }
            if ($this->userInfo['money'] < $need){
                $this->assign('alert', sweetAlert('购买失败', '账号余额不足，请先充值！', 'error',url('zxcz')));
                exit($this->fetch('common/sweetalert'));
            }
            $row = Db::name('goods_km')->where(['gid'=>$gid,'buyuid'=>0])->limit($num)->select();
            $kc = count($row);
            if ($kc < $num){
                $this->assign('alert', sweetAlert('购买失败', '商品库存不足', 'error',url()));
                exit($this->fetch('common/sweetalert'));
            }
            if (Db::name('users')->where(['uid'=>$this->uid])->setDec('money',$need)){
                for ($i = 0; $i < $kc; $i++) {
                    $kmmsg .= "卡号:".$row[$i]['km']."卡密:".$row[$i]['pass']."<br/>";
                    Db::name('goods_km')->where(['id'=>$row[$i]['id']])->update([
                        'buyuid'    =>  $this->uid,
                        'buytime'   =>  date("Y-m-d H:i:s"),
                        'goods'     =>  $GoodsRow['name'],
                        
                    ]);
                }
                
            }
            
        }
        $goodslist = Db::name('goods')->field('id,name,price')->where(['zid'=>ZID])->select();
        $list = Db::name('goods_km')->alias('a')->join('goods b','a.gid = b.id')->where(['b.zid'=>ZID,'a.buyuid'=>$this->uid])->paginate(10);
        $this->assign('list',$list);
        $this->assign('goodslist',$goodslist);
        $this->assign('kmmsg',$kmmsg);
        return $this->fetch();
    }
    
    function __construct(){
        parent :: __construct();
        if (empty($this->userInfo) && request()->action() != 'mzauth') {
            $this->assign('alert', sweetAlert('未登录', '请先登录！', 'error', url('index/login')));
            exit($this->fetch('common/sweetalert'));
        }
        $this->assign('active','');
    }
    
}