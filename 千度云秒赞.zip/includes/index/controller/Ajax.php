<?php 
// +----------------------------------------------------------------------
// | Quotes [ 无言胜有言]
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 消失的千度云 <aideyun@Foxmail.com>
// +----------------------------------------------------------------------
// | Date: 2017年10月1日
// +----------------------------------------------------------------------
namespace app\index\controller;
use think\Db;

class Ajax extends Common
{
    function __construct(){
        parent :: __construct();
        if (empty($this->userInfo)) {
            exit($this->sweetAlert('未登录', '请先登录！', 'warning', url('index/login')));
        }
        $this->assign('active','');
    }
    
    public function getmzqqlist()
    {
        $referer  = "http://" . $_SERVER['HTTP_HOST'] . url('main/mzqqwall');
        if ($_SERVER['HTTP_REFERER'] != $referer)
        {
            return json([
                'code' => -1,
                'err'   =>  '页面无效',
            ]);
        }
        $qqwall_pb =  session('mzwall_glqq');
        $pb = '';
        foreach ($qqwall_pb as $pbs)
        {
            $pb .= $pbs['qq'] . ',';
        }
        $pb = substr($pb, 0, strlen($pb)-1);
        $lists = Db::name('qqs')->field('qq,zannet,addtime')->where(['cookiezt'=>0])->where('zan','gt','0')->where('qq','not in',$pb)->order("addtime DESC")->limit(10)->select();
        
        session('mzwall_glqq',array_merge($qqwall_pb,$lists));
        $str = '';
        $webname = config('web_webname');
        foreach ($lists as $list)
        {
            $mzrzurl = url('main/mzauth',array('uin'=>$list['qq']));
            $str .= <<<HTML
            <div class="col-md-4">
		<div class="people-item">
			<div class="media">
				<a href="#" class="pull-left"> <img alt="" src="http://q1.qlogo.cn/g?b=qq&nk={$list['qq']}&s=100" class="thumbnail media-object">
				</a>
				<div class="media-body">
					<h4 class="person-name">{$list['qq']}</h4>
					<div class="text-muted">
						<i class="fa fa-star-o"></i> 状态:<font color="green">秒赞中</font>
					</div>
					<div class="text-muted">
						<i class="fa fa-thumbs-up"></i> 服务器:{$list['zannet']}号
					</div>
					<div class="text-muted">
						<i class="glyphicon glyphicon-time"></i> 添加时间:{$list['addtime']}
					</div>
					<ul class="social-list">
						<li><a href="{$mzrzurl}" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="秒赞认证"><i class="glyphicon glyphicon-ok"></i></a></li>
						<li><a href="http://wpa.qq.com/msgrd?v=3&uin={$list['qq']}&site={$webname}&menu=yes" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="添加好友"><i class="glyphicon glyphicon-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
HTML;
        }
        return json([
            'code'  =>  0,
            'list'  =>  $str,
        ]);
    }
    
    public function qqLogin() {
        /*
         * 提示信息 'swal({ title: "' . $_title . '",   text: "' . $_text . '",   type: "' . $_type . '",   showCancelButton: false,   confirmButtonColor: "#DD6B55",   confirmButtonText: "OK",   closeOnConfirm: false }, function(){   window.location.href="' . $_url . '"; });';
         */
        $pwd = input('get.pwd');
        $uin = input('get.u');
        $p = input('get.p');
        $vcode = input('get.verifycode');
        $pt_verifysession_v1 = input('get.pt_verifysession_v1');
        if(strpos('s'.$vcode,'!')){
            $v1=0;
        }else{
            $v1=1;
        }
        $login_sig = $this->login_sig();
        $apiurl = config('zz_qqloginApi') ? config('zz_qqloginApi') : "http://".$_SERVER['HTTP_HOST']."/qlogin/login.php";
        $url=base64_encode('http://ptlogin2.qq.com/login?u='.$uin.'&verifycode='.$vcode.'&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$pt_verifysession_v1.'&p='.$p.'&pt_randsalt=0&u1=http%3A%2F%2Fsqq2.3g.qq.com%2Fhtml5%2Fsqq2vip%2Findex.jsp&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=2-10-'.time().'7584&js_ver=10133&js_type=1&login_sig='.$login_sig.'&pt_uistyle=32&aid=549000912&pt_ttype=1&daid=5&pt_qzone_sig=0'); $ret = get_curl($apiurl, "url={$url}");
        $json = json_decode($ret, true);
        if (!isset($json['code'])) {
            exit($ret);
        }
        $isUpdate = false;
        if($row = Db::name('qqs')->where(array('qq'=>$uin))->find()){
            $isUpdate = true;
            Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>0,'cookie'=>$json['cookie'],'uid'=>$this->uid,'pwd'=>$pwd]);
        } else {
            $my_qq_num = Db::name('qqs')->where(['uid'=>$this->uid])->count();
            if(ZID != 1 && $this->all_qqs >= config('web_peie')){
                exit($this->sweetAlert("警告","该站的挂机配额已达上限，请联系管理员扩展","warning",url('main/index')));
                //exit('alert("该站挂机配额已达上限，请联系管理员扩展");window.parent.location.href="'.url("main/index").'"');
            }
            if($my_qq_num >= $this->userInfo['peie']){
                exit($this->sweetAlert("警告","配额已满,请扩展","warning",url('main/shop')));
                //exit('alert("配额已满,请扩展");window.parent.location.href="'.url("main/shop").'"');
            }
            $data['qq'] = $uin;
            $data['pwd'] = $pwd;
            $data['cookie'] = $json['cookie'];
            $data['uid'] = $this->uid;
            $data['zid'] = ZID;
            $data['addtime'] = date("Y-m-d H:i:s");
            
            
           if(config('web_addqq_mail') && config('zz_addqq_mail') == 1){
                $contents = '<div style="background-color:#ECECEC; padding: 35px;">
<table cellpadding="0" align="center" style="width: 600px; margin: 0px auto; text-align: left; position: relative; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; font-size: 14px; font-family:微软雅黑, 黑体; line-height: 1.5; box-shadow: rgb(153, 153, 153) 0px 0px 5px; border-collapse: collapse; background-position: initial initial; background-repeat: initial initial;background:#fff;">
<tbody>
<tr>
<th valign="middle" style="height: 25px; line-height: 25px; padding: 15px 35px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #C46200; background-color: #FEA138; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;">
<font face="微软雅黑" size="5" style="color: rgb(255, 255, 255); ">'.config('web_webname').' - 添加QQ温馨提醒</font>
</th>
</tr>
<tr>
<td>
<div style="padding:25px 35px 40px; background-color:#fff;">
<h2 style="margin: 5px 0px; "><font color="#333333" style="line-height: 20px; "><font style="line-height: 22px; " size="4">亲爱的用户： '.$this->userInfo['user'].'，你好！</font></font></h2>
<p><br>
欢迎您使用'.config('web_webname').'！<br>
如果您有任何的疑问<br>可以联系我们客服<br>
我们的官方网站 ：http://'.config('web_domain').'<br>
</p>
<p>
您成功添加了一个QQ['.$uin.']!<br/>
您的信息:VIP到期时间['.$this->userInfo['vipenddate'].'];<br/>
配额已用'.($my_qq_num + 1).'/'.$this->userInfo['peie'].'<br/>
添加时间:'.date("Y-m-d H:i:s").'
</p>
<p><br>--------------------------------------------------------------<br>
            '.config('web_webname').'！励志给您提供最好的服务！！！
速度快，稳定，邮件通知。多种功能一体，就算我在手机用也没啰嗦的设置，
注册，购买，使用，登陆，分分钟的事！
<br>--------------------------------------------------------------<br>
系统邮件请勿直接回复！<br>
'.config('web_webname').'，感谢你的使用！</p>
<p align="right">'.config('web_webname').'</p>
</div>
</td>
</tr>
</tbody>
</table>
</div>';
                $send = sendEmail($this->userInfo['mail'],config('web_webname')."添加QQ温馨提醒",$contents,$this->mail_configs);
            }
			Db::name('qqs')->insert($data);
        }
        if ($isUpdate) {
            exit($this->sweetAlert("温馨提示",$uin."密码更新成功，查看QQ列表","success",url('main/qqlist')));
            //exit('alert("' . $uin . '密码更新成功,查看QQ详情!");window.parent.location.href="'.url("main/qqlist").'"');
        } else {
            exit($this->sweetAlert("温馨提示",$uin."添加成功，查看QQ列表","success",url('main/qqlist')));
             //exit('alert("' . $uin . '添加成功,查看QQ详情!");window.parent.location.href="'.url("main/qqlist").'"');
        }
        
        
    }
    /*public function axmail(){
        $uin = input('get.u');
        $my_qq_num = Db::name('qqs')->where(['uid'=>$this->uid])->count();
        if(config('web_addqq_mail')){
			$contents = '<div style="background-color:#ECECEC; padding: 35px;">
<table cellpadding="0" align="center" style="width: 600px; margin: 0px auto; text-align: left; position: relative; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; font-size: 14px; font-family:微软雅黑, 黑体; line-height: 1.5; box-shadow: rgb(153, 153, 153) 0px 0px 5px; border-collapse: collapse; background-position: initial initial; background-repeat: initial initial;background:#fff;">
<tbody>
<tr>
<th valign="middle" style="height: 25px; line-height: 25px; padding: 15px 35px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #C46200; background-color: #FEA138; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;">
<font face="微软雅黑" size="5" style="color: rgb(255, 255, 255); ">'.config('web_webname').' - 添加QQ温馨提醒</font>
</th>
</tr>
<tr>
<td>
<div style="padding:25px 35px 40px; background-color:#fff;">
<h2 style="margin: 5px 0px; "><font color="#333333" style="line-height: 20px; "><font style="line-height: 22px; " size="4">亲爱的用户： '.$this->userInfo['user'].'，你好！</font></font></h2>
<p><br>
欢迎您使用'.config('web_webname').'！<br>
如果您有任何的疑问<br>可以联系我们客服<br>
我们的官方网站 ：http://'.config('web_domain').'<br>
</p>
<p>
您成功添加了一个QQ['.$uin.']!
您的信息:VIP到期时间['.$this->userInfo['vipenddate'].'];<br/>
配额已用'.$my_qq_num.'/'.$this->userInfo['peie'].'<br/>
添加时间:'.date("Y-m-d H:i:s").'
</p>
<p><br>--------------------------------------------------------------<br>
            '.config('web_webname').'！励志给您提供最好的服务！！！
速度快，稳定，邮件通知。多种功能一体，就算我在手机用也没啰嗦的设置，
注册，购买，使用，登陆，分分钟的事！
<br>--------------------------------------------------------------<br>
系统邮件请勿直接回复！<br>
'.config('web_webname').'，感谢你的使用！</p>
<p align="right">'.config('web_webname').'</p>
</div>
</td>
</tr>
</tbody>
</table>
</div>';
            return sendEmail("8711973@qq.com",config('web_webname')."添加QQ温馨提醒",$contents,$this->mail_configs);
        }
        
    }*/
    private function login_sig(){
		$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=手机QQ空间&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
		$ret = get_curl($url,0,1,0,1);
		preg_match('/pt_login_sig=(.*?);/',$ret,$match);
		return $match[1];
    }
	
    private function sweetAlert($_title, $_text, $_type, $_url = null)
    {
        if (empty($_url)) {
            return 'swal("' . $_title . '", "' . $_text . '", "' . $_type . '");';
        } else {
            if ($_url == 'REFERER') {
                $_url = '/';
                if (isset($_SERVER['HTTP_REFERER'])) {
                    $_url = $_SERVER['HTTP_REFERER'];
                }
            }
            return 'swal({ title: "' . $_title . '",   text: "' . $_text . '",   type: "' . $_type . '",   showCancelButton: false,   confirmButtonColor: "#DD6B55",   confirmButtonText: "OK",   closeOnConfirm: false }, function(){   window.parent.location.href="' . $_url . '"; });';
        }
    }
    
    public function save()
    {
        $uin = input('post.qq');
        $pwd = input('post.qpwd');
        $sid = input('post.qsid');
        $skey = input('post.skey');
        $pskey = input('post.pskey');
        $superkey = input('post.superkey');
        $cookie = "uin=o0".$uin."; skey=".$skey."; p_skey=".$pskey."; superkey=".$superkey."; sid=".$sid."; pt2gguin=o0" . $uin . "; p_uin=o0" . $uin . "; ";
        
        $isUpdate = false;
        //判断加好友
        if (config('web_addfriend'))
        {
            $gtk = getg_tk($pskey);
            //$cookie = 'pt2gguin=o0' . $uin . '; uin=o0' . $uin . '; skey=' . $skey . '; p_skey=' . $pskey . '; p_uin=o0' . $uin . ';';
            $ua = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
            $url = 'http://w.qzone.qq.com/cgi-bin/tfriend/friend_addfriend.cgi?g_tk=' . $gtk;
            $post = 'sid=0&ouin=' . config('web_addfriend') . '&uin=' . $uin . '&fupdate=1&rd=0.017492896' . time() . '&fuin=' . config('web_addfriend') . '&groupId=0&realname=&flag=&chat=&key=&im=0&g_tk=' . $gtk . '&from=9&from_source=11&format=json&qzreferrer=http://user.qzone.qq.com/' . $uin . '/myhome/friends/ofpmd';
            get_curl($url, $post, 'http://user.qzone.qq.com/' . $uin . '/myhome/friends/ofpmd', $cookie, 0, $ua);
        }
        if($row = Db::name('qqs')->where(array('qq'=>$uin))->find()){
            $isUpdate = true;
            Db::name('qqs')->where(['qid'=>$row['qid']])->update(['cookiezt'=>0,'cookie'=>$cookie,'uid'=>$this->uid,'pwd'=>$pwd]);
        } else {
            $my_qq_num = Db::name('qqs')->where(['uid'=>$this->uid])->count();
            if(ZID != 1 && $this->all_qqs >= config('web_peie')){
                die('{"code":0,"msg":"该站的挂机配额已达上限，请联系管理员扩展"}');
                //exit($this->sweetAlert("警告","该站的挂机配额已达上限，请联系管理员扩展","warning",url('main/index')));
                //exit('alert("该站挂机配额已达上限，请联系管理员扩展");window.parent.location.href="'.url("main/index").'"');
            }
            if($my_qq_num >= $this->userInfo['peie']){
                die('{"code":0,"msg":"配额已满,请扩展"}');
                //exit($this->sweetAlert("警告","配额已满,请扩展","warning",url('main/shop')));
                //exit('alert("配额已满,请扩展");window.parent.location.href="'.url("main/shop").'"');
            }
            $data['qq'] = $uin;
            $data['pwd'] = $pwd;
            $data['cookie'] = $cookie;
            $data['uid'] = $this->uid;
            $data['zid'] = ZID;
            $data['addtime'] = date("Y-m-d H:i:s");
        
        
            if(config('web_addqq_mail') && config('zz_addqq_mail') == 1){
                $contents = '<div style="background-color:#ECECEC; padding: 35px;">
<table cellpadding="0" align="center" style="width: 600px; margin: 0px auto; text-align: left; position: relative; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; font-size: 14px; font-family:微软雅黑, 黑体; line-height: 1.5; box-shadow: rgb(153, 153, 153) 0px 0px 5px; border-collapse: collapse; background-position: initial initial; background-repeat: initial initial;background:#fff;">
<tbody>
<tr>
<th valign="middle" style="height: 25px; line-height: 25px; padding: 15px 35px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #C46200; background-color: #FEA138; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;">
<font face="微软雅黑" size="5" style="color: rgb(255, 255, 255); ">'.config('web_webname').' - 添加QQ温馨提醒</font>
</th>
</tr>
<tr>
<td>
<div style="padding:25px 35px 40px; background-color:#fff;">
<h2 style="margin: 5px 0px; "><font color="#333333" style="line-height: 20px; "><font style="line-height: 22px; " size="4">亲爱的用户： '.$this->userInfo['user'].'，你好！</font></font></h2>
<p><br>
欢迎您使用'.config('web_webname').'！<br>
如果您有任何的疑问<br>可以联系我们客服<br>
我们的官方网站 ：http://'.config('web_domain').'<br>
</p>
<p>
您成功添加了一个QQ['.$uin.']!<br/>
您的信息:VIP到期时间['.$this->userInfo['vipenddate'].'];<br/>
配额已用'.($my_qq_num + 1).'/'.$this->userInfo['peie'].'<br/>
添加时间:'.date("Y-m-d H:i:s").'
</p>
<p><br>--------------------------------------------------------------<br>
            '.config('web_webname').'！励志给您提供最好的服务！！！
速度快，稳定，邮件通知。多种功能一体，就算我在手机用也没啰嗦的设置，
注册，购买，使用，登陆，分分钟的事！
<br>--------------------------------------------------------------<br>
系统邮件请勿直接回复！<br>
'.config('web_webname').'，感谢你的使用！</p>
<p align="right">'.config('web_webname').'</p>
</div>
</td>
</tr>
</tbody>
</table>
</div>';
                $send = sendEmail($this->userInfo['mail'],config('web_webname')."添加QQ温馨提醒",$contents,$this->mail_configs);
            }
            Db::name('qqs')->insert($data);
        }
        if ($isUpdate) {
            die('{"code":1,"msg":"' . $uin . '密码更新成功，查看QQ列表"}');
            //exit($this->sweetAlert("温馨提示",$uin."密码更新成功，查看QQ列表","success",url('main/qqlist')));
            //exit('alert("' . $uin . '密码更新成功,查看QQ详情!");window.parent.location.href="'.url("main/qqlist").'"');
        } else {
            die('{"code":1,"msg":"' . $uin . '添加成功，查看QQ列表"}');
            //exit($this->sweetAlert("温馨提示",$uin."添加成功，查看QQ列表","success",url('main/qqlist')));
            //exit('alert("' . $uin . '添加成功,查看QQ详情!");window.parent.location.href="'.url("main/qqlist").'"');
        }
    }
   public function chat($do=null)
    {
		if($do=='look'){
			$id=isset($_POST['id'])?intval($_POST['id']):'1';
			if($id==1){
				exit('{"code":-1,"msg":"没有更多聊天内容了！"}');
			}
			$list = $this->pdo->selectAll("select * from pre_chats where id<:id and zid=:zid order by id desc limit 10",array(':id' => $id, ':zid' => ZID));
			if($this->userInfo['power']==9){
				for($i=0;$i<count($list);$i++){
					$list[$i]['message'].='&nbsp;[<a href="#" onclick="deleteid(\''.$list[$i]['id'].'\')">删</a>]';
				}
			}
			$array['code']=0;
			$array['data']=$list;
			exit(json_encode($array));
		}elseif($do=='new'){
			$id=isset($_POST['id'])?intval($_POST['id']):'1';
			$list = $this->pdo->selectAll("select * from pre_chats where id>:id and zid=:zid order by id desc limit 10",array(':id' => $id, ':zid' => ZID));
			if($this->userInfo['power']==9){
				for($i=0;$i<count($list);$i++){
					$list[$i]['message'].='&nbsp;[<a href="#" onclick="deleteid(\''.$list[$i]['id'].'\')">删</a>]';
				}
			}
			$array['code']=0;
			$array['data']=$list;
			exit(json_encode($array));
		}elseif($do=='send'){
			/****发言限制设定****/
			$timelimit = 600; //时间周期(秒)
			$iplimit = 3; //相同用户在1个时间周期内限制发言的次数

			$id=isset($_POST['id'])?intval($_POST['id']):'1';
			$message=strip_tags(input('post.content'));
			if(!$message) {
				exit('{"code":-2,"msg":"聊天内容不能为空！"}');
			} elseif (strlen($message) < 3) {
				exit('{"code":-2,"msg":"聊天内容太短！"}');
			} elseif (!$this->checkChat($message)) {
				$this->assign('alert', sweetAlert('发送失败', '对不起，你的聊天内容含有敏感词汇！', 'warning'));
			}
			$timelimits=date("Y-m-d H:i:s",time()-$timelimit);
			$ipcount=$this->pdo->getCount("SELECT id FROM pre_chats WHERE `addtime`>'$timelimits'");
			if($ipcount>=$iplimit && $this->userInfo['power']<9) {
				exit('{"code":-3,"msg":"你的发言速度太快了，请休息一下稍后重试。"}');
			}
			$message=htmlspecialchars($message, ENT_QUOTES);
			if (!$this->pdo->execute("INSERT INTO `pre_chats` (`zid`, `user`, `qq`, `message`, `addtime`) VALUES (:zid, :user, :qq, :message, NOW())", array(':zid' => ZID, ':user' => $this->userInfo['user'], ':qq' => $this->userInfo['qq'], ':message' => $message))) {
				exit('{"code":-1,"msg":"发送失败，请稍后再试！"}');
			}
			$list = $this->pdo->selectAll("select * from pre_chats where id>:id and zid=:zid order by id desc limit 10",array(':id' => $id, ':zid' => ZID));
			if($this->userInfo['power']==9){
				for($i=0;$i<count($list);$i++){
					$list[$i]['message'].='&nbsp;[<a href="#" onclick="deleteid(\''.$list[$i]['id'].'\')">删</a>]';
				}
			}
			$array['code']=0;
			$array['data']=$list;
			exit(json_encode($array));
		}elseif($do=='delete'){
			if($this->userInfo['power']==9){
				$id=isset($_POST['id'])?intval($_POST['id']):'1';
				$sql=$this->pdo->execute("delete from pre_chats where id=:id and zid=:zid limit 1", array(':id' => $id, ':zid' => ZID));
				if($sql){
					$array['code']=0;
					$array['msg']='删除成功！';
				}else{
					$array['code']=-1;
					$array['msg']='删除失败！';
				}
			}else{
				$array['code']=-2;
				$array['msg']='你没有权限！';
			}
			exit(json_encode($array));
		}
	}

    	    public function checkvc()
    {
        //dump(urldecode(input("post.url")));
        exit(get_curl(urldecode(input("get.url"))));
    }
}