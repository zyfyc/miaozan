<?php
// +----------------------------------------------------------------------
// | Quotes [ 没有目标的人生就是张拼图，反之则是蓝图]
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 云影 <8711973@qq.com>
// +----------------------------------------------------------------------
// | Date: 2017年2月8日
// +----------------------------------------------------------------------
namespace app\model;

class Qzone {
    public $msg;
    public $error;
    public $skeyzt;
	private $qzonetoken;

    public function __construct($uin, $info = array()) {
        $this->uin = $uin;
        $this->sid = $info['sid'];
        $this->skey = $info['skey'];
        $this->gtk = $this->getGTK($info['pskey']);
        $this->cookie = 'pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$info['skey'].'; p_skey='.$info['pskey'].'; p_uin=o0'.$uin.';';
    }

    public function cpshuo($content,$richval='',$sname='',$lon='',$lat=''){
		$url='http://mobile.qzone.qq.com/mood/publish_mood?qzonetoken='.$this->getToken().'&g_tk='.$this->gtk;
		$post='opr_type=publish_shuoshuo&res_uin='.$this->uin.'&content='.urlencode($content).'&richval='.$richval.'&lat='.$lat.'&lon='.$lon.'&lbsid=&issyncweibo=0&is_winphone=2&format=json&source_name='.$sname;
		$result=$this->get_curl($url,$post,1,$this->cookie);
		$arr=json_decode($result,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]=$this->uin.' 发布说说成功[CP]';
			return '发布成功！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 发布说说失败[CP]！原因:SID已失效，请更新SID';
			return true;
		}elseif(@array_key_exists('code',$arr)){
			$this->msg[]=$this->uin.' 发布说说失败[CP]！原因:'.$arr['message'];
			return true;
		}else{
			$this->msg[]=$this->uin.' 发布说说失败[CP]！原因:'.$result;
			return true;
		}
	}

    public function pcshuo($content,$richval=0){
		$url='http://taotao.qq.com/cgi-bin/emotion_cgi_publish_v6?g_tk='.$this->gtk;
		$post='syn_tweet_verson=1&paramstr=1&pic_template=';
		if($richval){
			$post.="&richtype=1&richval=".$this->uin.",{$richval}&special_url=&subrichtype=1&pic_bo=uAE6AQAAAAABAKU!%09uAE6AQAAAAABAKU!";
		}else{
			$post.="&richtype=&richval=&special_url=";
		}
		$post.="&subrichtype=&con=".urlencode($content)."&feedversion=1&ver=1&ugc_right=1&to_tweet=0&to_sign=0&hostuin=".$this->uin."&code_version=1&format=json&qzreferrer=http%3A%2F%2Fuser.qzone.qq.com%2F".$this->uin."%2F311";
		$ua = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0";
		$json=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin.'/311',$this->cookie);
		if($json){
			$arr=json_decode($json,true);
			$arr['feedinfo']='';
			if(@array_key_exists('code',$arr) && $arr['code']==0){
				$this->msg[]=$this->uin.' 发布说说成功[PC]';
				return '发布成功！';
			}elseif($arr['code']==-3000){
				$this->skeyzt=1;
				$this->msg[]=$this->uin.' 发布说说失败[PC]！原因:SID已失效，请更新SID';
				return true;
			}elseif($arr['code']==-10045){
				$this->msg[]=$this->uin.' 发布说说失败[PC]！原因:'.$arr['message'];
				return true;
			}elseif(@array_key_exists('code',$arr)){
				$this->msg[]=$this->uin.' 发布说说失败[PC]！原因:'.$arr['message'];
				return true;
			}else{
				$this->msg[]=$this->uin.' 发布说说失败[PC]！原因'.$json;
				return true;
			}
		}else{
			$this->msg[]=$this->uin.' 获取发布说说结果失败[PC]';
			return true;
		}
	}

    public function shuo($do = 0, $content, $image = 0, $type = 0, $sname = '') {
        $richval = null;
        if (!$type && $image) {
            if ($pic = $this->get_curl($image)) {
				$image_size = getimagesize($image);
                $richval = $this->uploadimg($pic, $image_size);
            }
        } else {
            $richval = $image;
        }

        if ($do) {
            return $this->pcshuo($content, $richval);
        } else {
            return $this->cpshuo($content, $richval);
        }

    }

    public function getGTK($skey) {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
            $hash &= 0x7fffffff;
        }
        return $hash & 0x7fffffff; //计算g_tk
    }

    public function uploadimg($image,$image_size=array()){
		$url='http://mobile.qzone.qq.com/up/cgi-bin/upload/cgi_upload_pic_v2?qzonetoken='.$this->getToken().'&g_tk='.$this->gtk2;
        $post='picture='.urlencode(base64_encode($image)).'&base64=1&hd_height='.$image_size[1].'&hd_width='.$image_size[0].'&hd_quality=90&output_type=json&preupload=1&charset=utf-8&output_charset=utf-8&logintype=sid&Exif_CameraMaker=&Exif_CameraModel=&Exif_Time=&uin='.$this->uin;
        $data=preg_replace("/\s/","",$this->get_curl($url,$post,1,$this->cookie,0,1));
		preg_match('/_Callback\((.*)\);/',$data,$arr);
		$data=json_decode($arr[1],true);
        if($data && array_key_exists('filemd5',$data)){
			$this->msg[]='图片上传成功！';
			$post='output_type=json&preupload=2&md5='.$data['filemd5'].'&filelen='.$data['filelen'].'&batchid='.time().rand(100000,999999).'&currnum=0&uploadNum=1&uploadtime='.time().'&uploadtype=1&upload_hd=0&albumtype=7&big_style=1&op_src=15003&charset=utf-8&output_charset=utf-8&uin='.$this->uin.'&logintype=sid&refer=shuoshuo';
			$img=preg_replace("/\s/","",$this->get_curl($url,$post,1,$this->cookie,0,1));
			preg_match('/_Callback\(\[(.*)\]\);/',$img,$arr);
			$data=json_decode($arr[1],true);
            if($data && array_key_exists('picinfo',$data)){
				if($data[picinfo][albumid]!=""){
					$this->msg[]='图片信息获取成功！';
					return ''.$data['picinfo']['albumid'].','.$data['picinfo']['lloc'].','.$data['picinfo']['sloc'].','.$data['picinfo']['type'].','.$data['picinfo']['height'].','.$data['picinfo']['width'].',,,';
				}else{
					$this->msg[]='图片信息获取失败！';
					return;
				}
            }else{
                $this->msg[]='图片信息获取失败！';
                return;
            }
		}else{
			$this->msg[]='图片上传失败！原因：'.$data['msg'];
            return;
        }
	}

	private function getToken(){
		if($this->qzonetoken)return $this->qzonetoken;
        $url='https://h5.qzone.qq.com/mqzone/index';
		$json=$this->get_curl($url,0,0,$this->cookie);
		preg_match('/shine0callback = \'(.*?)\';/i',$json,$match);
		if($match[1]){
			$this->qzonetoken=$match[1];
			return $this->qzonetoken;
		}else{
			$this->msg[]='获取qzonetoken失败！';
			return false;
		}
    }

    public function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $head = 0, $ua = 0, $nobaody = 0) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($head) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            if ($referer == 1) {
                curl_setopt($ch, CURLOPT_REFERER, "http://h5.qzone.qq.com/mqzone/index");
            } else {
                curl_setopt($ch, CURLOPT_REFERER, $referer);
            }
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);//主要头部
        }
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;

    }
}