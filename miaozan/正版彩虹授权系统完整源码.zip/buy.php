<?php
include("api.inc.php");
if($_POST['do'] == 'do'){
	$km = $_POST['km'];
	$qq = $_POST['qq'];
	$url = $_POST['url'];
	$date = date("Y-m-d H-i-s");
	$row1=$DB->get_row("SELECT * FROM auth_site WHERE 1 order by sign desc limit 1");
	$row2=$DB->get_row("SELECT * FROM auth_site WHERE uid='{$qq}' limit 1");
	$row3=$DB->get_row("SELECT * FROM auth_site WHERE url='{$url}' limit 1");
	$sign=$row1['sign']+1;
	$authcode=md5(random(32).$qq);
	$row = $DB->get_row("SELECT * FROM auth_kms WHERE km = '{$km}'");
	if($km == '' or $qq == '' or $url ==''){
		exit("<script language='javascript'>alert('所有项不能留空!');history.go(-1);</script>");
	}
	if(!$row){
		exit("<script language='javascript'>alert('此卡密不存在!');history.go(-1);</script>");
	}else if($row['zt'] == '0'){
		exit("<script language='javascript'>alert('此卡密已使用！');history.go(-1);</script>");
	}else if($row3 != ''){
		exit("<script language='javascript'>alert('平台已存在此域名!');history.go(-1);</script>");
	}else if($row2 != ''){
		$DB->query("update auth_kms set zt = '0' where id='{$row['id']}'");
		$DB->query("INSERT INTO auth_site (`uid`, `url`, `date`, `authcode`, `sign`,`active`) VALUES ('$qq', '$url', '$date', '".$row2['authcode']."', '".$row2['sign']."', '1')");
		exit("<script language='javascript'>alert('授权成功!');history.go(-1);</script>");
	}else{
		$DB->query("update auth_kms set zt = '0' where id='{$row['id']}'");
		$DB->query("INSERT INTO auth_site (`uid`, `url`, `date`, `authcode`, `sign`,`active`) VALUES ('$qq', '$url', '$date', '$authcode', '$sign', '1')");
		exit("<script language='javascript'>alert('授权成功!');history.go(-1);</script>");
	}
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <title>自助授权</title>
    <!--baidu-->
    <meta name="baidu-site-verification" content="4IPJiuihDj" />
    <!-- Bootstrap -->
    <link href="http://cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script> 
function stop(){ return false; } 
document.oncontextmenu=stop; 
</script> 
</head>
<body>
<div class="container">    <div class="header">
        <ul class="nav nav-pills pull-right" role="tablist">
          <li role="presentation"><a href="index.php">正版查询</a></li>
          <li role="presentation"><a href="get">下载程序</a></li>
        </ul>
        <h3 class="text-muted" align="left">自助授权</h3>
     </div><hr>
     <div class="col-sm-2"></div>
     <div class="col-sm-8" style="margin-top:50px"> 
<div class="panel panel-primary">
  <div class="panel-heading">自助授权</div>
  <div class="panel-body">
    <form class="form-horizontal" method="post" action="">
    <input type="hidden" name="do" value="do">
  <div class="form-group">
    <label class="col-sm-2 control-label">卡密</label>
    <div class="col-sm-10">
      <input type="text" name="km" class="form-control" placeholder="请输入卡密!">
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">域名</label>
    <div class="col-sm-10">
      <input type="text" name='url' class="form-control" placeholder="请输入域名(不加http://)">
    </div>
      </div>
    <div class="form-group">
    <label class="col-sm-2 control-label">QQ</label>
    <div class="col-sm-10">
      <input type="text" name='qq' class="form-control" placeholder="请输入QQ!">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">确认授权</button>
    </div>
  </div>
</form>
  </div>
    <div class="panel-footer text-center"><a href="http://wpa.qq.com/msgrd?v=3&uin=2326575218&site=qq&menu=yes">点击购买卡密</a></div>
  </div>
<div class="col-sm-2"></div>
	 <hr>
</body>
</html>