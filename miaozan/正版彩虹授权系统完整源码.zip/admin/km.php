<?php
$mod='blank';
include("../api.inc.php");
$title='卡密生成';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$num = $_POST['num'];
function getkmkey($len = 16)
{
    $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $strlen = strlen($str);
    $randstr = '';
    for ($i = 0; $i < $len; $i++) {
        $randstr .= $str[mt_rand(0, $strlen - 1)];
    }
    return $randstr;
}
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">小杰代挂授权平台</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li>
            <a href="./"><span class="glyphicon glyphicon-user"></span> 平台首页</a>
          </li>
          <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-cloud"></span> 授权管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="./list.php">授权列表</a></li>
              <li><a href="./add.php">添加授权</a><li>
			  <li><a href="./addsite.php">添加站点</a><li>
			  <li><a href="./search.php">搜索授权</a><li>
                                        <li><a href="./km.php">生成卡密</a><li>
            </ul>
          </li>
		  <li><a href="./downfile.php"><span class="glyphicon glyphicon-thumbs-up"></span> 下载管理</a></li>
		  <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-globe"></span> 盗版管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="./pirate.php">站点列表</a></li>
              <li><a href="./getpwd.php">获取密码</a><li>
              <li><a href="./userlist.php">用户列表</a></li>
              <li><a href="./adduser.php">添加用户</a><li>
            </ul>
          </li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
	<div class="container"> 
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="margin-top:100px">
<div class="panel panel-primary">
  <div class="panel-heading">卡密生成</div>
  	<div class="panel-body">
<form method="post" action="" >
<input type="hidden" name="do" value="do">
<div class="input-group">
              <span class="input-group-addon">卡密个数</span>
              <input type="text" name="num"  class="form-control" placeholder="输入需要生成的个数">
            </div><br/>
<div class="col-sm-12"><input type="submit" value="确认生成" class="btn btn-primary form-control"/></div>
</from>
</div>
  <div class="panel-footer text-center">请你需要多少生成多少</div>
	</div>
		</div>
		<div class="col-sm-2"></div>
		<div class="col-sm-12" style="margin-top:10px">
	  <div class="panel panel-primary">
	  <div class="panel-heading">生成结果</div>
  	<div class="panel-body">
      <?php
if ($_POST['do'] != 'do') {
	echo "生成成功后将显示成功生成的卡密内容!";
}
if ($_POST['do'] == 'do') {
	echo "卡密生成成功，以下内容为生成的卡密!<br>";
	if ($num != '') {
		for ($i=1;$i<=$num;$i++) {
			$key = getkmkey();
			$DB->query("INSERT INTO `auth_kms` (`km`, `zt`) VALUES ('$key', '1')");
			echo $key.'<br>';
		}
	}else{
		exit("<script language='javascript'>alert('所有值不能为空！');history.go(-1);</script>");
	}
}
?>
</div>
<div>
</div>
</div>