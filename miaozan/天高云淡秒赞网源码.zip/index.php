<?php
// +----------------------------------------------------------------------
// | TGSPHP [ The most convenient framework ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://otodo.cc All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dragon <1340176819@qq.com>
// +----------------------------------------------------------------------

// [ 应用入口文件 ]

// 自定义应用目录
define('USER_PATH', __DIR__ . '/mgmt/');

define('ADMIN_PATH', __DIR__ . '/admin/');

define('CONN_PATH', __DIR__ . '/includes/');

//检查是否安装并获取数据库信息
if (!file_exists(CONN_PATH . '/db.php')) {
    header("Location:/install");
    exit();
}

//删除之前的robots限制文件
if (file_exists('robots.txt')) {
    @unlink('robots.txt');
}

//PHP版本支持检测
if (version_compare(PHP_VERSION, '5.3.0', '<')) {
    exit('require PHP > 5.3.0 !');
}

// 加载框架引导文件
require CONN_PATH . "/common.php";

if ($_GET['rand'] && $_COOKIE['tgyd_session'] != $_GET['rand']) {
    @header("Location:");
    exit();
}

if (!$_COOKIE['tgyd_session']) {
    if (!getspider()) {
        $session = md5(uniqid() . rand(1, 1000) . '1340176819');
        $_SESSION['tgyd_session'] = $session;
        setcookie("tgyd_session", $session, time() + 3600 * 24 * 14, '/');
        exit("<script language='javascript'>window.location.href='?{$_SERVER['QUERY_STRING']}&rand={$session}';</script>");
    }
}
if (C("version") != "1600") {
    if (!$install) {
        echo '请先完成网站升级！<a href="/install/update.php"><font color=red>点此升级</font></a>';
        exit;
    }
}
// 加载首页
include_once($index_mgmt);
?>