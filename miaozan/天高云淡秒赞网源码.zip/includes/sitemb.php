<?php
if (!defined('IF_CONF')) {
    exit;
}
$index = C("index_web");
$login = C("login_web");
$localhost = 'http://' . $_SERVER['SERVER_NAME'] . '/';

if ($index== 1) {
    $index_mgmt = 'other/index/tgv3.php';
} elseif ($index == 2) {
    $index_mgmt = 'other/index/mytg.php';
} elseif ($index == 3) {
    $index_mgmt = 'other/index/tgv2.php';
}

if ($login== 1) {
    $login_mgmt = 'login.php';
} elseif ($login == 2) {
    $login_mgmt = 'login1.php';
} elseif ($login == 3) {
    $login_mgmt = 'login2.php';
}

if ($find== 1) {
    $find_mgmt = 'find.php';
}
?>