<?php
// +----------------------------------------------------------------------
// | TGSPHP [ The most convenient framework ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://otodo.cc All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dragon <1340176819@qq.com>
// +----------------------------------------------------------------------

//Head
error_reporting(0);
@date_default_timezone_set('Asia/Shanghai');
@header('Content-Type: text/html; charset=UTF-8');

//Conn
define('IF_CONF', true);
define('VERSION', '1620');
define('Htkver', '1.00');
define('TIMESTAMP', time());
define('USER_PATH', '/mgmt/');
define('ADMIN_PATH', '/admin/');
define('CONN_PATH', '/includes/');
include_once "functions.php";
include_once "360_safe3.php";
include_once "authcode.php";
define('authcode', $authcode);
$domain = $_SERVER['HTTP_HOST'];

$mysql = (require "db.php");
try {
    $db = new PDO("mysql:host=" . $mysql['DB_HOST'] . ";dbname=" . $mysql['DB_NAME'] . ";port=" . $mysql['DB_PORT'], $mysql['DB_USER'], $mysql['DB_PWD']);
} catch (Exception $e) {
    exit('链接数据库失败:' . $e->getMessage());
}
$db->exec("set names utf8");
$stmt = $db->prepare("select * from tgyd_separate where urls=:urls limit 1");
$stmt->execute(array(':urls' => $domain));
if ($separate = $stmt->fetch(PDO::FETCH_ASSOC)) {
    if (!$separate['zt']) {
        exit("该站已被禁！");
    }
    $prefix = $separate['prefix'] . "_";
    $endtime = $separate['endtime'];
    $now = date("Y-m-d");
    if ($endtime <= $now) {
        exit("该站已经过期！");
    }
    $isdomain = 1;
} else {
    $prefix = $mysql['DB_PREFIX'];
}
if ($rows = $db->query('select * from ' . $prefix . 'webconfigs')) {
    while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
        $webconfig[$row['vkey']] = $row['value'];
    }
    C($webconfig);
}
if (C('txprotect') == '1')include 'txprotect.php';
//Other
include_once "site.inc.php";
include_once "siteapi.php";
include_once "sitemb.php";
$site_self = $_SERVER['PHP_SELF'];
$site_urlpara = $_SERVER['PHP_SELF'];
?>