<?php
if (!defined('IF_CONF')) {
    exit;
}
$qqlogin = C("api_qqlogin");
$qqfunc = C("api_qqfunc");
$webcdn = C("api_webcdn");
$qqyzm = C("api_qqloginyzm");
$login = C("api_login");
$localhost = 'http://' . $_SERVER['SERVER_NAME'] . '/';
if ($qqlogin == 1) {
    $qqlogin_api = 'http://tgapi.sh.yunqzan.com';
} elseif ($qqlogin == 2) {
    $qqlogin_api = 'http://qqlogin.api.odoto.cc';
} elseif ($qqlogin == 3) {
	$qqlogin_api = 'http://qqlogin.api.1sll.cc';
} else {
    $qqlogin_api = 'http://os.odoto.cc';
}

if ($qqfunc == 1) {
    $qqfunc_api = 'http://qqfunc.api.odoto.cc';
} else {
    $qqfunc_api = '';
}

if ($qqfunc == 1) {
    $qqfunc2_api = 'http://qqfunc.api.odoto.cc';
} else {
    $qqfunc2_api = 'http://' . $_SERVER['HTTP_HOST'];
}

if ($qqfunc == 1) {
    $qqfunc3_api = 'http://qqfunc.api.odoto.cc';
} else {
    $qqfunc3_api = 'http://os.odoto.cc';
}

if ($webcdn == 1) {
    $webcdn_api = '//cdn.api.odoto.cc';
} elseif ($webcdn == 2) {
    $webcdn_api = '//tg.lly.1sll.cc/';
} else {
    $webcdn_api = '';
}

if ($qqyzm == 1) {
    $qqyzm_api = 'https://www.qqmiaozan.com/other/getpic.php';
} elseif ($qqyzm == 2) {
    $qqyzm_api = 'http://qqlogin.api.odoto.cc/getpic.php';
} else {
    $qqyzm_api = 'getpic.php';
}

if ($login == 1) {
    $login_api = '//cdn.api.odoto.cc';
} elseif ($login == 2) {
    $login_api = '//tg.lly.1sll.cc';
} else {
    $login_api = '//cdn.api.odoto.cc';
}

?>