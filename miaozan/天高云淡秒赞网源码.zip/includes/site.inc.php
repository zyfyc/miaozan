<?php

$cookiesid = $_COOKIE['tgyd_sid'];

if (preg_match('/^[0-9a-z]{32}$/i', $cookiesid)) {

    $stmt = $db->prepare("select * from {$prefix}users where sid =:sid limit 1");

    $stmt->execute(array(':sid' => safestr($cookiesid)));

    if ($cookiesid && ($userrow = $stmt->fetch(PDO::FETCH_ASSOC))) {

        C('loginuser', $userrow['user']);

        C('loginuid', $userrow['uid']);

    }

}

?>