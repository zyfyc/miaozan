<?php
return array(
	'DB_HOST'               =>  'localhost',
    'DB_NAME'               =>  '123',
    'DB_USER'               =>  '123',
    'DB_PWD'                =>  '123',
    'DB_PORT'               =>  '3306',
    'DB_PREFIX'             =>  'tgyd_',
);