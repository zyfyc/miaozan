<?php
/*
 *Name：冰清玉洁秒赞专用QQ自动更新文件
 *Author: 顾念 <2302701417@qq.com>
 *Date: 2017/03/14
 *请珍惜作者努力。人在做，天在看！
*/
include_once '../includes/common.php';
include_once '../includes/chaoren.class.php';
require_once '../mgmt/qlogin.class.php';
$result = $db->query("select * from {$prefix}qqs where skeyzt='1' and (gxmsg<>'-3' or gxmsg<>'-2') order by rand() limit 5");
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $stmt = $db->query("select * from {$prefix}users where uid='" . $row['uid'] . "' limit 1");
    $userrow = $stmt->fetch(PDO::FETCH_ASSOC);
    if (get_isvip($userrow['vip'], $userrow['vipend'])) $isvip = 1;
    $uin = $row['qq'];
    $pwd = $row['pwd'];
    $time = date("Y-m-d H:i:s");
    $sub = 'QQ状态失效提醒';
    $msg = '您的QQ' . $row['qq'] . '状态已失效，且自动更新失败，请到' . C("webname") . "进行更新！" . $time;
	$data = new Qqlogin($uin, $pwd, $code, $sig,$cap_cd,$sess); 
	$qqs = json_decode($data->json, true);
    $check = checkvc($uin);
    if ($check['saveOK'] != 0) {
        if (C('chaoren_user') && C('chaoren_pwd') && $isvip == 1) {
            $chaoren = new Chaorendama(C('chaoren_user'), C('chaoren_pwd'));
            $sig = $check['sig'];
            $cap_cd = $check['cap_cd'];
			$sess = $check['sess'];
            $array = getvc2($uin,$sig,$sess);
            if ($array['saveOK'] == 0) {
                $bin = getvcpic($uin,$sess,$array['vc']);
                $dama_arr = $chaoren->recv_byte(bin2hex($bin));
                $arrays = dovc($uin,$sess, $array['vc'], $dama_arr['result']);
                if ($arrays['rcode'] == 0) {
                    $code = $arrays['randstr'];
                    $sig = $arrays['sig'];
                    $is = 1;
                } elseif ($arrays['rcode'] == 50) {
                    $chaoren->report_err($dama_arr['imgId']);
                    echo $uin . 'do code failure<br/>';
                    $db->query("UPDATE {$prefix}qqs SET gxmsg='-3',nextauto='{$time}' WHERE qq='{$uin}'");
                } elseif ($arrays['rcode'] == 12) {
                    $code = $dama_arr['result'];
                    $sig = $array['vc'];
                    $is = 1;
                } else {
                    $chaoren->report_err($dama_arr['imgId']);
                    echo $uin . ' code error<br/>';
                    $db->query("UPDATE {$prefix}qqs SET gxmsg='-3',nextauto='{$time}' WHERE qq='{$uin}'");
                }
            } else {
                echo $uin . ' obtain code failure<br/>';
                $db->query("UPDATE {$prefix}qqs SET gxmsg='-3',nextauto='{$time}' WHERE qq='{$uin}'");
            }
        } else {
            echo $uin . ' need code<br/>';
            $db->query("UPDATE {$prefix}qqs SET gxmsg='-2',nextauto='{$time}' WHERE qq='{$uin}'");
        }

    } else {
        $is = 1;
        //无需验证码
    }
    if (isset($is)) {
          if (isset($code)) {
         $data = new Qqlogin($uin, $pwd, $code, $sig,$cap_cd,$sess); 
        } 
         $qqs = json_decode($data->json, true);
        if ($qqs['code'] == -3) {
            //其他原因
            @$db->query("UPDATE {$prefix}qqs SET gxmsg='-3',nextauto='{$time}' WHERE qq='{$uin}'");
            if (C("email_user") and C("email_host") and C("email_port") and C("email_pwd")) send_mail(C("email_user"), C("email_host"), C("email_port"), C("email_pwd"), C('webname'), $userrow['qq'] . "@qq.com", $sub, $msg);
            echo $uin . $qqs['msg'] . '<br/>';
        } else {
            //更新成功
            if ($qqs['skey'] && $qqs['pookie'] && $qqs['p_skey']) {
                $skey = $qqs['skey'];
                $p_skey = $qqs['p_skey'];
                $pookie = $qqs['pookie'];
                $set = "skey='{$skey}',gxmsg='0',nextauto='{$time}',p_skey='{$p_skey}',pookie='{$pookie}',sidzt=0,skeyzt=0";
                $db->query("update {$prefix}qqs set {$set} where qq='{$uin}'");
                echo $uin . 'update success<br/>';
            } else {
                $db->query("UPDATE {$prefix}qqs SET gxmsg='-3',nextauto='{$time}' WHERE qq='{$uin}'");
                if (C("email_user") and C("email_host") and C("email_port") and C("email_pwd")) send_mail(C("email_user"), C("email_host"), C("email_port"), C("email_pwd"), C('webname'), $userrow['qq'] . "@qq.com", $sub, $msg);
                echo $uin . 'update failure<br/>';
            }
        }
        if (isset($code)) {
            unset($code);
            unset($sig);
        }
    }
}
exit("Updated completely");

function dovc($uin, $sig, $ans,$cap_cd,$sess)
{
    if (empty($uin)) return array('saveOK' => -1, 'msg' => 'QQ不能为空');
    if (empty($sig)) return array('saveOK' => -1, 'msg' => 'sig不能为空');
    if (empty($ans)) return array('saveOK' => -1, 'msg' => '验证码不能为空');
	if(empty($cap_cd))return array('saveOK'=>-1,'msg'=>'cap_cd不能为空');
    if(empty($sess))return array('saveOK'=>-1,'msg'=>'sess不能为空');
    $url='http://captcha.qq.com/cap_union_new_verify';
	$post='aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd=613819&rand=0.7449361890054536&sess='.$sess.'&subcapclass=0&vsig='.$sig.'&ans='.$ans;
    $data = get_curls($url,$post);
    if (preg_match("/cap\_InnerCBVerify\((.*?)\);/", $data, $json)) {
        $json = str_replace(array('{', ':', ','), array('{"', '":', ',"'), $json[1]);
        $arr = json_decode($json, true);
        return $arr;
    } else {
        return array('rcode' => 0, 'errmsg' => '验证失败，请重试。');
    }
}

 function getvcpic($uin,$sig,$cap_cd,$sess){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'QQ不能为空');
		if(empty($sig))return array('saveOK'=>-1,'msg'=>'sig不能为空');
		$url='http://captcha.qq.com/cap_union_new_getcapbysig?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999).'&rand=0.02398118'.time().'&sess='.$sess.'&vsig='.$sig.'&ischartype=1';
		return get_curls($url);
	}
	
function getvc2($uin, $sig,$sess)
{
    if($sess=='0'){
			$url='http://captcha.qq.com/cap_union_new_show?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$sig.'&rnd='.rand(100000,999999);
			$data=get_curl($url);
        if (preg_match("/g\_click\_cap\_sig=\"(.*?)\"/", $data, $arr)) {
            return array('saveOK' => 0, 'vc' => $arr[1],'sess'=>$arr[1]);
        } else {
            return array('saveOK' => -3, 'msg' => '获取验证码失败');
        }
    } else {
        $url='http://captcha.qq.com/cap_union_new_getsig';
			$post='aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&cap_cd='.$sig.'&rnd=634076&rand=0.37335288'.time().'&sess='.$sess;
			$data=get_curl($url,$post);
        if (preg_match("/cap_getCapBySig\(\"(.*?)\"\);/", $data, $arr)) {
            return array('saveOK' => 0, 'vc' => $arr[1]);
        } else {
            return array('saveOK' => -3, 'msg' => '获取验证码失败');
        }
    }
}
 function checkvc($uin){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'请先输入QQ号码');
		if(!preg_match("/^[1-9][0-9]{4,13}$/",$uin)) exit('{"saveOK":-2,"msg":"QQ号码不正确"}');
		$url='http://check.ptlogin2.qq.com/check?pt_tea=2&uin='.$uin.'&appid=549000912&ptlang=2052&regmaster=&pt_uistyle=9&r=0.397176'.time();
		$data=get_curl($url);
		if(preg_match("/ptui_checkVC\('(.*?)'\);/", $data, $arr)){
			$r=explode("','",$arr[1]);
			if($r[0]==0){
				return array('saveOK'=>0,'uin'=>$uin,'vcode'=>$r[1],'pt_verifysession'=>$r[3]);
			}else{
				return array('saveOK'=>1,'uin'=>$uin,'sig'=>$r[1]);
			}
		}else{
			return array('saveOK'=>-3,'msg'=>'获取验证码失败');
		}
	}

function get_curls($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $httpheader[] = "Accept:application/json";
    $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
    $httpheader[] = "Connection:close";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        curl_setopt($ch, CURLOPT_REFERER, "http://ptlogin2.qq.com/");
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);

    }
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}

?>