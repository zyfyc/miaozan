<?php
/* Author：消失的彩虹海 & 快乐是福 & 云上的影子 & 千度*/
class qzone {
    public $msg;
    public function __construct($uin, $sid = null, $skey = null, $p_skey = null, $pookie = null) {
        $this->uin = $uin;
        $this->sid = $sid;
        $this->skey = $skey;
        $this->p_skey = $p_skey;
        $this->pookie_new = $pookie;
        $this->gtk = $this->getGTK($skey);
        $this->gtk1 = $this->getGTK($p_skey);
        $this->gtk2 = $this->getGTK2($skey);
        $this->cookie = 'pt2gguin=o0' . $uin . '; uin=o0' . $uin . '; skey=' . $skey . '; p_skey=' . $p_skey . ';';
        $this->cookie1 = 'pt2gguin=o0' . $uin . '; uin=o0' . $uin . '; skey=' . $skey . ';';
    }
    public function tx() {
        $url = 'http://face.qq.com/client/webface.php';
        $id = rand(6319, 16097);
        $post = 'item_id=' . $id . '&size=1&cmd=set_static_face&g_tk=' . $this->gtk2 . '&callback=callback';
        $data = $this->get_curl($url, $post, $url, $this->cookie);
        preg_match('/callback\((.*?)\);/is', $data, $json);
        $arr = json_decode($json[1], true);
        if (@array_key_exists('result', $arr) && $arr['result'] == 0) {
            $this->msg[] = '更换头像成功！';
        } elseif ($arr['result'] == 1001) {
            $this->skeyzt = 1;
            $this->msg[] = '更换头像失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '更换头像失败！' . $data;
        }
    }
    public function pf() {
        $url = 'http://redirect.zb.qq.com/cgi-bin/setdec.fcg?g_tk=' . $this->gtk2;
        $dec0 = rand(688, 25000);
        $post = 'dec0=' . $dec0 . '&dec1=0&dec2=0&count=3&cmd=1&from=vip.gongneng.subsite.zhuangban.guide_setup_log&callback=callback';
        $data = $this->get_curl($url, $post, $url, $this->cookie);
        preg_match('/callback\((.*?)\);/is', $data, $json);
        $arr = json_decode($json[1], true);
        if (@array_key_exists('rc', $arr) && $arr['rc'] == 'setsucc') {
            $this->msg[] = '更换皮肤成功！' . $dec0;
        } elseif ($arr['rc'] == "try_login") {
            $this->skeyzt = 1;
            $this->msg[] = '更换头像失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '更换头像失败！' . $data;
        }
    }
    public function qipao() {
        $str = '87&96&107&110&114&16&21&28&36&40&42&45&47&49&56&72&81&82&85&180&201&209&16&21&28&36&40&42&45&47&49&56&72&81&82&85&180&201&209&0&1&2&3&4&5&6&7&8&9&11&12&14&16&19&21&24&25&26&28&29&35&36&38&39&40&42&43&44&45&48&49&52&55&56&58&59&61&63&67&68&69&71&72&73&74&75&76&78&80&81&82&83&85&86&87&89&90&91&92&94&95&96&98&101&105&106&107&109&110&111&112&113&114&117&118&120&122&124&125&126&127&128&129&132&133&138&142&146&150&151&152&155&159&168&169&178';
        $id = array_rand(explode('&', $str) , 1);
        $url = "http://logic.content.qq.com/bubble/setup?callback=&uin=" . $this->uin . "&id=" . $id . "&version=4.6.0.0&platformId=1&g_tk=" . $this->gtk . "&_=" . time() . "989";
        $get = $this->get_curl($url, 0, 0, $this->cookie);
        preg_match('/\((.*?)\)\;/is', $get, $json);
        if ($json = $json[1]) {
            $arr = json_decode($json, true);
            if (array_key_exists('ret', $arr) && $arr['ret'] == 0) {
                if ($arr['data']['ret'] == 0 && $arr['data']['msg'] == "ok") {
                    $this->msg[] = "气泡更换成功";
                } elseif ($arr['data']['ret'] == 5002) {
                    $this->msg[] = "需参与活动";
                } elseif ($arr['data']['ret'] == 2002) {
                    $this->msg[] = "非会员";
                }
            } elseif ($arr['ret'] == - 100001) {
                $this->skeyzt = 1;
                $this->msg[] = "SKEY过期";
            } else {
                $this->msg[] = "气泡更换失败！" . $arr['msg'];
            }
        }
    }
    public function flower() {
        $url = 'http://flower.qzone.qq.com/fcg-bin/cgi_plant?g_tk=' . $this->gtk;
        $post = 'fl=1&fupdate=1&act=rain&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
        $json = $this->get_curl($url, $post, $url, $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '浇水成功！';
        } elseif ($arr['code'] == - 6002) {
            $this->msg[] = '今天浇过水啦！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '浇水失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '浇水失败！' . $arr['message'];
        }
        $post = 'fl=1&fupdate=1&act=love&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
        $json = $this->get_curl($url, $post, $url, $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '修剪成功！';
        } elseif ($arr['code'] == - 6002) {
            $this->msg[] = '今天修剪过啦！';
        } elseif ($arr['code'] == - 6007) {
            $this->msg[] = '您的爱心值今天已达到上限！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '修剪失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '修剪失败！' . $arr['message'];
        }
        $post = 'fl=1&fupdate=1&act=sun&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
        $json = $this->get_curl($url, $post, $url, $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '光照成功！';
        } elseif ($arr['code'] == - 6002) {
            $this->msg[] = '今天日照过啦！';
        } elseif ($arr['code'] == - 6007) {
            $this->msg[] = '您的阳光值今天已达到上限！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '光照失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '光照失败！' . $arr['message'];
        }
        $post = 'fl=1&fupdate=1&act=nutri&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
        $json = $this->get_curl($url, $post, $url, $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '施肥成功！';
        } elseif ($arr['code'] == - 6005) {
            $this->msg[] = '暂不能施肥！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '施肥失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '施肥失败！' . $arr['message'];
        }
        $url = 'http://flower.qzone.qq.com/cgi-bin/cgi_pickup_oldfruit?g_tk=' . $this->gtk;
        $post = 'mode=1&g%5Ftk=' . $this->gtk . '&outCharset=utf%2D8&fupdate=1&format=json';
        $json = $this->get_curl($url, $post, $url, $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '兑换神奇肥料成功！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '兑换神奇肥料失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '兑换神奇肥料失败！' . $arr['message'];
        }
        $url = 'http://flower.qzone.qq.com/cgi-bin/fg_get_giftpkg?g_tk=' . $this->gtk;
        $post = 'outCharset=utf-8&format=json';
        $json = $this->get_curl($url, $post, 'http://ctc.qzs.qq.com/qzone/client/photo/swf/RareFlower/FlowerVineLite.swf', $this->cookie);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            if ($arr['data']['vDailyGiftpkg'][0]['caption']) {
                $this->msg[] = $arr['data']['vDailyGiftpkg'][0]['caption'] . ':' . $arr['data']['vDailyGiftpkg'][0]['content'];
                $giftpkgid = $arr['data']['vDailyGiftpkg'][0]['id'];
                $granttime = $arr['data']['vDailyGiftpkg'][0]['granttime'];
                $url = 'http://flower.qzone.qq.com/cgi-bin/fg_use_giftpkg?g_tk=' . $this->gtk;
                $post = 'giftpkgid=' . $giftpkgid . '&outCharset=utf%2D8&granttime=' . $granttime . '&format=json';
                $this->get_curl($url, $post, 'http://ctc.qzs.qq.com/qzone/client/photo/swf/RareFlower/FlowerVineLite.swf', $this->cookie);
            } else $this->msg[] = '领取每日登录礼包成功！';
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '领取每日登录礼包失败！原因:SKEY已过期！';
        } else {
            $this->msg[] = '领取每日登录礼包失败！' . $arr['message'];
        }
    }
    public function get_curl($url, $post = 0, $referer = 1, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $httpheader[] = "Accept:application/json";
        $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
        $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
        $httpheader[] = "Connection:close";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            if ($referer == 1) {
                curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
            } else {
                curl_setopt($ch, CURLOPT_REFERER, $referer);
            }
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);
        }
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }
    private function getGTK($skey) {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash+= (($hash << 5) & 0xffffffff) + ord($skey[$i]);
        }
        return $hash & 0x7fffffff;
    }
    private function getGTK2($skey) {
        $salt = 5381;
        $md5key = 'tencentQQVIP123443safde&!%^%1282';
        $hash = array();
        $hash[] = ($salt << 5);
        $len = strlen($skey);
        for ($i = 0; $i < $len; $i++) {
            $ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
            $ASCIICode = hexdec(bin2hex($ASCIICode));
            $hash[] = (($salt << 5) + $ASCIICode);
            $salt = $ASCIICode;
        }
        $md5str = md5(implode($hash) . $md5key);
        return $md5str;
    }
    public function dldqd() {
        $url = 'http://fight.pet.qq.com/cgi-bin/petpk?cmd=award&op=1&type=0';
        $data = $this->get_curl($url, 0, $url, $this->cookie);
        $data = mb_convert_encoding($data, "UTF-8", "GB2312");
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) {
            $this->msg[] = $arr['ContinueLogin'] . ' + ' . $arr['DailyAward'];
        } elseif ($arr['ret'] == - 1) {
            $this->msg[] = $arr['ContinueLogin'];
            $this->msg[] = $arr['DailyAward'];
        } elseif ($arr['result'] == - 5) {
            $this->skeyzt = 1;
            $this->msg[] = '大乐斗领礼包失败！SKEY已失效';
        } else {
            $this->msg[] = '大乐斗领礼包失败！' . $arr['msg'];
        }
    }

    public function pcblqd()
    {
        $url = "http://buluo.qq.com/cgi-bin/bar/card/bar_list_by_page?uin=" . $this->uin . "&neednum=30&startnum=0&r=0.98389" . time();
        $json = $this->get_curl($url, 0, 'http://buluo.qq.com/mobile/personal.html', $this->cookie);
        if ($json == '{"retcode":0,"result":{"followbarnum":0,"followbars":[],"isend":0}}') {
            $this->msg[] = $this->uin . '部落签到完成!，用户没有关注过部落';
        } else {
            $arr = json_decode($json, true);
            if ($arr['retcode'] == 100000) {
                $this->skeyzt = 1;
                $this->msg[] = '部落签到失败！SKEY已失效。';
            } else {
                $arr = $arr['result'];
                foreach ($arr['followbars'] as $followbars) {
                    $this->blqd($followbars['bid']);
                }
            }
        }
    }

     public function daoju(){
		$url = "http://apps.game.qq.com/ams/ame/ame.php?ameVersion=0.3&sServiceType=dj&iActivityId=11117&sServiceDepartment=djc&set_info=djc";
		$post = "iActivityId=11117&iFlowId=96939&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=djc&sServiceType=dj";
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr['modRet']) && $arr['modRet']['ret']==0){
			$this->msg[]='道聚城签到成功！';
		}elseif($arr['modRet']['ret']==600){
			$this->msg[]='道聚城今天已签到！';
		}else{
			$this->msg[]='道聚城签到失败！'.$arr['modRet']['msg'];
		}

		$post = "gameId=&sArea=&iSex=&sRoleId=&iGender=&sServiceType=dj&objCustomMsg=&areaname=&roleid=&rolelevel=&rolename=&areaid=&iActivityId=11117&iFlowId=96910&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=djc";
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('iRet',$arr['modRet']) && $arr['modRet']['iRet']==0){
			$this->msg[]=$arr['modRet']['sMsg'];
		}elseif($arr['ret']==600){
			$this->msg[]=$arr['msg'];
		}else{
			$this->msg[]=$arr['msg'];
		}
	}
    public function blqd($buluo)
    {
        $url = "http://buluo.qq.com/cgi-bin/bar/user/sign";
        $ua = 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36';
        $rf = "http://buluo.qq.com/p/barindex.html?bid=" . $buluo;
        $post = "&bid=" . $buluo . "&r=" . time() . "&bkn=" . $this->gtk;
        $json = $this->get_curl($url, $post, $rf, $this->cookie1, 0, $ua);
        $arr = json_decode($json, true);
        if (array_key_exists('retcode', $arr) && $arr['retcode'] == 0) {
            if ($arr['result']['sign'] == 1)
                $this->msg[] = $this->uin . ' 部落已签到！';
            else
                $this->msg[] = $this->uin . ' 部落签到成功！';
        } elseif ($arr['retcode'] == 100000) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 部落签到失败！SKEY已失效。';
        } else {
            $this->msg[] = $this->uin . ' 部落签到失败！' . $json;
        }
    }

	public function qqllq(){
		$url = 'http://i.browser.qq.com/all_data_query?guid=F27FE57A437658E7D11BC0D85ECBCC70&g_tk='.$this->gtk2;
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if($task_list=$arr['static_data']['task_list']){
			foreach($task_list as $row){
				if($row['interface']=='50619'||$row['interface']=='54000'||$row['interface']=='53998')continue;
				$this->qqllq_task($row['interface'],$row['title'],$row['score']);
			}
		}elseif($arr['ret']==-2){
			$this->skeyzt=1;
			$this->msg[]='获取活动列表失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='获取活动列表失败！'.$arr['msg'];
		}
	}
	private function qqllq_task($actid,$title,$score){
		$url = 'http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid='.$actid.'&guid=F27FE57A437658E7D11BC0D85ECBCC70&fromat=json&_='.time().'7071';
		$data = $this->get_curl($url,0,'http://i.browser.qq.com/',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='QQ浏览器 '.$title.' 成功！积分+'.$score;
		}elseif($arr['ret']==10601){
			$this->msg[]='QQ浏览器 '.$title.' 今天已完成！';
		}elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[]='QQ浏览器 '.$title.' 失败！SKEY过期';
		}else{
			$this->msg[]='QQ浏览器 '.$title.' 失败！'.$arr['msg'];
		}
	}
    public function pcqunqd($qun) {
        $url = "http://qiandao.qun.qq.com/cgi-bin/sign";
        $ua = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0';
        $rf = "http://qiandao.qun.qq.com/cgi-bin/sign";
        $post = "&gc=" . $qun . "&is_sign=0&from=1&bkn=" . $this->gtk . "";
        $json = $this->get_curl($url, $post, $rf, $this->cookie, 0, $ua);
        $arr = json_decode($json, true);
        if ($arr[ec] == 0) $this->msg[] = $this->uin . '在群号为' . $qun . '签到成功!您已累计签到' . $arr[conti_count] . '天,签到排名为' . $arr[rank] . '名,今天已有' . $arr[today_count] . '人签到!' . '<BR>';
        else $this->msg[] = $this->uin . '在群号为' . $qun . '签到失败，原因：' . $arr[em] . '<BR>';
    }
    public function qunqd() {
        $url = 'http://qun.qzone.qq.com/cgi-bin/get_group_list?groupcount=4&count=4&format=json&callbackFun=_GetGroupPortal&uin=' . $this->uin . '&g_tk=' . $this->gtk . '&ua=Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F31.0.1650.63%20Safari%2F537.36';
        $url2 = 'http://qiandao.qun.qq.com/cgi-bin/sign';
        $data = $this->get_curl($url, 0, 'http://qun.qzone.qq.com/group', $this->cookie);
        preg_match('/_GetGroupPortal_Callback\((.*?)\)\;/is', $data, $json);
        $arr = json_decode($json[1], true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            foreach ($arr['data']['group'] as $row) {
                $post = 'gc=' . $row['groupid'] . '&is_sign=0&from=1&bkn=' . $this->gtk;
                $data = $this->get_curl($url2, $post, 'http://qiandao.qun.qq.com/index.html?groupUin=' . $row['groupid'] . '&appID=100729587', $this->cookie);
                $arr = json_decode($data, true);
                if (array_key_exists('ec', $arr) && $arr['ec'] == 0) {
                    if (array_key_exists('name_list', $arr)) $this->msg[] = '群：' . $row['groupid'] . ' 签到成功！累计签到' . $arr['conti_count'] . '天,签到排名为' . $arr['rank'] . '名.';
                    elseif (array_key_exists('conti_count', $arr)) $this->msg[] = '群：' . $row['groupid'] . ' 今天已签到！累计签到' . $arr['conti_count'] . '天,签到排名为' . $arr['rank'] . '名.';
                    else $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：' . $data;
                } elseif ($arr['ec'] == 1) {
                    $this->skeyzt = 1;
                    $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：SKEY失效！';
                } else {
                    $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：' . $data;
                }
            }
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = '群签到失败！原因：SKEY已失效。';
        } else {
            $this->msg[] = '群签到失败！原因：' . $arr['message'];
        }
    }
    public function wyqd() {
        $data = $this->get_curl('http://web2.cgi.weiyun.com/weiyun_activity.fcg?cmd%20=17004&g_tk=' . $this->gtk . '&data=%7B%22req_header%22%3A%7B%22cmd%22%3A17004%2C%22appid%22%3A30013%2C%22version%22%3A2%2C%22major_version%22%3A2%7D%2C%22req_body%22%3A%7B%22ReqMsg_body%22%3A%7B%22weiyun.WeiyunDailySignInMsgReq_body%22%3A%7B%7D%7D%7D%7D&format=json', 0, 'http://www.weiyun.com/', $this->cookie);
        $json = json_decode($data, true);
        $arr = $json['rsp_header'];
        if (array_key_exists('retcode', $arr) && $arr['retcode'] == 0) {
            $this->msg[] = '微云签到成功！空间增加 ' . $json['rsp_body']['RspMsg_body']['weiyun.WeiyunDailySignInMsgRsp_body']['add_point'] . 'MB';
        } elseif ($arr['retcode'] == 190051) {
            $this->skeyzt = 1;
            $this->msg[] = '微云签到失败！SKEY已失效';
        } elseif (array_key_exists('retcode', $arr)) {
            $this->msg[] = '微云签到失败！' . $arr['retmsg'];
        } else {
            $this->msg[] = '微云签到失败！' . $data;
        }
    }
    public function vipqd() {
        $url = 'http://vipfunc.qq.com/act/client_oz.php?action=client&g_tk=' . $this->gtk2;
        $data = $this->get_curl($url, 0, $url, $this->cookie);
        if ($data == '{ret:0}') $this->msg[] = $this->uin . ' 会员面板签到成功！';
        else $this->msg[] = $this->uin . ' 会员面板签到失败！' . $json;
        $data = $this->get_curl("http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=23314&format=json&g_tk=" . $this->gtk2 . "&cachetime=" . time() , 0, 'http://vip.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) $this->msg[] = $this->uin . ' 会员网页版签到成功！';
        elseif ($arr['ret'] == 10601) $this->msg[] = $this->uin . ' 会员网页版今天已经签到！';
        elseif ($arr['ret'] == 10002) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 会员网页版签到失败！SKEY过期';
        } elseif ($arr['ret'] == 20101) $this->msg[] = $this->uin . ' 会员网页版签到失败！不是QQ会员！';
        else $this->msg[] = $this->uin . ' 会员网页版签到失败！' . $arr['msg'];
        $data = $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?actid=52002&rand=0.27489888' . time() . '&g_tk=' . $this->gtk2 . '&format=json', 0, 'http://vip.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) $this->msg[] = $this->uin . ' 会员手机端签到成功！';
        elseif ($arr['ret'] == 10601) $this->msg[] = $this->uin . ' 会员手机端今天已经签到！';
        elseif ($arr['ret'] == 10002) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 会员手机端签到失败！SKEY过期';
        } else $this->msg[] = $this->uin . ' 会员手机端签到失败！' . $arr['msg'];
        $data = $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=56247&g_tk=' . $this->gtk2 . '&pvsrc=&fotmat=json&cache=0', 0, 'http://vip.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) $this->msg[] = $this->uin . ' 三国之刃会员每周签到礼包领取成功！';
        elseif ($arr['ret'] == 10601) $this->msg[] = $this->uin . ' 三国之刃会员每周签到礼包已领取！';
        elseif ($arr['ret'] == 40039) $this->msg[] = $this->uin . ' 三国之刃会员每周签到礼包 不符合领取条件';
        elseif ($arr['ret'] == 10002) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 三国之刃会员每周签到礼包领取失败！SKEY过期';
        } else $this->msg[] = $this->uin . ' 三国之刃会员每周签到礼包领取失败！' . $arr['msg'];
        $data = $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=54963&isLoadUserInfo=1&format=json&g_tk=' . $this->gtk2, 0, 'http://vip.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) $this->msg[] = $this->uin . ' 会员积分签到成功！';
        elseif ($arr['ret'] == 10601) $this->msg[] = $this->uin . ' 会员积分今天已经签到！';
        elseif ($arr['ret'] == 10002) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 会员积分签到失败！SKEY过期';
        } else $this->msg[] = $this->uin . ' 会员积分签到失败！' . $arr['msg'];
        $data = $this->get_curl('http://iyouxi.vip.qq.com/ams2.02.php?actid=23074&g_tk_type=1sid=&rand=0.8656469448520889&format=json&g_tk=' . $this->gtk2, 0, 'http://vip.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) $this->msg[] = $this->uin . ' 会员积分2签到成功！';
        elseif ($arr['ret'] == 10601) $this->msg[] = $this->uin . ' 会员积分2今天已经签到！';
        elseif ($arr['ret'] == 10002) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 会员积分2签到失败！SKEY过期';
        } else $this->msg[] = $this->uin . ' 会员积分2签到失败！' . $arr['msg'];
        $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=27754&g_tk=' . $this->gtk2 . '&pvsrc=undefined&ozid=509656&vipid=MA20131223091753081&format=json&_=' . time() , 0, 'http://vip.qq.com/', $this->cookie);
        $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=27755&g_tk=' . $this->gtk2 . '&pvsrc=undefined&ozid=509656&vipid=MA20131223091753081&format=json&_=' . time() , 0, 'http://vip.qq.com/', $this->cookie);
        $this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk=' . $this->gtk2 . '&actid=22249&_c=page&format=json&_=' . time() , 0, 'http://vip.qq.com/', $this->cookie);
        $this->get_curl("http://iyouxi.vip.qq.com/jsonp.php?_c=page&actid=5474&isLoadUserInfo=1&format=json&g_tk=" . $this->gtk2 . "&_=" . time() , 0, 0, $this->cookie);
    }
    public function lzqd() {
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_feedback_send_lottery.fcg?activeid=110&rnd=' . time() . '157&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/fuliwo/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            if ($arr['data']['alreadysend'] == 1) $this->msg[] = '您今天已经签到过了！';
            else $this->msg[] = '绿钻签到成功！';
        } elseif ($arr['code'] == - 200017) {
            $this->msg[] = '你不是绿钻无法签到！';
        } else {
            $this->msg[] = '绿钻签到失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_draw_lottery.fcg?activeid=159&rnd=' . time() . '482&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/fuliwo/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻抽奖成功！';
        } elseif ($arr['code'] == 200008) {
            $this->msg[] = '您没有抽奖机会！';
        } else {
            $this->msg[] = '绿钻抽奖失败！';
        }
    }

	public function qzoneqd()
    {
        $url = 'http://vip.qzone.qq.com/fcg-bin/v2/fcg_mobile_vip_site_checkin?t=0.89457' . time() . '&g_tk=' . $this->new_gtk . '&qzonetoken=423659183';
        $post = 'uin=' . $this->uin . '&format=json';
        $referer = 'http://h5.qzone.qq.com/vipinfo/index?plg_nld=1&source=qqmail&plg_auth=1&plg_uin=1&_wv=3&plg_dev=1&plg_nld=1&aid=jh&_bid=368&plg_usr=1&plg_vkey=1&pt_qzone_sig=1';
        $data = $this->get_curl($url, $post, $referer, $this->pc_cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '黄钻签到成功！';
        } elseif (array_key_exists('code', $arr) && $arr['code'] == -3000) {
            $this->skeyzt = 1;
            $this->msg[] = '黄钻签到失败！SKEY已失效';
        } elseif (array_key_exists('code', $arr)) {
            $this->msg[] = '黄钻签到失败！' . $arr['message'];
        } else {
            $this->msg[] = '黄钻签到失败！' . $data;
        }
        $url = 'http://activity.qzone.qq.com/fcg-bin/fcg_qzact_count?g_tk=' . $this->gtk . '&format=json&actid=101&uin=' . $this->uin . '&_=' . time() . '3333';
        $data = $this->get_curl($url, 0, $url, $this->cookie);
        $data = mb_convert_encoding($data, 'UTF-8', 'GB2312');
        $arr = json_decode($data, true);
        $count = $arr['data']['rule']['1001']['count'][0]['left'];
        while ($count > 0) {
            $url = 'http://activity.qzone.qq.com/fcg-bin/fcg_qzact_lottery?g_tk=' . $this->gtk;
            $post = 'actid=101&ruleid=1001&format=json&uin=' . $this->uin . '&g_tk=' . $this->gtk . '&qzreferrer=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fqzact%2Fact%2Fhkhd%2Findex.html';
            $referer = 'http://qzs.qq.com/qzone/qzact/act/hkhd/index.html';
            $data = $this->get_curl($url, $post, $referer, $this->cookie);
            $arr = json_decode($data, true);
            if (array_key_exists('code', $arr) && $arr['code'] == 0) {
                $this->msg[] = '黄钻抽奖成功，抽到' . $arr['data'][0]['name'] . '！';
            } elseif ($arr['code'] == -3000) {
                $this->skeyzt = 1;
                $this->msg[] = '黄钻抽奖失败！SKEY已失效';
            } elseif ($arr['code'] == -5004) {
                $this->msg[] = '黄钻抽奖失败！抽奖机会已用完';
            } elseif (array_key_exists('code', $arr)) {
                $this->msg[] = '黄钻抽奖失败！' . $arr['message'];
            } else {
                $this->msg[] = '黄钻抽奖失败！' . $data;
            }
            --$count;
        }
    }
	public function jpgame(){
		$url = "http://1.game.qq.com/app/sign?start=".date("Y-m")."&g_tk=".$this->gtk."&_t=0.6780016267291531";
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('/var sign_index = (.*?);/is', $data, $json);
		$arr = json_decode($json[1], true);
		$arr = $arr['jData']['signInfo'];
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='精品页游签到成功！';
		}elseif($arr['ret']==1){
			$this->msg[]='精品页游今天已签到！';
		}else{
			$this->msg[]='精品页游签到失败！'.$arr['msg'];
		}
	}
	
    public function xzqd()
    {
        $url = 'http://starvip.qq.com/fcg-bin/v2/fcg_mobile_starvip_site_checkin?g_tk=' . $this->gtk . '&r=0.06027948' . time();
        $post = 'format=json&uin=' . $this->uin;
        $data = $this->get_curl($url, $post, 'http://xing.qq.com/', $this->pc_cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '星钻签到成功！成长值+' . $arr['data']['add'];
        } elseif ($arr['code'] == -10000) {
            $this->msg[] = '每天只需要签到一次哦！';
        } elseif ($arr['code'] == -3000) {
            $this->skeyzt = 1;
            $this->msg[] = '星钻签到失败！SKEY过期';
        } else {
            $this->msg[] = '星钻签到失败！' . $arr['message'];
        }
        $url = 'http://starvip.qq.com/fcg-bin/v2/fcg_qzact_lottery?g_tk=' . $this->gtk . '&r=0.00463036' . time();
        $post = 'actid=369&ruleid=2048&format=json&uin=' . $this->uin;
        $data = $this->get_curl($url, $post, 'http://xing.qq.com/', $this->pc_cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '星钻抽奖成功！抽奖结果：' . $arr['data'][0]['name'] . $arr['data'][0]['cdkey'];
        } elseif ($arr['code'] == -10000) {
            $this->msg[] = '您已经用完了所有的抽奖机会！';
        } elseif ($arr['code'] == -3000) {
            $this->skeyzt = 1;
            $this->msg[] = '星钻抽奖失败！SKEY过期';
        } else {
            $this->msg[] = '星钻抽奖失败！' . $arr['message'];
        }
    }
		public function qcloud(){
		$url = 'https://www.qcloud.com/act/campus/ajax/index?uin='.$this->uin.'&csrfCode='.$this->gtk;
		$post = 'action=getVoucher';
		$data = $this->get_curl($url,$post,'https://www.qcloud.com/act/campus',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']=='0'){
			$this->msg[]='领取腾讯云学生机代金卷成功！';
		}elseif($arr['code']==11035){
			$this->msg[]='本月您已领取优惠代金券，请下个月再领取。';
		}elseif($arr['code']=='NOT-LOGINED'){
			$this->skeyzt=1;
			$this->msg[]='登录态验证失败，请重新登录';
		}else{
			$this->msg[]=$arr['msg'];
		}
	}
		public function gamevip($superkey){
		$supertoken=(string)$this->getToken($superkey);
		$url = "http://ptlogin2.qq.com/pt4_auth?daid=176&appid=21000110&auth_token=".$this->getToken($supertoken);
		$data = $this->get_curl($url,0,'http://ui.ptlogin2.qq.com/cgi-bin/login','superuin=o0'.$this->uin.'; superkey='.$superkey.'; supertoken='.$supertoken.';');
		if(preg_match('/ptsigx=(.*?)&/',$data,$match)){
			$url='http://ptlogin4.gamevip.qq.com/check_sig?uin='.$this->uin.'&ptsigx='.$match[1].'&daid=176&pt_login_type=4&service=pt4_auth&pttype=2&regmaster=&aid=21000110&s_url=http%3A%2F%2Fgamevip.qq.com%2F';
			$data = $this->get_curl($url,0,'http://ui.ptlogin2.qq.com/cgi-bin/login',0,1);
			preg_match("/skey=(.*?);/", $data, $match);
			$skey=$match[1];
			preg_match("/p_skey=(.*?);/", $data, $match);
			$pskey=$match[1];
			$cookie='pt2gguin=o0'.$this->uin.'; uin=o0'.$this->uin.'; skey='.$skey.'; p_uin=o0'.$this->uin.'; p_skey='.$pskey.'; DomainID=176;';

			$url='http://app.gamevip.qq.com/cgi-bin/gamevip_sign/GameVip_SignIn?format=json&g_tk='.$this->gtk.'&_='.time().'0334';
			$data = $this->get_curl($url,0,'http://gamevip.qq.com/sign_pop/sign_pop_v2.html',$cookie);
			$arr = json_decode($data, true);
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='蓝钻签到成功！当前签到积分'.$arr['SignScore'].'点';
			}elseif($arr['result']==1000005){
				$this->msg[]='蓝钻签到失败！P_skey已失效';
			}else{
				$this->msg[]='蓝钻签到失败！'.$arr['resultstr'];
			}

			$url='http://app.gamevip.qq.com/cgi-bin/gamevip_sign/GameVip_Lottery?format=json&g_tk='.$this->gtk.'&_='.time().'0334';
			$data = $this->get_curl($url,0,$url,$cookie);
			$data = mb_convert_encoding($data, "UTF-8", "GB2312");
			$arr = json_decode($data, true);
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='蓝钻抽奖成功！';
			}elseif($arr['result']==1000005){
				$this->msg[]='蓝钻抽奖失败！P_skey已失效';
			}elseif($arr['result']==102){
				$this->msg[]='蓝钻抽奖次数已用完';
			}else{
				$this->msg[]='蓝钻抽奖失败！'.$arr['resultstr'];
			}

			$url='http://app.gamevip.qq.com/cgi-bin/gamevip_m_sign/GameVip_m_SignIn';
			$data = $this->get_curl($url,0,$url,$cookie);
			$data = mb_convert_encoding($data, "UTF-8", "GB2312");
			$arr = json_decode($data, true);
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='蓝钻手机签到成功！奖励魔法卡片'.$arr['MagicCard'].'张，星星'.$arr['McStar'].'颗';
			}elseif($arr['result']==1000005){
				$this->msg[]='蓝钻手机签到失败！P_skey已失效';
			}else{
				$this->msg[]='蓝钻手机签到失败！'.$arr['resultstr'];
			}
		}else{
			$this->msg[]='蓝钻签到失败！superkey已失效';
		}

		$url = "http://apps.game.qq.com/ams/ame/ame.php?ameVersion=0.3&sServiceType=qqgame&iActivityId=54614&sServiceDepartment=newterminals&set_info=newterminals";
		$post = "iActivityId=54614&iFlowId=279055&g_tk=".$this->gtk."&e_code=0&g_code=0&eas_url=http%253A%252F%252Flz.qq.com%252Fact%252Fa20160712sign%252F&eas_refer=&sServiceDepartment=group_h&sServiceType=qqgame";
		$data = $this->get_curl($url,$post,0,$this->cookie);
		$arr = json_decode($data, true);
		$arr = $arr['modRet'];
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='蓝钻微信公众号签到成功！';
		}elseif($arr['ret']==600){
			$this->msg[]='蓝钻微信公众号今天已签到！';
		}else{
			$this->msg[]='蓝钻微信公众号签到失败！'.$arr['msg'];
		}
	}
	public function xinyue(){
		$url = "http://apps.game.qq.com/ams/ame/ame.php?ameVersion=0.3&sServiceType=tgclub&iActivityId=21547&sServiceDepartment=xinyue&set_info=xinyue";
		$post = "iActivityId=21547&iFlowId=149694&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=xinyue&sServiceType=tgclub";
		$data = $this->get_curl($url,$post,0,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='心锐VIP签到成功！';
		}elseif($arr['ret']==600){
			$this->msg[]='心锐VIP今天已签到！';
		}else{
			$this->msg[]='心锐VIP签到失败！'.$arr['msg'];
		}
	}
	public function qd3366(){
		$url = 'http://fcg.3366.com/fcg-bin/growinfo/mgp_growinfo_signin?&_r='.time().'7197&sCSRFToken='.$this->gtk;
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		preg_match('/gGrowInfoSignInResult = (.*?);/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('result',$arr) && $arr['result']==0){
			$this->msg[]='3366签到成功！';
		}elseif($arr['result']==16001){
			$this->msg[]='3366今天已签到！';
		}elseif($arr['result']==10002){
			$this->skeyzt=1;
			$this->msg[]='3366签到失败！SKEY已失效';
		}elseif(array_key_exists('result',$arr)){
			$this->msg[]='3366签到失败！'.$arr['resultstr'];
		}else{
			$this->msg[]='3366签到失败！'.$data;
		}
	}
	public function sweet_sign(){
		$url = 'http://sweet.snsapp.qq.com/v2/cgi-bin/sweet_signlove_get?cmd=0&startts=1453564800&endts=1457280000&opuin='.$this->uin.'&uin='.$this->uin.'&plat=0&outputformat=4&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'http://sweet.snsapp.qq.com/',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣空间签到成功！';
			return $arr['data']['lover']['uin'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣空间签到失败！原因:SKEY已过期！';
			return false;
		}else{
			$this->msg[]='情侣空间签到失败！'.$arr['message'];
			return false;
		}
	}
		public function dongman(){
		$url = 'http://comic.vip.qq.com/cgi-bin/coupon_coin?merge=1&pageVersion=288192_online&platId=109&version=1&_='.time().'516&g_tk='.$this->gtk.'&p_tk=&sequence='.time().'431';
		$post = 'param=%7B%220%22%3A%7B%22param%22%3A%7B%22tt%22%3A0%7D%2C%22module%22%3A%22comic_sign_in_svr%22%2C%22method%22%3A%22SignIn%22%2C%22timestamp%22%3A'.time().'424%7D%7D';
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if($arr = $arr['data']['0']['retBody']){
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='手机QQ动漫签到成功！萌点+2，本月已累计签到'.$arr['data']['singedDayOfMonth'].'天';
			}elseif($arr['result']==-120000){
				$this->skeyzt=1;
				$this->msg[]='手机QQ动漫签到失败！SKEY已失效';
			}else{
				$this->msg[]='手机QQ动漫签到失败！'.$arr['message'];
			}
		}else{
			$this->msg[]='手机QQ动漫签到失败！'.$data;
		}

		$url = 'http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=105321&merge=1&plat=1&qqVersion=6.6.9.3060&_='.time().'749';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='手机QQ动漫领取奖励成功！';
		}elseif($arr['ret']==20226){
			$this->msg[]='累计签到天数不足，无法领取额外奖励';
		}elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[]='手机QQ动漫领取奖励失败！SKEY过期';
		}else{
			$this->msg[]='手机QQ动漫领取奖励失败！'.$arr['msg'];
		}
	}
	
	public function hlwqd() {
        $url = 'http://pay.video.qq.com/fcgi-bin/sign?low_login=1&uin=' . $this->uin . '&otype=json&_t=2&g_tk=' . $this->gtk2 . '&_=' . time() . '8906';
        $data = $this->get_curl($url, 0, $url, $this->cookie);
        preg_match('/QZOutputJson=(.*?)\;/is', $data, $json);
        $arr = json_decode($json[1], true);
        $arr = $arr['result'];
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = $this->uin . ' 好莱坞会员签到成功！';
        } elseif ($arr['code'] == - 11) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . ' 好莱坞会员签到失败！SKEY已失效';
        } elseif ($arr['code'] == 500) {
            $this->msg[] = $this->uin . ' 你不是好莱坞会员，无法签到';
        } else {
            $this->msg[] = $this->uin . ' 好莱坞会员签到失败！' . $arr['msg'];
        }
    }
	public function tsqd()
    {
        $url = "http://ubook.3g.qq.com/8/user/myMission?k1={$this->skey}&u1=o0{$this->uin}";
        $data = $this->get_curl($url, 0, 'http://ubook.qq.com/8/mymission.html');
        $arr = json_decode($data, true);
        if ($arr['isLogin'] == 'True' && $arr['signMap']['code'] == 0) {
            $this->msg[] = '图书签到成功！';
        } elseif ($arr['signMap']['code'] == -2) {
            $this->msg[] = '图书今日已经签到！';
        } elseif ($arr['isLogin'] == 'False') {
            $this->msg[] = '图书签到失败！SKEY过期！';
        } else {
            $this->msg[] = '图书签到失败！数据异常';
        }
    }
    public function pqd() {
        $url = "http://iyouxi.vip.qq.com/ams3.0.php?g_tk=" . $this->gtk2 . "&pvsrc=102&ozid=511022&vipid=&actid=32961&format=json" . time() . "8777&cache=3654";
        $data = $this->get_curl($url, 0, 'http://youxi.vip.qq.com/m/wallet/activeday/index.html?_wv=3&pvsrc=102', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) {
            $this->msg[] = '钱包签到成功！';
        } elseif ($arr['ret'] == 37206) {
            $this->msg[] = '钱包签到失败！你没有绑定银行卡';
        } elseif ($arr['ret'] == 10601) {
            $this->msg[] = '你今天已钱包签到！';
        } else {
            $this->msg[] = '钱包签到失败！' . $arr['msg'];
        }
    }
    public function getSubstr($str, $leftStr, $rightStr) {
        $left = strpos($str, $leftStr);
        $right = strpos($str, $rightStr, $left);
        if ($left < 0 or $right < $left) return '';
        return substr($str, $left + strlen($leftStr) , $right - $left - strlen($leftStr));
    }
}
?>