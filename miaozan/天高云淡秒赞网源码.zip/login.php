<?php
require_once('includes/common.php');
if ($_POST['do'] == 'login') {
    $user = safestr($_POST['user']);
    $pwd = safestr($_POST['pwd']);
    if (!$user || !$pwd) {
        $msgs = 'sweetAlert("温馨提示", "账号或密码不能为空", "warning");';
    } elseif (strlen($user) < 5) {
        $msgs = 'sweetAlert("温馨提示", "用户名太短！", "warning");';
    } elseif (strlen($pwd) < 5) {
        $msgs = 'sweetAlert("温馨提示", "密码太简单！", "warning");';
    } else {
        $pwd = md5(md5($pwd) . md5('1340176819'));
        $where = "(user=:user or qq=:user) and pwd=:pwd";
        $stmt = $db->prepare("select * from {$prefix}users where {$where} limit 1");
        $stmt->execute(array(':user' => $user, ':pwd' => $pwd));
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $sid = md5(get_sz(4) . uniqid() . rand(1, 1000));
            $now = date("Y-m-d H:i:s");
            $ip = getip();
            $db->query("update {$prefix}users set sid='$sid',lasttime='$now',lastip='$ip' where uid='{$row[uid]}'");
            setcookie("tgyd_sid", $sid, time() + 3600 * 24 * 14, '/');
            header("Location: /mgmt/index.php");
            exit;
        } else {
            $msgs = 'sweetAlert("温馨提示", "账号或密码错误！", "warning");';
        }
    }
}
if ($_POST['do'] == 'reg') {
    session_start();
    $user = safestr($_POST['user']);
    $qq = safestr($_POST['qq']);
    $pwd = safestr($_POST['pwd']);
    $code = safestr($_POST['code']);
    $ip = getip();
    $stmt = $db->query("select uid from {$prefix}users where qq='{$qq}' or user='{$user}' limit 1");
    if (strlen($user) < 5) {
        $msg = 'sweetAlert("温馨提示", "用户名太短", "warning");';
    } elseif (strlen($user) > 10) {
        $msg = 'sweetAlert("温馨提示", "用户名太长", "warning");';
    } elseif (strlen($qq) > 10) {
        $msg = 'sweetAlert("温馨提示", "QQ账号没有10位以上", "warning");';
    } elseif (!$code || strtolower($_SESSION['tgyd_code']) != strtolower($code)) {
        $msg = 'sweetAlert("温馨提示", "验证码错误", "warning");';
    } elseif (strlen($pwd) < 5) {
        $msg = 'sweetAlert("温馨提示", "密码太简单！", "warning");';
    } elseif (strlen($pwd) > 15) {
        $msg = 'sweetAlert("温馨提示", "密码太长！", "warning");';
    } elseif ($stmt->fetch(PDO::FETCH_ASSOC)) {
        $msg = 'sweetAlert("温馨提示", "QQ或用户名已存在", "warning");';
    } else {
        $_SESSION['tgyd_code'] = md5(rand(100, 500) . time());
        $sid = md5(get_sz(4) . uniqid() . rand(1, 1000));
        $pwd = md5(md5($pwd) . md5('1340176819'));
        $now = date("Y-m-d H:i:s");
        $nowdate = date("Y-m-d");
        $city = get_ip_city($ip);
        $peie = C('regpeie');
        $rmb = C('regrmb');
        if ($db->query("insert into {$prefix}users (user,pwd,sid,active,peie,rmb,qq,city,regip,lastip,regtime,lasttime,aqproblem,aqanswer,yq,adddate) values ('$user','$pwd','$sid','1','$peie','$rmb','$qq','$city','$ip','$ip','$now','$now','','','0','$nowdate')")) {
            $msg = 'sweetAlert("温馨提示", "注册成功，您的用户名为:' . $user . '", "success");';
        } else {
            $msg = 'sweetAlert("温馨提示", "注册失败，数据处理时出错", "warning");';
        }
    }
}
if ($_GET["do"] != "reg") {
    ?>
    <!DOCTYPE html>
    <!--[if IE 9]>
    <html class="no-js lt-ie10"> <![endif]-->
    <!--[if gt IE 9]><!-->
    <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <title><?= C("webname") ?> - 用户登录</title>
        <meta name="Keywords" content="<?= C("webname") ?>,秒赞平台,秒赞网,秒赞,离线秒赞,免费24h秒赞,秒赞吧,爱空间app"/>
        <meta name="Description" content="<?= C("webname") ?>帐号登陆，24小时不间断离线秒赞空间说说！"/>
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">


        <link rel="stylesheet" href="<?= $login_api ?>/user/css/bootstrap.min-2.1.css">

        <link rel="stylesheet" href="<?= $login_api ?>/user/css/plugins-2.1.css">

        <link rel="stylesheet" href="http://cdn.api.odoto.cc/style/login/main-2.1.css">

<?php
if($login_api){
?>
        <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/vendor/fontawesome/css/font-awesome.min.css">
<?php
}else{
?>
        <link rel="stylesheet" href="<?= $login_api ?>/style/vendor/fontawesome/css/font-awesome.min.css">
<?php
}
?>

        <link rel="stylesheet" href="<?= $login_api ?>/user/css/themes-2.1.css">

        <script src="<?= $login_api ?>/user/js/vendor/modernizr-2.8.3.min.js"></script>

        <link rel="stylesheet" type="text/css" href="<?= $login_api ?>/style/login/sweetalert.css"/>
    </head>
    <body>


    <img src="http://luoci-1252111933.cosgz.myqcloud.com/lock_full_bg.jpg" alt="Full Background" class="full-bg full-bg-bottom animation-pulseSlow">


    <div id="login-container">

        <h1 class="h2 text-light text-center push-top-bottom animation-pullDown">
            <i class="fa fa-cube text-light-op"></i> <strong><?= C("webname") ?></strong>
        </h1>


        <div class="block animation-fadeIn360">

            <div class="block-title">
                <div class="block-options pull-right">
                    <a href="<?= $find_mgmt ?>" class="btn btn-effect-ripple btn-primary" data-toggle="tooltip" data-placement="left" title="用户密码找回"><i class="fa fa-user"></i></a>
					<a href="?do=reg" class="btn btn-effect-ripple btn-primary" data-toggle="tooltip" data-placement="left" title="新用户注册"><i class="fa fa-plus-circle"></i></a>
                </div>
                <h2>用户登录</h2>
            </div>


            <form id="form-login" method="post" class="form-horizontal" onsubmit="?">
                <input type="hidden" name="do" value="login"/>
                <div class="form-group">
                    <label for="login-email" class="col-xs-12">用户名</label>
                    <div class="col-xs-12">
                        <input type="text" name="user" class="form-control" placeholder="请输入用户名或注册的QQ" onkeydown="if(event.keyCode==32){return false;}" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="login-password" class="col-xs-12">密码</label>
                    <div class="col-xs-12">
                        <input type="password" name="pwd" class="form-control" placeholder="请输入用户密码" onkeydown="if(event.keyCode==32){return false;}" required>
                    </div>
                </div>
                <div class="form-group form-actions">
                    <div class="col-xs-8">
                        <label class="csscheckbox csscheckbox-primary">
                            <input type="checkbox" id="login-remember-me" name="remember" checked><span></span>
                            <small>记住我</small>
                        </label>
                    </div>
                    <div class="col-xs-4 text-right">
                        <button type="submit" class="btn btn-effect-ripple btn-sm btn-primary" id="sub"><i class="fa fa-users"></i> 登 录
                        </button>
                    </div>
                </div>
            </form>


            <hr>
            <div class="push text-center">- Other -</div>
            <div class="row push">
                <div class="col-xs-6">
                    <a href="?do=reg" class="btn btn-effect-ripple btn-sm btn-info btn-block"><i class="fa fa-plus-circle"></i> 注册账号</a>
                </div>
                <div class="col-xs-6">
                    <a href="<?= $find_mgmt ?>" class="btn btn-effect-ripple btn-sm btn-success btn-block"><i class="fa fa-info-circle"></i> 忘记密码</a>
                </div>
            </div>

        </div>


        <footer class="text-muted text-center animation-pullUp">
            <small><span id="year-copy"></span> &copy; <a href="http://<?= $domain ?>/" target="_blank"><?= C("webname") ?></a></small>
        </footer>

    </div>
    <script src="<?= $login_api ?>/style/login/jquery-2.2.0.min.js"></script>
    <script src="<?= $login_api ?>/user/js/vendor/bootstrap.min-2.1.js"></script>
    <script src="<?= $login_api ?>/user/js/plugins-2.1.js"></script>
    <script src="<?= $login_api ?>/user/js/app-2.1.js"></script>
    <script src="<?= $login_api ?>/style/login/readyLogin.js"></script>
    <script src="<?= $login_api ?>/style/login/sweetalert.min.js"></script>
    <?php
    if ($msgs) {
        echo "<script type='text/javascript'>{$msgs}</script>";
    }
    ?>
    </body>
    </html>
    <?php
} else {
    ?>
    <!DOCTYPE html>
    <!--[if IE 9]>
    <html class="no-js lt-ie10"> <![endif]-->
    <!--[if gt IE 9]><!-->
    <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <title><?= C("webname") ?> - 注册账号</title>
        <meta name="Keywords" content="<?= C("webname") ?>,秒赞平台,秒赞网,秒赞,离线秒赞,免费24h秒赞,秒赞吧,爱空间app"/>
        <meta name="Description" content="<?= C("webname") ?>帐号注册，24小时不间断离线秒赞空间说说！"/>
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">


       <link rel="stylesheet" href="<?= $login_api ?>/user/css/bootstrap.min-2.1.css">

        <link rel="stylesheet" href="<?= $login_api ?>/user/css/plugins-2.1.css">

        <link rel="stylesheet" href="http://cdn.api.odoto.cc/style/login/main-2.1.css">

<?php
if($login_api){
?>
        <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/vendor/fontawesome/css/font-awesome.min.css">
<?php
}else{
?>
        <link rel="stylesheet" href="<?= $login_api ?>/style/vendor/fontawesome/css/font-awesome.min.css">
<?php
}
?>

        <link rel="stylesheet" href="<?= $login_api ?>/user/css/themes-2.1.css">

        <script src="<?= $login_api ?>/user/js/vendor/modernizr-2.8.3.min.js"></script>

        <link rel="stylesheet" type="text/css" href="<?= $login_api ?>/style/login/sweetalert.css"/>
    </head>
    <body>


    <img src="http://luoci-1252111933.cosgz.myqcloud.com/lock_full_bg.jpg" alt="Full Background" class="full-bg full-bg-bottom animation-pulseSlow">


    <div id="login-container">

        <h1 class="h2 text-light text-center push-top-bottom animation-pullDown">
            <i class="fa fa-cube text-light-op"></i> <strong><?= C("webname") ?></strong>
        </h1>


        <div class="block animation-fadeIn360">

            <div class="block-title">
                <div class="block-options pull-right">
                    <a href="<?= $find_mgmt ?>" class="btn btn-effect-ripple btn-primary" data-toggle="tooltip" data-placement="left" title="用户密码找回"><i class="fa fa-user"></i></a>
					<a href="?do=login" class="btn btn-effect-ripple btn-primary" data-toggle="tooltip" data-placement="left" title="用户登录"><i class="fa fa-users"></i></a>
                </div>
                <h2>注册账号</h2>
            </div>


            <form id="form-login" method="post" class="form-horizontal" onsubmit="?">
                <input type="hidden" name="do" value="reg"/>
                <div class="form-group">
                    <div class="col-xs-12">
                        <input type="text" name="user" class="form-control" placeholder="输入登录用户名" onkeydown="if(event.keyCode==32){return false;}" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-12">
                        <input type="password" name="pwd" class="form-control" placeholder="输入6~16位登录密码" onkeydown="if(event.keyCode==32){return false;}" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-12">
                        <input type="text" id="register-qq" name="qq" class="form-control" onkeyup="this.value=this.value.replace(/\D/g,'')" maxlength="10" placeholder="输入您的联系QQ号" onkeydown="if(event.keyCode==32){return false;}" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-12">
                        <img src="/other/code/code.php?+Math.random();" onclick="this.src='/other/code/code.php?'+Math.random();" title="点击更换验证码" style="margin-bottom:5px;border: 1px solid #5CAFDE;">
                        <input type="text" name="code" maxlength="5" class="form-control" placeholder="输入验证码(不分大小写)" onkeydown="if(event.keyCode==32){return false;}" required>
                    </div>
                </div>
                <div class="form-group form-actions">
                    <div class="col-xs-6">
                        <label class="csscheckbox csscheckbox-primary" data-toggle="tooltip" title="同意协议">
                            <input type="checkbox" id="register-terms" name="register-terms" checked>
                            <span></span>
                        </label>
                        <a href="#modal-terms" data-toggle="modal">
                            <small>用户协议</small>
                        </a>
                    </div>
                    <div class="col-xs-6 text-right">
                        <button type="submit" class="btn btn-effect-ripple btn-info" id="sub"><i class="fa fa-plus-circle"></i> 注 册 </button>
                    </div>
                </div>
            </form>


            <hr>
            <div class="push text-center">- Other -</div>
            <div class="row push">
                <div class="col-xs-6">
                    <a href="?do=login" class="btn btn-effect-ripple btn-sm btn-info btn-block"><i class="fa fa-user"></i> 用户登录</a>
                </div>
                <div class="col-xs-6">
                    <a href="<?= $find_mgmt ?>" class="btn btn-effect-ripple btn-sm btn-success btn-block"><i class="fa fa-info-circle"></i> 忘记密码</a>
                </div>
            </div>

        </div>


        <footer class="text-muted text-center animation-pullUp">
            <small><span id="year-copy"></span> &copy; <a href="http://<?= $domain ?>/" target="_blank"><?= C("webname") ?></a></small>
        </footer>

    </div>
    <div id="modal-terms" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-center"><strong>用户注册协议</strong></h3>
                </div>
                <div class="modal-body">
                    <p><iframe src="other/other/contract.txt" style="width:100%;height:465px;"></iframe></p>
                </div>
                <div class="modal-footer">
                    <div class="text-center">
                        <button type="button" class="btn btn-effect-ripple btn-sm btn-primary" data-dismiss="modal">
                            我明白了
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= $login_api ?>/style/login/jquery-2.2.0.min.js"></script>
    <script src="<?= $login_api ?>/user/js/vendor/bootstrap.min-2.1.js"></script>
    <script src="<?= $login_api ?>/user/js/plugins-2.1.js"></script>
    <script src="<?= $login_api ?>/user/js/app-2.1.js"></script>
    <script src="<?= $login_api ?>/style/login/readyLogin.js"></script>
    <script src="<?= $login_api ?>/style/login/sweetalert.min.js"></script>
    <?php if (!empty($msg)) echo "<script type='text/javascript'>{$msg}</script>"; ?>
    </body>
    </html>
	
    <?php
}
?>