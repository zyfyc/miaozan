<?php
require_once('includes/common.php');
if ($_POST['do'] == 'login') {
    $user = safestr($_POST['user']);
    $pwd = safestr($_POST['pwd']);
    if (!$user || !$pwd) {
        $msgs = 'sweetAlert("温馨提示", "账号或密码不能为空", "warning");';
    } elseif (strlen($user) < 5) {
        $msgs = 'sweetAlert("温馨提示", "用户名太短！", "warning");';
    } elseif (strlen($pwd) < 5) {
        $msgs = 'sweetAlert("温馨提示", "密码太简单！", "warning");';
    } else {
        $pwd = md5(md5($pwd) . md5('1340176819'));
        $where = "(user=:user or qq=:user) and pwd=:pwd";
        $stmt = $db->prepare("select * from {$prefix}users where {$where} limit 1");
        $stmt->execute(array(':user' => $user, ':pwd' => $pwd));
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $sid = md5(get_sz(4) . uniqid() . rand(1, 1000));
            $now = date("Y-m-d H:i:s");
            $ip = getip();
            $db->query("update {$prefix}users set sid='$sid',lasttime='$now',lastip='$ip' where uid='{$row[uid]}'");
            setcookie("tgyd_sid", $sid, time() + 3600 * 24 * 14, '/');
            header("Location: /mgmt/index.php");
            exit;
        } else {
            $msgs = 'sweetAlert("温馨提示", "账号或密码错误！", "warning");';
        }
    }
}
if ($_POST['do'] == 'reg') {
    session_start();
    $user = safestr($_POST['user']);
    $qq = safestr($_POST['qq']);
    $pwd = safestr($_POST['pwd']);
    $code = safestr($_POST['code']);
    $ip = getip();
    $stmt = $db->query("select uid from {$prefix}users where qq='{$qq}' or user='{$user}' limit 1");
    if (strlen($user) < 5) {
        $msg = 'sweetAlert("温馨提示", "用户名太短", "warning");';
    } elseif (strlen($user) > 10) {
        $msg = 'sweetAlert("温馨提示", "用户名太长", "warning");';
    } elseif (strlen($qq) > 10) {
        $msg = 'sweetAlert("温馨提示", "QQ账号没有10位以上", "warning");';
    } elseif (!$code || strtolower($_SESSION['tgyd_code']) != strtolower($code)) {
        $msg = 'sweetAlert("温馨提示", "验证码错误", "warning");';
    } elseif (strlen($pwd) < 5) {
        $msg = 'sweetAlert("温馨提示", "密码太简单！", "warning");';
    } elseif (strlen($pwd) > 15) {
        $msg = 'sweetAlert("温馨提示", "密码太长！", "warning");';
    } elseif ($stmt->fetch(PDO::FETCH_ASSOC)) {
        $msg = 'sweetAlert("温馨提示", "QQ或用户名已存在", "warning");';
    } else {
        $_SESSION['tgyd_code'] = md5(rand(100, 500) . time());
        $sid = md5(get_sz(4) . uniqid() . rand(1, 1000));
        $pwd = md5(md5($pwd) . md5('1340176819'));
        $now = date("Y-m-d H:i:s");
        $nowdate = date("Y-m-d");
        $city = get_ip_city($ip);
        $peie = C('regpeie');
        $rmb = C('regrmb');
        if ($db->query("insert into {$prefix}users (user,pwd,sid,active,peie,rmb,qq,city,regip,lastip,regtime,lasttime,aqproblem,aqanswer,yq,adddate) values ('$user','$pwd','$sid','1','$peie','$rmb','$qq','$city','$ip','$ip','$now','$now','','','0','$nowdate')")) {
            $msg = 'sweetAlert("温馨提示", "注册成功，您的用户名为:' . $user . '", "success");';
        } else {
            $msg = 'sweetAlert("温馨提示", "注册失败，数据处理时出错", "warning");';
        }
    }
}
if ($_GET["do"] != "reg") {
    ?>

<!DOCTYPE html>
<html>
  <head>
    <title><?=C('webname')?> - 用户登录</title>
    <meta charset="utf-8" />
    <meta name="keywords" content="云言秒赞网,秒赞网,免费秒赞平台,离线秒赞评,秒赞平台,QQ秒赞网,秒赞吧,24小时秒赞网,秒赞软件,刷赞平台,免费秒赞网,秒赞" />
    <meta name="description" content="云言秒赞网是一个提供自动点赞等功能的离线化平台，无需下载秒赞软件，免耗流量离线赞！采用多台高配服务器分布式执行，让秒赞不间断24小时稳定运行，免费面向全网提供优质秒赞服务，拥有全网独特刷说说赞等给力功能，快来一起秒赞吧。" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="http://www.lxzan.com/Style/css/login/login.css" rel="stylesheet">
    <link href="http://www.lxzan.com/Style/css/lxzan/alert.css" rel="stylesheet" />
    <script src="http://www.lxzan.com/Style/mzjc/jquery.min.js"></script>
    <script src="http://www.lxzan.com/Style/js/lxzan/alert.js"></script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet"></head>
	  <body>
	    <div class="yunyan_box">
      <div class="yunyan_logo">
        <i class="fa fa-thumbs-up"></i>
        <strong><?=C('webname')?></strong></div>
	            <form id="form-login" method="post" onsubmit="?">
                <input type="hidden" name="do" value="login"/>	
        <input name="user" placeholder="用户名/手机号/邮箱/QQ号" type="text" value="" required>
        <hr class="hr15">
		
        <input name="pwd" placeholder="请输入您注册时填写的密码" type="password" value="" required>
        <hr class="hr15">
        <input value="登录" name="submit" style="width:100%;" type="submit">
        <hr class="hr20">
        <input type="checkbox" name="remember" id="remember" class="chk_3" checked="">
        <label for="remember"></label>
        <font color="18px">记住密码</font>
        <hr class="new">
        <div class="row push">
          <div class="col-xs-6">
            <a href="<?= $login_mgmt ?>?do=reg" class="btn btn-sm btn-info btn-block">
              <i class="fa fa-plus-circle"></i> 注册账号</a>
          </div>
          <div class="col-xs-6">
            <a href="<?= $find_mgmt ?>" class="btn btn-sm btn-primary btn-block">
              <i class="fa fa-info-circle"></i> 忘记密码</a>
          </div>
        </div>
      </form>
    </div>
    <?php
    if ($msgs) {
        echo "<script type='text/javascript'>{$msgs}</script>";
    }
    ?>
    </body>
    </html>
    <?php
} else {
    ?>

<!DOCTYPE html>
<html>
  <head>
    <title><?=C('webname')?> - 注册账号</title>
    <meta charset="utf-8" />
    <meta name="keywords" content="云言秒赞网,秒赞网,免费秒赞平台,离线秒赞评,秒赞平台,QQ秒赞网,秒赞吧,24小时秒赞网,秒赞软件,刷赞平台,免费秒赞网,秒赞" />
    <meta name="description" content="云言秒赞网是一个提供自动点赞等功能的离线化平台，无需下载秒赞软件，免耗流量离线赞！采用多台高配服务器分布式执行，让秒赞不间断24小时稳定运行，免费面向全网提供优质秒赞服务，拥有全网独特刷说说赞等给力功能，快来一起秒赞吧。" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="http://www.lxzan.com/Style/css/login/login.css" rel="stylesheet">
    <link href="http://www.lxzan.com/Style/css/lxzan/alert.css" rel="stylesheet" />
    <script src="http://www.lxzan.com/Style/mzjc/jquery.min.js"></script>
    <script src="http://www.lxzan.com/Style/js/lxzan/alert.js"></script>
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet"></head>
	  <body>
	<div class="yunyan_box">
      <div class="yunyan_logo">
        <i class="fa fa-thumbs-up"></i>
        <strong><?=C('webname')?></strong></div>
		            <form id="form-login" method="post" onsubmit="?">
                <input type="hidden" name="do" value="reg"/>
        <input name="user" placeholder="输入用户名/手机号/邮箱" type="text" required>
        <hr class="hr15">
        <input name="pwd" placeholder="请输入6位以上登录密码" type="password" required>
        <hr class="hr15">
		<input name="qq"  id="register-qq" placeholder="请输入您的QQ号" type="text" maxlength="10" onkeyup="this.value=this.value.replace(/\D/g,'')" required>
        <hr class="hr15">
		<input name="code" placeholder="请输入验证码" type="text" required>
		<hr class="hr15">
		<img src="/other/code/code.php?+Math.random();" onclick="this.src='/other/code/code.php?'+Math.random();" title="点击更换验证码" width="100%" height="60px">
		<hr class="hr15">
        <input value="注册" name="submit" style="width:100%;" type="submit">
        <hr class="hr20">
        <hr class="new">
        <div class="row push">
          <div class="col-xs-6">
            <a href="/<?= $login_mgmt ?>" class="btn btn-sm btn-info btn-block">
              <i class="fa fa-sign-out"></i> 返回登陆</a>
          </div>
          <div class="col-xs-6">
            <a href="<?= $find_mgmt ?>" class="btn btn-sm btn-primary btn-block">
              <i class="fa fa-info-circle"></i> 忘记密码</a>
          </div>
        </div>
      </form>
    </div>

    <?php if (!empty($msg)) echo "<script type='text/javascript'>{$msg}</script>"; ?>
    </body>
    </html>
	
    <?php
}
?>