<?php
require_once('common.php');
C('webtitle','影视VIP');
C('pageid','TVvip');
include_once 'core.head.php';
?>

<div class="row">
<div class="col-md-12">
      <div class="panel panel-primary">
          <div class="panel-heading portlet-handler ui-sortable-handle">影视vip提示</div>
          <div class="panel-wrapper">
              <div class="list-group-item bb">影视vip为接口获取不定时更新</div>
              <div class="list-group-item">若账号密码无效请等待稍后更新获取~</div>
          </div>
      </div>
  </div>
<div class="list-group-item">
<table class="table table-bordered"><!--bottomS-->
				<table class="table table-bordered">
					<tbody>
						<tr height="50">
							<td><button type="button" class="btn btn-block btn-warning"> <a href="http://chat.ihuan.me/api.php?skey=t6fhsiwrrhf&req=爱奇艺账号" target="_blank"><span style="color:#ffffff;">爱奇VIP获取</span></a></button></td>
							<td><button type="button" class="btn btn-block btn-warning"><a href="http://chat.ihuan.me/api.php?skey=t6fhsiwrrhf&req=优酷账号" target="_blank"><span style="color:#ffffff;">优酷VIP获取</span></a></button></td>
						</tr>
						<tr height="50">
							<td><button type="button" class="btn btn-block btn-danger"><a href="http://chat.ihuan.me/api.php?skey=t6fhsiwrrhf&req=土豆账号" target="_blank"><span style="color:#ffffff;">土豆VIP获取</span></a></button></td>
							<td><button type="button" class="btn btn-block btn-danger"><a href="http://chat.ihuan.me/api.php?skey=t6fhsiwrrhf&req=好莱坞账号" target="_blank"><span style="color:#ffffff;">腾讯VIP获取</span></a></button></td>
						</tr>
					</tbody>
				</table>
<?php
include_once 'core.foot.php';
?>