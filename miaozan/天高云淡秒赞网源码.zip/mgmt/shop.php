<?php
require_once('common.php');
if ($do = $_POST['do']) {
    if ($do == 'shop') {
        $km = safestr($_POST['km']);
        if (!$km) exit("<script language='javascript'>alert('卡密不能为空！');history.go(-1);</script>");
        $stmt = $db->prepare("select * from {$prefix}kms where km=:km and isuse='0' limit 1");
        $stmt->execute(array(':km' => $km));
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $period = $row['period'];
            if ($row['kind'] == "1") { //会员
                if (get_isvip($userrow['vip'], $userrow['vipend'])) {
                    $vipend = date("Y-m-d", strtotime("+ {$period} months", strtotime($userrow['vipend'])));
                    if ($db->query("update {$prefix}users set vip=1,vipend='{$vipend}' where uid='{$userrow[uid]}'")) {
                        $db->query("update {$prefix}kms set isuse='1' where km='{$km}'");
                        exit("<script language='javascript'>alert('Vip续费成功，有效期延期至{$vipend}');window.location.href='shop.php';</script>");
                    } else {
                        exit("<script language='javascript'>alert('Vip续费失败，请与该站站长取得联系！');window.location.href='shop.php';</script>");
                    }
                } else {
                    $vipend = date("Y-m-d", strtotime("+ {$period} months"));
                    if ($db->query("update {$prefix}users set vip=1,vipstart='" . date("Y-m-d") . "',vipend='{$vipend}' where uid='{$userrow[uid]}'")) {
                        $db->query("update {$prefix}kms set isuse='1' where km='{$km}'");
                        exit("<script language='javascript'>alert('Vip开通成功，到期时间为{$vipend}');window.location.href='shop.php';</script>");
                    } else {
                        exit("<script language='javascript'>alert('Vip开通失败，请与该站站长取得联系！');window.location.href='shop.php';</script>");
                    }
                }
            } else { //配额
                if ($db->query("update {$prefix}users set peie=peie+{$period} where uid='{$userrow[uid]}'")) {
                    $db->query("update {$prefix}kms set isuse='1' where km='{$km}'");
                    exit("<script language='javascript'>alert('增加配额成功，本次增加{$period}个！');window.location.href='shop.php';</script>");
                } else {
                    exit("<script language='javascript'>alert('配额增加失败，请与该站站长取得联系！');window.location.href='shop.php';</script>");
                }
            }
        } else {
            exit("<script language='javascript'>alert('卡密不存在！');history.go(-1);</script>");
        }
    }
}
C('webtitle', '自助商城');
C('pageid', 'shop');
include_once 'core.head.php';
?>
    <div class="col-md-7">
        <div class="panel panel-primary panel-demo">
            <div class="panel-heading">
                <div class="panel-title">
                    平台公告
                </div>
            </div>
            <div class="panel-body bg-gonggao-p">
                <div class="col-lg-12 bg-gonggao">
                    <?= stripslashes(C('web_shop_gg')) ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="panel panel-primary">
            <div class="panel-heading portlet-handler ui-sortable-handle">卡密充值</div>
            <div class="panel-wrapper">
                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">会员状态</div>
                        <input type="text" class="form-control" value="<?php if (get_isvip($userrow['vip'], $userrow['vipend'])) { echo "已激活 " . $userrow['vipend']; } else { echo "未激活"; } ?>" disabled="disabled">
                    </div>
                </div>

                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">当前余额</div>
                        <input type="text" class="form-control" value="<?= $userrow['rmb'] ?>" disabled="disabled">
                    </div>
                </div>

                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">当前配额</div>
                        <input type="text" class="form-control" value="<?= $userrow['peie'] ?>" disabled="disabled">
                    </div>
                </div>
                <form action="?" role="form" class="form-horizontal ng-pristine ng-valid" method="post">
                    <input type="hidden" name="do" value="shop">
                    <div class="list-group-item bb">
                        除代挂卡密外，其它卡密均可以在此使用，代挂卡密请在添加代挂页面使用
                    </div>
                    <div class="list-group-item bb">
                        使用卡密过程中，若出现充值失败，卡密仍可正常使用！
                    </div>
                    <div class="list-group-item bb">
                        <div class="input-group">
                            <div class="input-group-addon">卡密</div>
                            <input type="text" class="form-control" name="km" placeholder="请输入卡密">
                        </div>
                    </div>
                    <div class="list-group-item">
                        <button class="btn btn-primary btn-block" type="submit">确定使用</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php
include_once 'core.foot.php';
?>