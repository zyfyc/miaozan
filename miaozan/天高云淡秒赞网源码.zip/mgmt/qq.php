<?php
require_once('common.php');
C('webtitle','QQ列表');
C('pageid','qq');
include_once 'core.head.php';
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=10;
$start=($p-1)*$pagesize;

if($_GET['do']=='search' && $s=safestr($_GET['s'])){
	$pagedo='seach';
	$qqs = $db->query("select * from {$prefix}qqs where qq='{$s}' or user like'%{$s}%' order by (case when qq='{$s}' then 8 else 0 end) desc limit 20");
}else{
	$pages=ceil(get_count('qqs','1=:1','qid',array(":1"=>"1"))/$pagesize);
	$qqs = $db->query("select * from {$prefix}qqs where uid=".$userrow[uid]." order by qid desc limit $start,$pagesize");
}
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
?>
<?php while($qq = $qqs->fetch(PDO::FETCH_ASSOC)){?>
<div class="col-lg-3 col-md-4 col-sm-6">
    <div class="panel panel-default">
       <div class="panel-heading">
          <div class="panel-title text-center">
              <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$qq['qq']?>&amp;spec=100" width="80" height="80" class="img-circle circle-border m-t-xxs" alt="profile">
              <h4 class="font-bold no-margins"><?=get_qqnick($qq['qq'])?></h4>
          </div>
       </div>
       <div class="list-group">
          <div class="list-group-item but-br">
             <div class="media-box">
                <div class="pull-left">
                   <span class="fa-stack">
                      <em class="fa fa-circle fa-stack-2x text-purple"></em>
                      <em class="fa fa-qq fa-stack-1x fa-inverse text-white"></em>
                   </span>
                </div>
                <div class="media-box-body clearfix">
                   <span class="text-muted-s pull-right ml"><a type="button" class="btn btn-square btn-primary btn-xs" href="qqlist.php?do=del&p=<?=$p?>&qid=<?=$qq[qid]?>" onClick="if(!confirm('确认删除QQ：<?=$qq[qq]?>吗？')){return false;}" style="font-size:12px;">删除</a></span>
                   <span class="text-muted-s pull-right ml"><a href="add.php?uin=<?=$qq['qq']?>&auto=1&type=add" class="btn btn-square btn-primary btn-xs" style="font-size:12px;">更新</a>
                   </span>
                   <div class="media-box-heading text-purple m0" style="line-height:21px;"># <?=$qq['qq']?></div>
                </div>
             </div>
          </div>
          <div class="list-group-item but-br">
             
             <div class="media-box">
                <div class="pull-left" style="margin:auto 5px;">
                   <span class="circle circle-success circle-lg text-left"></span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading text-info m0"><small>QQ运行状态：<?php if($qq['skeyzt']){ echo '已停止运行'; }else{ echo '正常运行中'; }?></small></div>
                </div>
             </div>
          
             <div class="media-box" style="margin-top:5px;">
                <div class="pull-left" style="margin:auto 5px;">
                   <span class="circle circle-success circle-lg text-left"></span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading m0"><small>添加/更新时间：<?=$qq['addtime']?></small></div>
                </div>
             </div>
             
          </div>
          
          <div class="list-group-item but-br">
             <div class="media-box">
                <div class="pull-left">
                   <span class="fa-stack">
					  <?php if($qq['iszan']==0){ echo '<em class="fa fa-circle fa-stack-2x text-danger"></em>'; }else{ echo '<em class="fa fa-circle fa-stack-2x text-success"></em>'; } ?>
                      <em class="fa fa-thumbs-up fa-stack-1x fa-inverse text-white"></em>
                   </span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading text-<?php if($qq['iszan']==0){ echo 'danger'; }else{ echo 'success'; } ?> m0"><small><?php if($qq['iszan']==0){ echo '秒赞关闭中,无信息!'; }else{ echo '秒赞运行正常'; } ?></small></div>
                </div>
             </div>
          </div>
                 </div>
       <div class="panel-footer clearfix">
          <div class="col-xs-6"><a href="qqlist.php?qid=<?=$qq['qid']?>" class="btn btn-square btn-primary btn-block btn-xs">功能设置</a></div>
          <div class="col-xs-6"><a href="mzrz.php?qq=<?=$qq['qq']?>" class="btn btn-square btn-primary btn-block btn-xs">秒赞认证</a></div>
       </div>
    </div>
 </div>
<?php }?>
<div class="col-lg-3 col-md-4 col-sm-6">
    <div class="panel panel-default">
       <div class="panel-heading">
          <div class="panel-title text-center">
              <img src="//q4.qlogo.cn/headimg_dl?dst_uin=10000&amp;spec=100" width="80" height="80" class="img-circle circle-border m-t-xxs" alt="profile">
              <h4 class="font-bold no-margins"><?=C('webname')?></h4>
          </div>
       </div>
       <div class="list-group">
          <div class="list-group-item but-br">
             <div class="media-box">
                <div class="pull-left" style="margin:0;">
                   <span class="fa-stack" style="width:1px;">
                   </span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading text-purple text-center m0" style="line-height:22px;">
                      虚位以待
                   </div>
                </div>
             </div>
          </div>
          <div class="list-group-item but-br">
             
             <div class="media-box">
                <div class="pull-left" style="margin:auto 5px;">
                   <span class="circle circle-success circle-lg text-left"></span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading text-info m0"><small>挂机配额信息：已用<b><?=get_count('qqs',"uid=:uid",'qid',array(":uid"=>$userrow[uid]))?></b>个，共有<b><?=$userrow[peie]?></b>个</small></div>
                </div>
             </div>
          
             <div class="media-box" style="margin-top:6px;">
                <div class="pull-left" style="margin:auto 5px;">
                   <span class="circle circle-success circle-lg text-left"></span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading m0"><small>我的用户权限：<?php if(get_isvip($userrow['vip'],$userrow['vipend'])){ echo "包月VIP";}else{echo"免费用户";}?>&nbsp;<?=$userrow['vipend']?></small></div>
                </div>
             </div>
             
          </div>
          
          <div class="list-group-item but-br">
             <div class="media-box">
                <div class="pull-left">
                   <span class="fa-stack">
                      <em class="fa fa-circle fa-stack-2x text-success"></em>
                      <em class="fa fa-thumbs-up fa-stack-1x fa-inverse text-white"></em>
                   </span>
                </div>
                <div class="media-box-body clearfix">
                   <div class="media-box-heading text-success m0"><small>点击下方按钮添加QQ秒赞</small></div>
                </div>
             </div>
          </div>
       </div>
       <div class="panel-footer clearfix">
          <a href="add.php" title="添加QQ" class="btn btn-square btn-primary btn-block btn-xs">添加QQ</a>
       </div>
    </div>
 </div>
 <?php
include_once 'core.foot.php';
?>
      
