<?php
require_once('common.php');
C('webtitle','用户中心');
C('pageid','user');
include_once 'core.head.php';
for ($i = 0; $i < 9; $i++) {
    $j = $i + 1;
    $userrs.=get_count('users', "adddate=:date", "uid", array(
        ":date" => date("Y-m-d", strtotime("-{$j} day"))
    )).",";
}
for ($i = 0; $i < 9; $i++) {
    $j = $i + 1;
    $qqrs.=get_count('qqs', "adddate=:date", "qid", array(
        ":date" => date("Y-m-d", strtotime("-{$j} day"))
    )).",";
}
if($_POST['infos']=="ye"){
$info=$_POST['info'];
$qid=$userrow['qq'];
$user=$userrow['user'];
$time=date("Y-m-d H:i:s");
	if($info==""){
    exit("<script language='javascript'>alert('喂喂，说话啊。⊙△⊙？【请输入信息】');window.location.href='index.php';</script>");
	}else{
		if($db->query("INSERT INTO `{$prefix}chat` (`id`, `uid`, `user`, `info`, `time`, `qid`) VALUES (NULL, '{$row[uid]}', '$user', '$info', '$time', '$qid')")){
			  exit("<script language='javascript'>alert('发表成功！^_^');window.location.href='index.php';</script>");
				}
			}
}
if($_GET['do']=="info"){
$id = $_GET['id'];
	if($userrow['active']!=9){
		exit("<script language='javascript'>alert('权限不足！');window.location.href='index.php';</script>");
	}else{
		if(!$id){
			exit("<script language='javascript'>alert('id不能为空！');window.location.href='index.php';</script>");
		}
		if($db->query("delete from `{$prefix}chat` where id=$id")){
			exit("<script language='javascript'>alert('删除成功！');window.location.href='index.php';</script>");
		}else{
			exit("<script language='javascript'>alert('删除失败！');window.location.href='index.php';</script>");
		}
	}
}
?>

<div class="col-lg-8">
    <div class="panel panel-default panel-demo">
        <div class="panel-heading">
            <div class="panel-title">平台公告</div>
        </div>
        <div class="panel-body bg-gonggao-p">
            <div class="col-lg-12 bg-gonggao">
                <?php
                $rows = $db->query("select * from {$prefix}gonggao where 1=1 order by id desc");
                while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                    ?>
                    <p><?=$row['con'] ?>[<?=$row['addtime'] ?>]</p>
                    <?php
                } ?>
            </div>
            <div class="col-md-4"><a href="mzlist.php" title="QQ秒赞墙"><p class="bg-primary-light"> [热]QQ秒赞墙，可以交友哦</p></a></div>
            <div class="col-md-4"><a href="qd.php" title="每日签到"><p class="bg-primary-light"> [热]签到送VIP会员与积分中,去看看</p></a></div>
            <div class="col-md-4"><a href="reginfo.php" title="邀请好友"><p class="bg-primary-light"> [邀请好友] 注册得积分，送VIP活动中</p></a></div>
        </div>
    </div>
</div>
<div class="col-lg-4">
<div class="panel panel-default">
<div class="panel-heading">
<div class="panel-title text-center">
<img src="//q4.qlogo.cn/headimg_dl?dst_uin=596844474&spec=100" alt="Avatar" width="80" height="80" class="img-thumbnail img-circle">
<h4 class="font-bold no-margins" style="margin-bottom:3.5px;"><?=$userrow['user']?> [uid:<?=$userrow['uid']?>]</h4>
</div>
</div>
<div data-height="200" data-scrollable="" class="list-group">
<div class="list-group-item" style="border-width:0px;">
<div class="media-box">
<div class="pull-left">
<span class="fa-stack">
<em class="fa fa-circle fa-stack-2x text-purple"></em>
<em class="fa fa-qq fa-stack-1x fa-inverse text-white"></em>
</span>
</div>
<div class="media-box-body clearfix">
<span class="text-muted-s pull-right ml"><?=$userrow['qq']?></span>
<div class="media-box-heading text-purple m0">绑定的QQ</div>
</div>
</div>
</div>
<div class="list-group-item" style="border-width:0px;">
<div class="media-box">
<div class="pull-left">
<span class="fa-stack">
<em class="fa fa-circle fa-stack-2x text-info"></em>
<em class="fa fa-user fa-stack-1x fa-inverse text-white"></em>
</span>
</div>
<div class="media-box-body clearfix">
<?php if($userrow['daili']){?>
<small class="text-muted-s pull-right ml">平台代理</small>
<?php }else{?>
<small class="text-muted-s pull-right ml">暂无权限</small>
<?php }?>
<div class="media-box-heading text-info m0">代理权限</div>
</div>
</div>
</div>
<div class="list-group-item" style="border-width:0px;">
<div class="media-box">
<div class="pull-left">
<span class="fa-stack">
<em class="fa fa-circle fa-stack-2x text-danger"></em>
<em class="fa fa-heart fa-stack-1x fa-inverse text-white"></em>
</span>
</div>
<div class="media-box-body clearfix">
<?php if(get_isvip($userrow['vip'], $userrow['vipend'])){?>
<small class="text-muted-s pull-right ml">付费用户</small>
<?php }else{?>
<small class="text-muted-s pull-right ml">免费用户</small>
<?php }?>
<div class="media-box-heading text-success m0">用户权限</div>
</div>
</div>
</div>
<div class="list-group-item" style="border-width:0px;">
<div class="media-box">
<div class="pull-left">
<span class="fa-stack">
<em class="fa fa-circle fa-stack-2x text-success"></em>
<em class="fa fa-trophy fa-stack-1x fa-inverse text-white"></em>
</span>
</div>
<div class="media-box-body clearfix">
<?php if(get_isvip($userrow['vip'], $userrow['vipend'])){?>
<small class="text-muted-s pull-right ml">包月VIP</small>
<?php }else{?>
<small class="text-muted-s pull-right ml">暂未开通</small>
<?php }?>
<div class="media-box-heading text-success m0">会员时间</div>
</div>
</div>
</div>
<div class="list-group-item" style="border-width:0px;">
<div class="media-box">
<div class="pull-left">
<span class="fa-stack">
<em class="fa fa-circle fa-stack-2x text-warning"></em>
<em class="fa fa-pencil-square fa-stack-1x fa-inverse text-white"></em>
</span>
</div>
<div class="media-box-body clearfix">
<small class="text-muted-s pull-right ml"><?=get_count('qqs',"uid=:uid",'qid',array(':uid'=>$userrow['uid']))?>个</small>
<div class="media-box-heading text-warning m0">已添加QQ数</div>
<div class="progress progress-xs m0">
<div role="progressbar" aria-valuenow="22" aria-valuemin="0" aria-valuemax="100" style="width:0%;" class="progress-bar progress-bar-warning progress-bar-striped">
<span class="sr-only"></span>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="panel-footer clearfix" style="border-top-width:1px;">
<div class="col-xs-3"><a href="add.php" data-pjax class="btn btn-square btn-primary btn-block btn-xs">添加QQ</a></div>
<div class="col-xs-3"><a href="qq.php" data-pjax class="btn btn-square btn-primary btn-block btn-xs">QQ列表</a></div>
<div class="col-xs-3"><a href="qd.php" data-pjax class="btn btn-square btn-primary btn-block btn-xs">有奖签到</a></div>
<div class="col-xs-3"><a href="uset.php" data-pjax class="btn btn-square btn-primary btn-block btn-xs">资料修改</a></div>
        </div>
    </div>
</div>
<div class="col-lg-8" style="padding:0;">
  <div class="col-lg-12">
    <div class="panel widget">
      <div class="col-sm-3 col-xs-6 pv text-center br">
        <div class="text-info text-sm">注册会员人数</div>
        <div class="text-muted text-md"> <em class="icon-user"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
         <?=get_count('users', "1=:1", "uid", array(":1" => "1")) ?>
        </span> </div>
      </div>
      <div class="col-sm-3 col-xs-6 hidden-xs pv text-center br">
        <div class="text-info text-sm">全部QQ数量</div>
        <div class="text-muted text-md"> <em class="fa fa-qq"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
         <?=get_count('qqs', "1=:1", "uid", array(":1" => "1")) ?>
        </span> </div>
      </div>
      <div class="col-sm-3 hidden-xs pv text-center br">
        <div class="text-info text-sm">秒赞QQ数量</div>
        <div class="text-muted text-md"> <em class="icon-like"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
        <?=get_count('qqs', "iszan=:2 or iszan=:1", "qid", array(":1" => "1",":2"=>"2")) ?></span>
        </span> </div>
      </div>
      <div class="col-sm-3 hidden-xs pv text-center">
        <div class="text-info text-sm">秒评QQ数量</div>
        <div class="text-muted text-md"> <em class="icon-note"></em> </div>
        <div class="text-info"><?=get_count('qqs', "isreply='2' or isreply='1'", "qid", array(":1" => "1",":2"=>"2")) ?></span>
        </span> </div>
      </div>
      <div class="col-sm-3 col-xs-6 visible-xs pv text-center">
        <div class="text-info text-sm">全部QQ数量</div>
        <div class="text-muted text-md"> <em class="fa fa-qq"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
         <?=get_count('qqs', "1=:1", "uid", array(":1" => "1")) ?>
        </span> </div>
      </div>
      <div class="col-xs-6 visible-xs pv text-center br bt">
        <div class="text-info text-sm">秒赞QQ数量</div>
        <div class="text-muted text-md"> <em class="icon-like"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
          <?=get_count('qqs', "iszan=:2 or iszan=:1", "qid", array(":1" => "1",":2"=>"2")) ?>
        </span> </div>
      </div>
      <div class="col-xs-6 visible-xs pv text-center bt">
        <div class="text-info text-sm">秒评QQ数量</div>
        <div class="text-muted text-md"> <em class="icon-note"></em> </div>
        <div class="text-info"> <em class="wi wi-sprinkles"></em><span class="text-muted-s">
          <?=get_count('qqs', "isreply='2' or isreply='1'", "qid", array(":1" => "1",":2"=>"2")) ?></span>
        </span> </div>
      </div>
    </div>
  </div>


    <div class="col-lg-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                <a href="mzlist.php" class="pull-right label label-danger">CQY交友墙</a>
                <div class="panel-title">ta们正在秒赞</div>
            </div>
            <div data-height="180" data-scrollable="" class="list-group">
                <?php
                $rowss = $db->query("select * from {$prefix}qqs where iszan='1' or iszan='2' order by qid desc limit 20");
                ?>
                <?php while ($row = $rowss->fetch(PDO::FETCH_ASSOC)) { ?>
                    <div class="list-group-item bb">
                        <div class="media-box">
                            <div class="pull-left">
                                <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$row['qq'] ?>&amp;spec=100" alt="Image" class="media-box-object img-circle thumb35">
                            </div>
                            <div class="media-box-body clearfix">
                                <a target="_blank" href="tencent://AddContact/?fromId=45&amp;fromSubId=1&amp;subcmd=all&amp;uin=<?=$row['qq'] ?>&amp;website=www.xkmz.cc" class="label label-info pull-right" style="margin-top:8px;">加为好友</a>
                                <strong class="media-box-heading text-primary">
                                    <span class="circle circle-success circle-lg text-left"></span><?=$row['qq'] ?></strong>
                                <p class="mb-sm">
                                    <small><i class="fa fa-clock-o"></i> <?=$row['addtime'] ?></small>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>


    <div class="col-lg-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="panel-title">最新加入的用户</div>
            </div>
            <div data-height="180" data-scrollable="" class="list-group">
                <div id="liao">
                    <?php
                    $rowss = $db->query("select * from {$prefix}users where 1=1 order by uid desc limit 20");
                    ?>
                    <?php while ($row = $rowss->fetch(PDO::FETCH_ASSOC)) { ?>
                        <a class="list-group-item bb">
                            <div class="media-box"><div class="pull-left"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$row['qq'] ?>&amp;spec=100" alt="Image" class="media-box-object img-circle thumb36"></div><div class="media-box-body clearfix"><p class="mb-sm"><small>#<?=$row['uid'] ?>&nbsp;<?=$row['user'] ?></small></p><small><i class="fa fa-clock-o"></i> <?=$row['regtime'] ?></small></div></div>
                        </a>
                        <?php
                    } ?>
                </div>
            </div>
        </div>
	</div>
</div>


	 <div class="col-sm-4">
            <div class="panel panel-default">
                <div class="panel-heading">
				<div class="panel-title">网站信息</div>
				</div>
                <div class="panel-body">
                    网站系统：METI秒赞系统
					<hr>
					网站名称：<?= C('webname') ?>
                    <hr>
                    站长QQ：<?= C('webqq') ?>
                    <hr>
                    官方售后群：<?= C('webgroup') ?>
                    <hr>
                    程序版本：V1 (Build <?= VERSION ?>)
                    <hr>
                    网站域名：<?= C('webdomain') ?>
                </div>
            </div>
        </div>
    </div>
       
    </div>
</div>
<?php
include_once 'core.foot.php';
?>