<?php
require_once('common.php');
C('webtitle','聊天社区');
C('pageid','ltsq');
include_once 'core.head.php';
for ($i = 0; $i < 9; $i++) {
    $j = $i + 1;
    $userrs.=get_count('users', "adddate=:date", "uid", array(
        ":date" => date("Y-m-d", strtotime("-{$j} day"))
    )).",";
}
for ($i = 0; $i < 9; $i++) {
    $j = $i + 1;
    $qqrs.=get_count('qqs', "adddate=:date", "qid", array(
        ":date" => date("Y-m-d", strtotime("-{$j} day"))
    )).",";
}
if($_POST['infos']=="ye"){
$info=$_POST['info'];
$qid=$userrow['qq'];
$user=$userrow['user'];
$time=date("Y-m-d H:i:s");
	if($info==""){
    exit("<script language='javascript'>alert('喂喂，说话啊。⊙△⊙？【请输入信息】');window.location.href='';</script>");
	}else{
		if($db->query("INSERT INTO `{$prefix}chat` (`id`, `uid`, `user`, `info`, `time`, `qid`) VALUES (NULL, '{$row[uid]}', '$user', '$info', '$time', '$qid')")){
			  exit("<script language='javascript'>alert('发表成功！^_^');window.location.href='';</script>");
				}
			}
}
if($_GET['do']=="info"){
$id = $_GET['id'];
	if($userrow['active']!=9){
		exit("<script language='javascript'>alert('权限不足！只有管理员才能删除哦~');window.location.href='';</script>");
	}else{
		if(!$id){
			exit("<script language='javascript'>alert('id不能为空！');window.location.href='';</script>");
		}
		if($db->query("delete from `{$prefix}chat` where id=$id")){
			exit("<script language='javascript'>alert('删除成功！');window.location.href='';</script>");
		}else{
			exit("<script language='javascript'>alert('删除失败！');window.location.href='';</script>");
		}
	}
}
?>
<div class="row">
<div class="col-md-12">
      <div class="panel panel-primary">
          <div class="panel-heading portlet-handler ui-sortable-handle">聊天社区友情提示！</div>
          <div class="panel-wrapper">
              <div class="list-group-item bb">请不要在此辱骂/刷屏/广告/涉及黄色等内容</div>
              <div class="list-group-item">违者查到直接封号处理不解释~多谢配合</div>
          </div>
      </div>
  </div>
  
	 <div class="col-lg-12">
    <div class="panel panel-default">
       <div class="panel-heading">
          <div class="panel-title">CQY聊天室</div>
       </div>
       <div data-height="265" data-scrollable="" class="list-group">
          <div id="liao">
		  <?php
          $rowss = $db->query("select * from {$prefix}chat where 1=1 order by uid desc limit 20");
          ?>
          <?php while ($info = $rowss->fetch(PDO::FETCH_ASSOC)) { ?>
		  <div class="list-group-item bb">
                        <div class="media-box">
                            <div class="pull-left">
                                <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $info['qid'];?>&amp;spec=100" alt="Image" class="media-box-object img-circle thumb35">
                            </div>
		  <div class="media-box-body clearfix">
		  <a href="?do=info&id=<?php echo $info['id']; ?>" class="label label-info pull-right" style="margin-top:8px;">删除</a>
		  <strong class="media-box-heading text-primary">
          <span class="circle circle-success circle-lg text-left"></span><?php echo $info['user'];?> 说：<?php echo $info['info'] ?> </strong>
          <p class="mb-sm">
          <small><i class="fa fa-clock-o"></i><?php echo $info['time'] ?></small>
          </p>
		  </div>
		  </div>
		  
          </div>
		  <?php
           } 
		  ?>
       </div>
	    </div>
	    <div class="panel-footer clearfix">
		<form action="?" method="post"> 
	   <input type="hidden" name="infos" value="ye">
                  <div class="input-group">
                     <input type="text" placeholder="广告\刷屏\封号处理" name="info" maxlength="24" class="form-control input-sm" required="">
                     <span class="input-group-btn">
                        <button type="submit" class="btn btn-default btn-sm">发送
                        </button>
                     </span>
                  </div>
               </div>
			   <?php
include_once 'core.foot.php';
?>