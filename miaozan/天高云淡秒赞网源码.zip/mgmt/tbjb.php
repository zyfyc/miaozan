<?php
require_once('common.php');
C('webtitle','淘宝金币');
C('pageid','tbjb');
include_once 'core.head.php';
?>
<div class="row">
<div class="col-md-12">
      <div class="panel panel-primary">
          <div class="panel-heading portlet-handler ui-sortable-handle">一键领取淘宝金币提示</div>
          <div class="panel-wrapper">
              <div class="list-group-item bb">本程序不太稳定，若失效请等待站长修复更新</div>
          </div>
      </div>
  </div>
<div class="list-group-item">
<hr>
 <a class="btn btn-danger btn-block bk-margin-top-10" type="submit" href="https://login.taobao.com/" rel="external nofollow" target="_blank">登录淘宝</a><br><hr>
						<a class="btn btn-success btn-block bk-margin-top-10" href="#Coin" role="button" id="receive" >点击领取</a><a id="update"></a><br><hr>
						
						<a class="btn btn-warning btn-block bk-margin-top-10" target="_blank" href="https://taojinbi.taobao.com/coin/userCoinDetail.htm">查看记录</a>
						<hr>
						</div>
<div id="coin" class="coin"><script>var Coin = true;</script></div>
<script src="../../../api/tjb.js"></script>
<?php
include_once 'core.foot.php';
?>