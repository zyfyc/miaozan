<?php
require_once('common.php');
$qid = is_numeric($_POST['qid']) ? $_POST['qid'] : '0';
$now = date("Y-m-d-H:i:s");
if (!$qid || !$qqrow = get_results("select * from {$prefix}qqs where qid=:qid and uid=:uid limit 1", array(":qid" => $qid, ":uid" => $userrow['uid']))) {
    $json = json_encode(array("code" => "3", "data" => (array("title" => "设置失败", "msg" => "对不起，该QQ不是您账户名下的！", "type" => "warning", "timer" => "2000"))));
    exit($json);
}
if ($_POST['do'] == 'change') {
    if (!C('webfree') && !get_isvip($userrow['vip'], $userrow['vipend'])) {
        $json = json_encode(array("code" => "2", "data" => (array("title" => "设置失败", "msg" => "对不起，此功能仅VIP可使用！", "type" => "warning"))));
        exit($json);
    } else {
        $the = safestr($_POST['modid']);
        if ($the == "zan" or $the == "reply" or $the == "zf" or $the == "shuo") {
            $json = json_encode(array("code" => "1", "data" => (array("url" => "qqset.php?qid={$qid}&xz={$the}"))));
            exit($json);
        } else {
            $stmt = $db->prepare("select * from {$prefix}qqs where is{$the}='1' and qid='{$qid}' limit 1");
            $stmt->execute(array(':off' => "1"));
            if ($qqfunc = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($db->query("update {$prefix}qqs set is{$the}='0',last{$the}='0000-00-00 00:00:00' where qid='{$qid}'")) {
                    $json = json_encode(array("code" => "2", "data" => (array("title" => "关闭成功", "msg" => "已关闭成功！", "type" => "success", "timer" => "2000"))));
                } else {
					exit("update {$prefix}qqs set is{$the}='0',last{$the}='0000-00-00 00:00:00' where qid='{$qid}'");
                    $json = json_encode(array("code" => "2", "data" => (array("title" => "关闭失败", "msg" => "关闭失败！", "type" => "danger"))));
                }
                exit($json);
            } else {
                if ($db->query("update {$prefix}qqs set is{$the}='1',next{$the}='$now' where qid='{$qid}'")) {
                    $json = json_encode(array("code" => "2", "data" => (array("title" => "开启成功", "msg" => "已开启成功！", "type" => "success", "timer" => "2000"))));
                } else {
                    $json = json_encode(array("code" => "2", "data" => (array("title" => "开启失败", "msg" => "开启失败！", "type" => "danger"))));
                }
                exit($json);
            }
        }
    }
}
?>