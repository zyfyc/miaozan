<?php
require_once('common.php');
C('pageid', 'link');
C('webtitle', '友情链接');
include_once 'core.head.php';
?>
	<div id="content" class="app-content" role="includes">
	<div id="Loading" style="display:none">
		<div ui-butterbar="" class="butterbar active"><span class="bar"></span></div>
	</div>
</div><div class="col-lg-12">
<div class="panel panel-primary panel-demo">
            <div class="panel-heading">友情链接</strong>
</div>
               <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                               <td>网站名称</td>
                        <td>添加时间</td>
						<td>站长QQ</td>
                        <td>网站链接</td>
                        <td>查看</td>
                            </tr>
                            </thead>
                            <tbody>
 <?php
                $rows = $db->query("select * from {$prefix}link where 1=1 order by id desc");
                while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                    ?>
                         <tr>
                        <td><?=$row['name']?></td>
                        <td><?=$row['addtime']?></td>
                        <td><?=$row['qq']?></td>
                        <td><?=$row['link']?></td>
						<td>
                          <a href="http://<?=$row['link']?>">点击进入</a>
                        </td>
                                </tr>
								<?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

<?php
include_once 'core.foot.php';
?>