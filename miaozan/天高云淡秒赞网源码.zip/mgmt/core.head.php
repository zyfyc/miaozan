<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <meta name="description" content="天高云淡程序自带HTK人性化系统,能够离线为网友提供许多云功能,HTK概念是达到无需人工手动则达成任务">
   <meta name="keywords" content="QZONE助手,QQ空间红人必备神奇,QQ空间点赞插件,QQ助手,微商必备工具">
   <title><?=C('webtitle')?> - <?=C('webname')?></title>
   <link rel="shortcut icon" href="<?= $webcdn_api ?>/favicon.ico">
<?php
if($webcdn_api){
?>
   <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/vendor/fontawesome/css/font-awesome.min.css">
<?php
}else{
?>
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/fontawesome/css/font-awesome.min.css">
<?php
}
?>
<?php
if($webcdn_api){
?>
   <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/vendor/simple-line-icons/css/simple-line-icons.css">
<?php
}else{
?>
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/simple-line-icons/css/simple-line-icons.css">
<?php
}
?>
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/animate.css/animate.min.css">
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/whirl/dist/whirl.css">
   <link rel="stylesheet" type="text/css" href="http://luoci-1252111933.cosgz.myqcloud.com/sweetalert.css"/>
<?php
if($webcdn_api){
?>
   <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/vendor/weather-icons/css/weather-icons.min.css">
<?php
}else{
?>
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/weather-icons/css/weather-icons.min.css">
<?php
}
?>
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/css/bootstrap.css" id="bscss">
   <link rel="stylesheet" href="<?= $webcdn_api ?>/style/vendor/css/app.css" id="maincss">
   <link href="/style/user/layer/skin/layer.css" rel="stylesheet">
   <script src="/style/user/layer/layer.js"></script>
</head>

<body>
   <div class="wrapper">
      <header class="topnavbar-wrapper">
         <nav role="navigation" class="navbar topnavbar">
            <div class="navbar-header">
               <a href="#/" class="navbar-brand">
                  <div class="brand-logo">
                     <img src="<?= C('index_logo') ?>" alt="App Logo" class="img-responsive">
                  </div>
                  <div class="brand-logo-collapsed">
                     <img src="<?= $webcdn_api ?>/style/vendor/img/logo-single.png" alt="App Logo" class="img-responsive">
                  </div>
               </a>
            </div>
            <div class="nav-wrapper">
               <ul class="nav navbar-nav">
                  <li>
                     <a href="#" data-trigger-resize="" data-toggle-state="aside-collapsed" class="hidden-xs">
                        <em class="fa fa-navicon"></em>
                     </a>
                     <a href="#" data-toggle-state="aside-toggled" data-no-persist="true" class="visible-xs sidebar-toggle">
                        <em class="fa fa-navicon"></em>
                     </a>
                  </li>
                  <li>
                     <a href="/mgmt/uset.php" title="用户信息">
                        <em class="icon-user"></em>
                     </a>
                  </li>
                  <li>
                     <a href="/mgmt/logout.php" title="注销登陆">
                        <em class="icon-lock"></em>
                     </a>
                  </li>
				  <li>
                     <a href="/mgmt/shop.php" title="会员商城">
                        <em class="icon-layers"></em>
                     </a>
                  </li>
                  <li>
                     <a href="/mgmt/qq.php" title="QQ管理">
                        <em class="fa fa-qq"></em>
                     </a>
                  </li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                  <li>
                     <a href="#" data-search-open="">
                        <em class="icon-magnifier"></em>
                     </a>
                  </li>
                  <li class="visible-lg">
                     <a href="#" data-toggle-fullscreen="">
                        <em class="icon-size-fullscreen"></em>
                     </a>
                  </li>
                  <li class="dropdown dropdown-list">
                     <a href="#" data-toggle="dropdown">
                        <em class="icon-bell"></em>
                     </a>
                     <ul class="dropdown-menu animated flipInX">
                        <li>
                           <div class="list-group">
                              <a href="/mgmt/shop.php" class="list-group-item">
                                 <div class="media-box">
                                    <div class="pull-left">
                                       <em class="fa fa-twitter fa-2x text-info"></em>
                                    </div>
                                    <div class="media-box-body clearfix">
                                       <p class="m0">用户商城</p>
                                       <p class="m0 text-muted">
                                          <small>会员开通 / 配额购买</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="/mgmt/qq.php" class="list-group-item">
                                 <div class="media-box">
                                    <div class="pull-left">
                                       <em class="fa fa-qq fa-2x text-warning"></em>
                                    </div>
                                    <div class="media-box-body clearfix">
                                       <p class="m0">QQ列表</p>
                                       <p class="m0 text-muted">
                                          <small>管理我账户下的所有QQ</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="/mgmt/user.php" class="list-group-item">
                                 <div class="media-box">
                                    <div class="pull-left">
                                       <em class="fa fa-tasks fa-2x text-success"></em>
                                    </div>
                                    <div class="media-box-body clearfix">
                                       <p class="m0">资料修改</p>
                                       <p class="m0 text-muted">
                                          <small>查看信息 / 资料修改</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="#" class="list-group-item">
                                 <small>更多功能 ....</small>
                                 <span class="label label-danger pull-right">N+</span>
                              </a>
                           </div>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="#" data-toggle-state="offsidebar-open" data-no-persist="true">
                        <em class="icon-notebook"></em>
                     </a>
                  </li>
               </ul>
            </div>
            <form role="search" action="mzrz.php" class="navbar-form">
               <div class="form-group has-feedback">
                  <input name="qq" type="text" placeholder="在这里可以搜索自己或他人的秒赞认证 ..." class="form-control">
                  <div data-search-dismiss="" class="fa fa-times form-control-feedback"></div>
               </div>
               <button type="submit" class="hidden btn btn-default">Submit</button>
            </form>
         </nav>
      </header>
      <aside class="aside">
         <div class="aside-inner">
            <nav data-sidebar-anyclick-close="" class="sidebar">
               <ul class="nav">
                  <li class="has-user-block">
                     <div class="item user-block">
                   <div class="user-block-picture">
                      <div class="user-block-status">
                         <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100" alt="Avatar" width="60" height="60" class="img-thumbnail img-circle">
                         <div class="circle circle-success circle-lg"></div>
                      </div>
                   </div>
                   <div class="user-block-info">
                      <span class="user-block-name"><?=$userrow['user']?></span>
                      <span class="user-block-role"><?php if(get_isvip($userrow['vip'],$userrow['vipend'])){ echo "包月VIP";}else{echo"免费用户";}?> UID:<?=$userrow['uid']?></span>
                   </div>
                </div>

                  </li>
                  <li class="nav-heading ">
                     <span data-localize="sidebar.heading.HEADER">导航</span>
                  </li>
                  <li <?php if(C('pageid')=='user'){ echo'class="active"';}?>>
                     <a href="#dashboard" title="用户中心" data-toggle="collapse">
                        <em class="icon-speedometer"></em>
                        <span data-localize="sidebar.nav.DASHBOARD">用户中心</span>
                     </a>
                     <ul id="dashboard" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">用户中心</li>
                        <li <?php if(C('pageid')=='user'){ echo'class="active"';}?>>
                           <a href="/mgmt/index.php" title="用户中心">
                              <span>用户中心</span>
                           </a>
                        </li>
						<?php if($userrow['active']==9){?>
                        <li>
                           <a href="/admin/index.php" title="后台管理">
                              <span>网站后台</span>
                           </a>
                        </li>
						<?php } ?>
						<?php if($userrow['daili']){?>
                        <li <?php if(C('pageid')=='daili'){ echo'class="active"';}?>>
                           <a href="/mgmt/daili.php" title="代理后台">
                              <span>代理后台</span>
                           </a>
                        </li>
						<?php } ?>
                     </ul>
                  </li>
                  <li <?php if(C('pageid')=='qq' or C('pageid')=='add' or C('pageids')=='qid' or C('pageid')=='qqset'){ echo'class="active"';}?>>
                     <a href="/mgmt/qq.php" title="QQ管理">
                        <div class="pull-right label label-success"><?=get_count('qqs',"uid=:uid",'qid',array(':uid'=>$userrow['uid']))?></div>
                        <em class="icon-grid"></em>
                        <span data-localize="sidebar.nav.WIDGETS">QQ管理</span>
                     </a>
                  </li>
				  <?php if($userrow['fuzhan']){?>
                  <li <?php if(C('pageid')=='fzkmlist' or C('pageid')=='deputyqq' or C('pageid')=='deputyuser' or C('pageid')=='deputyuserset'){ echo'class="active"';}?>>
                     <a href="#fzz" title="副站长后台" data-toggle="collapse">
                        <em class="icon-user-female"></em>
                        <span data-localize="sidebar.nav.FZZ">副站后台</span>
                     </a>
                     <ul id="fzz" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">副站后台</li>
                        <li <?php if(C('pageid')=='fzkmlist'){ echo'class="active"';}?>>
                           <a href="/mgmt/deputy/kmlist.php" title="卡密生成">
                              <span>卡密生成</span>
                           </a>
                        </li>
						<li <?php if(C('pageid')=='deputyuser'){ echo'class="active"';}?>>
                           <a href="/mgmt/deputy/ulist.php" title="卡密生成">
                              <span>用户管理</span>
                           </a>
                        </li>
						<li <?php if(C('pageid')=='deputyqq'){ echo'class="active"';}?>>
                           <a href="/mgmt/deputy/qlist.php" title="卡密生成">
                              <span>挂机列表</span>
                           </a>
                        </li>
                     </ul>
                  </li>
					<?php } ?>
                  <li <?php if(C('pageid')=='uset' or C('pageid')=='uindex'){ echo'class="active"';}?>>
                     <a href="#elements" title="用户资料" data-toggle="collapse">
                        <em class="icon-user"></em>
                        <span data-localize="sidebar.nav.element.ELEMENTS">用户资料</span>
                     </a>
                     <ul id="elements" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">用户资料</li>
                        <li <?php if(C('pageid')=='uset'){ echo'class="active"';}?>>
                           <a href="/mgmt/uset.php" title="资料修改">
                              <span data-localize="sidebar.nav.element.BUTTON">资料修改</span>
                           </a>
                        </li>
                        <li <?php if(C('pageid')=='uindex'){ echo'class="active"';}?>>
                           <a href="/mgmt/uindex.php?uid=<?=$userrow['uid']?>" title="我的主页">
                              <span data-localize="sidebar.nav.element.NOTIFICATION">我的主页</span>
                           </a>
                        </li>
                     </ul>
                  </li>
				  <li>
                    <a id="ggw" href="/mgmt/link.php">
                             <em class="icon-layers" style="font-size:14px;"></em>
                   <span class="sidebar-nav-mini-hide">友情链接</span></a>
</li>
                   <li>
                    <a id="ltsq" href="/mgmt/ltsq.php">
                             <em class="fa fa-comment-o" style="font-size:14px;"></em>
                   <span class="sidebar-nav-mini-hide">聊天社区</span></a>
</li>
                  <li <?php if(C('pageid')=='shop' or C('pageid')=='rmb'){ echo'class="active"';}?>>
                     <a href="#shop" title="自助购买" data-toggle="collapse">
                        <em class="icon-handbag"></em>
                        <span data-localize="sidebar.nav.element.SHOP">自助购买</span>
                     </a>
                     <ul id="shop" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">自助购买</li>
                        <li <?php if(C('pageid')=='shop'){ echo'class="active"';}?>>
                           <a href="/mgmt/shop.php" title="自助开通">
                              <span data-localize="sidebar.nav.element.BUTTON">自助开通</span>
                           </a>
                        </li>
                        <li <?php if(C('pageid')=='rmb'){ echo'class="active"';}?>>
                           <a href="/mgmt/rmb.php" title="余额充值">
                              <span data-localize="sidebar.nav.element.NOTIFICATION">余额充值</span>
                           </a>
                        </li>
                     </ul>
                  </li>
				   <li <?php if(C('pageid')=='qd' or C('pageid')=='freevip' or C('pageid')=='reginfo'){ echo'class="active"';}?>>
                     <a href="#fuli" title="福利中心" data-toggle="collapse">
                        <em class="fa fa-heart-o"></em>
                        <span data-localize="sidebar.nav.element.fuli">福利中心</span>
                     </a>
                    <ul id="fuli" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">福利中心</li>
                        <li <?php if(C('pageid')=='qd'){ echo'class="active"';}?>>
                           <a href="/mgmt/qd.php" title="每日签到">
                              <span data-localize="sidebar.nav.fuli.FLOT">每日签到</span>
                           </a>
                        </li>
						<?php if(C("freevip")){ ?>
                        <li <?php if(C('pageid')=='freevip'){ echo'class="active"';}?>>
                           <a href="/mgmt/freevip.php" title="免费会员">
                              <span data-localize="sidebar.nav.fuli.RADIAL">免费会员</span>
                           </a>
                        </li>			
						<?php } ?>
                        <li <?php if(C('pageid')=='reginfo'){ echo'class="active"';}?>>
                           <a href="/mgmt/reginfo.php" title="邀请好友">
                              <span data-localize="sidebar.nav.fuli.RADIAL">邀请好友</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li <?php if(C('pageid')=='daigua'){ echo'class="active"';}?>>
                     <a href="#djdg" title="QQ等级加速" data-toggle="collapse">
                        <em class="icon-rocket"></em>
                        <span data-localize="sidebar.nav.djdg.DJDG">等级代挂</span>
                     </a>
                     <ul id="djdg" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">QQ等级加速</li>
						<?php
							$rowss1 = $db->query("select * from {$prefix}qqs where uid=".$userrow['uid']." order by qid desc");
							while($row = $rowss1->fetch(PDO::FETCH_ASSOC)){
						?>
                        <li <?php if(C('pageids')=='dgqid'.$row['qid']){ echo'class="active"';}?>>
                           <a href="/mgmt/qqdg.php?qid=<?=$row['qid']?>" title="QQ<?=$row[qq]?>">
                              <span># <?=$row[qq]?> 设置/添加</span>
                           </a>
                        </li>
						<?php }?>
                     </ul>
                  </li>
                  <li <?php if(C('pageid')=='mzlist' or C('pageid')=='auth' or C('pageid')=='qiuqiu'){ echo'class="active"';}?>>
                     <a href="#charts" title="其他功能" data-toggle="collapse">
                        <em class="icon-grid"></em>
                        <span data-localize="sidebar.nav.chart.CHART">其他功能</span>
                     </a>
                     <ul id="charts" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">其他功能</li>
                        <li <?php if(C('pageid')=='mzlist'){ echo'class="active"';}?>>
                           <a href="/mgmt/mzlist.php" title="QQ秒赞墙">
                              <span>CQY交友</span>
                           </a>
                        </li>
						
						 <li <?php if(C('pageid')=='app'){ echo'class="active"';}?>>
                           <a href="/mgmt/app.php" title="APP下载">
                              <span>APP下载</span>
                           </a>
                        </li>
                       
                        <li <?php if(C('pageid')=='help'){ echo'class="active"';}?>>
                           <a href="/mgmt/help.php" title="新手帮助">
                              <span>功能介绍</span>
                           </a>
                        </li>
						
						 <li <?php if(C('pageid')=='TVvip'){ echo'class="active"';}?>>
                           <a href="/mgmt/TVvip.php" title="影视VIP">
                              <span>影视VIP领取</span>
                           </a>
                        </li>
						
						 <li <?php if(C('pageid')=='tbjb'){ echo'class="active"';}?>>
                           <a href="/mgmt/tbjb.php" title="淘宝金币">
                              <span>淘金币一键领取</span>
                           </a>
                        </li>
						
                     </ul>
                  </li>
                  <li class=" ">
                     <a href="/mgmt/logout.php" title="注销登陆">
                        <em class="icon-logout"></em>
                        <span data-localize="sidebar.nav.DOCUMENTATION">注销登陆</span>
                     </a>
                  </li>
               </ul>
               <!-- END sidebar nav-->
            </nav>
         </div>
         <!-- END Sidebar (left)-->
      </aside>
      <!-- offsidebar-->
      <aside class="offsidebar hide">
         <!-- START Off Sidebar (right)-->
         <nav>
            <div role="tabpanel">
               <!-- Nav tabs-->
               <ul role="tablist" class="nav nav-tabs nav-justified">
                  <li role="presentation" class="active">
                     <a href="#app-settings" aria-controls="app-settings" role="tab" data-toggle="tab">
                        <em class="icon-equalizer fa-lg"></em>
                     </a>
                  </li>
                  <li role="presentation">
                     <a href="#app-chat" aria-controls="app-chat" role="tab" data-toggle="tab">
                        <em class="icon-user fa-lg"></em>
                     </a>
                  </li>
               </ul>
               <!-- Tab panes-->
               <div class="tab-content">
                  <div id="app-settings" role="tabpanel" class="tab-pane fade in active">
                     <h3 class="text-center text-thin">性能调节</h3>
                     <div class="p">
                        <h4 class="text-muted text-thin">主题</h4>
                        <div class="table-grid mb">
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-a.css">
                                    <input type="radio" name="setting-theme" checked="checked">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-info"></span>
                                       <span class="color bg-info-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-b.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-green"></span>
                                       <span class="color bg-green-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-c.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-purple"></span>
                                       <span class="color bg-purple-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-d.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-danger"></span>
                                       <span class="color bg-danger-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                        </div>
                        <div class="table-grid mb">
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-e.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-info-dark"></span>
                                       <span class="color bg-info"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-f.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-green-dark"></span>
                                       <span class="color bg-green"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-g.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-purple-dark"></span>
                                       <span class="color bg-purple"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="<?= $webcdn_api ?>/style/vendor/css/theme-h.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-danger-dark"></span>
                                       <span class="color bg-danger"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="p">
                        <h4 class="text-muted text-thin">布局</h4>
                        <div class="clearfix">
                           <p class="pull-left">固定导航</p>
                           <div class="pull-right">
                              <label class="switch">
                                 <input id="chk-fixed" type="checkbox" data-toggle-state="layout-fixed">
                                 <span></span>
                              </label>
                           </div>
                        </div>
                        <div class="clearfix">
                           <p class="pull-left">居中显示</p>
                           <div class="pull-right">
                              <label class="switch">
                                 <input id="chk-boxed" type="checkbox" data-toggle-state="layout-boxed">
                                 <span></span>
                              </label>
                           </div>
                        </div>
                        <div class="clearfix">
                           <p class="pull-left">收起侧边栏</p>
                           <div class="pull-right">
                              <label class="switch">
                                 <input id="chk-collapsed" type="checkbox" data-toggle-state="aside-collapsed">
                                 <span></span>
                              </label>
                           </div>
                        </div>
                        <div class="clearfix">
                           <p class="pull-left">窗口浮动</p>
                           <div class="pull-right">
                              <label class="switch">
                                 <input id="chk-collapsed-text" type="checkbox" data-toggle-state="aside-collapsed-text">
                                 <span></span>
                              </label>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div id="app-chat" role="tabpanel" class="tab-pane fade">
                     <h3 class="text-center text-thin">系统QQ列表</h3>
                     <ul class="nav">
                        <!-- START list title-->
                        <li class="p">
                           <small class="text-muted">最新添加</small>
                        </li>
                        <!-- END list title-->
						<?php 
						$rowss = $db->query("select * from {$prefix}qqs where 1=1 order by qid desc limit 10");
						while($row = $rowss->fetch(PDO::FETCH_ASSOC)){
						?>
                        <li>
                           <!-- START User status-->
                           <a href="#" class="media-box p mt0">
                              <span class="pull-right">
                                 <span class="circle circle-success circle-lg"></span>
                              </span>
                              <span class="pull-left">
                                 <!-- Contact avatar-->
                                 <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$row['qq']?>&spec=100" alt="Image" class="media-box-object img-circle thumb48">
                              </span>
                              <!-- Contact info-->
                              <span class="media-box-body">
                                 <span class="media-box-heading">
                                    <strong># <?=$row[qq]?></strong>
                                    <br>
                                    <small class="text-muted"><?=$row[addtime]?></small>
                                 </span>
                              </span>
                           </a>
                           <!-- END User status-->
                           <!-- END User status-->
                        </li>
						<?php } ?>
                        <li>
                           <div class="p-lg text-center">
                              <!-- Optional link to list more users-->
                              <a href="#" ui-sref="add" title="See more contacts" class="btn btn-info btn-square btn-block btn-sm">
							  查看更多
							  </a>
                           </div>
                        </li>
                     </ul>
                     <!-- Extra items-->
                  </div>
               </div>
            </div>
         </nav>
         <!-- END Off Sidebar (right)-->
      </aside>
      <!-- Main section-->
      <section>
         <!-- Page content-->
         <div class="content-wrapper fadeIn ng-scope">
			<h3 style="overflow:hidden;">
			<span class="pull-left"><?=C('webtitle')?></span>
			<div style="width:100%; height:4px;" class="hidden-xs"></div>
			<ol class="breadcrumb pull-right">
                  <?php if(C('pageid')!='user'){ ?>
				  <li class="active"><?=C('webtitle')?></li>
				  <?php } ?>
				  <li><a href="/mgmt/index.php" title="返回用户中心">主页</a></li>
			</ol>
			</h3>