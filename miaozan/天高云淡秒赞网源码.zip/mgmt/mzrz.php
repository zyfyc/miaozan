<?php
require_once('common.php');
C('webtitle', '秒赞认证');
C('pageid', 'mzrz');
$qq = is_numeric($_GET['qq']) ? $_GET['qq'] : '0';
if ($_GET['do'] == "search") {
    if (!$_POST['qq'] || !$qqrows = get_results("select * from {$prefix}qqs where qq=:qq limit 1", array(":qq" => $_POST['qq']))) {
        $dofor=1;
    }
} else {
    if (!$qq || !$qqrows = get_results("select * from {$prefix}qqs where qq=:qq limit 1", array(":qq" => $qq))) {
        $dofor=1;
    }
}
	if($qqrows['zannet']=="1"){
		$net="免费";
	}else{
		$net="VIP";
	}
?>
<?php if($dofor==1){?>

<!DOCTYPE HTML>
<html>
<head>
<title>不!此QQ还没加入系统-秒赞认证-<?=C('webname')?></title>
<meta charset="utf-8">
<meta name="keywords" content="<?=C('webname')?>秒赞认证,离线CQY认证,24h离线秒赞"/>
<meta name="description" content="<?=C('webname')?>"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://luoci-1252111933.cosgz.myqcloud.com/rz/rz.css" />
<link href="//netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
</head>
	<body class="is-loading">
			<div id="wrapper">
					<section id="main">				
						<header>
						<img src="http://luoci-1252111933.cosgz.myqcloud.com/rz/rz.png" style="margin-bottom:10px;">
			<h3>槽糕,系统未找到</h3>
			<p>
				该QQ未通过或未加入本站认证系统
			</p>		
						</header>
						<footer>
							<ul class="icons">
<img src="http://luoci-1252111933.cosgz.myqcloud.com/rz/qq.png" title="该QQ未加入本站认证系统">
							</ul>
						</footer>
						<hr>
						  <form action="/mgmt/mzrz.php" role="form" method="get">
                            <input type="text"  name="qq" value="" placeholder="输入QQ账号" type="submit" name="submit" value="1" placeholder="输入要查询的QQ号码" class="form-control">
							 
<br>
<p style="text-align:center;">
<input value="秒赞认证查询" style="width:100%;" type="submit">
</p>
</form>
					</section>
					<footer id="footer">
						<ul class="copyright">
							<li> ©2016 <a href="http://<?php echo $_SERVER['HTTP_HOST']?>" id="foot_a"><?php echo $_SERVER['HTTP_HOST']?>						</a></li>
						</ul>
					</footer>

			</div>
			<script>
				if ('addEventListener' in window) {
					window.addEventListener('load', function() { document.body.className = document.body.className.replace(/\bis-loading\b/, ''); });
					document.body.className += (navigator.userAgent.match(/(MSIE|rv:11\.0)/) ? ' is-ie' : '');
				}
			</script>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<?php }else{ ?>
<!DOCTYPE HTML>
<html>
<head>
<title><?=$qqrows['qq']?>-秒赞认证-<?=C('webname')?></title>
<meta charset="utf-8">
<meta name="keywords" content="<?=C('webname')?>秒赞认证,离线CQY认证,<?=$qqrows['qq']?>秒赞验证,<?=$qqrows['qq']?>-24h离线秒赞"/>
<meta name="description" content="<?=C('webname')?>"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://luoci-1252111933.cosgz.myqcloud.com/rz/rz.css" />
<link href="//netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
</head>
	<body class="is-loading">
			<div id="wrapper">
					<section id="main">				
						<header>
						<img src="http://luoci-1252111933.cosgz.myqcloud.com/rz/rz.png" style="margin-bottom:10px;">
							<span class="avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$qqrows['qq']?>&s=100"></span>
							<h1><?= get_qqnick($qqrows['qq']) ?></h1>
							<?php
$result=$db->query("select * from {$prefix}qqs where qq='$qq' limit 1");
if($row = $result->fetch(PDO::FETCH_ASSOC)){
	$gtk=getGTK($row['p_skey']);
	$url='http://mobile.qzone.qq.com/list?g_tk='.$gtk.'&res_attach=att%3D0&format=json&list_type=shuoshuo&action=0&res_uin='.$row['qq'].'&count=5';
	$cookie='uin=o0'.$row['qq'].'; skey='.$row['skey'].'; p_skey='.$row['p_skey'].'; p_uin=o0'.$row['qq'].';';
	$json=get_curl($url,0,'http://mobile.qzone.qq.com/infocenter?g_ut=3&g_f=6676',$cookie);
	$arr=json_decode($json,true);
	$zan=0;
	if($arr=$arr['data']['vFeeds']){
		foreach($arr as $new){
			if($new['like']['num']>$zan) $zan=$new['like']['num'];
		}
	}
?>
							<p>
								本QQ目前已经积累底赞：<?php echo $zan?>个 ，快加他吧！
										</p>	
										<?php }?>
						<p>
								QQ：[<?=$qqrows['qq']?>]，<?php if (!getzts($qqrows['iszan'])) {?>已开启<?php }else{?>未开启<?php }?><a href="http://<?php echo $_SERVER['HTTP_HOST']?>"><?=C('webname')?></a>秒赞服务，可放心添加为好友。
										</p>					
						</header>
						<footer>
							<ul class="icons">
							    <li>

								<a href="http://user.qzone.qq.com/<?=$qqrows['qq']?>" target="_blank" class="fa fa-star-o bg-darkorange" title="访问空间"></a></li>
							    <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?=$qqrows['qq']?>&site=qq&menu=yes" target="_blank" class="fa fa-commenting-o" title="点击聊天"></a></li>
																<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?=$qqrows['qq']?>&site=qq&menu=yes" target="_blank" class="fa fa-qq" title="添加好友">></a></li>								</a></li>
							</ul>
						</footer>
						<hr>
						  <form action="/mgmt/mzrz.php" role="form" method="get">
                            <input type="text"  name="qq" value="" placeholder="输入QQ账号" type="submit" name="submit" value="1" placeholder="输入要查询的QQ号码" class="form-control">
							 
<br>
<p style="text-align:center;">
<input value="秒赞认证查询" style="width:100%;" type="submit">
</p>
</form>
					</section>
					<footer id="footer">
						<ul class="copyright">
							<li> ©2016 <a href="http://<?php echo $_SERVER['HTTP_HOST']?>" id="foot_a"><?php echo $_SERVER['HTTP_HOST']?>						</a></li>
						</ul>
					</footer>

			</div>
			<script>
				if ('addEventListener' in window) {
					window.addEventListener('load', function() { document.body.className = document.body.className.replace(/\bis-loading\b/, ''); });
					document.body.className += (navigator.userAgent.match(/(MSIE|rv:11\.0)/) ? ' is-ie' : '');
				}
			</script>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<?php }?>
</body>
<html>
