<?php
require_once('common.php');
if(C("dgapi")!="1")exit ("<script> alert('请到QQ列表中选择QQ号码进入管理中找到QQ等级代挂打开');history.go(-1); </script>");
$hera = C('kmurl');//购卡链接
$apiid = C('apiid');//APIID
$apikey = C('apikey');//APIKEY
$uid=$userrow['uid'];

if(!$apiid || !$apikey){
	exit ("<script> alert('请站长先在后台配置好代挂设置！');history.go(-1); </script>");
}

if($_POST['do']=='add'){ //添加代挂
	$qq = trim($_POST['qq']);
	$pwd = trim($_POST['pwd']);
	$km = trim($_POST['km']);
	$data=get_curl('http://api.66dg.cc/Mzapi/add.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq.'&pwd='.urlencode($pwd).'&kami='.urlencode($km));
	if($arr=json_decode($data,true)){
		if($arr['code']==10000) {
			exit('{"code":1,"msg":"'.$arr['msg'].'"}');
		}else{
			exit('{"code":0,"msg":"'.$arr['msg'].'"}');
		}
	}else{
		exit('{"code":0,"msg":"连接失败，请重试！1"}');
	}
}

if($_POST['do']=='xu'){ //续费代挂
	$qq = trim($_POST['qq']);
	$km = trim($_POST['km']);
	$data=get_curl('http://api.66dg.cc/Mzapi/renew.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq.'&kami='.urlencode($km));
	if($arr=json_decode($data,true)){
		if($arr['code']==10000) {
			exit('{"code":1,"msg":"'.$arr['msg'].'"}');
		}else{
			exit('{"code":0,"msg":"'.$arr['msg'].'"}');
		}
	}else{
		exit('{"code":0,"msg":"连接失败，请重试！1"}');
	}
}

if($_POST['do']=='gm'){ //更新密码
	$qq = trim($_POST['qq']);
	$pwd = trim($_POST['pwd']);
	$data=get_curl('http://api.66dg.cc/Mzapi/password.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq.'&pwd='.urlencode($pwd));
	if($arr=json_decode($data,true)){
		if($arr['code']==10000) {
			exit('{"code":1,"msg":"'.$arr['msg'].'"}');
		}else{
			exit('{"code":0,"msg":"'.$arr['msg'].'"}');
		}
	}else{
		exit('{"code":0,"msg":"连接失败，请重试！1"}');
	}
}

if($_POST['do']=='set'){ //设置开关
	$qq = trim($_POST['qq']);
	$yid = trim($_POST['id']);
	$data=get_curl('http://api.66dg.cc/Mzapi/operation.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq.'&num='.$yid);
	if($arr=json_decode($data,true)){
		if($arr['code']==10001) {
			exit('{"code":1}');
		}elseif($arr['code']==10002) {
			exit('{"code":2}');
		}else{
			exit('{"code":0,"msg":"'.$arr['msg'].'"}');
		}
	}else{
		exit('{"code":0,"msg":"连接失败，请重试！1"}');
	}
}

if($_POST['do']=='bugua'){ //补挂操作
	$qq = trim($_POST['qq']);
	$yid = trim($_POST['id'])-7;
	$data=get_curl('http://api.66dg.cc/Mzapi/bugua.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq.'&num='.$yid);
	if($arr=json_decode($data,true)){
		if($arr['code']==10000) {
			exit('{"code":1,"msg":"'.$arr['msg'].'"}');
		}else{
			exit('{"code":0,"msg":"'.$arr['msg'].'"}');
		}
	}else{
		exit('{"code":0,"msg":"连接失败，请重试！1"}');
	}
}

if($_GET['do']=='del'){ //删除QQ
	$qq = trim($_GET['qq']);
	$p=is_numeric($_GET['p'])?$_GET['p']:'1';
	$data=get_curl('http://api.66dg.cc/Mzapi/refund.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq);
	if($arr=json_decode($data,true)){
		if($arr['code']==10000) {
			exit("<script language='javascript'>alert('删除QQ成功！');window.location.href='daigua.php?p=".$p."';</script>");
		}else{
			exit ("<script language='javascript'>alert('".$arr['msg']."');window.location.href='daigua.php?p=".$p."'; </script>");
		}
	}else{
		exit ("<script language='javascript'>alert('连接失败，请重试！');window.location.href='daigua.php?p=".$p."'; </script>");
	}
}

if($_GET['se']=='qq'){ //获取QQ信息
	$qq=is_numeric($_GET['qq'])?$_GET['qq']:'0';
	if(!$qq){exit ("<script> alert('QQ号不存在！');history.go(-1); </script>");}
	$data=get_curl('http://api.66dg.cc/Mzapi/message.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq);
	if($arr=json_decode($data,true)){
		if($arr['code']!=10000) {
			exit ("<script> alert('".$arr['msg']."');history.go(-1); </script>");
		}
	}else{
		exit ("<script> alert('连接失败，请重试！');history.go(-1); </script>");
	}
}

$gg=get_curl('http://api.66dg.cc/Mzapi/gg.html?buid=1.4');

function getszt($is,$id){
	if($is==2){
		return '<a class="btn btn-block btn-info xu" id="'.$id.'" >已开启</a>';
	}else{
		return '<a class="btn btn-block btn-warning xu" id="'.$id.'" >已暂停</a>';
	}
}

function getsbg($is,$tm,$id,$num){
	if($is==1 && $tm==date('Y-m-d')){
		return '[<a class="xu" id="'.$id.'" xz="1">已加入</a>]';
	}elseif($is==2 && $tm==date('Y-m-d')){
		return '[<a class="xu" id="'.$id.'" xz="1">已补挂</a>]';
	}else{
		return '[<a class="xu" id="'.$id.'" xz="1">补挂</a>]';
	}
}

C('pageid','daigua');
C('webtitle','代挂列表');
include_once 'core.head.php';
?>
<link href="http://www.52daigua.cc/xiaoke/css/plugins/sweetalert/sweetalert.css" rel="stylesheet">
<script src="http://www.52daigua.cc/xiaoke/js/plugins/sweetalert/sweetalert.min.js"></script>
<script src="http://www.52daigua.cc/xiaoke/js/jquery-2.1.1.min.js"></script>

<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8 col-md-6">
        <h2>代挂设置</h2>
        <ol class="breadcrumb">
            <li><a href="/mgmt">主页</a>
            </li>
            <li><strong><a href="daigua.php">代挂列表</a></strong>
            </li>
            <li><a data-toggle="modal" data-target="#myModal1">代挂帮助</a>
            </li>
        </ol>
    </div>
    <div class="col-lg-4 col-md-6">
        <form style="margin-top:10px;" role="search" action="daigua.php" method="post">
            <input type="hidden" name="do" value="search">
            <div class="input-group">
                <input type="text" class="form-control" name="qq" placeholder="输入你要搜索的QQ号码" maxlength="10" onKeyUp="value=value.replace(/[^1234567890-]+/g,'')">
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-primary">搜索</button>
                </span>
            </div>
        </form>
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <?php if($gg){?>
        
        <!-----------主系统通知开始---------->
        <div class="col-md-12">
            <div class="alert alert-danger" style="margin-bottom:10px;">
                <?=$gg?>
            </div>
        </div>
        <!-----------主系统通知结束---------->
        
		<?php }
        if($_GET['se']=='add' || $_GET['se']=='xu' || $_GET['se']=='gm'){?>
		
        <!-----------公告内容开始---------->
        <div class="col-md-4">
            <div class="widget-head-color-box blue-bg p-xs text-center" style="margin-top:0px;">
                <div class="m-t-xxs m-b-xxs">
                    <h2 class="font-bold no-margins">代挂公告</h2>
                </div>
            </div>
            <div class="widget-text-box" style="padding:10px 10px 2px 10px;margin-bottom:15px;">
                <?php if(C('gonggao_daigua')){echo C('gonggao_daigua');}else{echo '<p class="bg-success" style="padding:10px;">请在后台管理配置代挂公告内容！</p>';}?>
            </div>
        </div>
        <!-----------公告内容结束---------->
        
        <?php }
		if($_GET['se']=='add'){ ?>
        
        <!-----------添加代挂页面开始---------->
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">添加QQ进行代挂</h3>
                </div>
                <div class="list-group-item"><?php if($hera){?><a href="<?=$hera?>" class="pull-right btn btn-success btn-xs">购买卡密</a><?php }?>
                <span style="size:14px; color:#F36" id='load'>&nbsp;添加QQ后可进行详细设置，添加前请看上方的代挂帮助，有问题请联系QQ:<?=C('webqq')?></span>
                </div>
                <div class="list-group-item">
                    <form>
                    <div class="input-group" style="padding-bottom:15px;">
                        <div class="input-group-addon">Q&nbsp;&nbsp;Q</div>
                        <input type="text" class="form-control" id="qq" placeholder="请输入QQ号" value="" onKeyUp="value=value.replace(/[^1234567890-]+/g,'')" maxlength="10">
                    </div>
                    <div class="input-group" style="padding-bottom:15px;">
                        <div class="input-group-addon">密&nbsp;&nbsp;码</div>
                        <input type="text" class="form-control" id="pwd" placeholder="请输入QQ密码" value="">
                    </div>
                    <div class="input-group" style="padding-bottom:15px;">
                        <div class="input-group-addon">代挂卡密</div>
                        <input type="text" class="form-control" id="km" placeholder="请输入卡密" value="">
                    </div>
                    <label class="btn btn-primary btn-block" id='isdaigua'>确定</label>
                    </form>  
                </div>
            </div>
        </div>
        <script>
			$(document).ready(function () {
				$("#isdaigua").click(function(){
					var qq= $("#qq").val(); 
					var pwd= $("#pwd").val(); 
					var km= $("#km").val();
					if(!qq){
						swal({title:"操作失败!",text:"亲，你还没有输入QQ号呢！",type:"warning"})
						return false;
					}
					if(!pwd){
						swal({title:"操作失败!",text:"亲，你还没有输入密码呢！",type:"warning"})
						return false;
					}
					if(!km){
						swal({title:"操作失败!",text:"亲，你还没有输入卡密呢！",type:"warning"})
						return false;
					}
					swal({
						title:"请核对QQ号和密码！",
						text:"Q Q："+qq+"\r\n密码："+pwd+"\r\nQQ号码填错将无法修改！！",
						showCancelButton:true,
						confirmButtonColor:"#DD6B55",
						confirmButtonText:"确定正确",
						cancelButtonText:"返回重写",
						closeOnConfirm:false
					},
					function(){
						layer.load(0,2);
						var url="daigua.php";
						xiha.postData(url, "do=add&qq="+qq+"&pwd="+pwd+"&km="+km, function(d) {
							layer.closeAll('loading');
							if(d.code==1){
								swal({title:"添加成功！",type:"success"})
								$('#load').html(d.msg+' <strong><a href="?se=qq&qq='+qq+'" >点此进入设置</a></strong>');
							}else{
								swal({title:"添加失败!",text:d.msg,type:"warning"})
							}
						});
					})
				});
			});
		</script>
        <!-----------添加代挂页面结束---------->
        
        <?php }
        if($_GET['se']=='xu'){?>
        
        <!-----------续费代挂页面开始---------->
        <div class="col-md-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>代挂续费</h5><?php if($hera){?><a href="<?=$hera?>" class="pull-right btn btn-success btn-xs">购买卡密</a><?php }?>
                </div>
                <div class="ibox-content">
                    <form>
                        <div class="list-group-item red" style="color:#F36" id='load'>
                            你正在为QQ:<?=$_GET['qq']?>进行续费操作，请输入新的代挂卡密。
                        </div>
                        <div class="list-group-item">
                            <div class="input-group">
                                <div class="input-group-addon">输入卡密</div>
                                <input type="text" class="form-control" id="km" placeholder="请输入代挂卡密" value="">
                            </div>
                        </div>
                        
                        <div class="list-group-item">
                            <label class="btn btn-primary btn-block" id='isxu'>确定</label>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
			$(document).ready(function () {
				$("#isxu").click(function(){
					var km= $("#km").val();
					if(!km){
						swal({title:"操作失败!",text:"亲，你还没有输入卡密呢！",type:"warning"})
						return false;
					}
					layer.load(0,2);
					var url="";
					xiha.postData(url, "do=xu&qq=<?=$_GET['qq']?>&km="+km, function(d) {
						layer.closeAll('loading');
						if(d.code==1){
							swal({title:"续费成功！",type:"success"})
							$('#load').html(d.msg+' <strong><a href="?se=qq&qq=<?=$_GET['qq']?>" >点此进入设置</a></strong>');
						}else{
							swal({title:"续费失败!",text:d.msg,type:"warning"})
						}
					});
				});
			});
		</script>
        <!-----------续费代挂页面结束---------->
        
        <?php }
		if($_GET['se']=='gm'){ ?>
        
        <!-----------更新密码页面开始---------->
        <div class="col-md-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>更新密码</h5>
                </div>
                <div class="ibox-content">
                    <form>
                        <div class="list-group-item red" style="color:#F36" id='load'>
                            你正在为QQ:<?=$_GET['qq']?>更新密码，请输入你的新密码。
                        </div>
                        <div class="list-group-item">
                            <div class="input-group">
                                <div class="input-group-addon">密&nbsp;&nbsp;码</div>
                                <input type="text" class="form-control" id="pwd"placeholder="输入QQ密码" value="">
                            </div>
                        </div>
                        
                        <div class="list-group-item">
                            <label class="btn btn-primary btn-block" id='isgm'>确定</label>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
			$(document).ready(function () {
				$("#isgm").click(function(){
					var pwd= $("#pwd").val(); 
					if(!pwd){
						swal({title:"操作失败!",text:"亲，你还没有输入密码呢！",type:"warning"})
						return false;
					}
					swal({
						title:"请核对您的密码！",
						text:"密码："+pwd,
						showCancelButton:true,
						confirmButtonColor:"#DD6B55",
						confirmButtonText:"确定正确",
						cancelButtonText:"返回重写",
						closeOnConfirm:false
					},
					function(){
						layer.load(0,2);
						var url="";
						xiha.postData(url, "do=gm&qq=<?=$_GET['qq']?>&pwd="+pwd, function(d) {
							layer.closeAll('loading');
							if(d.code==1){
								swal({title:"更新密码成功！",type:"success"})
								$('#load').html(d.msg+' <strong><a href="?se=qq&qq=<?=$_GET['qq']?>" >点此进入设置</a></strong>');
							}else{
								swal({title:"更新密码失败!",text:d.msg,type:"warning"})
							}
						});
					})
				});
			});
		</script>
        <!-----------更新密码页面结束---------->
        
        <?php }
		if($_GET['se']=='qq'){ ?>
        
        <!-----------QQ设置页面开始---------->
        <div class="col-md-6">
            <div class="widget-head-color-box navy-bg p-xxs" style="overflow:hidden; margin-top:0px;">
                <div class="m-b-xs">
                    <dl class="dl-horizontal" style="margin-bottom:0px;">
                        <dt style="float:left;"><img alt="image" class="img-circle m-r-xs" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$arr['qq']?>&spec=100" style="width:85px;"></dt>
                        <dd>
                            <h3><strong># <?=$arr['qq']?></strong></h3>
                            <h4><strong>状态：<?php if($arr['zt']==3){ echo '已过期&nbsp;&nbsp;<a class="btn btn-success btn-xs" href="?se=xu&qq='.$arr['qq'].'">续费</a>';}elseif($arr['zt']==1){ echo '密码错误';}elseif($arr['zt']==2){ echo '帐号冻结';}else{ echo '正常';}?></strong></h4>
                            <hr style="margin:3px auto;">
                            添加时间:<?=$arr['addtm']?>
                            <br/>
                        </dd>
                    </dl>
                </div>
            </div>
            <div class="ibox-content profile-content m-b">
                <h3 class="font-bold no-margins" style=" padding-bottom:5px;">温馨提醒：</h3>
                <small>代挂期间修改了QQ的密码，记得来这里更新，否则登录不上无法代挂哦！<br /></small>
                <small>上方状态非正常时请更新一次QQ密码即可恢复！<br /></small>
                <h5><hr style="margin:10px auto;"></h5>
                <div class="user-button">
                    <div class="row" style="margin:auto -5px;">
                        <div class="col-xs-6 m-b-xs">
                            <a class="btn btn-success btn-sm btn-block" href="?se=gm&qq=<?=$arr['qq']?>">更新密码</a>
                        </div>
                        <div class="col-xs-6 m-b-xs">
                            <a data-toggle="modal" data-target="#myModal1" class="btn btn-success btn-sm btn-block">代挂帮助</a>
                        </div>
                    </div>
                </div>
                <hr style="margin:10px auto;">
                <div class="table-responsive" style="margin-bottom:0px;">
                    <div class="tooltip-demo">
                        <table class="table table-bordered table-striped" style="margin-bottom:0px;">
                            <thead>
                                <tr>
                                    <th height="50px" style="vertical-align:inherit;background-color:#35b5c8;color:#FFF;">#</th>
                                    <th style="vertical-align:inherit;background-color:#35b5c8;color:#FFF;">加速项目</th>
                                    <th width="30%" style="vertical-align:inherit;background-color:#35b5c8;color:#FFF;">操作开关</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-danger"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="每天0点登陆PcQQ进行登陆挂机2小时，领取0.5天成长值(会不断挤掉你自己的电脑QQ，介意者请勿开启！)">电脑在线&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['pcnum']?>天  <?=getsbg($arr['pcbg'],$arr['pcbgtm'],8)?>
                                    </small></td>
                                    <td><?=getszt($arr['ispc'],1)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-navy"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="每天0点登陆手机QQ6小时，领取1.0天成长值(会零时挤掉一次你的手机QQ，介意者请勿开启！)">手机在线&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['mqqnum']?>天  <?=getsbg($arr['mqqbg'],$arr['mqqbgtm'],9)?>
                                    </small></td>
                                    <td><?=getszt($arr['ismqq'],2)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-navy"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="登陆电脑管家代挂30分钟，领取1.0天成长值">管家加速&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['gjnum']?>天  <?=getsbg($arr['gjbg'],$arr['gjbgtm'],10)?>
                                    </small></td>
                                    <td><?=getszt($arr['isgj'],3)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-primary"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="登陆PCQQ点亮勋章墙图标，领取0.2天成长值(会临时顶掉你的电脑QQ一次！)">勋章加速&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['xznum']?>天  <?=getsbg($arr['xzbg'],$arr['xzbgtm'],11)?>
                                    </small></td>
                                    <td><?=getszt($arr['isxz'],4)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-danger"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="登陆QQ音乐秒领0.5天成长值">音乐加速&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['yynum']?>天  <?=getsbg($arr['yybg'],$arr['yybgtm'],12)?>
                                    </small></td>
                                    <td><?=getszt($arr['isyy'],5)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-info"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="登陆天天飞车游戏进行签到，领取0.2天成长值">手游加速&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['synum']?>天  <?=getsbg($arr['sybg'],$arr['sybgtm'],13)?>
                                    </small></td>
                                    <td><?=getszt($arr['issy'],6)?></td>
                                </tr>
                                
                                <tr>
                                    <th style="vertical-align:inherit;"><i class="fa fa-circle text-warning"></i></th>
                                    <td><strong data-toggle="tooltip" data-placement="top" title="登陆QQ钱包进行签到，领取0.2天成长值">钱包加速&nbsp;<i class="fa fa-question-circle"></i></strong><br />
                                    <small class="text-muted">
                                    剩余:<?=$arr['qbnum']?>天  <?=getsbg($arr['qbbg'],$arr['qbbgtm'],14)?>
                                    </small></td>
                                    <td><?=getszt($arr['isqb'],7)?></td>
                                </tr>
                                
                                <tr>
                                    <th colspan="2"><a class="btn btn-block btn-info xu" id="15" xz="1"><?php if($bgtime==date("Y-m-d")){ echo '已加入补挂列队';}else{ echo '一键补挂';} ?></a></th>
                                    <td><a class="btn btn-block btn-success" href="?se=xu&qq=<?=$arr['qq']?>">续费</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>代挂错误日志 <small class="text-muted">[ 请参见<a data-toggle="modal" data-target="#myModal1" >代挂帮助</a>对应解决方法 ]</small></h5>
                </div>
                <div class="ibox-content">
                    <table class="table table-bordered" style="margin-bottom:0px;">
                        <thead>
                            <tr style="color:#FFF;">
                                <th style="background-color:#35b5c8;">代挂类型</th>
                                <th style="background-color:#35b5c8;">错误原因</th>
                                <th style="background-color:#35b5c8;">代挂时间</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($arr['rlist']){
							foreach($arr['rlist'] as $arrs){?>
                            <tr>
                                <td><?=$arrs['name']?></td>
                                <td><?=$arrs['mc']?></td>
                                <td><?php echo date('m-d H:i',strtotime($arrs['addtime']));?></td>
                            </tr>
                        <?php }
						}else{?>
                            <tr><td colspan="4" align="center">暂无错误记录！</td></tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
			$('.xu').click(function(){
				var self=$(this),
				xz=self.attr('xz'),
				id=self.attr('id');
				layer.load(0,2);
				if(xz==1){
					var url="";
					xiha.postData(url, "do=bugua&qq=<?=$arr['qq']?>&id="+id, function(d) {
						layer.closeAll('loading');
						if(d.code==1){
							swal({title:"操作成功!",text:d.msg,type:"success"});
							if(id==15){
								$("#"+id).html("已加入补挂列队");
							}else{
								$("#"+id).html("已加入");
							}
						}else{
							swal({title:"操作失败!",text:d.msg,type:"warning"});
						}
					})
				}else{
					var url="";
					xiha.postData(url, "do=set&qq=<?=$arr['qq']?>&id="+id, function(d) {
						layer.closeAll('loading');
						if(d.code==1){
							var divcss = {
							  background: '#23c6c8',
							  border: '#23c6c8',
							};
							$('#'+id).html('已开启');
							$('#'+id).css(divcss);
						}else if(d.code==2){
							var divred = {
							  background: '#f7a54a',
							  border: '#f7a54a',
							};
							$('#'+id).html('已暂停');
							$('#'+id).css(divred);
						}else{
							swal({title:"操作失败!",text:d.msg,type:"warning"});
						}
					});
				}
			});  
		</script>
        <!-----------QQ设置页面结束---------->
        
        <?php }
		if(!$_GET['se']){?>
        
        <!-----------代挂列表页面开始---------->
        <div class="col-lg-3 col-md-4 col-sm-6" style="margin:7px auto;">
            <div class="ibox-content text-center" style="padding:10px;">
                <div class="m-b-sm">
                    <img alt="image" class="img-circle" src="//q4.qlogo.cn/headimg_dl?dst_uin=10000&spec=100" width="100" height="100">
                </div>
                <h2 class="text-success">虚拟占位</h2>
                <h3 class="text-warning">点击下方按钮添加代挂QQ</h3>
                <hr style="margin:5px auto;">
                <div style="width:100%; height:3px;"></div>
                <div class="text-center">
                    <a class="btn btn-w-m btn-info" href="?se=add">添加QQ</a>
                </div>
            </div>
        </div>	
        <?php 
		$p=is_numeric($_GET['p'])?$_GET['p']:'1';
		if($_POST['do']=='search' && $qq=is_numeric($_POST['qq'])?$_POST['qq']:'0'){
			$data=get_curl('http://api.66dg.cc/Mzapi/qqlist.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&qq='.$qq);
			if($arr=json_decode($data,true)){
				if($arr['code']!=10000){
					exit ("<script> alert('".$arr['msg']."');history.go(-1); </script>");
				}
				$pages=1;$count=1;
			}else{
				exit ("<script> alert('连接失败，请重试！');history.go(-1); </script>");
			}
		}else{
			$data=get_curl('http://api.66dg.cc/Mzapi/qqlist.html?apiid='.$apiid.'&apikey='.$apikey.'&uid='.$uid.'&p='.$p.'&next=11');
			if($arr=json_decode($data,true)){
				if($arr['code']!=10000){
					exit ("<script> alert('".$arr['msg']."');history.go(-1); </script>");
				}else{
					$count=$arr['count'];
					$pages=ceil($count/11);
					if(($p-1)>0){
						$start=$p-1;
					}else{
						$start=1;
					}
					if(($p+5)<$pages){
						$end=$p+5;
					}else{
						$end=$pages;
					}
				}
			}else{
				exit ("<script> alert('获取代挂列表失败，请重试！');history.go(-1); </script>");
			}
		}
		if($arr['qqlist'])foreach($arr['qqlist'] as $arrs){
		?>
            <div class="col-lg-3 col-md-4 col-sm-6" style="margin:7px auto;">
            <div class="ibox-content text-center" style="padding:10px;">
                <a href="daigua.php?do=del&p=<?=$page?>&qq=<?=$arrs['qq']?>" onClick="if(!confirm('确认删除QQ:<?=$arrs['qq']?>吗(注意：未到期的QQ删除后不退还卡密的)?')){return false;}" title="删除QQ:<?=$arrs['qq']?>"><span class="glyphicon glyphicon-remove" aria-hidden="true" style="float:right;"></span></a>
                <div class="m-b-sm">
                    <img alt="image" class="img-circle" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$arrs['qq']?>&spec=100" width="100" height="100">
                </div>
                <h2 class="text-success"># <?=$arrs['qq']?></h2>
                <h3 class="text-warning">状态：<?php if($arrs['zt']==3){echo '已过期';}elseif($arrs['zt']==1){echo '密码错误';}elseif($arrs['zt']==2){echo '帐号冻结';}else{echo '正常';}?></h3>
                <hr style="margin:5px auto;">
                <div style="width:100%; height:3px;"></div>
                <div class="text-center">
                    <a class="btn btn-outline btn-success" href="?se=gm&qq=<?=$arrs['qq']?>">更新密码</a>
                    <a class="btn btn-outline btn-info" href="?se=xu&qq=<?=$arrs['qq']?>">续费</a>
                    <a class="btn btn-outline btn-warning" href="?se=qq&qq=<?=$arrs['qq']?>">设置</a>
                </div>
            </div>
        </div>
        <?php }?>
        <div style="width:100%; height:15px; overflow:hidden;"></div>
        <div class="col-md-12">
            <div class="ibox ibox-content" style="padding:5px 10px 0px;">
                <ul class="pagination" style="margin:5px; 0 0 0;">
                <?php if($pages>1){?>
                    <li><a href="daigua.php">首页</a></li>
                    <?php for ($i=$start; $i<=$end; $i++) { ?>
                    <li <?php if($i==$page){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
                    <?php }?>
                    <li><a href="?p=<?=$pages?>">未页</a></li>
                <?php }else{?>
                    <li><a href="daigua.php">首页</a></li>
                    <li class="active"><a href="javascript:;">1</a></li>
                    <li><a href="?p=1">未页</a></li>
                <?php }?>
                </ul>
            </div>
        </div>
        <!-----------代挂列表页面结束---------->
        
        <?php }?>
    </div>
</div>

<!-----------代挂帮助开始---------->
<div class="modal inmodal fade" id="myModal1" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">代挂帮助</h4>
            </div>
            <div class="modal-body">
                <div class="ibox-content m-b-sm border-bottom">
                <div class="text-center p-sm text-danger">
                    <h2>如果在这里找不到自己需要的内容，您可以联系站长咨询</h2>
                </div>
            </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq1" class="faq-question">什么是代挂？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq1" class="panel-collapse collapse faq-answer">
                                <p>
                                    代挂是帮助你QQ等级加速升级，每天帮你完成等级加速任务，服务器每天帮你挂机，免去自己手动的麻烦。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq2" class="faq-question">代挂里面包含哪些加速任务？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq2" class="panel-collapse collapse faq-answer">
                                <p>
                                <b>包含</b><br />
                                手机QQ在线6小时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速1.0天<br />
                                电脑QQ在线2小时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.5天<br />
                                非隐身在线2小时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.2天<br />
                                点亮QQ勋章墙&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.2天<br />
                                QQ音乐听歌半小时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.5天<br />
                                QQ钱包签到&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.2天<br />
                                电脑管家在线30分钟&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.2天<br />
                                电脑管家使用安全功能(月限4次)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.5天<br />
                                玩QQ手机游戏&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加速0.2天<br />
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq3" class="faq-question">如何添加QQ进行代挂呢？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq3" class="panel-collapse collapse faq-answer">
                                <p>
                                    购买卡密后在添加代挂QQ页面输入QQ号、QQ密码和购买的代挂卡密即可代挂。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq4" class="faq-question">代挂每天什么时候开始挂机？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq4" class="panel-collapse collapse faq-answer">
                                <p>
                                    第一次添加的QQ会在当天晚上9点开始登陆代挂，以后每天晚上凌晨12点后开始代挂，在你早上醒来时所有加速任务均已完成！
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq5" class="faq-question">补挂是干什么用的以及补挂的是时间是多少？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq5" class="panel-collapse collapse faq-answer">
                                <p>
                                    补挂是当天凌晨代挂时由于帐号进入保护模式或密码错误导致代挂无法登陆完成加速任务的，可以点击补挂连接申请补挂，这样会在晚上9点时给你的QQ再代挂一次，补挂的时间也就是晚上9点！
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq6" class="faq-question">QQ为什么会进入保护模式？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq6" class="panel-collapse collapse faq-answer">
                                <p>
                                    这是你平时使用QQ的地区与我们的代挂服务器地区不一致，导致出现异地登陆，腾讯为了保护你的帐号，担心你是被盗号了，所以会出现这个提示，或者是被冻结进入保护模式，这个一般是在刚开始代挂前3-7天容易出现，之后就不会再有了。（建议你在QQ安全中心APP里的登陆记录中把异地登陆的“确认为本人登陆”，这样可以加快挂出常用地点和减少冻结的可能）
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq7" class="faq-question">QQ进入保护模式了怎么办？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq7" class="panel-collapse collapse faq-answer">
                                <p>
                                    登陆 <a href="https://aq.qq.com/007" target="_blank">https://aq.qq.com/007</a>这个页面可以解除保护模式，解除后在本平台更新一次QQ密码就可以恢复代挂了。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq8" class="faq-question">代挂的服务器地理位置在哪里？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq8" class="panel-collapse collapse faq-answer">
                                <p>
                                    位置在“广东省 佛山市”，如果你也是在这个地方，那么你添加的代挂QQ不会异常哦。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq9" class="faq-question">代挂加速任务每天能加速多少呢？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq9" class="panel-collapse collapse faq-answer">
                                <p>
                                    非QQ会员每天固定加速3天，QQ会员用户根据会员加速倍数计算公式为：会员加速倍数×1.7+1.7 ，例如SVIP8级加速是3.0倍的计算为3×1.7+1.7=6.8天。(以上计算不包含电脑管家月限4次使用安全功能任务的0.5天)
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq10" class="faq-question">代挂错误日志中出现错误怎么办呢？</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq10" class="panel-collapse collapse faq-answer">
                                <p>
                                    请查看本代挂帮助下方最底部，根据代挂错误日志上的原因查看对应的解决方法。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq11" class="faq-question">错误日志【登陆密码错误】解决方法</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq11" class="panel-collapse collapse faq-answer">
                                <p>
                                    密码错误的无法登陆，所有项目都不会加速，请在平台更新QQ密码后申请补挂即可，密码中尽量不要带特殊符号，符号大部分是分为全角和半角的，如果带有符号输入时需要注意区分，否则可能因为这个导致密码错误！
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq12" class="faq-question">错误日志【QQ进入保护模式】解决方法</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq12" class="panel-collapse collapse faq-answer">
                                <p>
                                    请在<a href="http://aq.qq.com/007" target="_blank">http://aq.qq.com/007</a>解除冻结后在平台更新一次密码即可，没加速的可以点下补挂按钮，一般代挂在前两三天因为异地登陆导致的容易冻结，多挂几次，两三天后就不会了。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq13" class="faq-question">错误日志【有登陆保护】【有设备锁】解决方法</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq13" class="panel-collapse collapse faq-answer">
                                <p>
                                    请用户关闭设备锁、登陆保护这些即可，关闭地址：<a href="https://aq.qq.com/cn2/safe_service/device_lock" target="_blank">https://aq.qq.com/cn2/safe_service/device_lock</a>，也可以在QQ安全中心APP中关闭，这些不关闭会导致勋章墙、电脑QQ在线、手机QQ在线这三项挂不上。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="row">
                        <div class="col-md-7">
                            <a data-toggle="collapse" href="#faq14" class="faq-question">错误日志【未绑定银行卡】解决方法</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="faq14" class="panel-collapse collapse faq-answer">
                                <p>
                                    请在QQ钱包中绑定一张银行卡，钱包签到这项加速官方要求是必须绑定银行卡的账户签到才有效，否则钱包签到加速这项不加速的。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>
<!-----------代挂帮助结束---------->

<script>
var xiha={
  postData: function(url, parameter, callback, dataType, ajaxType) {
	  if(!dataType) dataType='json';
	  $.ajax({
		  type: "POST",
		  url: url,
		  async: true,
		  dataType: dataType,
		  json: "callback",
		  data: parameter,
		  timeout : 10000, //超时时间设置，单位毫秒
		  success: function(data) {
			  if (callback == null) {
				  return;
			  } 
			  callback(data);
		  },
		  error: function(request,status,err) {
			  layer.closeAll('loading');
			  if (status == "timeout"){
				  swal({title:"请求超时，请重试！",type:"warning"});
			  }else{
				  swal({title:"链接失败，请重试！",type:"warning"});
			  }
			  return false;
		  }
	  });
  }
}
</script>
<?php
include_once 'core.foot.php';
?>