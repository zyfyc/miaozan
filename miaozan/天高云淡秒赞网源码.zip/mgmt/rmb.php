<?php
require_once('common.php');
C('webtitle', '在线充值');
C('pageid', 'rmb');
include_once 'core.head.php';
if ($do = $_POST['do']) {
    if ($do == 'shop') {
        $shop = is_numeric($_POST['shop']) ? $_POST['shop'] : '0';
        if ($shop == 99) {
            $rmb = C('price_1dvip');
            $buyms = 1;
            $buyday = 1;
        } elseif ($shop == 1) {
            $rmb = C('price_1vip');
            $buyms = 1;
        } elseif ($shop == 2) {
            $rmb = C('price_3vip');
            $buyms = 3;
        } elseif ($shop == 3) {
            $rmb = C('price_6vip');
            $buyms = 6;
        } elseif ($shop == 4) {
            $rmb = C('price_12vip');
            $buyms = 12;
        } elseif ($shop == 5) {
            $rmb = C('price_1peie');
            $buypeie = 1;
        } elseif ($shop == 6) {
            $rmb = C('price_3peie');
            $buypeie = 3;
        } elseif ($shop == 7) {
            $rmb = C('price_5peie');
            $buypeie = 5;
        } elseif ($shop == 8) {
            $rmb = C('price_10peie');
            $buypeie = 10;
        } else {
            exit("<script language='javascript'>alert('请先选择你需要购买 的商品！');window.location.href='rmb.php';</script>");
        }
        if ($userrow['rmb'] < $rmb) {
            echo "<script language='javascript'>alert('余额不足，请联系QQ" . C('webqq') . "充值！');window.location.href='rmb.php';</script>";
        } else {
            if ($buyms) {
                if (get_isvip($userrow[vip], $userrow[vipend])) {
                    if ($buyday) {
                        $vipend = date("Y-m-d", strtotime("+ $buyday days", strtotime($userrow[vipend])));
                        echo "<script language='javascript'>alert('成功续费{$buyms}天VIP');window.location.href='rmb.php';</script>";
                    } else {
                        $vipend = date("Y-m-d", strtotime("+ $buyms months", strtotime($userrow[vipend])));
                        echo "<script language='javascript'>alert('成功续费{$buyms}个月VIP');window.location.href='rmb.php';</script>";
                    }
                    $db->query("update {$prefix}users set rmb=rmb-{$rmb},vip=1,vipend='{$vipend}' where uid='{$userrow[uid]}'");
                } else {
                    if ($buyday) {
                        $vipend = date("Y-m-d", strtotime("+ $buyday days"));
                        echo "<script language='javascript'>alert('成功开通{$buyday}天VIP');window.location.href='rmb.php';</script>";
                    } else {
                        $vipend = date("Y-m-d", strtotime("+ $buyms months"));
                        echo "<script language='javascript'>alert('成功开通{$buyms}个月VIP');window.location.href='rmb.php';</script>";
                    }
                    $db->query("update {$prefix}users set rmb=rmb-{$rmb},vip=1,vipstart='" . date("Y-m-d") . "',vipend='{$vipend}' where uid='{$userrow[uid]}'");
                }
            } elseif ($buypeie) {
                $db->query("update {$prefix}users set rmb=rmb-{$rmb},peie=peie+$buypeie where uid='{$userrow[uid]}'");
                echo "<script language='javascript'>alert('成功购买{$buypeie}个配额');window.location.href='rmb.php';</script>";
            }
            $userrow = get_results("select * from {$prefix}users where uid=:uid limit 1", array(":uid" => $uid));
        }
    }
}
?>
    <div class="col-md-7">
        <div class="panel panel-primary panel-demo">
            <div class="panel-heading">
                <div class="panel-title">平台公告</div>
            </div>
            <div class="panel-body bg-gonggao-p">
                <div class="col-lg-12 bg-gonggao">
                    <?= stripslashes(C('web_rmb_gg')) ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="panel panel-primary">
            <div class="panel-heading portlet-handler ui-sortable-handle">VIP会员开通</div>
            <div class="panel-wrapper">
                <div class="list-group-item bb">1、开通VIP可使用本站所有功能，无任何限制，可加入VIP售后群享受后续服务。</div>
                <div class="list-group-item but-br">
                    <p>请选择付款方式：</p>

                    <a href="<?= C('kmurl') ?>" class="btn btn-danger btn-block">发卡平台</a>

                </div>


                <div class="list-group-item">
                    <span style="font-size:10px; color:#999;">发卡平台24小时自助提卡，付款后自动发邮件，无需等待。</span>
                </div>

            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="panel panel-primary">
            <div class="panel-heading portlet-handler ui-sortable-handle">自助购买</div>
            <div class="panel-wrapper">
                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">会员状态</div>
                        <input type="text" class="form-control" value="<?php if (get_isvip($userrow['vip'], $userrow['vipend'])) { echo "已激活 " . $userrow['vipend']; } else { echo "未激活"; } ?>" disabled="disabled">
                    </div>
                </div>

                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">当前余额</div>
                        <input type="text" class="form-control" value="<?= $userrow['rmb'] ?>" disabled="disabled">
                    </div>
                </div>

                <div class="list-group-item bb">
                    <div class="input-group">
                        <div class="input-group-addon">当前配额</div>
                        <input type="text" class="form-control" value="<?= $userrow['peie'] ?>" disabled="disabled">
                    </div>
                </div>
                <form action="?" role="form" class="form-horizontal ng-pristine ng-valid" method="post">
                    <input type="hidden" name="do" value="shop">
                    <div class="list-group-item bb">
                        <div class="input-group">
                            <div class="input-group-addon">购买服务</div>
                            <select multiple="multiple" class="form-control m-bot15" name="shop">
                                <option value='99'>
                                    1天试用VIP(<?= C('price_1dvip') ?>
                                    元)
                                </option>
                                <option value='1'>
                                    1个月VIP(<?= C('price_1vip') ?>
                                    元)
                                </option>
                                <option value='2'>
                                    3个月VIP(<?= C('price_3vip') ?>
                                    元)
                                </option>
                                <option value='3'>
                                    6个月VIP(<?= C('price_6vip') ?>
                                    元)
                                </option>
                                <option value='4'>
                                    12个月VIP(<?= C('price_12vip') ?>
                                    元)
                                </option>
                                <option value='5'>
                                    1个配额(<?= C('price_1peie') ?>
                                    元)
                                </option>
                                <option value='6'>
                                    3个配额(<?= C('price_3peie') ?>
                                    元)
                                </option>
                                <option value='7'>
                                    5个配额(<?= C('price_5peie') ?>
                                    元)
                                </option>
                                <option value='8'>
                                    10个配额(<?= C('price_10peie') ?>
                                    元)
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="list-group-item">
                        <input type="submit" name="submit" value="确认购买" class="btn btn-primary btn-block">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
include_once 'core.foot.php';
?>