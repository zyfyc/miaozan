<?php
require_once('common.php');
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : '0';
$now = date("Y-m-d-H:i:s");
if (!$qid) {
    $rowss = $db->query("select * from {$prefix}qqs where 1=1 order by qid desc limit 1");
    while ($row = $rowss->fetch(PDO::FETCH_ASSOC)) {
        $qid = $row['qid'];
    }
}
if (!$qid || !$qqrow = get_results("select * from {$prefix}qqs where qid=:qid and uid=:uid limit 1", array(":qid" => $qid, ":uid" => $userrow['uid']))) {
    exit("<script language='javascript'>alert('QQ不存在！');window.location.href='/mgmt';</script>");
}
if ($_GET['do'] == 'del') {
    $db->query("delete from {$prefix}qqs where qid='$qid'");
    exit("<script language='javascript'>alert('删除成功！');window.location.href='/mgmt';</script>");
} elseif ($_GET['do'] == 'qqgame') {
    $uin = $_GET['uin'];
    $skey = $_GET['skey'];
    if ($uin && $skey) {
        $data = get_curl("http://qqfunc.api.odoto.cc/api/qqgame.php?uin={$uin}&skey={$skey}");
        $arr = json_decode($data, true);
        if ($arr['code'] == '0') {
            exit("<script language='javascript'>alert('{$arr['msg']}');window.location.href='/mgmt/qqlist.php?qid={$_GET['qid']}';</script>");
        } else {
            exit("<script language='javascript'>alert('加速失败，请稍后再试！');window.location.href='/mgmt/qqlist.php?qid={$_GET['qid']}';</script>");
        }
    }
}
C('webtitle', 'QQ' . $qqrow['qq']);
C('pageid', 'qid' . $qqrow['qid']);
C('pageids', 'qid');
include_once 'core.head.php';
if ($qqrow['skeyzt']) $msg = 'swal({title:"温馨提示",text:"当前QQ的状态已经过期，导致无法继续使用功能，立即更新？",type:"warning",showCancelButton:true,confirmButtonColor:"#DD6B55",confirmButtonText:"更新",cancelButtonText:"暂不",closeOnConfirm:false,closeOnCancel:true},function(isConfirm){if(isConfirm){window.location.href="add.php?uin=' . $qqrow['qq'] . '&auto=1&type=add"}else{return false;}});';
?>
<script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
<script>
    var xiha = {
        postData: function (url, paratgyder, callback, dataType, ajaxType) {
            if (!dataType) dataType = 'json';
            $.ajax({
                type: "POST",
                url: url,
                async: true,
                dataType: dataType,
                json: "callback",
                data: paratgyder,
                success: function (data) {
                    if (callback == null) {
                        return;
                    }
                    callback(data);
                },
                error: function (error) {
                    setTimeout(function () {
                    }, 1);
                    alert('获取失败！');
                }
            });
        }
    }
    $(document).ready(function () {
        $('#startcheck').click(function () {
            var getvcurl = "http://<?=$domain?>/cron/pclike.php?qid=<?=$qqrow['qid']?>&func=zan";
            $('#load').html("正在加载中....");
            xiha.postData(getvcurl, '', function (d) {
                setTimeout(function () {
                }, 1);
                $('#load').html(d.ret);
            });
            self.attr("data-lock", "false");
        });
        $('#startcheck1').click(function () {
            var getvcurl = "http://<?=$domain?>/cron/getnew.php?qid=<?=$qqrow['qid']?>";
            $('#loads').html("正在加载中....");
            xiha.postData(getvcurl, '', function (d) {
                setTimeout(function () {
                }, 1);
                $('#loads').html(d.ret);
            });
            self.attr("data-lock", "false");
        });
    });
</script>
<div class="row">
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="panel-title text-center">
                    <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?= $qqrow['qq'] ?>&amp;spec=100" width="80" height="80" class="img-circle circle-border m-t-xxs" alt="profile">
                    <h4 class="font-bold no-margins"><?= get_qqnick($qqrow['qq']) ?></h4>
                </div>
            </div>
            <div class="list-group">
                <div class="list-group-item but-br">
                    <div class="media-box">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-info circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <span class="text-muted-s pull-right ml">
							<a href="?do=del&p=<?= $p ?>&qid=<?= $qqrow['qid'] ?>" class="btn btn-square btn-primary btn-xs delqq" style="font-size:12px;">删除</a></span>
                   <span class="text-muted-s pull-right ml">
				   <a href="add.php?uin=<?= $qqrow['qq'] ?>&auto=1&type=add" class="btn btn-square btn-primary btn-xs" style="font-size:12px;">更新</a>
                   </span>
				     <span class="text-muted-s pull-right ml">
				   <a href="mzrz.php?qq=<?= $qqrow['qq'] ?>&auto=1&type=add" class="btn btn-square btn-primary btn-xs" style="font-size:12px;">认证</a>
                   </span>
                            <div class="media-box-heading text-purple m0"># <?= $qqrow['qq'] ?>  丨 登陆IP：<?php echo getip($userrow['ip']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="list-group-item but-br">
                    <div class="media-box">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-success circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <div class="media-box-heading text-<?php if ($qqrow['skeyzt']) {echo 'pull';} else {echo 'info';} ?> m0">
                                <small>QQ运行状态：<?php if ($qqrow['skeyzt']) {echo '已停止运行';} else {echo '正常运行中';} ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="list-group-item but-br">
                    <div class="media-box" style="margin-top:5px;">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-success circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <div class="media-box-heading m0">
                                <small>以上状态若显示失效请及时更新防止功能不运行！</small>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="list-group-item but-br">
                    <div class="media-box">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-success circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <div class="media-box-heading m0">
                                <small>Skey：<?= $qqrow['skey'] ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="list-group-item but-br">
                    <div class="media-box">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-success circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <div class="media-box-heading m0">
                                <small>P_skey：<?= $qqrow['p_skey'] ?></small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="list-group-item but-br">
                    <div class="media-box">
                        <div class="pull-left" style="margin:auto 5px;">
                            <span class="circle circle-success circle-lg text-left"></span>
                        </div>
                        <div class="media-box-body clearfix">
                            <div class="media-box-heading text-<?php if ($qqrow['iszan'] == 0) {echo 'danger';} else {echo 'success';} ?> m0">
                                <small><?php if ($qqrow['iszan'] == 0) {echo '秒赞关闭中,无信息!';} else {echo '秒赞运行正常';} ?></small>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="panel-footer clearfix">
                <button data-tool="panel-collapse" class="btn btn-square btn-primary btn-block btn-xs">
                    <em class="fa fa-plus"></em> Q Q 小工具
                </button>
            </div>
            <div class="panel-wrapper collapse" aria-expanded="true" style="height: 0px;">
                <div class="panel-body">
                    <div class="col-xs-6">
                        <a href="dxjc.php?qid=<?= $qqrow['qid'] ?>" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">单项好友检测</a>
                    </div>
                    <div class="col-xs-6">
                        <a href="mzjc.php?qid=<?= $qqrow['qid'] ?>" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">秒赞好友检测</a>
                    </div>
                    <div class="col-xs-6">
                        <a href="http://ptlogin2.qq.com/jump?uin=<?= $qqrow['qq'] ?>&amp;skey=<?= $qqrow['skey'] ?>&amp;u1=http://kf.qq.com/touch/qzone/qzone_status.html" target="_blank" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">空间状态检测</a>
                    </div>
                    <div class="col-xs-6">
                        <a href="quanz.php?qid=<?= $qqrow['qid'] ?>&qq=<?= $qqrow['qq'] ?>" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">一键拉圈圈99+</a>
                    </div>
                    <div class="col-xs-6">
                        <a href="group.php?qid=<?= $qqrow['qid'] ?>" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">提取QQ群成员</a>
                    </div>
                    <div class="col-xs-6">
                        <a href="?do=qqgame&uin=<?= $qqrow['qq'] ?>&amp;skey=<?= $qqrow['skey'] ?>&qid=<?= $qqrow['qid'] ?>" class="btn btn-oval btn-primary btn-block btn-xs" style="margin:3px 0;">一键加速手Q游戏</a></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div id="panelDemo14" class="panel panel-default">
            <div role="tabpanel">
                <ul role="tablist" class="nav nav-tabs">
                    <li role="presentation" class="active"><a href=".kj" aria-controls="home" role="tab" data-toggle="tab">常规功能</a></li>
					<li role="presentation"><a href=".gn" aria-controls="profile" role="tab" data-toggle="tab">签到功能</a>
					<li role="presentation"><a href=".bq" aria-controls="profile" role="tab" data-toggle="tab">扩展功能</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane kj active">
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isauto.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="hide" data-name="自动更新">
                                        <input type="checkbox" checked="checked" disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="自动更新QQ在线状态。">
                                        <span class="circle circle-success circle-lg text-left"></span>自动更新
                                    </strong>
                                    <p class="mb0">
                                        <small><i class="fa fa-clock-o pr-sm"></i> <?= $qqrow['nextauto'] ?>
                                            <small>
                                                <?= get_gxzt($qqrow['gxmsg']) ?>
                                            </small>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/iszan.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="zan" data-name="说说秒赞">
                                        <input type="checkbox" id="inputzan"<?php if (!getzts($qqrow['iszan'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="为好友的说说点赞">
                                        <span class="circle circle-danger circle-lg text-left"></span>说说秒赞</strong>										<?= getzt($qqrow['iszan']) ?>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastzan']) ?>
                                        </small>
                                        <small>
                                            <a data-toggle="modal" id="startcheck" class="zan" data-target="#myModa3">手动执行</a>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/istx.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="tx" data-name="百变头像">
                                        <input type="checkbox" id="inputtx" <?php if (!getzts($qqrow['istx'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="开启后头像将随机切换">
                                        <span class="circle circle-danger circle-lg text-left"></span>百变头像</strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lasttx']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/ispf.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="pf" data-name="百变皮肤">
                                        <input type="checkbox" id="inputpf" <?php if (!getzts($qqrow['ispf'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="开启后每次登陆QQ的皮肤将随机切换">
                                        <span class="circle circle-danger circle-lg text-left"></span>百变皮肤
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastpf']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isshuo.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qipao" data-name="百变气泡">
                                        <input type="checkbox" id="inputqipao" <?php if (!getzts($qqrow['isqipao'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="开启后在任意地方输入气泡都不同">
                                        <span class="circle circle-danger circle-lg text-left"></span>百变气泡
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqipao']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isgq.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="3gqq" data-name="离线手机挂Q">
                                        <input type="checkbox" id="input3gqq" <?php if (!getzts($qqrow['is3gqq'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="离线手机挂Q">
                                            <span class="circle circle-danger circle-lg text-left"></span>3GQQ挂机
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['last3gqq']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isreply.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="reply" data-name="说说评论">
                                        <input type="checkbox" id="inputreply" <?php if (!getzts($qqrow['isreply'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span></label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="评论好友的说说动态">
                                        <span class="circle circle-danger circle-lg text-left"></span>说说秒评</strong> <?= getzt($qqrow['isreply']) ?>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastreply']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/iszf.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="zf" data-name="说说转发">
                                        <input type="checkbox" id="inputzf" <?php if (!getzts($qqrow['iszf'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="转发指定好友的说说">
                                        <span class="circle circle-danger circle-lg text-left"></span>说说转发
                                    </strong> <?= getzt($qqrow['iszf']) ?>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastzf']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isqt.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qt" data-name="说说圈图">
                                        <input type="checkbox" id="inputqt" <?php if (!getzts($qqrow['isqt'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="在好友的图文说说中@自己">
                                        <span class="circle circle-danger circle-lg text-left"></span>说说圈图
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqt']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isshuo.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="shuo" data-name="自动说说">
                                        <input type="checkbox" id="inputshuo" <?php if (!getzts($qqrow['isshuo'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="定时发随机或指定的说说">
                                        <span class="circle circle-danger circle-lg text-left"></span>自动说说
                                    </strong> <?= getzt($qqrow['isshuo']) ?>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastshuo']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isdel.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="del" data-name="说说删除">
                                        <input type="checkbox" id="inputdel" <?php if (!getzts($qqrow['isdel'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="定时删除随机的说说">
                                        <span class="circle circle-danger circle-lg text-left"></span>删除说说
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastdel']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isdelly.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="dell" data-name="留言删除">
                                        <input type="checkbox" id="inputdell" <?php if (!getzts($qqrow['isdell'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="定时删除随机的留言">
                                        <span class="circle circle-danger circle-lg text-left"></span>删除留言
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastdell']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
 	 <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isht.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="ht" data-name="花藤浇花">
                                        <input type="checkbox" id="inputht" <?php if (!getzts($qqrow['isht'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="花藤浇花">
                                        <span class="circle circle-danger circle-lg text-left"></span>花藤浇花
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastht']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						</div>
						<div role="tabpanel" class="tab-pane gn">
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isvipqd.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="vipqd" data-name="会员签到">
                                        <input type="checkbox" id="inputvipqd" <?php if (!getzts($qqrow['isvipqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQVIP会员签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>会员签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastvipqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                          <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isqb.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qb" data-name="钱包签到">
                                        <input type="checkbox" id="inputqb" <?php if (!getzts($qqrow['isqb'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ钱包签到助于QQ等级加速">
                                        <span class="circle circle-danger circle-lg text-left"></span>钱包签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqb']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isdld.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qd" data-name="空间签到">
                                        <input type="checkbox" id="inputqd" <?php if (!getzts($qqrow['isqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ空间每日自动签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>空间签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isqd.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="dldqd" data-name="大乐斗签到">
                                        <input type="checkbox" id="inputdldqd" <?php if (!getzts($qqrow['isdldqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ大乐斗每日签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>大乐斗签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastdldqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/iswyqd.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="wyqd" data-name="微云签到">
                                        <input type="checkbox" id="inputwyqd" <?php if (!getzts($qqrow['iswyqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ微云签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>微云签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastwyqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isxqbl.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="blqd" data-name="兴趣部落签到">
                                        <input type="checkbox" id="inputblqd" <?php if (!getzts($qqrow['isblqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ兴趣部落每日签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>部落签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastblqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/isqunqd.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qqd" data-name="QQ群签到">
                                        <input type="checkbox" id="inputqqd" <?php if (!getzts($qqrow['isqqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ用户群每日签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ群签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/ishlwqd.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="hlwqd" data-name="好莱坞签到">
                                        <input type="checkbox" id="inputhlwqd" <?php if (!getzts($qqrow['ishlwqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="好莱坞签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>好莱坞签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lasthlwqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/ists.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="tsqd" data-name="Q图书签到">
                                        <input type="checkbox" id="inputtsqd" <?php if (!getzts($qqrow['istsqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="Q图书签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ图书签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lasttsqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/gamevip.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="gamevip" data-name="蓝钻签到">
                                        <input type="checkbox" id="inputgamevip" <?php if (!getzts($qqrow['isgamevip'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="蓝钻签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>蓝钻签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastgamevip']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/qloud.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qcloud" data-name="腾讯云代金券">
                                        <input type="checkbox" id="inputqcloud" <?php if (!getzts($qqrow['isqcloud'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="腾讯云代金券">
                                        <span class="circle circle-danger circle-lg text-left"></span>腾讯云学生机代金券
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqcloud']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/islz.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="xzqd" data-name="QQ星钻签到">
                                        <input type="checkbox" id="inputxzqd" <?php if (!getzts($qqrow['isxzqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ星钻签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ星钻签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastxzqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/islz.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="lzqd" data-name="QQ绿钻签到">
                                        <input type="checkbox" id="inputlzqd" <?php if (!getzts($qqrow['islzqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ绿钻签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ绿钻签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastlzqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/islz.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qzoneqd" data-name="QQ黄钻签到">
                                        <input type="checkbox" id="inputqzoneqd" <?php if (!getzts($qqrow['isqzoneqd'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ黄钻签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ黄钻签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqzoneqd']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
					<div role="tabpanel" class="tab-pane bq">  
						     <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/daoju.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="daoju" data-name="道聚城签到">
                                        <input type="checkbox" id="inputdaoju" <?php if (!getzts($qqrow['isdaoju'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="道聚城签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>道聚城签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastdaoju']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						    <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/qqllq.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qqllq" data-name="QQ浏览器签到">
                                        <input type="checkbox" id="inputqqllq" <?php if (!getzts($qqrow['isqqllq'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="QQ浏览器签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>QQ浏览器签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqqllq']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						 <div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/tgpgame.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="jpgame" data-name="腾讯TGP游戏签到">
                                        <input type="checkbox" id="inputjpgame" <?php if (!getzts($qqrow['isjpgame'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="腾讯TGP游戏签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>腾讯TGP游戏签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastjpgame']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/qd3366.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="qd3366" data-name="3366签到">
                                        <input type="checkbox" id="inputqd3366" <?php if (!getzts($qqrow['isqd3366'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="3366签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>3366签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastqd3366']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/ql.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="sweet_sign" data-name="情侣空间签到">
                                        <input type="checkbox" id="inputsweet_sign" <?php if (!getzts($qqrow['issweet_sign'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="情侣空间签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>情侣空间签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastsweet_sign']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/dongman.png" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="dongman" data-name="腾讯动漫签到">
                                        <input type="checkbox" id="inputsweet_sign" <?php if (!getzts($qqrow['isdongman'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="腾讯动漫签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>腾讯动漫签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastdongman']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="media-box">
                                <div class="pull-left">
                                    <img src="/style/user/img/xinyue.jpg" alt="Image" class="media-box-object img-circle thumb44 img-thumbnail">
                                </div>
                                <div class="media-box-body clearfix">
                                    <label class="switch switch-lg pull-right pt9" id="xinyue" data-name="心悦会员签到">
                                        <input type="checkbox" id="inputxinyue" <?php if (!getzts($qqrow['isxinyue'])) {echo 'checked="checked"';} ?> disabled="">
                                        <span></span>
                                    </label>
                                    <strong class="media-box-heading text-primary" data-toggle="tooltip" data-original-title="心悦会员签到">
                                        <span class="circle circle-danger circle-lg text-left"></span>心悦会员签到
                                    </strong>
                                    <p class="mb0">
                                        <small>
                                            <i class="fa fa-clock-o pr-sm"></i> <?= zhtime($qqrow['lastxinyue']) ?>
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    </div>
</div>
<script>
    $(".switch").click(function () {
        var url = "qqfunc.php";
        var self = $(this);
        var inputs = $(this).find("input:first");
        if (self.attr("id") == 'hide') {
            swal('该功能目前无法自主修改，由系统调控');
            return;
        } // 无需设置的功能
        if (self.attr("data-lock") === "1") return;
        else self.attr("data-lock", "1");//锁定按钮

        var data = "do=change&qid=<?=$qid?>&modid=" + self.attr("id");
        loadingIco(self, inputs);
        TianYa.postData(url, data, function (d) {
            if (d.code == '1') { // 需要高级配置,直接跳转
                window.location.href = d.data.url;
            } else if (d.code == '2') { // 自动开关
                if (d.data.type == 'success') {
                    swal({
                        title: self.attr("data-name"),
                        text: '该功能' + d.data.msg,
                        type: d.data.type,
                        timer: d.data.timer,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "OK"
                    });
                    loadingIco(self, inputs, 1);
                } else if (d.data.type == 'danger') { // 其他提示
                    swal({
                        title: self.attr("data-name"),
                        text: '该功能' + d.data.msg,
                        type: "warning",
                        timer: d.data.timer,
                        confirmButtonColor: "#ec6c62",
                        confirmButtonText: "OK"
                    });
                    loadingIco(self, inputs);
                } else {
                    swal({
                        title: d.data.title,
                        text: d.data.msg,
                        type: d.data.type,
                        showCancelButton: true,
                        closeOnConfirm: false,
                        showLoaderOnConfirm: true,
                        confirmButtonText: "开通",
                        cancelButtonText: "关闭",
                        confirmButtonColor: "#ec6c62"
                    }, function () {
                        window.location.href = 'shop.php';
                    });
                    loadingIco(self, inputs);
                }
                self.attr("data-lock", "0");
            } else if (d.code == '3') { // 其他提示
                swal({
                    title: self.attr("data-name"),
                    text: d.data.msg,
                    type: d.data.type,
                    timer: d.data.timer,
                    confirmButtonColor: "#ec6c62",
                    confirmButtonText: "OK"
                });
                loadingIco(self, inputs);
            } else {
                alert('服务器数据异常，请刷新后重试或联系QQ<?=C("webqq")?>！');
            }
        });
    })
</script>
<script><?php if ($msg) echo $msg; ?></script>
<?php
include_once 'core.foot.php';
?>
<div class="modal inmodal fade" id="myModa3" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content animated flipInY">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">关闭</span></button>
                <h4 class="modal-title">
                    手动执行
                </h4>
            </div>
            <div class="modal-body" id="load"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>