<?php
require_once('common.php');
C('webtitle','APP下载');
C('pageid','app');
include_once 'core.head.php';
?>

          <div class="panel b-a">
            <div class="panel-heading bg-info dk no-border wrapper-lg">
              <button class="btn btn-sm btn-icon btn-rounded btn-info pull-right m-r"><i class="fa fa-qq"></i></button>
              <button class="btn btn-sm btn-icon btn-rounded btn-info m-l"><i class="fa fa-heart"></i></button>
            </div>
            <div class="text-center m-b clearfix">
              <div class="thumb-lg avatar m-t-n-xxl">
			  <br/>
                 <img src="<?= C('app_logo') ?>" width="80" height="80" class="img-circle circle-border m-t-xxs" alt="profile">
				<br/>
                <div class="media-box-body clearfix">
<h2>秒赞APP<h2>
<h3>版本：1.6.1012<h3>
<h3>大小：7 M<h3>
<h3>2017-5-1<h3>
<br/>
       <div class="panel-footer clearfix">
          <a href="../../app.apk" title="下载APP" class="btn btn-square btn-primary btn-block btn-xs">下载APP</a>
            </div>
          </div>
        </div>
<?php
include_once 'core.foot.php';
?>