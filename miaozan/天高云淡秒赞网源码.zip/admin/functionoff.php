<?php
require_once('common.php');
if ($do = $_POST['do']) {
    foreach ($_POST as $k => $value) {
        if (safestr($k) == 'web_separate_gg' && $isdomain) {
            exit("<script language='javascript'>alert('保存失败！您不能修改分站公告');window.location.href='functionoff.php';</script>");
        }
        $db->query("insert into {$prefix}webconfigs set vkey='" . safestr($k) . "',value='" . safestr($value) . "' on duplicate key update value='" . safestr($value) . "'");
    }
    if ($rows = $db->query('select * from ' . $prefix . 'webconfigs')) {
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $webconfig[$row['vkey']] = $row['value'];
        }
        C($webconfig);
    }
    echo "<script language='javascript'>alert('保存成功！');window.location.href='functionoff.php';</script>";
}
C('webtitle', '功能开关');
C('pageid', 'off');
include_once 'common.head.php';
?>
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    功能off
                </div>
                <div class="panel-body">
                    <form action="?" class="form-horizontal ng-pristine ng-valid" method="post">
                        <input type="hidden" name="do" value="off">
                        <div class="list-group-item bb">
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded">
                                    <input type="radio" value="0" name="freevip" checked="">
                                    <span class="fa fa-check"></span>关闭免费领取VIP会员</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded">
                                    <input type="radio" value="1" name="freevip" <?php if (C('freevip') == 1) echo 'checked=""'; ?>>
                                    <span class="fa fa-check"></span>开启免费领取VIP会员</label>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
include_once 'common.foot.php';
?>