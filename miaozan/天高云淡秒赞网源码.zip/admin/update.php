<?php
require_once('common.php');
if ($isdomain) exit("<script language='javascript'>alert('您没有总站权限');window.location.href='/admin';</script>");
$query = get_curl("http://auth.momo5.cn/check.php?url=" . $domain . "&authcode=" . authcode . "&ver=" . VERSION);
if ($query = json_decode($query, true)) {
    $upcode = $query['code'];
    $upmsg = $query['msg'];
    $upmsgs = $query['uplog'];
}
if ($_POST['type'] == 'update') {
    if ($_POST['submit'] == "返回首页") header("Location: /");
    $url = $query['file'];
    $RemoteFile = $url;
    $ZipFile = "update.zip";
    copy($RemoteFile, $ZipFile) or showmsg("无法下载更新包文件", false, "", true);
    if (zipExtract($ZipFile, $_SERVER['DOCUMENT_ROOT'])) {
        $upcode = 0;
        unlink($ZipFile);
        $upmsg = "升级完成";
    } else {
        $upmsg = "无法解压文件";
        $upcode = 0;
        if (file_exists($ZipFile)) unlink($ZipFile);
    }
}
function zipExtract($src, $dest)
{
    $zip = new ZipArchive();
    if ($zip->open($src) === true) {
        $zip->extractTo($dest);
        $zip->close();
        return true;
    }
    return false;
}
C('pageid', 'update');
C('webtitle', '网站升级');
include_once 'common.head.php';
?>
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                检测更新
            </div>
            <div class="panel-body">
                <form action="?" class="form-horizontal" method="post">
                    <input type="hidden" value="update" name="type">
                    <?php if ($upcode) echo '<label>' . $upmsgs . '</label><hr/>'; ?>
                    <?= $upmsg ?>
                    <?php if ($upcode) echo '<div class="form-group text-right"><input type="submit" name="submit" value="确定升级" class="btn btn-danger"></div>'; ?>
                </form>
            </div>
        </div>
    </div>
<?php
include_once 'common.foot.php';
?>