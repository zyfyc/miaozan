<?php
require_once('common.php');
if ($do = $_POST['do']) {
    foreach ($_POST as $k => $value) {
        if (safestr($k) == 'web_separate_gg' && $isdomain) {
            exit("<script language='javascript'>alert('保存失败！您不能修改分站公告');window.location.href='set.php';</script>");
        }
        $db->query("insert into {$prefix}webconfigs set vkey='" . safestr($k) . "',value='" . safestr($value) . "' on duplicate key update value='" . safestr($value) . "'");
    }
    if ($rows = $db->query('select * from ' . $prefix . 'webconfigs')) {
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $webconfig[$row['vkey']] = $row['value'];
        }
        C($webconfig);
    }

    echo "<script language='javascript'>alert('保存成功！');window.location.href='set.php';</script>";
}
if ($doapi = $_POST['doapi']) {
    foreach ($_POST as $k => $value) {
        if (safestr($k) == 'web_separate_gg' && $isdomain) {
            exit("<script language='javascript'>alert('保存失败！您不能修改分站公告');window.location.href='set.php';</script>");
        }
        $db->query("insert into {$prefix}webconfigs set vkey='" . safestr($k) . "',value='" . safestr($value) . "' on duplicate key update value='" . safestr($value) . "'");
    }
    if ($rows = $db->query('select * from ' . $prefix . 'webconfigs')) {
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $webconfig[$row['vkey']] = $row['value'];
        }
        C($webconfig);
    }

    echo "<script language='javascript'>alert('保存成功！');window.location.href='set.php?to=api';</script>";
}
if ($_GET['to'] == "siteinfo") {
    C('webtitle', '系统信息');
    C('pageid', 'siteinfo');
    include_once 'common.head.php';
    ?>
    <div class="row">
        <div class="col-sm-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    模板感谢
                </div>
                <div class="panel-body">
                    用户中心: <a href="http://www.xkmz.cc" target="_blank">小柯 >> 小柯秒赞网 </a> 用户首页: <a
                        href="http://www.5llo.com" target="_blank">晴天 >> 天高云淡秒赞网 </a>
                    <hr>
                    QQ列表部分Ajax: <a href="http://www.qqmiaozan.com" target="_blank">天涯 >> QQ秒赞网 </a>
                </div>
            </div>
        </div>
       <div class="col-sm-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    程序信息
                </div>
                <div class="panel-body">
                    程序名称：METI秒赞系统
                    <hr>
                    现版权所有：裸辞
                    <hr>
                    ＱＱ：596844474
                    <hr>
                    程序版本：V1 (Build <?= VERSION ?>)
                    <hr>
                    HTK插件版本：Build <?= Htkver ?>     
                </div>
            </div>
        </div>
    </div>
    <?php
} elseif ($_GET['to'] == "api") {
    C('webtitle', 'API设置');
    C('pageid', 'apiset');
    include_once 'common.head.php';
    ?>
     <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    API接口设置
                </div>
                <div class="panel-body">
                    <form action="?xz=api" class="form-horizontal ng-pristine ng-valid" method="post">
                        <input type="hidden" name="doapi" value="api">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">首页模板切换接口</div>

                                <select class="form-control" name="index_web">
                                    <option value="1" <?php if (C('index_web') == 1) echo 'selected = "selected"'; ?>>
                                        1_天高V3首页模板
                                    </option>
                                    <option value="2" <?php if (C('index_web') == 2) echo 'selected = "selected"'; ?>>
                                        2_时光秒赞网首页模板
                                    </option>
									<option value="3" <?php if (C('index_web') == 3) echo 'selected = "selected"'; ?>>
                                        3_天高V2首页模板
                                    </option>
                                </select>
                            </div>
                        </div>
						 <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">登录/注册页切换接口</div>

                                <select class="form-control" name="login_web">
                                    <option value="1" <?php if (C('login_web') == 1) echo 'selected = "selected"'; ?>>
                                        1_天高V3登录/注册页
                                    </option>
                                    <option value="2" <?php if (C('login_web') == 2) echo 'selected = "selected"'; ?>>
                                        2_云言秒赞登录/注册页
                                    </option>
									<option value="3" <?php if (C('login_web') == 3) echo 'selected = "selected"'; ?>>
                                        3_小柯秒赞登录/注册页
                                    </option>
                                </select>
                            </div>
                        </div>
						 <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">找回密码页切换接口</div>

                                <select class="form-control" name="login_web">
                                    <option value="1" <?php if (C('find_web') == 1) echo 'selected = "selected"'; ?>>
                                        1_天高V3找回密码页
                                    </option>
                                </select>
                            </div>
                        </div>
                     
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">静态资源CDN</div>

                                <select class="form-control" name="api_webcdn">
                                    <option value="0" <?php if (C('api_webcdn') == 0) echo 'selected = "selected"'; ?>>
                                        0_本地文件[荐]
                                    </option>
                                    <option value="1" <?php if (C('api_webcdn') == 1) echo 'selected = "selected"'; ?>>
                                        1_天高云淡官方Cdn
                                    </option>
                                    <option value="2" <?php if (C('api_webcdn') == 2) echo 'selected = "selected"'; ?>>
                                        2_榴莲云加速cdn
                                    </option>
                                </select>
                            </div>
                        </div>
						<div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">站点收费设置</div>

                                <select class="form-control" name="freevip">
                                    <option value="1" <?php if (C('freevip') == 1) echo 'selected = "selected"'; ?>>
                                        1_开启全站免费
                                    </option>
                                    <option value="0" <?php if (C('freevip') == 0) echo 'selected = "selected"'; ?>>
                                        2_收费模式
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">登录/注册/找回密码CDN</div>

                                <select class="form-control" name="api_login">
                                    <option value="1" <?php if (C('api_login') == 1) echo 'selected = "selected"'; ?>>
                                        1_天高云淡官方Cdn
                                    </option>
                                    <option value="2" <?php if (C('api_login') == 2) echo 'selected = "selected"'; ?>>
                                        2_榴莲云加速cdn
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
} else {
    C('webtitle', '系统设置');
    C('pageid', 'set');
    include_once 'common.head.php';
    ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    基本设置
                </div>
                <div class="panel-body">
                    <form action="?xz=set" class="form-horizontal tasi-form" method="post">
                        <input type="hidden" name="do" value="set">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">网站名称</div>

                                <input class="form-control" type="text" name="webname" value="<?= C('webname') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">网站介绍</div>

                                <input class="form-control" type="text" name="webkey" value="<?= C('webkey') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">网站域名</div>

                                <input class="form-control" type="text" name="webdomain" value="<?php
                                if (!C('webdomain')) {
                                    echo $_SERVER['HTTP_HOST'];
                                }
                                ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">站长扣扣</div>

                                <input class="form-control" type="text" name="webqq" value="<?= C('webqq') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">注册送钱</div>

                                <input class="form-control" type="text" name="regrmb" value="<?= C('regrmb') ?>">
                                <div class="input-group-addon">￥</div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">会员售后群</div>

                                <input class="form-control" type="text" name="webgroup" value="<?= C('webgroup') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">注册有配额</div>

                                <input class="form-control" type="text" name="regpeie" value="<?= C('regpeie') ?>">
                                <div class="input-group-addon">个</div>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">自动加好友</div>

                                <input class="form-control" type="text" name="addqq" value="<?= C('addqq') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">监控识别码</div>

                                <input class="form-control" type="text" name="cronrand" value="<?= C('cronrand') ?>">
                            </div>
                        </div>

                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">自动发卡地址</div>

                                <input class="form-control" type="text" name="kmurl" value="<?= C('kmurl') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页音乐外链(网易云)</div>

                                <input class="form-control" type="text" name="index_163music"
                                       value="<?= C('index_163music') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页背景一[图片外链]</div>

                                <input class="form-control" type="text" name="index_pic_1"
                                       value="<?= C('index_pic_1') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页背景二[图片外链]</div>

                                <input class="form-control" type="text" name="index_pic_2"
                                       value="<?= C('index_pic_2') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页背景三[图片外链]</div>

                                <input class="form-control" type="text" name="index_pic_3"
                                       value="<?= C('index_pic_3') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页背景四[图片外链]</div>

                                <input class="form-control" type="text" name="index_pic_4"
                                       value="<?= C('index_pic_4') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">主页背景五[图片外链]</div>

                                <input class="form-control" type="text" name="index_pic_5"
                                       value="<?= C('index_pic_5') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">用户中心logo[图片外链]</div>

                                <input class="form-control" type="text" name="index_logo"
                                       value="<?= C('index_logo') ?>">
                            </div>
                        </div>
						 <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">APP下载二维码[图片外链]</div>

                                <input class="form-control" type="text" name="app_logo"
                                       value="<?= C('app_logo') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">

                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="0"
                                                                                             name="txprotect"
                                                                                             checked=""><span
                                        class="fa fa-check"></span>关闭反腾讯检测系统</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="1"
                                                                                             name="txprotect" <?php if (C('txprotect') == 1) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>开启反腾讯检测系统</label>
                            </div>

                        </div>
                        <div class="list-group-item bb">

                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="0"
                                                                                             name="webfree"
                                                                                             checked=""><span
                                        class="fa fa-check"></span>是VIP才可以使用所有功能</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="1"
                                                                                             name="webfree" <?php if (C('webfree') == 1) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>不是VIP也可以使用所有功能</label>
                            </div>

                        </div>


                        <div class="list-group-item bb">

                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="1"
                                                                                             name="dgapi" <?php if (C('dgapi') == 1) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>对接我爱代挂</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="2"
                                                                                             name="dgapi" <?php if (C(dgapi) == 2) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>对接Q族代挂</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="3"
                                                                                             name="dgapi" <?php if (C(dgapi) == 3) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>对接新领域代挂</label>
                            </div>
                            <div class="form-control-1">
                                <label class="checkbox c-checkbox c-checkbox-rounded"><input type="radio" value="0"
                                                                                             name="dgapi" <?php if (C(dgapi) == 0) echo 'checked=""'; ?>><span
                                        class="fa fa-check"></span>对接其他代挂</label>
                            </div>
                        </div>
                        <div class="list-group-item bb">其他代挂接口需在下面填写,只对其他代挂有效，选择其他代挂后刷新页面即可！</div>
                        <?php
                        if (C("dgapi") == 0) {
                            ?>
                            <div class="list-group-item bb">
                                <div class="input-group">
                                    <div class="input-group-addon">自定义代挂</div>

                                    <input class="form-control" type="text" name="dgzdy" value="<?= C('dgzdy') ?>">
                                </div>
                            </div>
                            <?php
                        }
                        ?>


                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    公告发布编辑
                </div>
                <div class="panel-body">
                    <form action="?xz=gg" class="form-horizontal tasi-form" method="post">
                        <input type="hidden" name="do" value="gg">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">用户中心</div>
                            
                                <textarea class="form-control" name="web_control_gg"
                                          rows="5"><?= stripslashes(C('web_control_gg')) ?></textarea>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">自助购买</div>
                            
                                <textarea class="form-control" name="web_shop_gg"
                                          rows="5"><?= stripslashes(C('web_shop_gg')) ?></textarea>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">余额充值</div>
                            
                                <textarea class="form-control" name="web_rmb_gg"
                                          rows="5"><?= stripslashes(C('web_rmb_gg')) ?></textarea>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    广告设定
                </div>
                <div class="panel-body">
                    <form action="?xz=wb" class="form-horizontal tasi-form" method="post">
                        <input type="hidden" name="do" value="wb">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">免费用户说说尾巴</div>
                            
                                <textarea class="form-control" name="shuogg"
                                          rows="5"><?= stripslashes(C('shuogg')) ?></textarea>
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">网站每日签到内容</div>
                            
                                <textarea class="form-control" name="qdgg"
                                          rows="5"><?= stripslashes(C('qdgg')) ?></textarea>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    用户余额自助购卡设定
                </div>
                <div class="panel-body">
                    <form action="?xz=price" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="pricet">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">1天VIP</div>

                                <input class="form-control" type="text" name="price_1dvip"
                                       value="<?= C('price_1dvip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">1月VIP</div>

                                <input class="form-control" type="text" name="price_1vip"
                                       value="<?= C('price_1vip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">3月VIP</div>

                                <input class="form-control" type="text" name="price_3vip"
                                       value="<?= C('price_3vip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">6月VIP</div>

                                <input class="form-control" type="text" name="price_6vip"
                                       value="<?= C('price_6vip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">12月VIP</div>

                                <input class="form-control" type="text" name="price_12vip"
                                       value="<?= C('price_12vip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">1个配额</div>

                                <input class="form-control" type="text" name="price_1peie"
                                       value="<?= C('price_1peie') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">3个配额</div>

                                <input class="form-control" type="text" name="price_3peie"
                                       value="<?= C('price_3peie') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">5个配额</div>

                                <input class="form-control" type="text" name="price_5peie"
                                       value="<?= C('price_5peie') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">10个配额</div>

                                <input class="form-control" type="text" name="price_10peie"
                                       value="<?= C('price_10peie') ?>">
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    代理购卡设定
                </div>
                <div class="panel-body">
                    <form action="?xz=daili" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="daili">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">一个月VIP</div>

                                <input class="form-control" type="text" name="daili_vip" value="<?= C('daili_vip') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">一个配额</div>

                                <input class="form-control" type="text" name="daili_peie" value="<?= C('daili_peie') ?>">
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    圈圈99+接口设置
                </div>
                <div class="panel-body">
                    <form action="?xz=quanquan" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="quanquan">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">圈圈接口</div>

                                <input class="form-control" type="text" name="web_quanquanjk"
                                       value="<?= C('web_quanquanjk') ?>">
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    自动更新失败发送邮件设置[Old]
                </div>
                <div class="panel-body">
                    <form action="?xz=email" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="email">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">SMTP服务器</div>

                                <input class="form-control" type="text" name="email_host"
                                       value="<?= C('email_host') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">发信端口</div>

                                <input class="form-control" type="text" name="email_port"
                                       value="<?= C('email_port') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">邮箱账号</div>

                                <input class="form-control" type="text" name="email_user"
                                       value="<?= C('email_user') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">邮箱密码</div>

                                <input class="form-control" type="text" name="email_pwd" value="<?= C('email_pwd') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">全部为空则该功能不开启</div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    功能服务器设置
                </div>
                <div class="panel-body">
                    <form action="?xz=net" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="net">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">每个服务器最多QQ数</div>

                                <input class="form-control" type="text" name="netnum" value="<?= C('netnum') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">秒赞服务器数量</div>

                                <input class="form-control" type="text" name="zannet" value="<?= C('zannet') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">说说服务器数量</div>

                                <input class="form-control" type="text" name="shuonet" value="<?= C('shuonet') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">秒评服务器数量</div>

                                <input class="form-control" type="text" name="replynet" value="<?= C('replynet') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">转发服务器数量</div>

                                <input class="form-control" type="text" name="zfnet" value="<?= C('zfnet') ?>">
                            </div>
                        </div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    自动更新打码平台对接设置
                </div>
                <div class="panel-body">
                    <form action="?xz=net" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="net">
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">超人打码账号</div>

                                <input class="form-control" type="text" name="chaoren_user"
                                       value="<?= C('chaoren_user') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">
                            <div class="input-group">
                                <div class="input-group-addon">超人打码密码</div>

                                <input class="form-control" type="password" name="chaoren_pwd"
                                       value="<?= C('chaoren_pwd') ?>">
                            </div>
                        </div>
                        <div class="list-group-item bb">全部为空则该功能不开启，超人打码官网 <a
                                href="http://www.chaorendama.com/">http://www.chaorendama.com/</a></div>
                        <div class="list-group-item">
                            <button class="btn btn-primary btn-block" type="submit" name="submit" value="1">保存设置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
}
include_once 'common.foot.php';
?>