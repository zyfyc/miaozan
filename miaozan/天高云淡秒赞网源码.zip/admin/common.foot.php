         </div>
      </section>
      <!-- Page footer-->
      <footer>
	  <div class="pull-right hidden-xs">
              <a href="http://wpa.qq.com/msgrd?v=3&uin=<?=C('webqq')?>&site=qq&menu=yes" target="_blank">站长QQ：<?=C('webqq')?></a>
         </div>
         <span>&copy; 2016 - <?=C('webname')?>(<?=$domain?>)</span>
      </footer>
   </div>
   <!-- =============== VENDOR SCRIPTS ===============-->
   <!-- MODERNIZR-->
   <script src="<?= $webcdn_api ?>/style/vendor/modernizr/modernizr.custom.js"></script>
   <!-- MATCHMEDIA POLYFILL-->
   <script src="<?= $webcdn_api ?>/style/vendor/matchMedia/matchMedia.js"></script>
   <!-- JQUERY-->
   <script src="<?= $webcdn_api ?>/style/vendor/jquery/dist/jquery.js"></script>
   <!-- BOOTSTRAP-->
   <script src="<?= $webcdn_api ?>/style/vendor/bootstrap/dist/js/bootstrap.js"></script>
   <!-- STORAGE API-->
   <script src="<?= $webcdn_api ?>/style/vendor/jQuery-Storage-API/jquery.storageapi.js"></script>
   <!-- JQUERY EASING-->
   <script src="<?= $webcdn_api ?>/style/vendor/jquery.easing/js/jquery.easing.js"></script>
   <!-- ANIMO-->
   <script src="<?= $webcdn_api ?>/style/vendor/animo.js/animo.js"></script>
   <!-- SLIMSCROLL-->
   <script src="<?= $webcdn_api ?>/style/vendor/slimScroll/jquery.slimscroll.min.js"></script>
   <!-- SCREENFULL-->
   <script src="<?= $webcdn_api ?>/style/vendor/screenfull/dist/screenfull.js"></script>
   <!-- LOCALIZE-->
   <script src="<?= $webcdn_api ?>/style/vendor/jquery-localize-i18n/dist/jquery.localize.js"></script>
   <!-- RTL demo-->
   <script src="<?= $webcdn_api ?>/style/vendor/js/demo/demo-rtl.js"></script>
   <!-- =============== PAGE VENDOR SCRIPTS ===============-->
   <!-- SPARKLINE-->
   <script src="<?= $webcdn_api ?>/style/vendor/sparkline/index.js"></script>
   <!-- FLOT CHART-->
   <script src="<?= $webcdn_api ?>/style/vendor/Flot/jquery.flot.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/Flot/jquery.flot.resize.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/Flot/jquery.flot.pie.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/Flot/jquery.flot.time.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/Flot/jquery.flot.categories.js"></script>
   <script src="<?= $webcdn_api ?>/style/vendor/flot-spline/js/jquery.flot.spline.min.js"></script>
   <!-- CLASSY LOADER-->
   <script src="<?= $webcdn_api ?>/style/vendor/jquery-classyloader/js/jquery.classyloader.min.js"></script>
   <!-- MOMENT JS-->
   <script src="<?= $webcdn_api ?>/style/vendor/moment/min/moment-with-locales.min.js"></script>
   <!-- DEMO-->
   <script src="<?= $webcdn_api ?>/style/vendor/js/demo/demo-flot.js"></script>
   <!-- =============== APP SCRIPTS ===============-->
   <script src="<?= $webcdn_api ?>/style/vendor/js/app.js"></script>
   <script src="<?= $webcdn_api ?>/style/login/sweetalert.min.js"></script>
 <?php if(!empty($msg))echo "<script type='text/javascript'>{$msg}</script>";?>
</body>

</html>