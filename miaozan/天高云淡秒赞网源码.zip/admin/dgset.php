<?php
require_once('common.php');
C('webtitle','网站管理后台');
$index=1;
if($do=$_POST['do']){
	foreach($_POST as $k=> $value){
		$db->query("insert into {$prefix}webconfigs set vkey='".$k."',value='".$value."' on duplicate key update value='".$value."'");
	}
	if ($rows = $db->query('select * from ' . $prefix . 'webconfigs')) {
		while($row = $rows->fetch(PDO::FETCH_ASSOC)){
			$webconfig[$row['vkey']] = $row['value'];
		}
		C($webconfig);
	}
	echo"<script language='javascript'>alert('保存成功！');window.location.href='dgset.php';</script>";
}

if($_GET['type']=="1"){
	$data = get_curl('http://api.66dg.cc/Mzapi/tggetid.html?name='.C('webname').'&qq='.C('webqq'));
	$arr = json_decode($data,true);
	if($arr['code']==10000){
		$db->query("insert into {$prefix}webconfigs set vkey='apiid',value='".$arr['apiid']."' on duplicate key update value='".$arr['apiid']."'");
		$db->query("insert into {$prefix}webconfigs set vkey='apikey',value='".$arr['apikey']."' on duplicate key update value='".$arr['apikey']."'");
		echo"<script language='javascript'>alert('获取APIID和APIKEY成功，系统已自动保存！');window.location.href='dgset.php';</script>";
	}else{
		echo"<script language='javascript'>alert('".$arr['msg']."');window.location.href='dgset.php';</script>";
	}
}

if($_GET['type']=="2"){
	$data = '<p class="bg-success" style="padding:10px;">本站代挂服务器位于广东佛山，代挂时可能会出现异地登陆提醒以及被冻结，请了解！</p>
<p class="bg-danger" style="padding:10px;">即日起开始大量招收代挂代理，低价拿卡密，有意者请联系站长！</p>
<p class="bg-info" style="padding:10px;">代挂价格：5元/一月，12元/一季，20元/半年，36元/一年。</p>
<p class="bg-warning" style="padding:10px;">自助购买卡密连接：<a href="连接地址" target="_blank">连接地址</a></p>';

	$db->query("insert into {$prefix}webconfigs set vkey='gonggao_daigua',value='".$data."' on duplicate key update value='".$data."'");
	echo"<script language='javascript'>alert('代挂公告初始化成功！');window.location.href='dgset.php';</script>";
}
C('pageid','dgset');
include_once 'common.head.php';
?>
    <div class="row">
        <div class="col-md-5">
            <div class="panel panel-primary">
                <div class="panel-heading">
					<h2 class="panel-title">代挂设置说明</h2>
                </div>
                <p class="bg-success" style="padding:10px;">APIID:<?php if(!C('apiid')){echo '暂无';}else{echo C('apiid');}?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;APIKEY: <?php if(!C('apikey')){echo '暂无';}else{echo C('apikey');}?>
                <p class="bg-danger" style="padding:10px;">代挂QQ管理、代挂代理管理和拿货请登陆管理系统操作！</p>
                <p class="bg-info" style="padding:10px;">管理系统地址：http://66dg.cc (可使用APIID和APIKEY登陆)</p>
            </div>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">QQ等级代挂初始化设置</h3>
                </div>
                <?php if(!C('apiid') || !C('apikey')){?>
                <div class="list-group-item" style="size:14px; color:#F36" >
                &nbsp;如果你是第一次使用天高代挂，请先获取APIID和APIKEY。 <a href="?type=1" class="btn btn-success btn-xs">点此获取</a>
                </div>
                <div class="list-group-item" style="size:14px; color:#F36" >
                &nbsp;如果你是重新安装的，以前有过APIID和APIKEY的，请直接在下方输入保存即可。
                </div>
                <?php }else{?>
                <div class="list-group-item" style="size:14px; color:#F36" >
                &nbsp;请蒋APIID和APIKEY保存到电脑或手机中，防止重装程序后丢失(一个网站仅可以获取一次APIID和APIKEY)。
                </div>
                <?php }?>
                <form action="" role="form" method="post">
                    <input type="hidden" name="do" value="set">
                    <div class="list-group-item">
                        <div class="input-group">
                            <div class="input-group-addon">APIID</div>
                            <input type="text" class="form-control" name="apiid" placeholder="请输入APIID" value="<?=C('apiid')?>">
                        </div>
                    </div>
                    <div class="list-group-item">
                        <div class="input-group">
                            <div class="input-group-addon">APIKEY</div>
                            <input type="text" class="form-control" name="apikey" placeholder="请输入APIKEY" value="<?=C('apikey')?>">
                        </div>
                    </div>
                    <div class="list-group-item">购卡连接可不填，主要用于把卡密放到发卡平台，让用户在前台自助购买卡密使用的</div>
                    <div class="list-group-item">
                        <div class="input-group">
                            <div class="input-group-addon">用户购卡连接</div>
                            <input type="text" class="form-control" name="kmurl" placeholder="请输入APIKEY" value="<?=C('kmurl')?>">
                        </div>
                    </div>
                    <div class="list-group-item">
                        <input type="submit" value="确定" class="btn btn-primary btn-block">
                    </div>
                </form>  
            </div>
        </div>
        
        <div class="col-md-7">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h5 class="panel-title">代挂页面公告设置</h5>
                </div>
                    <form action="" role="form" method="post">
                    <input type="hidden" name="do" value="set">
                        <div class="list-group-item red" style="color:#F36">
                            公告内容可自行修改，美化版公告代码请 <a href="?type=2" class="btn btn-success btn-xs">点此初始化</a>
                        </div>
                        <div class="list-group-item">
                            <div class="input-group">
                                <div class="input-group-addon">公告内容</div>
                                <textarea class="form-control" name="gonggao_daigua" rows="10" placeholder="输入公告内容"><?=C('gonggao_daigua')?></textarea>
                            </div>
                        </div>
                        
                        <div class="list-group-item">
                           <input type="submit" value="保存" class="btn btn-primary btn-block">
                        </div>
                    </form>
            </div>
        </div>
        
    </div>
<?php
include_once 'common.foot.php';
?>