<?php 
require_once ('common.php');
C('webtitle', '服务器状态');
C('pageid', 'web');
include_once 'common.head.php';
?>
</div>
    <div class="row">
		   <div class="col-md-6">
		    <div class="list-group-item bb">
        <div class="panel panel-default">
            <div role="tabpanel">
   				<div role="tabpanel" class="tab-pane gn">
                <div class="panel-body">
        <div class="form-group">
            <ul>
                <div class="list-group-item bb">秒赞服务器
                <li><?php 
										$str="";
										for($i=1;$i<=C('zannet');$i++){
											$str.="<option value ='{$i}' ";
											if($qqrow['zannet'] == $i){
												$str.="selected='selected'";
											}
											$str.=">{$i}号极速服务器(";
											$num=get_count('qqs',"zannet='$i'",'qid');
											if($num>=C('netnum')){
												$str.="共".$num."个人 已满";
											}else{
												$sy=(C('netnum')-$num);
												$str.="已有{$num}人 还可加入".$sy."个";
											}
											$str.=")</option>";
										}
										echo $str;
										?></li>
                <!-- 免费 End -->
            </ul>
            <ul>
                 <div class="list-group-item bb">秒评服务器
                <li><?php 
										$str="";
										for($i=1;$i<=C('replynet');$i++){
											$str.="<option value ='{$i}' ";
											if($qqrow['replynet'] == $i){
												$str.="selected='selected'";
											}
											$str.=">{$i}号云端服务器(";
											$num=get_count('qqs',"replynet='$i'",'qid');
											if($num>=C('netnum')){
												$str.="共".$num."个人 已满";
											}else{
												$sy=(C('netnum')-$num);
												$str.="已有{$num}人 还可加入".$sy."个";
											}
											$str.=")</option>";
										}
										echo $str;
										?></li>
            </ul>
            <ul>
                 <div class="list-group-item bb">说说转发云端服务器
                <li><?php 
										$str="";
										for($i=1;$i<=C('zfnet');$i++){
											$str.="<option value ='{$i}' ";
											if($qqrow['zfnet'] == $i){
												$str.="selected='selected'";
											}
											$str.=">{$i}号云端服务器(";
											$num=get_count('qqs',"zfnet='$i'",'qid');
											if($num>=C('netnum')){
												$str.="共".$num."个人 已满";
											}else{
												$sy=(C('netnum')-$num);
												$str.="已有{$num}人 还可加入".$sy."个";
											}
											$str.=")</option>";
										}
										echo $str;
										?> </li>
            </ul>
            <ul>
			 <div class="list-group-item bb">自动说说云端服务器
                <li><?php 
										$str="";
										for($i=1;$i<=C('shuonet');$i++){
											$str.="<option value ='{$i}' ";
											if($qqrow['shuonet'] == $i){
												$str.="selected='selected'";
											}
											$str.=">{$i}号云端服务器(";
											$num=get_count('qqs',"shuonet='$i'",'qid');
											if($num>=C('netnum')){
												$str.="共".$num."个人 已满";
											}else{
												$sy=(C('netnum')-$num);
												$str.="已有{$num}人 还可加入".$sy."个";
											}
											$str.=")</option>";
										}
										echo $str;
										?></li>

            </ul>
        </div>
    </div>
    </div>
	
	<?php include_once 'common.foot.php';
		?>