<?php
require_once('includes/common.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title><?= C('webname') ?> - <?= C('webkey') ?></title>
    <meta name="description" content="轻飞曼舞程序自带HTK人性化系统,能够离线为网友提供许多云功能,HTK概念是达到无需人工手动则达成任务">
    <meta name="keywords" content="轻飞曼舞秒赞网,秒赞网,免费秒赞网,QQ秒赞网,秒赞吧,免费QQ秒赞网">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="http://www.lxzan.com/Style/css/bootstrap.min.css" type="text/css" media="all">
   <link rel="stylesheet" href="https://fonts.cdn.1sll.cc/style/index/Css/font-awesome.min.css">
<link rel="stylesheet" href="http://www.lxzan.com/Style/css/pcmb_4/app.css">
<link rel="shortcut icon" href="favicon.ico">
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?f5079ed1c93135817bc86cf735bde375";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script></head>


<body>

<section class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-6 col-xs-6 logo">
                <a href="/"><i class="fa fa-thumbs-o-up"></i> <?= C('webname') ?></a>
            </div>
            <div class="col-md-10 col-sm-6 col-xs-6 nav-top">
                <ul>
                         <li class="link" style="margin-left:10px;"><a href="login.php?do=reg">注册</a></li>
                        <li class="link" style="margin-left:10px;"><a href="login.php">登录</a></li>
                    <li class="hidden-sm hidden-xs"><a href="mgmt"><i class="fa fa-user"></i> 用户中心</a></li>
                    <li class="hidden-sm hidden-xs"><a href="/"><i class="fa fa-home"></i> 首页</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

    <div class="container">
            <div class="index-bg-text">
                <h1>
                    <?= C('webname') ?>                  <p></p> <p></p>
					</h1><h3>稳定实时／离线使用／简单上手</h3>
                
                <p class="i">致力为广大用户打造QQ空间离线稳定点赞平台</p>
				<?php if (C('loginuid')) { ?>
                <a href="login.php?do=reg" class="btn btn-lg btn-info btn-more">立即注册</a>
				 <a href="mgmt/index.php" class="btn btn-lg btn-success btn-more">欢迎回来，<?= $userrow['user'] ?></a>
				 <?php } else { ?>
                <a href="login.php?do=reg" class="btn btn-lg btn-info btn-more">立即注册</a>
				 <a href="login.php" class="btn btn-lg btn-success btn-more">立即登录</a>
				 <?php } ?>
            </div>
    </div>
</section>

<section class="index-service">
    <div class="container">
        <h2>专业提供优质的秒赞秒评等离线服务</h2>
        <div class="row">
            <div class="col-md-4">
                <h3>稳定使用</h3>
                <p>无需秒赞软件，无需设备挂机！支持自动更新，完美离线使用，快来一起秒赞吧。</p>
            </div>
            <div class="col-md-2" style="border-right:1px solid #eee">
                <span class="fa fa-thumbs-o-up"></span>
            </div>
            <div class="col-md-4 col-md-offset-1">
                <h3>分布执行</h3>
                <p>分布多台服务器各自执行各自功能，再也无需担心因为平台QQ增多而影响到效率。</p>
            </div>
            <div class="col-md-1">
                <span class="fa fa-rocket"></span>
            </div>
        </div>
		        <div class="row" style="margin-top:30px;">
            <div class="col-md-4">
                <h3>节省流量</h3>
                <p>不再需要消耗流量下载秒赞软件，不再需要消耗流量挂机，直接平台一键操作！</p>
            </div>
            <div class="col-md-2" style="border-right:1px solid #eee">
                <span class="fa fa-wifi"></span>
            </div>
            <div class="col-md-4 col-md-offset-1">
                <h3>设备兼容</h3>
                <p>采用响应式设计，无论电脑、手机、平板均可使用，都会自动适应您的设备。</p>
            </div>
            <div class="col-md-1">
                <span class="fa fa-laptop"></span>
            </div>
        </div>
    </div>
</section>

<section class="index-device">
    <div class="container">
        <h2>因为稳定 他们信赖<p>		 运营690天来，我们已有<?=get_count('users',"1=:1",'uid',array(':1'=>"1"))?>位用户和<?=get_count('qqs',"1=:1",'qid',array(':1'=>"1"))?>个QQ</p></h2>
        <ul>
		<?php
                $rowss = $db->query("select * from {$prefix}qqs where skeyzt='0' order by qid desc limit 6");
                while ($row = $rowss->fetch(PDO::FETCH_ASSOC)) {
                    ?>
		<a href="Home/mzrz.php?qq=<?= $row['qq'] ?>" target="_blank">
<img style="border:1px solid #FFF;-moz-box-shadow:0 0 3px #AAA;-webkit-box-shadow:0 0 3px #AAA;box-shadow:0 0 3px #AAA;padding:3px;margin-right:10px;margin-top:15px;margin-left:15px;"  src="//q1.qlogo.cn/g?b=qq&nk=<?= $row['qq'] ?>&s=100" width="80px" height="80px" alt="<?= $row['qq'] ?>" title="<?= $row['qq'] ?>|添加时间:<?= $row['addtime'] ?>"></a>
	<?php } ?>
</ul>
    </div>
</section>
<section class="index-process">
    <div class="container">
        <div class="row">
            <h2><?= C('webname') ?> 简约而不简单</h2>
            <div class="col-md-2">
                <i><span class="glyphicon glyphicon">①</span></i>
                <p>注册<?= C('webname') ?></p>
            </div>
            <div class="col-md-2">
                <i><span class="glyphicon glyphicon">②</span></i>
                <p>登陆<?= C('webname') ?></p>
            </div>
            <div class="col-md-2">
                 <i><span class="glyphicon glyphicon">③</span></i>
                <p>添加您的QQ账号</p>
            </div>
            <div class="col-md-2">
                  <i><span class="glyphicon glyphicon">④</span></i>
                <p>免费开启秒赞服务</p>
            </div>
            <div class="col-md-2">
                 <i><span class="glyphicon glyphicon">⑤</span></i>
                <p>开始您的离线之旅</p>
            </div>
            <div class="col-md-2">
                  <i><span class="glyphicon glyphicon">⑥</span></i>
                <p>向好友推荐本站</p>
            </div>
        </div>
    </div>
</section>
<section class="index-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-1 col-sm-6">
                <dl>
                    <dt>相关链接</dt>
                    <dd><a href="login.php">秒赞认证</a></dd>
					<dd><a href="login.php">用户中心</a></dd>
                    <dd><a href="login.php">代理后台</a></dd>
                    <dd><a href="login.php">我要登陆</a></dd>
                </dl>
            </div>
            <div class="col-md-4 col-sm-6">
                <dl>
                    <dt>站点信息</dt>
                    <dd>今日注册：<?= get_count('users', "adddate=:date", "uid", array(":date" => date("Y-m-d"))) ?>个</dd>
					<dd>用户数量：<?=get_count('users', "1=:1", "uid", array(":1" => "1")) ?>个</dd>
                    <dd>扣扣数量：<?=get_count('qqs', "1=:1", "uid", array(":1" => "1")) ?>个</dd>
                    <dd>站长扣扣：<?=C('webqq')?></dd>
                </dl>
            </div>
            <div class="col-md-3 hidden-sm hidden-xs">
                <dl>
                    <dt>联系我们</dt>
                    <dd><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?=C('webqq')?>&amp;site=qq&amp;menu=yes"><img border="0" src="http://luoci-1252111933.cosgz.myqcloud.com/qqzx.png" alt="联系站长" title="联系站长"></a></dd>
                </dl>
            </div>
        </div>
    </div>
</section>
<section class="footer">
    Copyright © 2017 <?= C('webname') ?> 版权所有
</section>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>

<audio controls="controls" style="display: none;"></audio><div id="qq-sendUrl-btn"></div><div id="qb-sougou-search" style="display: none; opacity: 0;"><p>搜索</p><p class="last-btn">复制</p><iframe src="style/index_xy/saved_resource.html"></iframe></div></body><style type="text/css">#yddContainer{display:block;font-family:Microsoft YaHei;position:relative;width:100%;height:100%;top:-4px;left:-4px;font-size:12px;border:1px solid}#yddTop{display:block;height:22px}#yddTopBorderlr{display:block;position:static;height:17px;padding:2px 28px;line-height:17px;font-size:12px;color:#5079bb;font-weight:bold;border-style:none solid;border-width:1px}#yddTopBorderlr .ydd-sp{position:absolute;top:2px;height:0;overflow:hidden}.ydd-icon{left:5px;width:17px;padding:0px 0px 0px 0px;padding-top:17px;background-position:-16px -44px}.ydd-close{right:5px;width:16px;padding-top:16px;background-position:left -44px}#yddKeyTitle{float:left;text-decoration:none}#yddMiddle{display:block;margin-bottom:10px}.ydd-tabs{display:block;margin:5px 0;padding:0 5px;height:18px;border-bottom:1px solid}.ydd-tab{display:block;float:left;height:18px;margin:0 5px -1px 0;padding:0 4px;line-height:18px;border:1px solid;border-bottom:none}.ydd-trans-container{display:block;line-height:160%}.ydd-trans-container a{text-decoration:none;}#yddBottom{position:absolute;bottom:0;left:0;width:100%;height:22px;line-height:22px;overflow:hidden;background-position:left -22px}.ydd-padding010{padding:0 10px}#yddWrapper{color:#252525;z-index:10001;background:url(chrome-extension://eopjamdnofihpioajgfdikhhbobonhbb/ab20.png);}#yddContainer{background:#fff;border-color:#4b7598}#yddTopBorderlr{border-color:#f0f8fc}#yddWrapper .ydd-sp{background-image:url(chrome-extension://eopjamdnofihpioajgfdikhhbobonhbb/ydd-sprite.png)}#yddWrapper a,#yddWrapper a:hover,#yddWrapper a:visited{color:#50799b}#yddWrapper .ydd-tabs{color:#959595}.ydd-tabs,.ydd-tab{background:#fff;border-color:#d5e7f3}#yddBottom{color:#363636}#yddWrapper{min-width:250px;max-width:400px;}</style></html>