<?php
require_once('includes/common.php');
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?=C('webname')?>-<?=C('name')?></title>
<meta name="description" content="<?=C('webname')?>,免费秒赞,梦月天高秒赞,离线秒赞,秒赞,秒赞系统,免费24h小时秒赞,秒赞秒评,QQ空间秒赞APP,秒赞吧,手机秒赞,秒赞挂机网站">
<meta name="keywords" content="<?=C('webname')?>,最稳定的QQ离线秒赞平台,自主研发智能协议自动切换,全分布式高端服务器架构,承载数万QQ稳定秒赞,独家提供配套图文说说全自动发表,彻底解放双手,更多功能等你体验,一起来使用吧">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="images/favicon.ico">

<link href="http://lib.baomitu.com/twitter-bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
<link href="http://lib.baomitu.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet">
<link href="http://lib.baomitu.com/flexslider/2.2.0/flexslider-min.css" rel="stylesheet">
<link href="http://cdn.yunqzan.com/tgyd/index/css/styles.css"" rel="stylesheet">
<link href="http://cdn.yunqzan.com/tgyd/index/css/queries.css" rel="stylesheet">
<link href="http://cdn.yunqzan.com/tgyd/index/css/animate.css" rel="stylesheet">
</head>
<body id="top">
<header id="home">
<nav>
<div class="container-fluid">
<div class="row">
<div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-8 col-xs-offset-2">
<nav class="pull">
<ul class="top-nav">
<?php if(C('loginuid')){?>
<li><a href="/mgmt">用户中心 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
<?php }else{?>
<li><a href="/<?= $login_mgmt ?>">登陆 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
<li><a href="/<?= $login_mgmt ?>?do=reg">注册 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
<?php }?>
<li><a href="#responsive">特色功能 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
<li><a href="#portfolio">功能介绍 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
<li><a href="#contact">用户数量 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
</ul>
</nav></div></div></div></nav>
<section class="hero" id="hero">
<div class="container">
<div class="row">
<div class="col-md-12 text-right navicon">
<a id="nav-toggle" class="nav_slide_button" href="#"><span></span></a>
</div></div>
<div class="row">
<div class="col-md-8 col-md-offset-2 text-center inner">
<h1 class="animated fadeInDown"><?=C('webname')?></h1> 
</div>
<div class="col-md-6 col-md-offset-3 text-center">
<p class="animated fadeInUp delay-1s"></p>
</div>
<div class="col-md-6 col-md-offset-3 text-center">
<p class="animated fadeInUp delay-05s">本站功能一键开启,无需安装软件,电脑,平板,手机全部一站式通用!</p>
<a href="#" class="down-arrow-btn">2.0</a>
</div></div>
<div class="row">
<div class="col-md-6 col-md-offset-3 text-center">
<p class="animated fadeInUp delay-05s">目前我们正在为 <font color=red><?=get_count('users',"uid")?></font> 用户的 <font color=red><?=get_count('qqs',"uid")?></font> 个QQ提供服务,欢迎您的加入。</p>
</div>
<div class="col-md-6 col-md-offset-3 text-center">
<?php if(C('loginuid')){?>
<a href="/mgmt"  class="learn-more-btn" style="padding-left: 80px;padding-right: 80px;">用户中心</a>
<?php }else{?>
<a href="/<?= $login_mgmt ?>" class="learn-more-btn">登陆</a>
<a href="/<?= $login_mgmt ?>?do=reg" class="learn-more-btn">注册</a>
<?php }?>
</div></div></div>
</section>
</header>
<section class="intro text-center section-padding" id="intro">
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2 wp1">
<h1 class="arrow">多功能组合性系统</h1>
<p>在用户界面中添加需要托管的QQ号，之后点击开启秒赞功能即可离线运行，无需一直开着网页，任务会24小时自动运行。<br>
更有全网独家的配套图文说说系统，多种语录可以选择，文字与图片配套，全天24小时自动发表，让你的小伙伴羡慕嫉妒去吧！<br>
全新的QQ等级代挂功能只需提交QQ即可每天满加速，快速升级QQ等级到皇冠不再是梦。</p>
</div></div></div>
</section>
<section class="features text-center section-padding" id="features">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1 class="arrow">热爱你的QQ,你会做得更好</h1> - <a href="/">HTK系统</a>
<div class="features-wrapper">
<div class="col-md-4 wp2">
<div class="icon">
<i class="fa fa-laptop shadow"></i>
</div>
<h2>一站式管理</h2>
<p>使用<?=C('webname')?>进行挂机，无需安装任何额外软件，注册登陆后添加QQ即可正常运行，您可以随时在电脑/手机/平板登陆本网站进行功能设置 </p>
</div>
<div class="col-md-4 wp2 delay-05s">
<div class="icon">
<i class="fa fa-code shadow"></i>
</div>
<h2>分布式架构</h2>
<p>高配置服务器采用分布式监控系统的运行，24小时不间断稳定不宕机，服务器秒级切换更改随心，离线托管完美使用体验 </p>
</div>
<div class="col-md-4 wp2 delay-1s">
<div class="icon">
<i class="fa fa-heart shadow"></i>
</div>
<h2>智能提醒服务</h2>
<p>SID/KEY过期后邮件自动推送，<?=C('webname')?>使用付费邮局进行发信，保证邮件的送达率，让您秒赞24小时正常运行一切由我们来操作 </p>
</div>
<div class="clearfix"></div>
</div></div></div></div>
</section>
<section class="text-center" id="responsive">
<div class="container-fluid nopadding responsive-services">
</div></div>
</section>
<section class="swag text-center">
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<h1>奔驰过无数个好友空间<span>踩过无数好友的说说 <span>践踏过无数好友评论 <span>只因为她点上一个赞!</span></h1>
<a href="#portfolio" class="down-arrow-btn"><i class="fa fa-chevron-down"></i></a>
</div></div></div>
</section>
<section class="portfolio text-center section-padding" id="portfolio">
<div class="container">
<div class="row">
<div id="portfolioSlider">
<ul class="slides">
<li>
<div class="col-md-4 wp4">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-01.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>各项签到</h2>
<p>更有QQ会员 绿钻 蓝钻 QQ群等签到新增QQ管家 好莱坞 QQ部落 黄钻 空间 大乐斗 等等签到功能让您每天全自动领取签到奖励和积分 QQ等级迅速提升.</p>
</div>
<div class="col-md-4 wp4 delay-05s">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-02.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>其他功能</h2>
<p>本系统带有QQ空间音乐查询 在线拉圈圈赞99+ 好友测赞 一测便知 单项好友测试 抓出无视你的好友 领取图书VIP会员 免费使用7天 等等更多免费功能.</p>
</div>
<div class="col-md-4 wp4 delay-1s">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-03.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>主要功能</h2>
<p>系统自带的主要核心功能 离线云点赞 评论 在线转发 24h不断发表说说 还可以说说圈图片 让空间不再孤单 迅速成为QQ达人 空间全能达人 赶紧加入我们吧！.</p>
</div>
</li>
<li>
<div class="col-md-4 wp4">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-01.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>QQ群功能</h2>
<p>我们的系统目前已开发出QQ群全套功能,带有QQ群部落签到 QQ群签到 QQ群问问签到 更稳定 对协议各种程度的更新 不同程度的优化后 稳定高效.</p>
</div>
<div class="col-md-4 wp4 delay-05s">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-02.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>互刷功能</h2>
<p>目前本站有 说说队列 说说刷赞 互刷人气 互刷空间主页赞 互刷空间礼物 互刷空间留言 使用站内的用户和您实现互动 .</p>
</div>
<div class="col-md-4 wp4 delay-1s">
<div class="overlay-effect effects clearfix">
<div class="img">
<img src="http://cdn.yunqzan.com/tgyd/index/img/portfolio-03.jpg" alt="Portfolio Item">
<div class="overlay">
<a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
<a class="close-overlay hidden">x</a>
</div></div></div>
<h2>高效率系统</h2>
<p>本系统已研发QS点赞协议保证不漏赞 QQ全能助手 全新的系统 极致 让你体验不一样的感觉,犹如风拂过您的身旁 我们来自于爱好 源于2016 为您而生.</p>
</div>
</li>
</ul>
</div></div></div>
</section>
<div class="ignite-cta text-center">
<div class="container">
<div class="row">
<div class="col-md-12">
<?php if(C('loginuid')){?>
<a href="/mgmt/index.php" class="ignite-btn">点燃你的青春岁月</a>
<?php }else{?>
<a href="/mgmt/index.php" class="ignite-btn">用户中心</a>
<?php }?>
</div></div></div></div>
<section class="subscribe text-center">
<div class="container">
<h1><i class="fa fa-paper-plane"></i><span>Music appreciation</span></h1>
<script language="JavaScript" type="text/javascript">
tips = new Array(14);
tips[0] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=36496595&auto=1&height=66"></iframe>';


tips[1] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=36496596&auto=1&height=66"></iframe>';


tips[2] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=498181&auto=1&height=66"></iframe>';


tips[3] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=498184&auto=1&height=66"></iframe>';


tips[4] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=31066263&auto=1&height=66"></iframe>';


tips[5] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=31649313&auto=1&height=66"></iframe>';


tips[6] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=31649311&auto=1&height=66"></iframe>';


tips[7] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=31649314&auto=1&height=66"></iframe>';


tips[8] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=26201959&auto=1&height=66"></iframe>';


tips[9] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=461011&auto=1&height=66"></iframe>';


tips[10] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=28528420&auto=1&height=66"></iframe>';


tips[11] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=28613686&auto=1&height=66"></iframe>';


tips[12] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=34478647&auto=1&height=66"></iframe>';


tips[13] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=30284319&auto=1&height=66"></iframe>';


index = Math.floor(Math.random() * tips.length);


document.write(tips[index]);


</script>
</div>
</section>
<section class="dark-bg text-center section-padding contact-wrap" id="contact">
<a href="#top" class="up-btn"><i class="fa fa-chevron-up"></i></a>
<div class="container">
<div class="row">
<div class="col-md-12">
<h1 class="arrow">系统信息</h1>
</div></div>
<div class="row contact-details">
<div class="col-md-4">
<div class="light-box box-hover">
<h2><i class="fa fa-map-marker"></i><span>用户</span></h2>
<p>
用户数量 <?=get_count('users',"uid")?>
</p>
</div></div>
<div class="col-md-4">
<div class="light-box box-hover">
<h2><i class="fa fa-mobile"></i><span>QQ</span></h2>
<p>QQ数量 <?=get_count('qqs',"uid")?></p>
</div>
</div>
<div class="col-md-4">
<div class="light-box box-hover">
<h2><i class="fa fa-paper-plane"></i><span>正在秒赞</span></h2>
<p><a href="#"></a>正在秒赞 <?php echo get_count('qqs', 'iszan=:2 or iszan=:1', 'qid', array(':1' => '1', ':2' => '2'))?></p>
</div></div></div>
<div class="row">
<div class="col-md-12">
<ul class="social-buttons">
<li><a href="#" class="social-btn"><i class="fa fa-dribbble"></i></a></li>
<li><a href="#" class="social-btn"><i class="fa fa-thumbs-o-up"></i></a></li>
<li><a href="#" class="social-btn"><i class="fa fa-envelope"></i></a></li>
</ul>
</div></div></div>
</section>
<footer>
<div class="container">
<div class="row">
<div class="col-md-6">
<ul class="legals">
<div class="friend_links">
<li><a href="#">合作网站</a></li>
<li><a href="#">更多</a></li>
</ul>
</div>
<div class="col-md-6 credit">
<p>METI秒赞 <a href="sitemap.txt">裸辞</a> - <a href="/" target="_blank" title="<?=C('webname')?>"><?=C('webname')?></a></p>
</div></div></div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="http://cdn.yunqzan.com/tgyd/index/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="http://cdn.yunqzan.com/tgyd/index/js/waypoint.min.js"></script>
<script src="http://cdn.yunqzan.com/tgyd/index/js/bootstrap.min.js"></script>
<script src="http://cdn.yunqzan.com/tgyd/index/js/scripts.js"></script>
<script src="http://cdn.yunqzan.com/tgyd/index/js/jquery.flexslider.js"></script>
<script src="http://cdn.yunqzan.com/tgyd/index/js/modernizr.js"></script>
</body>
</html>