﻿<?php
require_once('includes/common.php');
?>
<!doctype html>
<html class="no-js" lang="zh" data-attr-t lang-t="lang">
  <head>
    <meta charset="utf-8" />
    <meta name="Author" content="Ping++">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?=C('webname')?> - <?=C('webkey')?>梦月天高秒赞</title>
    <link rel="stylesheet" href="http://www.wmsg.cc/css/app-821eedfc46.css">
    <meta name="description" content="<?=C('webname')?>,免费秒赞,梦月天高秒赞,离线秒赞,秒赞,秒赞系统,免费24h小时秒赞,秒赞秒评,QQ空间秒赞APP,秒赞吧,手机秒赞,秒赞挂机网站">
    <meta name="keywords" content="<?=C('webname')?>,最稳定的QQ离线秒赞平台,自主研发智能协议自动切换,全分布式高端服务器架构,承载数万QQ稳定秒赞,独家提供配套图文说说全自动发表,彻底解放双手,更多功能等你体验,一起来使用吧">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <script type='text/javascript'>
    var _vds = _vds || [];
    window._vds = _vds;
    (function(){
        _vds.push(['setAccountId', '8c9473c015e1499aa686406418f60e4a']);
        (function() {
          var vds = document.createElement('script');
          vds.type='text/javascript';
          vds.async = true;
          vds.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'dn-growing.qbox.me/vds.js';
          var s = document.getElementsByTagName('script')[0];
          s.parentNode.insertBefore(vds, s);
        })();
    })();
    </script>


    <style>
    <?php 


        $ga = date("w");
        switch($ga){
          case 1:
            $bj_img = 'http://img01.sogoucdn.com/app/a/100540002/1042209.jpg?f=download';
            $font_color = '#fcfcfc';
            break;
          case 2:
            $bj_img = 'http://img.bizhi.sogou.com/images/2013/12/10/445290.jpg?f=download';
            $font_color = '#35c8e6';
            break;
          case 3:
            $bj_img = 'http://img.bizhi.sogou.com/images/2014/01/21/497238.jpg?f=download';
            $font_color = '#FFB300';
            break;
          case 4:
            $bj_img = 'http://img.bizhi.sogou.com/images/2014/03/11/540548.jpg?f=download';
            $font_color = '#35C8E6';
            break;
          case 5:
            $bj_img = 'http://img.bizhi.sogou.com/images/2013/12/12/449860.jpg?f=download';
            $font_color = '#4CAF50';
            break;
          case 6:
            $bj_img = 'http://img.bizhi.sogou.com/images/2013/12/12/449860.jpg?f=download';
            $font_color = '#FFB300';
            break;
          case 0:
            $bj_img = 'http://img.bizhi.sogou.com/images/2013/12/12/449860.jpg?f=download';
            $font_color = '#e0e0e0';
            break;
        }

      echo ".hero {background: #ecedf0 url($bj_img); background-repeat: no-repeat;background-position: center top ;color: $font_color;}
            ul.menu li a {color: $font_color;}";
    ?>
    </style>
  </head>
  <body class="">
    
    <div class="top-bar-wrapper">
      <div class="row column">
    <div class="title-bar show-for-small-only">
        <button id="hamburger" class="menu-icon" type="button" data-toggle></button>
    </div>
    
    <div class="top-bar hide-for-small-only">
      <div class="top-bar-title">
      </div>
      <div class="top-bar-left">
      </div>
      <div class="top-bar hide-for-small-only">
      <div class="top-bar-right">
        <ul class="menu">
          <li><a target="_blank" href="/mgmt/shop.php"  data-t="top-nav.documentation">自助商城</a></li>
          <li><a href="/mgmt/logout.php"  data-t="top-nav.login">登录</a></li>
          <li><a href="/<?= $login_mgmt ?>?do=reg" class="button cta hollow small" data-t="top-nav.signup">注册</a></li>
        </ul>
      </div>
    </div>
    </div>
    
      </div>
    </div>
     <div class="mobile-nav show-for-small-only" id="sidebar-menu">
      <ul>
        
        <li class="divider"><a href="index.php?mod=shop" data-t="top-nav.documentation">自助商城</a></li>
        <li class="divider"><a href="index.php?mod=dlyz" data-t="top-nav.documentation">代理验证</a></li>
        <li><a href="/mgmt/logout.php" data-t="top-nav.login">登录</a></li>
        <li class="divider"><a href="/<?= $login_mgmt ?>?do=reg" data-t="top-nav.signup">注册</a></li>
        <li class="divider"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?=C('webqq')?>&site=qq&menu=yes" data-t="top-nav.documentation">联系客服</a></li>
      </ul>
    </div>
    <div class="ui-mask"></div>
    
    <section class="hero hero--clip" id="hero">
      <div class="row">
        <div class="small-12 columns">
            <div class="hero-copy">
              <h1 data-t="dashboard.hero.heading">欢迎使用<?=C('webname')?></h1>
              <h4 data-t="dashboard.hero.subheading">手机电脑平板一站通用，<br>轻松开启又快又稳定的免费秒赞。</h4>
              <p>
			  <?php if(C('loginuid')){?>
				<a href="/mgmt/index.php" class="button cta">欢迎回来，<?= $userrow['user'] ?></a>
				<?php }else{?>
              <a class="button cta" href="/<?= $login_mgmt ?>?do=reg" data-t="index.hero.cta">立即注册</a>
              <a class="button cta" href="/<?= $login_mgmt ?>" data-t="index.hero.cta">立即登录</a>
              	  <?php }?>
			  </p>
            </div>
        </div>
      </div>
    </section>
  
    <section class="news ld-content" id="financing">
      <div class="row align-center align-middle">
        <div class="column shrink">
          <h5 data-t="index.news.fq.title">目前我们正在为 <font color=red><?=get_count('users',"uid")?></font> 用户的 <font color=red><?=get_count('qqs',"uid")?></font> 个QQ提供服务,欢迎您的加入。</h5>
        </div>
    
      </div>
    </section>
  
    <section class="ld-feature-grid ld-content ld-content--center" id="overview">
      <div class="row align-center">
        <div class="small-11 medium-10 large-9 column">
          <div class="row small-up-1 medium-up-3 align-top">
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-shopping-chart.svg"></div>
              <h5 data-t="dashboard.features.data.title">超人打码</h5>
              <p class="small" data-t="dashboard.features.data.description">我们平台已经对接超人打码平台，自动更新QQ，只要密码不修改就不用您每次手动更新。</p>
            </div>
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-emoticons-wink.svg"></div>
              <h5 data-t="dashboard.features.account.title">多QQ管理</h5>
              <p class="small" data-t="dashboard.features.account.description">支持一个账号管理多个QQ，免去频繁登录多个账号的烦恼。</p>
            </div>
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-media-sound-wave.svg"></div>
              <h5 data-t="dashboard.features.monitoring.title">拉圈圈赞</h5>
              <p class="small" data-t="dashboard.features.monitoring.description">平台实现免费拉圈圈赞99+，平台独立接口免费拉圈圈赞。</p>
            </div>
          </div>
          <div class="row small-up-1 medium-up-3 align-top">
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-ui-grid.svg"></div>
              <h5 data-t="dashboard.features.apps.title">多功能管理</h5>
              <p class="small" data-t="dashboard.features.apps.description">我们提供多项使用功能，满足您的多种需求。</p>
            </div>
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-tech-mobile-recharger.svg"></div>
              <h5 data-t="dashboard.features.dev.title">多平台管理</h5>
              <p class="small" data-t="dashboard.features.dev.description">平台适配PC，手机平板多平台随时随地管理您的账号。</p>
            </div>
            <div class="ld-feature-grid__column column">
              <div class="ld-feature-grid__icon"><img src="http://www.wmsg.cc/css/img/ds-headphones-mic.svg"></div>
              <h5 data-t="dashboard.features.tickets.title">客服系统</h5>
              <p class="small" data-t="dashboard.features.tickets.description">本站VIP用户如遇问题可联系站长为你解答。</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  <section class="bottom-cta bottom-cta--gray">
      <div class="row align-center">
        <div class="small-12 medium-8 large-7 columns">
          <h3 data-t="bottom-cta.default.title">开启秒赞仅需一分钟</h3>
          <p><a href="/<?= $login_mgmt ?>?do=reg" class="button cta" data-t="bottom-cta.default.cta">免费注册账号</a></p>
        </div>
      </div>
    </section>
    
    
    <footer>
      <div class="row">
        <div class="small-12 medium-expand columns">
          <p class="xsmall">Copyright &copy; 2016 <a target="_blank" href="<?=C('webname')?>"><?=C('webname')?></a></p>
        </div>
      </div>
    </footer>   
    <script src="http://www.wmsg.cc/css/app-f8b80f22b3.js"></script>
  </body>
</html>