<?php
if($mod=='error'){
	define('DBQZ', $dbconfig['dbqz']);
	return;
}
if(!$_COOKIE['siteid'])unset($_COOKIE['adminid']);
$siterow=$DB->get_row("select * from ".$dbconfig['dbqz']."_domain where domain='".addslashes($_SERVER['HTTP_HOST'])."' limit 1");
if($siterow){
	$dbqz=$siterow['db'];
	$siterow=$DB->get_row("select * from ".$dbconfig['dbqz']."_site where db='{$dbqz}' limit 1");
	if($siterow['date']<date("Y-m-d"))
		exit("<script language='javascript'>window.location.href='./index.php?mod=error&msg=分站已到期，请联系管理员续期！';</script>");
	elseif($siterow['active']==0)
		exit("<script language='javascript'>window.location.href='./index.php?mod=error&msg=分站已关闭，请联系管理员开通！';</script>");
	else{
		$is_fenzhan=1;
		define('DBQZ', $dbqz);
	}
}else{
	$is_fenzhan=0;
	define('DBQZ', $dbconfig['dbqz']);
}