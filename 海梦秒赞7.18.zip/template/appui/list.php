<?php
if(!defined('IN_CRONLITE'))exit();
$act=isset($_GET['act'])?$_GET['act']:null;

if($islogin==1)
{
switch($act) {

case 'qqtask':
$qq=daddslashes($_GET['qq']);
$qqrow=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
if($qqrow['uid']!=$uid && $isadmin!=1)
{showmsg('你只能操作自己的QQ哦！',3);
}
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE qq='{$qq}'");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
<div class="panel panel-default table-responsive" id="list">
<table class="table table-hover">
	<thead>
		<tr>
			<th><font size="2">任务名称（<?php echo $gls?>）</font></th>
			<th><font size="2">其他信息</font></th>
			<th><font size="2">状态/操作</font></th>
		</tr>
	</thead>
	<tobdy>
	<tr>
		<td><b>已开启SID/SKEY自动更新</b></td><td>状态:<font color="green">正在运行</font><br/>上次更新:<font color="blue"><?php echo $qqrow['time']?></font></td><td><a class="btn btn-danger btn-sm" disabled><i class="fa fa-trash"></i>&nbsp;删除</a></td>
	</tr>
<?php
$i=0;
$rs=$DB->query("SELECT * FROM ".DBQZ."_qqjob WHERE qq='$qq' order by jobid desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
	$i++;
	$pagesl = $i + ($page - 1) * $pagesize;

	$type=$myrow['type'];
	$qqjob=qqjob_decode($qq,$type,$myrow['method'],$myrow['data']);
	if(!$qqTaskNames[$type])continue;
	echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$qqTaskNames[$type].'任务</b><br/>'.$qqjob['info'];
	echo '</td><td style="width:35%">状态:';
	if ($myrow['zt'] == '1'){
		echo '<font color="red">暂停运行...</font><br/>';
	}else{
		echo '<font color="green">正在运行</font><br/>';
	}
	echo '运行次数:<font color="red">'.$myrow['times'].'</font><br>上次执行:<font color="blue">'.dgmdate($myrow['lasttime']).'</font>';
	echo '<br/>运行时间:<font color="blue">'.$myrow['start'].'时 - '.$myrow['stop'].'时</font>';
	if($myrow['pl']!=0)
		echo '<br>运行频率:<font color="red">'.$myrow['pl'].'</font>秒/次';
	elseif(in_array($type,$qqSignTasks))
		echo '<br>运行频率:<font color="red">18000</font>秒/次';
	elseif(in_array($type,$qqLimitTasks) || in_array($type,$qqGuajiTasks))
		echo '<br>运行频率:<font color="red">600</font>秒/次';

	echo '</td><td style="width:25%">';
	if($myrow['data'] || $type=='3gqq')
		echo '<a href="#" onclick="qqjob_edit(\''.$qq.'\',undefined,\''.$myrow['jobid'].'\',\''.$page.'\')" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;编辑</a><br/>';
	if ($myrow['zt'] == '1') {
		echo '<a href="#" onclick="job_edit(\'kq\','.$myrow['jobid'].',\'qqjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-play"></i>&nbsp;开启</a>';
	}else{
		echo '<a href="#" onclick="job_edit(\'zt\','.$myrow['jobid'].',\'qqjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-pause"></i>&nbsp;暂停</a>';
	}
	echo '<br/><a href="#" onclick="job_edit(\'del\','.$myrow['jobid'].',\'qqjob\',\''.$page.'\')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp;删除</a></div></td></tr>';
}

?>
	</tbody>
</table>
</div>
<?php 
break;

case 'signtask':
$gls=$DB->count("SELECT count(*) from ".DBQZ."_signjob WHERE uid='{$uid}'");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
<div class="panel panel-default table-responsive" id="list">
<table class="table table-hover">
	<thead>
		<tr>
			<th>任务名称</th>
			<th>其他信息</th>
			<th>状态/操作</th>
		</tr>
	</thead>
	<tobdy>
<?php
$i=0;
$rs=$DB->query("SELECT * FROM ".DBQZ."_signjob WHERE uid='$uid' order by jobid desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
	$i++;
	$pagesl = $i + ($page - 1) * $pagesize;

	$type=$myrow['type'];
	$signjob=signjob_decode($type,$myrow['data']);
	echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$signTaskNames[$type].'任务</b><br/>签到数据：'.$signjob['data'].$signjob['info'];
	echo '</td><td style="width:35%">状态:';
	if ($myrow['zt'] == '1'){
		echo '<font color="red">暂停运行...</font><br/>';
	}else{
		echo '<font color="green">正在运行</font><br/>';
	}
	echo '运行次数:<font color="red">'.$myrow['times'].'</font><br>上次执行:<font color="blue">'.dgmdate($myrow['lasttime']).'</font>';

	echo '</td><td style="width:25%">';
	if($myrow['data'])
		echo '<a href="#" onclick="signjob_edit(\''.$type.'\',\''.$myrow['jobid'].'\',\''.$page.'\')" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;编辑</a><br/>';
	if ($myrow['zt'] == '1') {
		echo '<a href="#" onclick="job_edit(\'kq\','.$myrow['jobid'].',\'signjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-play"></i>&nbsp;开启</a>';
	}else{
		echo '<a href="#" onclick="job_edit(\'zt\','.$myrow['jobid'].',\'signjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-pause"></i>&nbsp;暂停</a>';
	}
	echo '<br/><a href="#" onclick="job_edit(\'del\','.$myrow['jobid'].',\'signjob\',\''.$page.'\')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp;删除</a></div></td></tr>';
}

?>
	</tbody>
</table>
</div>
<?php 
break;

case 'wztask':
$sysid=daddslashes($_GET['sysid']);
if(is_numeric($sysid))
	$sqls=" and sysid='{$sysid}'";
elseif(!empty($sysid))
	$sqls=" and `url` LIKE '%{$sysid}%'";
else
	$sqls=null;
$gls=$DB->count("SELECT count(*) from ".DBQZ."_wzjob WHERE uid='{$uid}'{$sqls}");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
<div class="panel panel-default table-responsive" id="list">
<table class="table table-hover">
	<thead>
		<tr>
			<th>任务名称/网址</th>
			<th>其他信息</th>
			<th>状态/操作</th>
		</tr>
	</thead>
	<tobdy>
<?php
$i=0;
$rs=$DB->query("SELECT * FROM ".DBQZ."_wzjob WHERE uid='$uid'{$sqls} order by jobid desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
	$i++;
	$pagesl = $i + ($page - 1) * $pagesize;

	echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$myrow['name'].'</b><br/><a href="'.$myrow['url'].'" target="_blank">'.$myrow['url'].'</a><br>';
	if(!empty($myrow['realip']))echo '{真实IP:'.$myrow['realip'].'}';
	if($myrow['usep']==1)echo '{代理IP}';
	if($myrow['post']==1)echo '{模拟POST}';
	if($myrow['cookie']!='')echo '{模拟Cookie}';
	if($myrow['referer']!='')echo '{模拟来源}';
	if($myrow['useragent']!='')echo '{模拟浏览器}';

	echo '</td><td style="width:35%">状态:';
	if ($myrow['zt'] == '1'){
		echo '<font color="red">暂停运行...</font><br/>';
	}else{
		echo '<font color="green">正在运行</font><br/>';
	}
	echo '运行次数:<font color="red">'.$myrow['times'].'</font><br>上次执行:<font color="blue">'.dgmdate($myrow['lasttime']).'</font><br/>运行时间:<font color="blue">';
	echo $myrow['start'].'时 - '.$myrow['stop'].'时</font>';
	if($myrow['pl']!=0)
		echo '<br>运行频率:<font color="red">'.$myrow['pl'].'</font>秒/次';

	echo '</td><td style="width:25%">';
	echo '<a href="#" onclick="wzjob_edit(\'edit\',\''.$myrow['jobid'].'\',\''.$myrow['sysid'].'\',\''.$page.'\')" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;编辑</a><br/>';
	if ($myrow['zt'] == '1') {
		echo '<a href="#" onclick="job_edit(\'kq\','.$myrow['jobid'].',\'wzjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-play"></i>&nbsp;开启</a>';
	}else{
		echo '<a href="#" onclick="job_edit(\'zt\','.$myrow['jobid'].',\'wzjob\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-pause"></i>&nbsp;暂停</a>';
	}
	echo '<br/><a href="#" onclick="job_edit(\'del\','.$myrow['jobid'].',\'wzjob\',\''.$page.'\')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp;删除</a></div></td></tr>';
}

?>
	</tbody>
</table>
</div>
<?php
break;

case 'qqlist':
if(isset($_GET['super']) && $isadmin==1) {
	if(isset($_GET['qq']))
		$gls=1;
	else
		$gls=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1");
} else
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE uid='{$uid}'");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>

<?php
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE uid='{$uid}'");
if($gls==0)
echo'<script>swal({   title: "请先添加QQ账号",   text: "本站功能将在添加QQ后开启",   type: "warning", showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "去添加",   closeOnConfirm: false }, function(){   addqq(\'login\') });</script>
<div class="sweet-overlay" tabindex="-1" style="opacity: 1.15; display: block;"></div>
<div class="sweet-alert showSweetAlert visible" data-custom-class="" data-has-cancel-button="true" data-has-confirm-button="true" data-allow-outside-click="false" data-has-done-function="true" data-animation="pop" data-timer="null" style="display: block; margin-top: -169px;"><div class="sa-icon sa-error" style="display: none;">
      <span class="sa-x-mark">
        <span class="sa-line sa-left"></span>
        <span class="sa-line sa-right"></span>
      </span>
    </div><div class="sa-icon sa-warning pulseWarning" style="display: block;">
      <span class="sa-body pulseWarningIns"></span>
      <span class="sa-dot pulseWarningIns"></span>
    </div><div class="sa-icon sa-info" style="display: none;"></div><div class="sa-icon sa-success" style="display: none;">
      <span class="sa-line sa-tip"></span>
      <span class="sa-line sa-long"></span>

      <div class="sa-placeholder"></div>
      <div class="sa-fix"></div>
    </div><div class="sa-icon sa-custom" style="display: none;"></div><h2>请先添加QQ账号</h2>
    <p style="display: block;">本站功能将在添加QQ后开启</p>
    <fieldset>
      <input type="text" tabindex="3" placeholder="">
      <div class="sa-input-error"></div>
    </fieldset><div class="sa-error-container">
      <div class="icon">!</div>
      <p>Not valid!</p>
    </div><div class="sa-button-container">
      <button class="cancel" tabindex="2" style="display: inline-block;">不了</button>
      <div class="sa-confirm-button-container">
        <button class="confirm" tabindex="1" style="display: inline-block; background-color: rgb(221, 107, 85);-shadow: rgba(221, 107, 85, 0.8) 0px 0px 2px, rgba(0, 0, 0, 0.0470588) 0px 0px 0px 1px inset;">去添加</button><div class="la-ball-fall">
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    </div></div>'
?>

<br>
<table class="table table-hover">
<?php
$i=0;
if(isset($_GET['super']) && $isadmin==1) {
	if($qq=daddslashes($_GET['qq']))
		$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' order by id desc limit $pageu,$pagesize");
	else
		$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE 1 order by id desc limit $pageu,$pagesize");
	$link.='&super=1';
} else
$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE uid='{$uid}' order by id desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
$i++;
$pagesl = $i + ($page - 1) * $pagesize;
  echo '<div class="col-sm-4 "><div class="widget"><div class="widget-content themed-background-flat text-center "><a href="index.php?mod=list-qq&qq='.$myrow['qq'].$link.'" title="进入任务管理"><img src="//q2.qlogo.cn/headimg_dl?bs=qq&dst_uin='.$myrow['qq'].'&src_uin='.$myrow['qq'].'&fid='.$myrow['qq'].'&spec=100&url_enc=0&referer=bu_interface&term_type=PC" class="img-circle img-thumbnail img-thumbnail-transparent img-thumbnail-avatar-2x" ></a><h2 class="widget-heading h3 text-light">'.$myrow['qq'].'</h2></div>
  <div class="widget-content themed-background-muted text-dark text-center">
  <p>QQ状态码:<span aria-hidden="true">&nbsp;
';if ($myrow['status'] == '1')
echo '<font color="green">正常使用</font>';
else
echo '<font color="red">请更新</font>';
echo'</p>';
echo'<p>SuperKey状态:<span aria-hidden="true">&nbsp;';
if ($myrow['status2'] == '1')
echo '<font color="green">正常使用</font>';
else
echo '<font color="red">请更新</font>';echo'</span></p>';
if($conf['vipmode']==1) {
	if($myrow['vip']==1){
		if(strtotime($myrow['vipdate'])>time()){
			$vipstatus='到期时间:<font color="green">'.$myrow['vipdate'].'</font>[<a href="index.php?mod=shop&act=1&qq='.$myrow['qq'].'">续期</a>]';
		}else{
			$vipstatus='<font color="red">已过期，请及时<a href="index.php?mod=shop&act=1&qq='.$myrow['qq'].$link.'">续费</a></font>';
		}
	}elseif($myrow['vip']==2){
		$vipstatus='<font color="green">永久 VIP</font>';
	}else{
		$vipstatus='<font color="red">已过期，请及时<a href="index.php?mod=shop&act=1&qq='.$myrow['qq'].'">续费</a></font>';
	}
	echo $vipstatus.'<br/>';
}
if(isset($_GET['super']) && $isadmin==1)echo '所属用户:<a href="index.php?mod=admin-user&my=user&uid='.$myrow['uid'].$link.'">ID '.$myrow['uid'].'</a>';
echo'</div>';

echo '
<div class="widget-content text-center">
<div class="btn-group">
<a href="index.php?mod=list-qq&qq='.$myrow['qq'].$link.'" class="btn btn-effect-ripple btn-default" style="overflow: hidden; position: relative;"><i class="fa fa-gears"></i> 功能配置</a>
<a href="#" onclick="addqq(\'update\',\''.$myrow['qq'].'\')" class="btn btn-effect-ripple btn-default" style="overflow: hidden; position: relative;"><i class="fa fa-refresh"></i> 更新密码</a>
</div>
<div class="btn-group">
<button href="#" onclick="addqq(\'del\',\''.$myrow['qq'].'\')" class="btn btn-effect-ripple btn-default" style="overflow: hidden; position: relative;"><i class="fa fa-times"></i> 删除账号</button>
<a href="index.php?mod=search&q='.$myrow['qq'].'" class="btn btn-effect-ripple btn-default" style="overflow: hidden; position: relative;" target="_blank"><i class="fa fa-check"></i>
秒赞认证</a>
</div>
</div>
</p>
</div>
';
?>
<?php
  echo '</td><td style="width:30%">';

echo '</td>';}

?>
</table>
</div>
<?php
break;

case 'damalist':
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE status2='4'");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
?>
<div class="panel panel-default table-responsive">
<table class="table table-hover">
	<thead>
		<tr>
			<th>QQ账号</th>
			<th>状态/操作</th>
		</tr>
	</thead>
	<tobdy>
<?php
$i=0;
$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE status='4' or status2='4' order by id desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
$i++;
$pagesl = $i + ($page - 1) * $pagesize;
  echo '<tr><td style="width:50%;"><img src="//q2.qlogo.cn/headimg_dl?bs=qq&dst_uin='.$myrow['qq'].'&src_uin='.$myrow['qq'].'&fid='.$myrow['qq'].'&spec=100&url_enc=0&referer=bu_interface&term_type=PC" class="qqlogo" width="80px"><label>'.$myrow['qq'].'</label>';
  echo '</td><td style="width:50%">';
if ($myrow['status'] == '1')
echo '<font color="green">SKEY 正常</font><br/><font color="green">P_skey 正常</font>';
else
echo '<font color="red">SKEY 已失效</font><br/><font color="red">P_skey 已失效</font>';
if ($myrow['status2'] == '1')
echo '<br/><font color="green">Superkey 正常</font>';
else
echo '<br/><font color="red">Superkey 已失效</font>';
echo '<br/><a href="#" onclick="addqq(\'dama\',\''.$myrow['qq'].'\')" title="协助打码" class="btn btn-success btn-sm">协助打码</a></td></tr>';
}

?>
	</tbody>
</table>
</div>
<?php
break;
}
$s = ceil($gls / $pagesize);
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$s;
echo '<div class=" text-center"><ul class="pagination ">';
if ($page>1)
{
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$first.')">首页</a></li>';
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$prev.')">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$i.')">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$s;$i++)
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$i.')">'.$i .'</a></li>';
echo '';
if ($page<$s)
{
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$next.')">&raquo;</a></li>';
echo '<li><a href="#" onclick="showlist(\''.$act.'\','.$last.')">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo '</ul></div>';

}else{
	showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}