<!-- Start: Header -->
    <div id="page-wrapper" class="page-loading">
        <div class="preloader">
            <div class="inner">
                <div class="preloader-spinner themed-background hidden-lt-ie10">
                </div>
                <h3 class="text-primary visible-lt-ie10">
                    <strong>Loading...</strong></h3>
            </div>
        </div>
        <div id="page-container" class="header-fixed-top sidebar-visible-lg-full enable-cookies">
<div id="sidebar-alt" tabindex="-1" aria-hidden="true">
<a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 888px;"><div id="sidebar-scroll-alt" style="overflow: hidden; width: auto; height: 888px;">
<div class="sidebar-content">
<div class="sidebar-section">
<style>
h4{font-family:"微软雅黑",Georgia,Serif;}
</style>
<h4 class="text-light">框架变色(New)</h4>
<br>
<ul class="sidebar-themes clearfix">
<li class="">
<a href="javascript:void(0)" class="themed-background-default" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/themes-2.2.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-default"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/classy-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-classy"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/social-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-social"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/flat-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-flat"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/amethyst-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-amethyst"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/creme-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-creme"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-passion" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/passion-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="">
<span class="section-side themed-background-dark-passion"></span>
<span class="section-content"></span>
</a>
<br>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/classy-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/social-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/flat-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/amethyst-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/creme-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-passion" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/passion-2.4.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="">
<span class="section-side"></span>
<span class="section-content"></span>
</a>
</li>

<li class="">
<a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/classy-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-classy"></span>
<span class="section-content"></span>
</a>
<br>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/social-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-social"></span>
<span class="section-content"></span>
</a>
</li>
<li>
<a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/flat-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-flat"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/amethyst-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-amethyst"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/creme-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-creme"></span>
<span class="section-content"></span>
</a>
</li>
<li class="">
<a href="javascript:void(0)" class="themed-background-passion" data-toggle="tooltip" title="" data-theme="<?php echo $cdnserver?>assets/appui/css/themes/passion-2.4.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="">
<span class="section-header"></span>
<span class="section-side themed-background-dark-passion"></span>
<span class="section-content"></span>
</a>
</li>
</ul>
</div>
</div>
</div><div class="slimScrollBar" style="background: rgb(187, 187, 187); width: 3px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 888px;"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 1; z-index: 90; right: 1px;"></div></div>
</div>
            <div id="sidebar">
                <div id="sidebar-brand" class="themed-background">
				<a href="./" class="sidebar-title">
                    <i class="fa fa-thumbs-up"></i> <span class="sidebar-nav-mini-hide"><?php echo $conf['sitename']?></span>
                </a>
				</div>
                <div id="sidebar-scroll">
                    <div class="sidebar-content">
                        <ul class="sidebar-nav">
                        <?php if($islogin==1) {?>
<li>
	<a id="yonghu" class="<?php echo checkIfActive("user") ?>" onclick="activeselect(this)" href="index.php?mod=user">
		<i class="fa fa-gittip sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">用户中心</span>
	</a>
</li>
<?php if($isadmin==1 || $isdeputy==1){?>
<li>
	<a id="houtai" class="<?php echo checkIfActive("admin") ?>" onclick="activeselect(this)" href="index.php?mod=admin">
		<i class="fa fa-wrench sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">后台管理</span>
	</a>
</li>
<?php } elseif($isdaili==1){?>
<li>
	<a id="houtai" class="<?php echo checkIfActive("admin-adili") ?>" onclick="activeselect(this)" href="index.php?mod=admin-daili">
		<i class="fa fa-wrench sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">代理后台</span>
	</a>
</li>
<?php }?>
<?php if(OPEN_QQOL==1){
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE uid='{$uid}'");
?>
<li class="<?php echo checkIfActive("list-qq") ?>">
<a  href="javascript:void(0)" id="other" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-qq sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">ＱＱ管理<?php echo $gls>0?'&nbsp;('.$gls.')':null?></span></a>
<ul>
<?php
$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE uid='{$uid}' order by id desc limit 6");
while($myrow = $DB->fetch($rs))
{
$i++;
$pagesl = $i + ($page - 1) * $pagesize;
echo '<li class="'.($_GET['qq']==$myrow['qq']?'active':null).'">
<a href="index.php?mod=list-qq&qq='.$myrow['qq'].$link.'" title="进入任务管理"><i class="fa fa-check"></i> '.$myrow['qq'].$link.'</a>
</li>';
}
if($gls>6)echo '<li>
<a href="index.php?mod=qqlist" title="更多QQ"><i class="fa fa-qq"></i> 更多QQ...</a>
</li>';
?>
</ul>
<li>
	<a id="qiandao" onclick="activeselect(this)" href="index.php?mod=qqlist&addqq=1">
		<i class="fa fa-plus sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">添加新QQ</span>
	</a>
</li>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("qqlist") ?>" onclick="activeselect(this)" href="index.php?mod=qqlist">
		<i class="fa fa-table sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">已添加列表</span>
	</a>
</li>
<?php }else{?>
<?php if(OPEN_SIGN==1){?>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("list-sign") ?>" onclick="activeselect(this)" href="index.php?mod=list-sign">
		<i class="fa fa-cloud sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">自动签到</span>
	</a>
</li>
<?php }?>
<?php if(OPEN_CRON==1){?>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("list-sign") ?>" onclick="activeselect(this)" href="<?php if($conf['server_wz']>1){?>index.php?mod=syslist<?php }else{?>index.php?mod=list-wz<?php }?>">
		<i class="fa fa-tasks sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">网址监控</span>
	</a>
</li>
<?php }?>
<?php }?>

<li class="sidebar-separator">
<i class="fa fa-ellipsis-h"></i>
</li>
<li>
	<a id="vip" class="<?php echo checkIfActive("shop") ?>" onclick="activeselect(this)" href="index.php?mod=shop">
		<i class="fa fa-shopping-cart sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">自助商城</span>
	</a>
</li>
<li>
<?php if(OPEN_CHAT==1){?>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("chat") ?>" onclick="activeselect(this)" href="index.php?mod=chat">
		<i class="fa fa-commenting sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">交友聊天</span>
	</a>
</li>
<?php }?>
<?php if(OPEN_QQOL==1){?>
<li>
	<a id="web" class="<?php echo checkIfActive("wall") ?>" onclick="activeselect(this)" href="index.php?mod=wall">
		<i class="fa fa-bookmark sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">Q秒赞墙</span>
	</a>
</li>
<?php }?>
<?php if(OPEN_QQOL==1 && (OPEN_SIGN==1 || OPEN_CRON==1)){?>
<li>
	<a href="javascript:void(0)" id="other" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-navicon sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">其他功能</span></a>
	<ul>
<?php if(OPEN_SIGN==1){?>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("list-sign") ?>" onclick="activeselect(this)" href="index.php?mod=list-sign">
		<i class="fa fa-cloud sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">自动签到</span>
	</a>
</li>
<?php }?>
<?php if(OPEN_CRON==1){?>
<li>
	<a id="qiandao" class="<?php echo checkIfActive("list-sign") ?>" onclick="activeselect(this)" href="<?php if($conf['server_wz']>1){?>index.php?mod=syslist<?php }else{?>index.php?mod=list-wz<?php }?>">
		<i class="fa fa-tasks sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">网址监控</span>
	</a>
</li>
<?php }?>
	</ul>
</li>
<?php }?>
<li >
<a id="qd" class="<?php echo checkIfActive("qd") ?>" onclick="activeselect(this)" href="index.php?mod=qd"><i class="fa fa-table sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">每日签到</span></a>
</li>
<li>
<a id="yq" class="<?php echo checkIfActive("invite") ?>" onclick="activeselect(this)" href="index.php?mod=invite"><i class="fa fa-user-plus sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">邀请好友</span></a>
</li>
<li>
<a id="bz" class="<?php echo checkIfActive("help") ?>" onclick="activeselect(this)" href="index.php?mod=help"><i class="fa fa-heart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">功能简介</span></a>
</li>
<?php }?>
<?php if($islogin==0) {?>
<li>
	<li>
		<a id="denglu" class="<?php echo checkIfActive("login") ?>" onclick="activeselect(this)" href="index.php?mod=login">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">登录</span>
		</a>
	</li>
</li>
<li>
	<li>
		<a id="zhuce" class="<?php echo checkIfActive("reg") ?>" onclick="activeselect(this)" href="index.php?mod=reg">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">注册</span>
		</a>
	</li>
</li>
<li>
	<li>
		<a id="zhaohui" class="<?php echo checkIfActive("findpwd") ?>" onclick="activeselect(this)" href="index.php?mod=findpwd">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">找回密码</span>
		</a>
	</li>
</li>
<?php }?>
                        </ul>
                    </div>
                </div>
                <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
<div class="progress progress-mini push-bit">
<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
</div>
<div class="text-center">
<small><span id="year-copy">2018</span> © <a href="#" target="_blank"><?php echo $conf['sitename']?></a></small>
</div>
</div>
            </div>
            <div id="main-container">
                <header class="navbar navbar-inverse navbar-fixed-top">
 
<ul class="nav navbar-nav-custom">
 
<li>
<a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');this.blur();">
<i class="fa fa-ellipsis-v fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
<i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>菜单
</a>
</li>
<li>
<a href="javascript:void(0)" onclick="javascript:history.go(-1);">
<i class="fa fa-reply fa-fw animation-fadeInRight"></i> 返回
</a>
</li>
 
</ul>
 
 
<ul class="nav navbar-nav-custom pull-right">
<li>
<a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar-alt');this.blur();">
<i class="fa fa-wrench sidebar-nav-icon"></i>
</a>
</li>
<li class="dropdown">
<a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
<img src="<?php echo ($row['qq'])?'//q2.qlogo.cn/headimg_dl?bs=qq&dst_uin='.$row['qq'].'&src_uin='.$row['qq'].'&fid='.$row['qq'].'&spec=100&url_enc=0&referer=bu_interface&term_type=PC':'assets/img/user.png'?>" alt="avatar">
</a>
<ul class="dropdown-menu dropdown-menu-right">
<li class="dropdown-header text-center">
<strong><?php echo $row['user']?></strong>
</li>
<?php if($islogin==1){?>
<li>
<a href="index.php?mod=userinfo">
<i class="fa fa-inbox fa-fw pull-right"></i>
个人资料
</a>
</li>
<li>
<a href="index.php?mod=set&my=mm">
<i class="fa fa-pencil-square fa-fw pull-right"></i>
密码修改
</a>
</li>
<li class="divider">
</li>
<?php if(OPEN_QQOL==1){?>
<li>
<li>
<a href="index.php?mod=qqlist">
<i class="fa fa-plus fa-fw pull-right"></i>
添加挂机
</a>
</li>
<li class="divider">
</li>
<?php }?>
<li>
<li>
<a href="index.php?my=loginout">
<i class="fa fa-power-off fa-fw pull-right"></i>
注销登录
</a>
</li>
<?php }?>
<?php if($islogin==0) {?>
<li>
<a href="index.php?mod=login">
<i class="fa fa-power-off fa-fw pull-right"></i>
马上登录
</a>
</li>
<li>
<a href="index.php?mod=reg">
<i class="fa fa-power-off fa-fw pull-right"></i>
马上注册
</a>
</li>
<?php }?>
</ul>
</li>
</ul>
</header>
<div id="page-content">
		<div id="myDiv"></div>
			<div class="main pjaxmain">
				<div class="content-header">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="header-section">
                                    <h1><?php echo $title ?></h1>
                                </div>
                            </div>
                        </div>
				</div>
<div class="row">
<?php unset($already);?>