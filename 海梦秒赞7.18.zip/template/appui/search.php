<?php
if(!defined('IN_CRONLITE'))exit();
$uin=is_numeric($_GET['q'])?$_GET['q']:'0';
@header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="charset" content="utf-8">
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $uin?>-秒赞认证-<?php echo $conf['sitename']?></title>
<meta name="keywords" content="离线CQY,<?php echo $uin?>,<?php echo $uin?>秒赞验证"/>
<meta name="description" content="<?php echo $config['web_name']?>"/>
<link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="//cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
<link rel="stylesheet" href="assets/css/rz.css" />
</head>
<?php
$result=$DB->query("select * from ".DBQZ."_qq where qq='$uin' and status='1' limit 1");
if($row = $DB->fetch($result)){
	$gtk=getGTK($row['pskey']);
	$url='http://mobile.qzone.qq.com/list?g_tk='.$gtk.'&res_attach=att%3D0&format=json&list_type=shuoshuo&action=0&res_uin='.$row['qq'].'&count=5';
	$cookie='uin=o0'.$row['qq'].'; skey='.$row['skey'].'; p_skey='.$row['pskey'].'; p_uin=o0'.$row['qq'].';';
	$json=get_curl($url,0,'http://mobile.qzone.qq.com/infocenter?g_ut=3&g_f=6676',$cookie);
	$arr=json_decode($json,true);
	$zan=0;
	if($arr=$arr['data']['vFeeds']){
		foreach($arr as $new){
			if($new['like']['num']>$zan) $zan=$new['like']['num'];
		}
	}
?>
	<body class="is-loading">
			<div id="wrapper">
					<section id="main">				
						<header>
						<img src="assets/img/rz.png" style="margin-bottom:10px;">
							<span class="avatar"><img src="//q1.qlogo.cn/g?b=qq&nk=<?php echo $uin?>&s=100&t=<?php echo date("Ymd")?>" title="【QQ：<?php echo $uin?>】已获得<?php echo $conf['sitename']?>权威认证"></span>
							<h1><?php echo get_qqnick($uin);?></h1>
						<p>
								QQ：[<?php echo $uin?>]，已开启<a><?php echo $conf['sitename']?></a>秒赞服务，请放心添加为好友！
						</p>					
						</header>
						<footer>
							<ul class="icons">
							    <li><a href="http://user.qzone.qq.com/<?php echo $uin?>" target="_blank" class="fa fa-star-o bg-darkorange" title="访问空间"></a></li>
							    <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $uin?>&site=qq&menu=yes" target="_blank" class="fa fa-commenting-o" title="点击聊天"></a></li>
								<li><a href="index.php?mod=wall&do=add&qq=<?php echo $uin?>" target="_blank" class="fa fa-qq" title="添加好友"></a></li>								</a></li>
							</ul>
						</footer>
						<hr>
<form action="index.php" method="get" >
<input type="hidden" name="mod" value="search">
<input type="text" name="q" onkeyup="value=value.replace(/[^1234567890-]+/g,'')" placeholder="输入要查询的QQ号码" class="form-control">  
<br>
<p style="text-align:center;">
<button type="submit" class="p-btn" align="center" style="width:100%;">秒赞认证查询</button>
</p>
</form>
					</section>
					<footer id="footer">
						<ul class="copyright">
							<li> ©2018 <a href="#" id="foot_a"><?php echo $conf['sitename']?></a>
							</li>
						</ul>
					</footer>

			</div>
						<script>
				if ('addEventListener' in window) {
					window.addEventListener('load', function() { document.body.className = document.body.className.replace(/\bis-loading\b/, ''); });
					document.body.className += (navigator.userAgent.match(/(MSIE|rv:11\.0)/) ? ' is-ie' : '');
				}
			</script>
			<script type="text/javascript" src="http://clouds.odata.cc/static/jquery.easy-ticker.js?r=<?php echo rand()?>"></script>
			</body>
<?php
}else{
?>
<body class="is-loading">
			<div id="wrapper">
					<section id="main">				
						<header>
						<img src="assets/img/rz.png" style="margin-bottom:10px;">
							<span class="avatar"><img src="//q1.qlogo.cn/g?b=qq&nk=<?php echo $uin?>&s=100&t=<?php echo date("Ymd")?>" title="【QQ：<?php echo $uin?>】已获得<?php echo $conf['sitename']?>权威认证"></span>
							<h1><?php echo get_qqnick($uin);?></h1>
						<p>
								QQ：[<?php echo $uin?>]，未开启<a><?php echo $conf['sitename']?></a>秒赞服务</font></strong>
						</p>					
						</header>
						<footer>
							<ul class="icons">
							    <li>

								<a href="http://user.qzone.qq.com/<?php echo $uin?>" target="_blank" class="fa fa-star-o bg-darkorange" title="访问空间"></a></li>
							    <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $uin?>&site=qq&menu=yes" target="_blank" class="fa fa-commenting-o" title="点击聊天"></a></li>
								<li><a href="index.php?mod=wall&do=add&qq=<?php echo $uin?>" target="_blank" class="fa fa-qq" title="添加好友"></a></li>
							</ul>
						</footer>
						<hr>
<form action="index.php" method="get" >
<input type="hidden" name="mod" value="search">
<input type="text" name="q" onkeyup="value=value.replace(/[^1234567890-]+/g,'')" placeholder="输入要查询的QQ号码" class="form-control">  
<br>
<p style="text-align:center;">
<button type="submit" class="p-btn" align="center" style="width:100%;">秒赞认证查询</button>
</p>
</form>
					</section>
					<footer id="footer">
						<ul class="copyright">
							<li> ©2018 <a href="#" id="foot_a"><?php echo $conf['sitename']?></a>
							</li>
						</ul>
					</footer>

			</div>
						<script>
				if ('addEventListener' in window) {
					window.addEventListener('load', function() { document.body.className = document.body.className.replace(/\bis-loading\b/, ''); });
					document.body.className += (navigator.userAgent.match(/(MSIE|rv:11\.0)/) ? ' is-ie' : '');
				}
			</script>
			</body>
<?php
}
?>
</html>