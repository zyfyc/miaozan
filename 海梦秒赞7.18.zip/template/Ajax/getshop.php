<?php
if(!defined('IN_CRONLITE'))exit();
if($islogin==1)
{
	$type=isset($_GET['type'])?daddslashes($_GET['type']):exit('No paytype!');
	$orderid=isset($_GET['trade_no'])?daddslashes($_GET['trade_no']):exit('No trade_no!');

	$row=$DB->get_row("SELECT * FROM ".DBQZ."_pay WHERE orderid='{$orderid}' limit 1");
	if($row['status']==1){
		exit('{"code":1,"msg":"付款成功","backurl":"index.php?mod=shop"}');
	}else{
		exit('{"code":-1,"msg":"未付款"}');
	}
}else{
	exit('{"code":-3,"msg":"登录失败，可能是密码错误或者身份失效了，请重新登录！"}');
}