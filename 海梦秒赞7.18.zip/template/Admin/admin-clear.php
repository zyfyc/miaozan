<?php
 /*
　*　后台清空数据文件
*/
if(!defined('IN_CRONLITE'))exit();
$title="后台管理";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-refresh"></i>数据清理</a></li>';
include TEMPLATE_ROOT."head.php";

$my=isset($_POST['my'])?$_POST['my']:$_GET['my'];
echo '<div class="col-lg-8 col-sm-10 col-xs-12 center-block" role="main">';

if ($isadmin==1)
{
echo '<div class="panel panel-primary">';
if($my == 'sysall'){
echo '<div class="panel-heading"><h3 class="panel-title">清空系统所有数据</h3></div><div class="panel-body">';
echo '<font color="#FF0033">警告：此项操作将清空本站所有数据，包括用户数据和任务数据，且不可恢复！</font><br><br>
如果你确定要继续执行清空操作，请在下方输入“ok”并点击确定：<form action="index.php" method="GET"><input type="hidden" name="mod" value="admin-clear"><input type="hidden" name="my" value="sysall_ok">
<input type="text" class="form-control" name="key" value="" maxlength="10"><br/><input type="submit" class="btn btn-primary btn-block"
value="确定清空！"></form>';
echo '</div>';
}

/*elseif($my == 'sysall_ok' && $_GET['key']=='ok'){
$sql="TRUNCATE TABLE `".DBQZ."_user`;
TRUNCATE TABLE `".DBQZ."_job`;
TRUNCATE TABLE `".DBQZ."_qq`";
$sql=explode(';',$sql);
$t=0;$e=0;
for($i=0;$i<count($sql);$i++) {
if($DB->query($sql[$i]))
++$t;
else
++$e;
}
$DB->query("insert into `".DBQZ."_user` (`pass`,`user`,`date`,`last`) values ('".$row['pass']."','".$row['user']."','".$date."','".$date."')");
echo '<div class="panel-body"><font color="green">已清空系统所有数据！</font><br/>（SQL成功执行'.$t.'句）<br></div>';
}*/

elseif($my == 'chat'){
echo '<div class="panel-heading"><h3 class="panel-title">清空所有聊天记录</h3></div><div class="panel-body">';
echo '<font color="#FF0033">警告：此项操作将清空本站聊天室所有聊天记录，且不可恢复！</font><br><br>
如果你确定要继续执行清空操作，请在下方输入“ok”并点击确定：<form action="index.php" method="GET"><input type="hidden" name="mod" value="admin-clear"><input type="hidden" name="my" value="chat_ok">
<input type="text" class="form-control" name="key" value="" maxlength="10"><br/><input type="submit" class="btn btn-primary btn-block"
value="确定清空！"></form>';
echo '</div>';
}

elseif($my == 'chat_ok' && $_GET['key']=='ok'){
$sql="TRUNCATE TABLE `".DBQZ."_chat`";
if($DB->query($sql))
echo '<div class="panel-body"><font color="green">已清空所有聊天数据！</font></div>';
else echo '<div class="panel-body"><font color="red">清空失败！</font>'.$DB->error().'</div>';
}

elseif($my == 'jobs'){
echo '<div class="panel-heading"><h3 class="panel-title">清空全部挂机任务</h3></div><div class="panel-body">';
echo '<font color="#FF0033">警告：此项操作将清空本站全部挂机任务，且不可恢复！</font><br><br>
如果你确定要继续执行清空操作，请在下方输入“ok”并点击确定：<form action="index.php" method="GET"><input type="hidden" name="mod" value="admin-clear"><input type="hidden" name="my" value="jobs_ok">
<input type="text" class="form-control" name="key" value="" maxlength="10"><br/><input type="submit" class="btn btn-primary btn-block"
value="确定清空！"></form>';
echo '</div>';
}

/*elseif($my == 'jobs_ok' && $_GET['key']=='ok'){
$sql="TRUNCATE TABLE `".DBQZ."_job`";
if($DB->query($sql))
echo '<div class="panel-body"><font color="green">已清空全部挂机任务！</font></div>';
else echo '<div class="panel-body"><font color="red">清空失败！</font>'.$DB->error().'</div>';
}*/

elseif($my == 'users'){
echo '<div class="panel-heading"><h3 class="panel-title">清空无挂机用户</h3></div><div class="panel-body">';
echo '<font color="#FF0033">警告：此项操作将清空本站没有任何挂机的用户，且不可恢复！</font><br><br>
如果你确定要继续执行清空操作，请在下方输入“ok”并点击确定：<form action="index.php" method="GET"><input type="hidden" name="mod" value="admin-clear"><input type="hidden" name="my" value="users_ok">
<input type="text" class="form-control" name="key" value="" maxlength="10"><br/><input type="submit" class="btn btn-primary btn-block"
value="确定清空！"></form>';
echo '</div>';
}

elseif($my == 'users_ok' && $_GET['key']=='ok'){
$sql="DELETE FROM ".DBQZ."_user WHERE qqnum='0' and userid!='1'";
if($DB->query($sql))
echo '<div class="panel-body"><font color="green">已清空无挂机用户！</font></div>';
else echo '<div class="panel-body"><font color="red">清空失败！</font>'.$DB->error().'</div>';
}

elseif($my == 'qlrw'){
echo '<div class="panel-heading"><h3 class="panel-title">删除指定任务</h3></div><div class="panel-body">';
echo '您确认要删除所有包含'.$_GET['kw'].'的任务吗？清空后无法恢复！<br><a href="index.php?mod=admin-clear&my=qlrw_ok&table='.$_GET['table'].'&kw='.urlencode($_GET['kw']).'">确认</a> | <a href="javascript:history.back();">返回</a>';
echo '</div>';
}

elseif($my == 'qlrw_ok'){
$sql="delete from `".DBQZ."_{$_GET['table']}` where `url` LIKE '%{$_GET['kw']}%'";
if($DB->query($sql))
echo '<div class="panel-body"><font color="green">已删除所有包含'.$_GET['kw'].'的任务！</font></div>';
else echo '<div class="panel-body"><font color="red">删除失败！</font>'.$DB->error().'</div>';
}

elseif($my == 'qlqq'){
echo '<div class="panel-heading"><h3 class="panel-title">清理SID过期QQ</h3></div><div class="panel-body">';
echo '您确认要清理所有SID过期QQ吗？清空后无法恢复！<br><a href="index.php?mod=admin-clear&my=qlqq_ok">确认</a> | <a href="javascript:history.back();">返回</a>';
echo '</div>';
}

elseif($my == 'qlqq_ok'){
$rs=$DB->query("select * from `".DBQZ."_qq` where status='5' limit 100");
$i=0;
while($row=$DB->fetch($rs)){
	$DB->query("delete from `".DBQZ."_qqjob` where `qq`='{$row['qq']}' limit 1");
	$DB->query("delete from `".DBQZ."_qq` where `id`='{$row['id']}' limit 1");
	$i++;
}
echo '<div class="panel-body"><font color="green">已清理 '.$i.' 个状态过期的QQ！</font><br/>(请<a href="index.php?mod=admin-clear&my=qlqq_ok">刷新</a>此页面，直到显示已清理0个QQ即为清理完成)</div>';
}

elseif($my == 'qlzt'){
echo '<div class="panel-heading"><h3 class="panel-title">清理已暂停的任务</h3></div><div class="panel-body">';
echo '您确认要清理所有已暂停的任务吗？清空后无法恢复！<br><a href="index.php?mod=admin-clear&my=qlzt_ok">确认</a> | <a href="javascript:history.back();">返回</a>';
echo '</div>';
}

elseif($my == 'qlzt_ok'){
$sql="delete from `".DBQZ."_qqjob` where `zt`='1'";
$sql2="delete from `".DBQZ."_signjob` where `zt`='1'";
$sql3="delete from `".DBQZ."_wzjob` where `zt`='1'";
if($DB->query($sql)&&$DB->query($sql2)&&$DB->query($sql3))
echo '<div class="panel-body"><font color="green">已清理所有已暂停的任务！</font></div>';
else echo '<div class="panel-body"><font color="red">删除失败！</font>'.$DB->error().'</div>';
}

elseif($my == 'cache'){
if($CACHE->clear())
echo '<div class="panel-body"><font color="green">已成功清空缓存！</font></div>';
else echo '<div class="panel-body"><font color="red">清空失败！</font>'.$DB->error().'</div>';
}

elseif($my == 'optim'){
$rs=$DB->query("SHOW TABLES FROM `".$dbconfig['dbname'].'`');
while ($row = $DB->fetch($rs)) {
	$DB->query('OPTIMIZE TABLE  `'.$dbconfig['dbname'].'`.`'.$row[0].'`');
}
echo '<div class="panel-body"><font color="green">已成功优化所有数据表！</font></div>';
}

elseif($my == 'repair'){
$rs=$DB->query("SHOW TABLES FROM `".$dbconfig['dbname'].'`');
while ($row = $DB->fetch($rs)) {
	$DB->query('REPAIR TABLE  `'.$dbconfig['dbname'].'`.`'.$row[0].'`');
}
echo '<div class="panel-body"><font color="green">已成功修复所有数据表！</font></div>';
}

echo '</div>';
}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>