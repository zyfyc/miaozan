<?php
/**
 * 核心功能库
 */
 
//获取数组的数据 By ez_sql
function TFYT_Data($name = null, $value = null, $default = null){
	static $_config = array();
	// 无参数时获取所有
	if (empty($name)) {
		return $_config;
	}
	// 优先执行设置获取或赋值
	if (is_string($name)) {
		if (!strpos($name, '.')) {
			$name = strtoupper($name);
			if (is_null($value)) return isset($_config[$name]) ? $_config[$name] : $default;
			$_config[$name] = $value;
			return null;
		}
		// 二维数组设置和获取支持
		$name = explode('.', $name);
		$name[0] = strtoupper($name[0]);
		if (is_null($value)) return isset($_config[$name[0]][$name[1]]) ? $_config[$name[0]][$name[1]] : $default;
		$_config[$name[0]][$name[1]] = $value;
		return null;
	}
	// 批量设置
	if (is_array($name)) {
		$_config = array_merge($_config, array_change_key_case($name, CASE_UPPER));
		return null;
	}
	return null; // 避免非法参数
}

//生成随机字符串
function get_randstr($len = 12) {
	$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	$strlen = strlen($str);
	$randstr = '';
	for ($i = 0;$i < $len;$i++) {
		$randstr.= $str[mt_rand(0, $strlen - 1) ];
	}
	return $randstr;
	//获取12位随机数据
}

//过滤危险字符
function safestr($str) {
	if (!get_magic_quotes_gpc()) {
		return addslashes($str);
	} else {
		return $str;
	}
}

//计算数量
function get_count($table, $where = '1=1', $key = '*') {
	global $db;
	$mysql = (require "database.php");
	$dbhost = $mysql['DB_HOST'] . ':' . $mysql['DB_PORT'];
	$dbuser = $mysql['DB_USER'];
	$dbpassword = $mysql['DB_PWD'];
	$dbmysql = $mysql['DB_NAME'];
	$dbprefix = $mysql['DB_PREFIX'];
	if ($con = mysql_connect($dbhost, $dbuser, $dbpassword)) {
		mysql_select_db($dbmysql, $con);
	} else {
		exit('数据库链接失败！');
	}
	mysql_query("set names utf8");
	$row = $db->get_row("select count({$key}) as count from {$dbprefix}{$table} where {$where}");
	$count = $row['count'];
	return $count;
	//计数
}

//QQ登录
function login_sig(){
	$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=手机QQ空间&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
	$ret = get_curl($url,0,1,0,1);
	preg_match('/pt_login_sig=(.*?);/',$ret,$match);
	return $match[1];
}

//计算g_tk
function get_gtk($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0;$i < $len;$i++) {
		$hash+= ($hash << 5) + ord($skey[$i]);
	}
	return $hash & 0x7fffffff;
}

//QQ状态
function qq_zt($qq_state){
	if($qq_state==0){
		return '<font color="green">正常</font>';
	}else{
		return '<font color="red">已被封禁</font>';
	}
}

//查询Q币
function get_qb($uin,$skey){
	$url = file_get_contents('https://api.xuwenhui.xin/api/qq_money?C_U='.$uin.'&C_K='.$skey.'');
	$json = json_decode($url, true);
	if($json['code']=="ok"){
		return $json['qb'];
	}else{
		return "skey失效";
	}
}

//查询QQ积分
function get_jf($uin,$skey){
	$url = file_get_contents('https://api.xuwenhui.xin/api/qq_money?C_U='.$uin.'&C_K='.$skey.'');
	$json = json_decode($url, true);
	if($json['code']=="ok"){
		return $json['jf'];
	}else{
		return "skey失效";
	}
}

//查询QQ好友数量
function get_qqyou($uin,$skey){
	$url = file_get_contents('https://api.xuwenhui.xin/api/qq_all_friends?C_U='.$uin.'&C_K='.$skey.'');
	$arr_1 = strstr($url, '",gnum:"',TRUE);//屏蔽后面的字符串
	$arr_2 = strstr($arr_1, '",num:"');//频闭之前的字符串
	$str = str_replace('",num:"','',$arr_2);//替换字符串
	if(is_numeric($str)){
		return $str.' 个';//返回数量
	}else{
		return "skey失效";
	}
}

//查询QQ好友分组数量
function get_qqyoufz($uin,$skey){
	$url = file_get_contents('https://api.xuwenhui.xin/api/qq_all_friends?C_U='.$uin.'&C_K='.$skey.'');
	$arr_1 = strstr($url, '",group:',TRUE);//屏蔽后面的字符串
	$arr_2 = strstr($arr_1, '",gnum:"');//频闭之前的字符串
	$str = str_replace('",gnum:"','',$arr_2);//替换字符串
	if(is_numeric($str)){
		return $str.' 个';//返回数量
	}else{
		return "skey失效";
	}
}

//获取所在地
function ip_cip($ip){
	$url = file_get_contents('http://ip.taobao.com/service/getIpInfo.php?ip='.$ip.'');
	return $url;
}

//获取站点运行天数
function site_time($time){
	$Date_1 = date("Y-m-d");
	$Date_2 = $time;
	$d1 = strtotime($Date_1);
	$d2 = strtotime($Date_2);
	$Days = round(($d2-$d1)/3600/24);
	return $Days;
}