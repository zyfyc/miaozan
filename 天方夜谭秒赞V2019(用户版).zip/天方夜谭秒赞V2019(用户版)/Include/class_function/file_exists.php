<?php
/**
 * TFYT框架目录
 * 检测框架是否完整
 */

//判断程序是否安装
if(!file_exists(dirname(__FILE__) . '/database.php')){
	@header("Location:/Application/Install");
	exit;
}