<?php
/**
 * 天方夜谭秒赞
 * 作者：天方夜谭
 * 版本：V2019
 */
//关闭报错
//@error_reporting(E_ALL & ~E_NOTICE);

//设置时区
@date_default_timezone_set("PRC");

//设置编码
@header("Content-type: text/html; charset=utf-8");

//检测PHP版本
if(version_compare(PHP_VERSION, '5.3.0', '<')){
	die('require PHP > 5.3.0 !');
}

//加载WEB安全防护类
require_once('class_function/360_safe3.php');

//部署TFYT框架
include_once "class_function/file_exists.php";

//加载数据库操作类
include_once "class_ezmysql/ez_sql_core.php";
include_once "class_ezmysql/ez_sql_mysql.php";
$mysql = (require "class_function/database.php");

//加载核心功能库
include_once "class_function/function.php";

//实例化数据库操作类
TFYT_data($mysql);
$db = new ezSQL_mysql(TFYT_Data('DB_USER'),TFYT_Data('DB_PWD'),TFYT_Data('DB_NAME'),TFYT_Data('DB_HOST').':'.TFYT_Data('DB_PORT'));
$mysql = TFYT_Data('DB_PREFIX');

//网站初始化
if ($rows = $db->get_results("select * from {$mysql}website")){
	foreach ($rows as $value) {
		$website[$value['vkey']] = $value['value'];
	}
	TFYT_Data($website);
}

//用户状态
$cookiesid = $_COOKIE['tfyt_sid'];
if ($cookiesid && ($userrow = $db->get_row("select * from {$mysql}user where sid ='".$cookiesid."' limit 1"))) {
	TFYT_Data('login_state', $userrow['user']);
	TFYT_Data('login_state', $userrow['uid']);
}

//核心文件编写完毕！
?>