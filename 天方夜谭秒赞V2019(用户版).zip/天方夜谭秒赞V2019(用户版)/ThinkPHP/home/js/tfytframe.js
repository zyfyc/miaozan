//引入angular插件
document.write('<script src="http://cdn.static.runoob.com/libs/angular.js/1.4.6/angular.min.js"></script>');

//引入TFYT框架
document.write('<script type="text/javascript" src="/Application/Home/index.php"></script>');

//用户登录URL
var user_login_url = "/Application/Home/login.php";

//用户注册URL
var user_reg_url = "/Application/Home/reg.php";

//找回密码URL
var user_drop_url = "/Application/Home/drop.php";