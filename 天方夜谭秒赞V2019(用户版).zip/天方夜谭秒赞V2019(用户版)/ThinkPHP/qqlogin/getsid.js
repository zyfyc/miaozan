/**
 * By 天方夜谭
 * QQ 17404785
 */

//定义全局变量
function variable(){
	load = '<img src="https://ui.ptlogin2.qq.com/style/0/images/load.gif">';
}
variable();

//去除特殊字符
function trim(str){
	return str.replace(/(^\s*)|(\s*$)/g, "");
}

//开始处理业务
$(document).ready(function(){
	$('#submit').click(function(){
		var self=$(this);
		var uin = trim($('[name="uin"]').val());
		var pwd = trim($('[name="pwd"]').val());
		$('.msg').show();
		$('.msg').html(''+load+' 正在处理，请稍等...');
		if(uin == ""){
			$('.msg').html('请输入QQ账号！');
			return false;
		}else if(pwd == ""){
			$('.msg').html('请输入QQ密码！');
			return false;
		}else{
			if(self.attr('do') == 'code'){
				var vcode=trim($('#code').val()),
					vc=$('#codeimg').attr('vc');
				dovc(uin,vcode,vc);
			}else{
			if (self.attr("data-lock") === "true") return;
				else self.attr("data-lock", "true");
				checkvc();
				self.attr("data-lock", "false");
			}
		}
	});
});

//正在处理
function checkvc(){
	var uin=trim($('[name="uin"]').val());
	var pwd=trim($('[name="pwd"]').val());
	$('.msg').html(''+load+' 正在登录中，请稍候...');
	var getvcurl=""+domain+"login.php?do=checkvc";
	xiha.postData(getvcurl,'uin='+uin+'&r='+Math.random(1), function(d) {
		if(d.saveOK ==0){
			login(uin,pwd,d.vcode,d.pt_verifysession);
		}else if(d.saveOK ==1){
			$('[name="uin"]').attr('cap_cd',d.sig);
			getvc(uin,d.sig,0);
		}else{
			$('.msg').html(d.msg);
		}
	});
}

//获取验证码
function getvc(uin,sig,sess){
	$('.msg').html(''+load+' 正在获取验证码，请稍等...');
	sess = sess||0;
	var getvcurl=""+domain+"login.php?do=getvc";
	xiha.postData(getvcurl,'uin='+uin+'&sig='+sig+'&sess='+sess+'&r='+Math.random(1), function(d) {
		if(d.saveOK ==0){
			$('.msg').html('请输入验证码');
			$('#codeimg').attr('vc',d.vc);
			$('#codeimg').attr('sess',d.sess);
			$('#codeimg').html('<img onclick="getvc(\''+uin+'\',\''+d.vc+'\',\''+d.sess+'\')" src="'+''+domain+'login.php?do=getvcpic&uin='+uin+'&cap_cd='+sig+'&sig='+d.vc+'&sess='+d.sess+'&r='+Math.random(1)+'" title="点击刷新">');
			$('#submit').attr('do','code');
			$('#code').val('');
			$('.code').show();
		}else if(d.saveOK ==2){
			$('#codeimg').attr('vc',d.vc);
			$('#codeimg').attr('sess',d.sess);
			$('#codeimg').attr('cdata',d.cdata);
			if(typeof d.websig != "undefined"){
				$('#codeimg').attr('collectname',d.collectname);
				$('#codeimg').attr('websig',d.websig);
			}
			dovc(uin,d.ans,d.vc);
		}else{
			alert(d.msg);
		}
	});
}

//验证验证码
function dovc(uin,code,vc){
	$('.msg').html(''+load+' 正在验证验证码，请稍等...');
	var cap_cd=$('[name="uin"]').attr('cap_cd');
	var sess=$('#codeimg').attr('sess');
	var getvcurl=""+domain+"login.php?do=dovc";
	xiha.postData(getvcurl,'uin='+uin+'&ans='+code+'&sig='+vc+'&cap_cd='+cap_cd+'&sess='+sess+'&r='+Math.random(1), function(d) {
		if(d.rcode == 0){
			var pwd=$('[name="pwd"]').val();
			login(uin,pwd,d.randstr.toUpperCase(),d.sig);
		}else if(d.rcode == 50){
			$('.msg').html('验证码错误，重新生成验证码，请稍等...');
			getvc(uin,cap_cd,sess);
		}else{
			$('.msg').html('验证失败，请重试。');
			getvc(uin,cap_cd,sess);
		}
	});
}

//处理业务
function login(uin,pwd,vcode,pt_verifysession){
	$('.msg').html(''+load+' 正在登录，请稍等...');
	var loginurl=""+domain+"login.php?do=qqlogin";
	var p=getmd5(uin,pwd,vcode);
	xiha.postData(loginurl,"uin="+uin+"&pwd="+pwd+"&p="+p+"&vcode="+vcode+"&pt_verifysession="+pt_verifysession+"&r="+Math.random(1), function(d) {
		if(d.saveOK ==0){
			$('.msg').html(''+load+' QQ已成功登录，正在保存...');
			xiha.postData("/Application/Users/ajax.php","ajax=qqlogin&nick="+d.nick+"&uin="+uin+"&pwd="+pwd+"&sid="+d.sid+"&skey="+d.skey+"&p_skey="+d.pskey+"&superkey="+d.superkey+"", function(out) {
				if(out.code==1) {
					alert(out.msg);
					window.location.href="/Application/Users/qqlist.php";
				}else{
					//alert(out.msg);
					$('.msg').html(out.msg);
				}
			});
		}else if(d.saveOK ==4){
			$('.msg').html('验证码错误，请重新登录。');
			$('#submit').attr('do','submit');
			$('.code').hide();
			$('#code').val("");
		}else if(d.saveOK ==3){
			$('.msg').html('您输入的帐号或密码不正确，请重新输入密码！');
			$('#submit').attr('do','submit');
			$('[name="pwd"]').val('');
			$('.code').hide();
		}else if(d.msg =='pwd不能为空'){
			$('.msg').html('请输入密码！');
			$('#submit').attr('do','submit');
			$('.code').hide();
		}else{
			$('.msg').html(d.msg);
			$('#submit').attr('do','submit');
		}
	});
}

//异步提交
var xiha={
	postData: function(url, parameter, callback, dataType, ajaxType) {
		if(!dataType) dataType='json';
		$.ajax({
			type: "POST",
			url: url,
			async: true,
			dataType: dataType,
			json: "callback",
			data: parameter,
			success: function(data) {
				if (callback == null) {
					return;
				} 
				callback(data);
			},
			error: function(error) {
				alert('创建连接失败');
			}
		});
	}
}