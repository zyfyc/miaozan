<?php
/**
 * 天方夜谭
 */
//加载核心文件
require_once('../../Include/common.php');

//用户注册
if($_POST['reg']=='ok'){
	session_start();
	header('Content-Type:application/json');
	$name = safestr($_POST['name']);
	$user = safestr($_POST['user']);
	$qq = safestr($_POST['qq']);
	$pwd = safestr($_POST['pwd']);
	$code = safestr($_POST['code']);
	$sid=md5(get_randstr(4).uniqid().rand(1,1000));
	$time = date("Y-m-d h:i:s");
	if($name=="" || $user=="" || $qq=="" || $pwd=="" || $code==""){
		$output = array('msg' => '所有项不能为空！');
	}else if(strlen($user) < 5){
		$output = array('msg' => '用户名太短！');
	}elseif(strlen($user) > 10){
		$output = array('msg' => '用户名不能太长！');
	}else if(strlen($qq) < 5){
		$output = array('msg' => '没有小于5位数的QQ！');
	}elseif(strlen($qq) > 11){
		$output = array('msg' => 'QQ号没有11位以上的！');
	}else if(strlen($pwd) < 5){
		$output = array('msg' => '密码太短！');
	}else if(strlen($pwd) > 18){
		$output = array('msg' => '密码不能太长！');
	}else if(!$code || strtolower($_SESSION['tfyt_code'])!=strtolower($code)){
		$output = array('msg' => '验证码错误！');
	}else if($row_user = $db->get_row("select uid from {$mysql}user where user='{$user}' limit 1")){
		$output = array('msg' => '该用户名已被其他用户注册，换一个吧！');
	}else if($db->get_row("select user from {$mysql}user where qq='{$qq}' limit 1")){
		$output = array('msg' => '此QQ号已被'.$row_user['user'].'该用户注册，换一个吧！');
	}else{
		$_SESSION['tfyt_code'] =md5(rand(100,500).time());
		$pwd=md5(md5($pwd).md5('17404785'));
		if($db->query("insert into {$mysql}user (name,user,pwd,sid,qq,regtime,lasttime)values('$name','$user','$pwd','$sid','$qq','$time','0000-00-00')")){
			$output = array('msg' => '注册成功！您的账号为：'.$user.'');
		}else{
			$output = array('msg' => '注册失败！服务器内部错误');
		}
	}
	echo json_encode($output);
}