<?php
/**
 * 天方夜谭
 */
//加载核心文件
require_once('../../Include/common.php');
?>
var domain = 'http://host806129909.s348.pppf.com.cn/api/getsid/';
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
	$scope.name = '<?=TFYT_Data('name')?>';
});