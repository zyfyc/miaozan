<?php
/**
 * 天方夜谭
 */
//加载核心文件
require_once('../../Include/common.php');

//用户登录
if($_POST['login']=='ok'){
	header('Content-Type:application/json');
	$user = safestr($_POST['user']);
	$pwd = safestr($_POST['pwd']);
	$sid=md5(get_randstr(4).uniqid().rand(1,1000));
	$time = date("Y-m-d h:i:s");
	if($user==""){
		$output = array('msg' => '账号不能为空！');
	}else if($pwd==""){
		$output = array('msg' => '密码不能为空！');
	}else if($db->get_row("select active from {$mysql}user where user='{$user}' limit 1")==1){
		$output = array('msg' => '您的账号已被停用！无法登录');
	}else{
		$pwd=md5(md5($pwd).md5('17404785'));
		if($row=$db->get_row("select uid,name from {$mysql}user where user='{$user}' and pwd='{$pwd}' limit 1")){
			$db->query("update {$mysql}user set sid='{$sid}',lasttime='{$time}' where uid='{$row['uid']}'");
			setcookie("tfyt_sid",$sid,time()+3600*24*14,'/');
			$output = array('msg' => '登录成功，尊敬的'.$row['name'].'欢迎您回来！');
		}else{
			$output = array('msg' => '登录失败，账号或密码错误！');
		}
	}
	echo json_encode($output);
}