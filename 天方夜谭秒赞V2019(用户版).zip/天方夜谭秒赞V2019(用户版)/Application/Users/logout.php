<?php
require_once ('conn.php');
$newsid = md5(uniqid() . rand(1, 1000));
$db->query("update {$mysql}user set sid='$newsid' where uid='{$userrow['uid']}'");
setcookie("tfyt_sid", "", -1, '/');
@header("Location:/");
?>