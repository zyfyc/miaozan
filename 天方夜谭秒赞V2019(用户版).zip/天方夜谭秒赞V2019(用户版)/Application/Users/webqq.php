<?php
require_once('conn.php');
$title = "挂机管理";
include_once 'head.php';
if($_GET['del']=='ok'){
	$qid = $_GET['qid'];
	$db->query("delete from {$mysql}qq where qid='$qid'");
	echo "<script language='javascript'>alert('删除成功！');window.location.href='webqq.php';</script>";
}
function qq_user($uid,$mysql){
	global $db;
	if($user=$db->get_row("select user from {$mysql}user where uid='{$uid}' limit 1")){
		return $user['user'];
	}else{
		return 'null';
	}
}
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">挂机管理</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                挂机列表
                            </div>
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>QID</th>
                                                <th>所属用户</th>
                                                <th>QQ</th>
												<th>状态</th>
												<th>添加时间</th>
												<th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php if($rows=$db->get_results("select * from {$mysql}qq where 1=1 order by qid desc")){ foreach($rows as $row){?>
                                            <tr class="odd gradeX">
                                                <td>#<?=$row['qid']?></td>
                                                <td><?=qq_user($row['uid'],$mysql)?></td>
                                                <td><?=$row['qq']?></td>
                                                <td><?=qq_zt($row['qqzt'])?></td>
												<td><?=$row['addtime']?></td>
												<td><a href="?del=ok&qid=<?=$row['qid']?>">删除</a></td>
                                            </tr>
										<?php }}?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>