<?php
require_once('conn.php');
$title = "添加挂机";
include_once 'head.php';
$qq_html=is_numeric($_GET['qqlogin'])?$_GET['qqlogin']:'1';
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">添加挂机</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-success">
                            <div class="panel-heading" align="center">
                                提示：
                            </div>
                            <div class="panel-body">
                                <p>1、首次使用本网站可能会因为异地登陆而被TX临时冻结QQ，改密即可解冻</p>
                                <p>2、添加后会提示异地登陆提醒，以及可能被盗号的安全提醒，本站承诺不盗号读取数据</p>
								<p>3、若添加过程中不出现验证码,则自动更新功能开启</p>
								<p>4、您已在本站中添加<font color=green><?=get_count('qq','uid='.$userrow['uid'].'')?></font>个QQ</p>
								<strong>添加QQ即代表同意本站协议并自愿使用，不同意以上内容请关闭本网站。</strong>
                            </div>
                        </div>
                    </div>
					<?php if($qq_html==1){?>
					<!-- 密码方式 -->
					<div class="col-lg-8">
						<div class="panel panel-default" ng-app="" ng-init="qq=''">
                            <div class="panel-heading">
                                添加挂机
								<div class="pull-right">
									<a href="?qqlogin=2" class="btn btn-danger btn-xs">扫码登录</a>
								</div>
                            </div>
							<div class="panel-body">
								<div align="center">
									<img class="img-circle img-thumbnail" id="img" src="http://q4.qlogo.cn/headimg_dl?dst_uin={{qq}};&amp;spec=100">
								</div>
								<hr>
								<div class="alert alert-info msg" id="load" style="display:none;"></div>
								<div class="form-group">
									<label>Q Q账号：</label>
									<input type="text" class="form-control" name="uin" placeholder="请输入QQ账号" ng-model="qq" id="uin">
								</div>
								<div class="form-group">
									<label>Q Q密码：</label>
									<input type="password" class="form-control" name="pwd" placeholder="请输入QQ密码" id="pwd">
								</div>
								<div class="form-group code" style="display: none;">
									<label>验证码：</label>
									<input type="text" class="form-control" name="code" placeholder="请输入验证码" id="code" onkeydown="if(event.keyCode==13){submit.click()}">
									<span class="input-group-btn" style="width:0;" id="codeimg"><img alt="image" src="//q4.qlogo.cn/headimg_dl?dst_uin=10000&spec=100"></span>
								</div>
								<div class="pull-right">
									<button type="button" class="btn btn-danger submit" id="submit" onkeydown="if(event.keyCode==13){submit.click()}">点击登录</button>
								</div>
							</div>
						</div>
					</div>
					<?php }else{ ?>
					<!-- 扫码登录 -->
					<div class="col-lg-8">
						<div class="panel panel-default" ng-app="" ng-init="qq=''">
                            <div class="panel-heading">
                                添加挂机
								<div class="pull-right">
									<a href="?qqlogin=1" class="btn btn-danger btn-xs">密码登录</a>
								</div>
                            </div>
							<div class="panel-body">
								<div class="tab-pane text-center">
									<div align="center">
										<img class="img-circle img-thumbnail qqimg" src="http://q4.qlogo.cn/headimg_dl?dst_uin={{qq}};&amp;spec=100">
										<h2 class="widget-heading h3 text-dark qqnick"></h2>
									</div>
									<hr>
									<div class="alert alert-info" id="login" align="center">
										<span id="loginmsg">请使用手机QQ扫描二维码</span><span id="loginload" style="padding-left: 10px;color: #790909;">.</span>
									</div>
									<hr>
									<div align="center">
										<div id="qrimg"></div>
									</div>
									<hr>
									<div align="center">
										我是手机用户怎么扫？
										<hr>
										长按二维码或截图保存图片到手机中，之后在“手机QQ”的扫一扫中点击“相册”即可识别，必须是手机QQ！
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php }?>
                    <!-- /.col-lg-4 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>