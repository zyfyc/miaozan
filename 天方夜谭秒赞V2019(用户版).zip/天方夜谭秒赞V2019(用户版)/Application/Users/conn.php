<?php
require_once('../../Include/common.php');
//判断是否登录
if(!TFYT_Data('login_state')){
	exit("<script language='javascript'>window.location.href='/Template/Login.html';</script>");
}