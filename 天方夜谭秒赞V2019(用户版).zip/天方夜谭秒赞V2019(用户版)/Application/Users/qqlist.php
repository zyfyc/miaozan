<?php
require_once('conn.php');
$title = "控制台";
include_once 'head.php';
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">我的挂机</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <!-- /.col-lg-6 -->
					<?php if($rows=$db->get_results("select * from {$mysql}qq where 1=1 order by qid desc")){ foreach($rows as $row){?>
                    <div class="col-lg-3">
                        <div class="panel tabbed-panel panel-success">
                            <div class="panel-heading clearfix">
                                <div class="panel-title pull-left">QQ：<?=$row['qq']?></div>
                                <div class="pull-right">
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a href="#tab-success-1-qq<?=$row['qq']?>" data-toggle="tab">我的挂机</a></li>
                                        <li><a href="#tab-success-2-qq<?=$row['qq']?>" data-toggle="tab">基本信息</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade in active" id="tab-success-1-qq<?=$row['qq']?>">
										<div class="widget-content border-bottom text-center">
											<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$row['qq']?>&spec=100" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
											<h2 class="widget-heading h3 text-dark"><?=$row['qq']?></h2>
											<p>QQ状态：<?=qq_zt($row['qqzt'])?></p>
											<p>SID状态：<?php if($row['sidzt']==0){echo'<font color="green">正常</font>';}else{echo'<font color="red">已失效</font>';}?> 丨 SKEY状态：<?php if($row['skeyzt']==0){echo'<font color="green">正常</font>';}else{echo'<font color="red">已失效</font>';}?></p>
											<div class="widget-content themed-background-muted text-dark-op text-center">
												添加日期：<?=$row['addtime']?>
											</div>
										</div>
										<hr>
										<a href="qqset.php?qid=<?=$row['qid']?>" class="btn btn-default btn-block"><i class="fa fa-gears fa-fw"></i>管理挂机</a>
									</div>
                                    <div class="tab-pane fade" id="tab-success-2-qq<?=$row['qq']?>">
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">QQID：</div>
												<div class="col-md-6 pull-right"><code>[<?=$row['qid']?>]</code></div>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">QQ账号：</div>
												<div class="col-md-6 pull-right"><code>[<?=$row['qq']?>]</code></div>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">Q币：</div>
												<div class="col-md-6 pull-right"><code>[<?=get_qb($row['qq'],$row['skey'])?> 个]</code></div>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">QQ积分：</div>
												<div class="col-md-6 pull-right"><code>[<?=get_jf($row['qq'],$row['skey'])?> 分]</code></div>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">QQ好友：</div>
												<div class="col-md-6 pull-right"><code>[<?=get_qqyou($row['qq'],$row['skey'])?>]</code></div>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-12">
												<div class="col-md-6">QQ好友分组：</div>
												<div class="col-md-6 pull-right"><code>[<?=get_qqyoufz($row['qq'],$row['skey'])?>]</code></div>
											</div>
										</div>
									</div>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel -->
                    </div>
					<?php }}?>
                    <!-- /.col-lg-6 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>