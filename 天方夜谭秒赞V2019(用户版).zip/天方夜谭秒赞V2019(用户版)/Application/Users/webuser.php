<?php
require_once('conn.php');
$title = "用户管理";
include_once 'head.php';
if($_GET['del']=='ok'){
	$uid = $_GET['uid'];
	if($uid==1){
		echo "<script language='javascript'>alert('删除失败！您不能删除管理员');window.location.href='webuser.php';</script>";
	}else{
		$db->query("delete from {$mysql}user where uid='$uid'");
		echo "<script language='javascript'>alert('删除成功！');window.location.href='webuser.php';</script>";
	}
}
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">用户管理</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                用户管理
                            </div>
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>UID</th>
                                                <th>名称</th>
                                                <th>用户名</th>
                                                <th>QQ</th>
                                                <th>邮箱</th>
												<th>状态</th>
												<th>注册时间</th>
												<th>上次登录</th>
												<th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php if($rows=$db->get_results("select * from {$mysql}user where 1=1 order by uid desc")){ foreach($rows as $row){?>
                                            <tr class="odd gradeX">
                                                <td><?=$row['uid']?> <?php if($row['uid']==1){echo '[站长]';}?></td>
                                                <td><?=$row['name']?></td>
                                                <td><?=$row['user']?></td>
                                                <td><?=$row['qq']?></td>
                                                <td><?=$row['mail']?></td>
												<td><?=qq_zt($row['active'])?></td>
												<td><?=$row['regtime']?></td>
												<td><?=$row['lasttime']?></td>
												<td><a href="?del=ok&uid=<?=$row['uid']?>">删除</a></td>
                                            </tr>
										<?php }}?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>