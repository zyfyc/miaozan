<?php
require_once('conn.php');
$title = "资料修改";
include_once 'head.php';
if($_POST['uset']=='ok'){
	$name=safestr($_POST['name']);
	$qq=safestr($_POST['qq']);
	$mail=safestr($_POST['mail']);
	$aqproblem=safestr($_POST['aqproblem']);
	$aqanswer=safestr($_POST['aqanswer']);
	$set="name='{$name}',qq='{$qq}',mail='{$mail}',aqproblem='{$aqproblem}',aqanswer='{$aqanswer}'";
	if($_POST['pwd']){
		$pwd=md5(md5($_POST['pwd']).md5('17404785'));
		$set.=",pwd='{$pwd}'";
	}
	if($db->get_row("select * from {$mysql}user where qq='{$qq}' and uid!='{$userrow['uid']}' limit 1")){
		echo"<script language='javascript'>alert('QQ号已存在！');history.go(-1);</script>";
	}else{
		$db->query("update {$mysql}user set {$set} where uid='{$userrow['uid']}'");
		echo"<script language='javascript'>alert('保存成功！');window.location.href='user.php';</script>";
	}
}
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">资料修改</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                资料修改
                            </div>
                            <div class="panel-body">
								<form action="?" method="post">
									<input type="hidden" name="uset" value="ok">
									<div class="form-group">
										<label>名称：</label>
										<input type="text" class="form-control" name="name" value="<?=$userrow['name']?>" placeholder="您的称呼">
									</div>
									<div class="form-group">
										<label>Q Q：</label>
										<input type="text" class="form-control" name="qq" value="<?=$userrow['qq']?>" placeholder="您的 Q Q，方便联系">
									</div>
									<div class="form-group">
										<label>Q Q邮箱：</label>
										<input type="text" class="form-control" name="mail" value="<?=$userrow['mail']?>" placeholder="您的邮箱，用于将QQ状态发送给您">
									</div>
									<div class="form-group">
										<label>密保问题：</label>
										<input type="text" class="form-control" name="aqproblem" value="<?=$userrow['aqproblem']?>" placeholder="密保问题，用于找回密码">
									</div>
									<div class="form-group">
										<label>密保答案：</label>
										<input type="text" class="form-control" name="aqanswer" value="<?=$userrow['aqanswer']?>" placeholder="密保答案，用于找回密码">
									</div>
									<div class="form-group">
										<label>新密码：</label>
										<input type="text" class="form-control" name="pwd" placeholder="不修改请留空">
									</div>
									<div class="pull-right">
										<button type="submit" class="btn btn-danger">点击保存</button>
									</div>
								</form>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>