<?php
require_once('conn.php');
$title = "网站设置";
include_once 'head.php';
if($_POST['webset']=='ok'){
	foreach($_POST as $k=> $value){
		$db->query("insert into {$mysql}website set vkey='".safestr($k)."',value='".safestr($value)."' on duplicate key update value='".safestr($value)."'");
	}
	if($rows=$db->get_results("select * from {$mysql}website")){
		foreach($rows as $row){
			$website[$row['vkey']]=$row['value'];
		}
		TFYT_Data($website);
	}
	echo "<script language='javascript'>alert('保存成功！');window.location.href='webset.php';</script>";
}
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">网站设置</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                基本信息
                            </div>
                            <div class="panel-body">
								<form action="?" method="post">
								   <input type="hidden" name="webset" value="ok">
									<div class="form-group">
										<label>网站名称</label>
										<input class="form-control" name="name" value="<?=TFYT_Data('name')?>">
									</div>
									<div class="form-group">
										<label>网站描述</label>
										<input class="form-control" name="describe" value="<?=TFYT_Data('describe')?>">
									</div>
									<div class="form-group">
										<label>网站域名</label>
										<input class="form-control" name="domain" value="<?=TFYT_Data('domain')?>">
									</div>
									<div class="form-group">
										<label>站长Q Q：</label>
										<input class="form-control" name="qq" value="<?=$userrow['qq']?>">
									</div>
									<div class="form-group">
										<label>监控密匙</label>
										<input class="form-control" name="cron" value="<?=TFYT_Data('cron')?>">
									</div>
									<hr>
									<div class="pull-right">
										<button type="submit" class="btn btn-default">保存</button>
										<button type="reset" class="btn btn-danger">重置</button>
									</div>
								</form>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <div class="col-md-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                公告管理
                            </div>
                            <div class="panel-body">
								<form action="?" method="post">
								   <input type="hidden" name="webset" value="ok">
									<div class="form-group">
										<label>网站名称</label>
										<textarea class="form-control" rows="6" name="notice"><?=TFYT_Data('notice')?></textarea>
									</div>
									<hr>
									<div class="pull-right">
										<button type="submit" class="btn btn-default">保存</button>
										<button type="reset" class="btn btn-danger">重置</button>
									</div>
								</form>
                                <!-- /.row (nested) -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>