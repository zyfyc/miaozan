        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="/ThinkPHP/js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="/ThinkPHP/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="/ThinkPHP/js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="/ThinkPHP/js/startmin.js"></script>

		<!-- tfyt frame -->
		<script src="/ThinkPHP/home/js/tfytframe.js"></script>
		
		<!-- QQ Login -->
		<script src="/ThinkPHP/qqlogin/login.js"></script>
		<script src="/ThinkPHP/qqlogin/collect.js"></script>
		<script src="/ThinkPHP/qqlogin/getsid.js"></script>
		
		<?php if($qq_html==2){?>
		<script src="/ThinkPHP/qqlogin/qrlogin.js"></script>
		<?php }?>
		
    </body>
</html>
