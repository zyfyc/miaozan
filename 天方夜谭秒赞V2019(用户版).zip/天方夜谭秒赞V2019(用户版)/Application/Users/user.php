<?php
require_once('conn.php');
$title = "我的资料";
include_once 'head.php';
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">我的资料</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                我的资料
                            </div>
                            <div class="panel-body">
								<div class="widget-content border-bottom text-center">
									<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
									<h2 class="widget-heading h3 text-dark"><?=$userrow['name']?></h2>
									<?=$userrow['user']?>
									<div class="widget-content themed-background-muted text-dark-op text-center">
										我的生日：<?=$userrow['regtime']?>
									</div>
								</div>
                            </div>
							<div class="list-group">
								<a href="#" class="list-group-item">
									<i class="fa fa-drupal fa-fw"></i> UID：
										<span class="pull-right text-muted small"><em><?=$userrow['uid']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-opera fa-fw"></i> 名称：
										<span class="pull-right text-muted small"><em><?=$userrow['name']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-user fa-fw"></i> 用户名：
										<span class="pull-right text-muted small"><em><?=$userrow['user']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-qq fa-fw"></i> Q Q：
										<span class="pull-right text-muted small"><em><?=$userrow['qq']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-envelope fa-fw"></i> 邮箱：
										<span class="pull-right text-muted small"><em><?=$userrow['mail']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-cubes fa-fw"></i> 状态：
										<span class="pull-right text-muted small"><em><?php if($userrow['active']==0){echo '正常';}else{echo '已被封禁';}?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-calendar fa-fw"></i> 注册时间：
										<span class="pull-right text-muted small"><em><?=$userrow['regtime']?></em>
										</span>
								</a>
								<a href="#" class="list-group-item">
									<i class="fa fa-calendar fa-fw"></i> 上一次登录：
										<span class="pull-right text-muted small"><em><?=$userrow['lasttime']?></em>
										</span>
								</a>
							</div>
							<!-- /.list-group -->
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>