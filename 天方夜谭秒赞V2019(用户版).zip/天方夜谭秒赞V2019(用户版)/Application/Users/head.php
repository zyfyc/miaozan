<!DOCTYPE html>
<html lang="en" ng-app="myApp" ng-controller="myCtrl">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title><?=$title?> - {{name}}</title>

        <!-- Bootstrap Core CSS -->
        <link href="/ThinkPHP/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="/ThinkPHP/css/metisMenu.min.css" rel="stylesheet">

        <!-- Timeline CSS -->
        <link href="/ThinkPHP/css/timeline.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="/ThinkPHP/css/startmin.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="/ThinkPHP/css/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="/ThinkPHP/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="./"><?=$title?></a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown navbar-inverse">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-bell fa-fw"></i> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-alerts">
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-comment fa-fw"></i> 请全体成员做好升级的准备！
                                        <span class="pull-right text-muted small">下午 4 时</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>查看更多</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> <?=$userrow['name']?> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="user.php"><i class="fa fa-user fa-fw"></i> 我的资料</a>
                            </li>
                            <li><a href="qqlist.php"><i class="fa fa-gear fa-fw"></i> 挂机管理</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> 安全退出</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                            <li>
                                <a href="./" class="active"><i class="fa fa-dashboard fa-fw"></i> 控制台</a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-pencil-square-o fa-fw"></i> 用户中心 <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="user.php">我的资料</a>
                                    </li>
                                    <li>
                                        <a href="uset.php">资料修改</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-shopping-cart fa-fw"></i> 在线商城 <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="#">在线充值</a>
                                    </li>
                                    <li>
                                        <a href="#">自助购买</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-gear fa-fw"></i> 平台工具 <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="#">交友系统</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-qq fa-fw"></i> 挂机管理 <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addqq.php">添加挂机</a>
                                    </li>
                                    <li>
                                        <a href="qqlist.php">挂机管理</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
							<?php if($userrow['uid']=='1'){?>
                            <li>
                                <a href="#"><i class="fa fa-cloud fa-fw"></i> 系统设置 <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="webset.php">网站设置</a>
                                    </li>
                                    <li>
                                        <a href="webuser.php">用户管理</a>
                                    </li>
                                    <li>
                                        <a href="webqq.php">挂机管理</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
							<?php }?>
                        </ul>
                    </div>
                </div>
            </nav>