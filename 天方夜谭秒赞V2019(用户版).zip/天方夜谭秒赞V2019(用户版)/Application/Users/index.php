<?php
require_once('conn.php');
$title = "控制台";
include_once 'head.php';
?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">控制台</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=get_count('user','uid')?></div>
                                        <div>平台用户</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-qq fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=get_count('qq','qid')?></div>
                                        <div>平台挂机</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-shield fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=site_time(TFYT_Data('SITE_TIME'))?></div>
                                        <div>运行天数</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-calendar fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=date('Y-m-d')?></div>
                                        <div>系统时间</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bullhorn fa-fw"></i> 公告
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body" style="min-height: 560px;">
                                <?=TFYT_Data('notice')?>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-8 -->
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-pencil-square-o fa-fw"></i> UID：<?=$userrow['uid']?>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
								<div class="widget-content border-bottom text-center">
									<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['qq']?>&spec=100" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
									<h2 class="widget-heading h3 text-dark"><?=$userrow['name']?></h2>
									<?=$userrow['user']?>
									<div class="widget-content themed-background-muted text-dark-op text-center">
										我的生日：<?=$userrow['regtime']?>
									</div>
								</div>
								<hr>
                                <!-- /.list-group -->
                                <a href="uset.php" class="btn btn-default btn-block"><i class="fa fa-pencil-square-o fa-fw"></i> 修改资料</a>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-qq fa-fw"></i> 添加挂机
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart"></div>
                                <a href="addqq.php" class="btn btn-default btn-block"><i class="fa fa-gear fa-fw"></i> 添加挂机</a>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
<?php
include_once 'foot.php';
?>