<?php
//关闭报错
error_reporting(E_ALL & ~E_NOTICE);
//设置编码
@header('Content-Type: text/html; charset=UTF-8');
//判断是否安装
if(file_exists('../../Include/class_function/database.php')){
	$step=is_numeric($_GET['step'])?$_GET['step']:'4';
}else if($_POST['install']=="ok"){
	if(!$_POST['DB_HOST'] || !$_POST['DB_PORT'] || !$_POST['DB_NAME'] || !$_POST['DB_USER'] || !$_POST['DB_PWD'] || !$_POST['DB_PREFIX']){
		echo '<script language=\'javascript\'>alert(\'所有项都不能为空\');history.go(-1);</script>';
	}else if(!$con=mysql_connect($_POST['DB_HOST'].':'.$_POST['DB_PORT'],$_POST['DB_USER'],$_POST['DB_PWD'])){
		echo '<script language=\'javascript\'>alert("连接数据库失败，'.mysql_error().'");history.go(-1);</script>';
	}else if(!mysql_select_db($_POST['DB_NAME'],$con)){
		echo '<script language=\'javascript\'>alert("选择的数据库不存在，'.mysql_error().'");history.go(-1);</script>';
	}else{
		mysql_query("set names utf8",$con);
$time = date("Y-m-d");
$data="<?php
return array(
	'DB_HOST'               =>  '{$_POST['DB_HOST']}',
    'DB_NAME'               =>  '{$_POST['DB_NAME']}',
    'DB_USER'               =>  '{$_POST['DB_USER']}',
    'DB_PWD'                =>  '{$_POST['DB_PWD']}',
    'DB_PORT'               =>  '{$_POST['DB_PORT']}',
    'DB_PREFIX'             =>  '{$_POST['DB_PREFIX']}_',
	
	'SITE_TIME'             =>  '{$time}',
);";
		if(file_put_contents('../../Include/class_function/database.php',$data)){
			$sqls = file_get_contents('install.sql');
			$data_new = str_replace('{DB_PREFIX}', ''.$_POST['DB_PREFIX'].'',$sqls);
			file_put_contents('install.sql',$data_new);
			$newsql = file_get_contents('install.sql');
			$explode = explode(";",$newsql);
			$num = count($explode);
			foreach($explode as $sql){
				if($sql=trim($sql)){
					mysql_query($sql);
				}
			}
			if(mysql_error()){
				echo'<script language=\'javascript\'>alert("导入数据表时错误，'.mysql_error().'");history.go(-1);</script>';
			}else{
				@header("Location:?step=3&num={$num}");
				exit;
			}
		}
	}
}else{
	$step=is_numeric($_GET['step'])?$_GET['step']:'1';
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>程序安装 - 天方夜谭秒赞</title>

        <!-- Bootstrap Core CSS -->
        <link href="/ThinkPHP/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="/ThinkPHP/css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="/ThinkPHP/css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="/ThinkPHP/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title" align="center">程序安装</h3>
                        </div>
						<?php if($step=='1'){?>
                        <div class="panel-body">
                            <form role="form">
								<div class="progress">
									<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 30%;"></div>
									<span>30% 完成（安装向导）</span>
								</div>
                                <fieldset>
                                    <pre>天方夜谭秒赞V2019安装说明</pre>
                                    <pre>当前程序为免费开源版本，请勿倒卖</pre>
									<pre>开源程序，可能存在部分Bug，请见谅</pre>
									<pre>此程序由天方夜谭（QQ:424787419）独立编写</pre>
									<pre>天方夜谭程序交流群：294470669</pre>
                                    <a href="?step=2" class="btn btn-success btn-block">开始安装</a>
                                </fieldset>
                            </form>
                        </div>
						<?php }else if($step=='2'){ ?>
                        <div class="panel-body">
                            <form action="?" method="post">
							   <input type="hidden" name="install" value="ok">
								<div class="progress">
									<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 70%;">
										<span>70% 完成（安装配置）</span>
									</div>
								</div>
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="数据库链接地址" name="DB_HOST" type="text" value="localhost" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="数据库端口" name="DB_PORT" type="text" value="3306" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="数据库名称" name="DB_NAME" type="text" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="数据库用户名" name="DB_USER" type="text" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="数据库密码" name="DB_PWD" type="text" autofocus>
                                    </div>
                                   <div class="form-group">
                                        <input class="form-control" placeholder="数据库前缀" name="DB_PREFIX" type="text" value="tfyt" autofocus>
                                    </div>
									<input type="submit" class="btn btn-success btn-block" name="submit" value="确认，下一步">
                                </fieldset>
                            </form>
                        </div>
						<?php }else if($step=='3'){ ?>
                        <div class="panel-body">
                            <form role="form">
								<div class="progress">
									<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
										<span>100% 完成（安装完成）</span>
									</div>
								</div>
                                <fieldset>
                                    <pre>程序安装完成！</pre>
									<pre>本次安装共导入<code><?php echo $_GET['num']; ?></code>条数据</pre>
									<pre>更多的功能设置请到后台查看</pre>
                                    <!-- Change this to a button or input when using this as a form -->
                                    <a href="/" class="btn btn-success btn-block">网站首页</a>
                                </fieldset>
                            </form>
                        </div>
						<?php }else if($step=='4'){?>
                        <div class="panel-body">
                            <form role="form">
                                <fieldset>
                                    <div class="alert alert-success">系统检测到您已经安装本程序，如需程序安装，请删除根目录/Include/class_function/下的database.php文件即可！</div>
                                    <!-- Change this to a button or input when using this as a form -->
                                    <a href="/" class="btn btn-success btn-block">网站首页</a>
                                </fieldset>
                            </form>
                        </div>
						<?php }?>
                    </div>
                </div>
            </div>
        </div>

        <!-- jQuery -->
        <script src="/ThinkPHP/js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="/ThinkPHP/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="/ThinkPHP/js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="/ThinkPHP/js/startmin.js"></script>

    </body>
</html>
