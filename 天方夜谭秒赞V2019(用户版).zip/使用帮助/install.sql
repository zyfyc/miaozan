﻿DROP TABLE IF EXISTS `tfyt_qq`;
CREATE TABLE `tfyt_qq` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `nick` varchar(80) DEFAULT NULL,
  `qq` decimal(10,0) NOT NULL,
  `pwd` varchar(80) DEFAULT NULL,
  `sid` varchar(80) DEFAULT NULL,
  `sidzt` tinyint(1) DEFAULT '0',
  `skey` varchar(80) DEFAULT NULL,
  `skeyzt` tinyint(1) DEFAULT '0',
  `p_skey` varchar(80) DEFAULT NULL,
  `superkey` varchar(80) DEFAULT NULL,
  `cookie` varchar(1000) DEFAULT NULL,
  `qqzt` tinyint(1) DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `gxtime` datetime DEFAULT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_user`;
CREATE TABLE `tfyt_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `user` varchar(255) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `aqproblem` varchar(255) DEFAULT NULL,
  `aqanswer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `tfyt_website`;
CREATE TABLE `tfyt_website` (
  `vkey` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`vkey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `tfyt_website` VALUES ('cron', '123456');
INSERT INTO `tfyt_website` VALUES ('name', '天方夜谭自动化程序');
INSERT INTO `tfyt_website` VALUES ('describe', '天方夜谭全自动化QQ托管程序');
INSERT INTO `tfyt_website` VALUES ('domain', 'www.baidu.com');
INSERT INTO `tfyt_website` VALUES ('qq', '10001');
INSERT INTO `tfyt_website` VALUES ('notice', '欢迎来到天方夜谭QQ全自动化托管平台！');