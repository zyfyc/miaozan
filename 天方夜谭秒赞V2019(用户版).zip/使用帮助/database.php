<?php
return array(
	'DB_HOST'               =>  '127.0.01',	//数据库连接地址
    'DB_NAME'               =>  'root',	//数据库库名
    'DB_USER'               =>  'root',	//数据库用户名
    'DB_PWD'                =>  'root',	//数据库用户名
    'DB_PORT'               =>  '3306',	//数据库端口
    'DB_PREFIX'             =>  'tfyt_',
	
	'SITE_TIME'             =>  '2018-10-06',
);