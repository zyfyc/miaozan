<?php global $zym_decrypt;$zym_decrypt['�֮�����î����֯�þ��Į���֥����']=base64_decode('ZGVmaW5lZA==');$zym_decrypt['�����Ď���Ô����ĮĈ�����îî���']=base64_decode('cGhvbmVfY2hlY2s='); ?>
<?php
if(!$GLOBALS['zym_decrypt']['�֮�����î����֯�þ��Į���֥����'](base64_decode('SU5fQ1JPTkxJVEU=')))exit();$title="试用卡获取";$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li class="active"><a href="#"><i class="icon fa fa-check-square"></i>试用卡获取</a></li>';include TEMPLATE_ROOT.base64_decode('aGVhZC5waHA=');echo base64_decode('PGRpdiBjbGFzcz0iY29sLW1kLTEwIGNvbC1tZC1vZmZzZXQtMSBjb2wtbGctOCBjb2wtbGctb2Zmc2V0LTIiIHJvbGU9Im1haW4iPjxkaXYgY2xhc3M9IndpZGdldCI+PGRpdiBjbGFzcz0id2lkZ2V0LWNvbnRlbnQgdGhlbWVkLWJhY2tncm91bmQgdGV4dC1saWdodC1vcCI+CjxpIGNsYXNzPSJmYSBmYS1mdyBmYS1wZW5jaWwiPjwvaT4gPHN0cm9uZz7pooblj5bor5XnlKjkvJrlkZg8L3N0cm9uZz4KPC9kaXY+');$result =$DB->query("SELECT * FROM ".DBQZ."_kms WHERE kind='3' and isuse='0' LIMIT 30");if($conf['active']!=0)$GLOBALS['zym_decrypt']['�����Ď���Ô����ĮĈ�����îî���']();echo base64_decode('PHRhYmxlIGNsYXNzPSJ0YWJsZSB0YWJsZS1ib3JkZXJlZCI+Cjx0Ym9keSBhbGlnbj0iY2VudGVyIj4KPHRyPgo8dGQ+5Y2h5a+GPC90ZD4KPHRkPuaXtumVvzwvdGQ+Cjx0ZD7mmK/lkKbkvb/nlKg8L3RkPgo8dGQ+5L2/55SoPC90ZD4KPCEtLTx0ZD7nlJ/miJDml7bpl7Q8L3RkPi0tPgo8L3RyPg==');while($rows =$DB->fetch($result)){if($rows['isuse']==1){$sfsy='<font color="#FF0000">已使用</font>';}else{$sfsy='<font color="#0000C6">未使用</font>';}echo base64_decode('PHRyPg0KPHRkPg=='). $rows['km'] . '</td>
<td>'. $rows['value'] . '天</td>
<td>' . $sfsy . '</td>
<td><form action="index.php?mod=shop&kind=3" method="POST">
<input name="km" type="hidden" value="'. $rows['km'] . '">
<button type="submit" name="submit" class="btn btn-info">使用</button>
</form>
</td>
<!--<td>' . $rows['addtime'] . '</td>-->
</tr>';}echo base64_decode('PC90Ym9keT48L3RhYmxlPg==');echo'</div>';include TEMPLATE_ROOT.base64_decode('Zm9vdC5waHA=');?>