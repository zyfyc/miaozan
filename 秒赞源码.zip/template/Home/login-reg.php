﻿<?php
if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');
if($ismobile==true && $conf['ui_style2'])
	$ui_style=$conf['ui_style2'];
else
	$ui_style=$conf['ui_style'];
$sitename=$conf['sitename'];

if($title=='首页' || empty($title))
$titlename=$sitename.' '.$conf['sitetitle'];
else
$titlename=$title.'|'.$sitename.' '.$conf['sitetitle'];

if($conf['ui_background']==0)
$repeat='background-repeat:repeat;';
elseif($conf['ui_background']==1)
$repeat='background-repeat:repeat-x;
background-size:auto 100%;';
elseif($conf['ui_background']==2)
$repeat='background-repeat:repeat-y;
background-size:100% auto;';
elseif($conf['ui_background']==3)
$repeat='background-repeat:no-repeat;
background-size:100% 100%;';
if($conf['ui_background2']==0)
$fixed=null;
elseif($conf['ui_background2']==1)
$fixed='fixed';

if($is_fenzhan) $bjname = DBQZ;else $bjname = '';
if(!file_exists(ROOT.'images/'.$bjname.'bj.png')) $bjname='';

if($conf['ui_bing']==1){
	if(date("Ymd")==$conf['ui_bing_date']){
		$backgroundimage=$conf['ui_backgroundurl'];
		$repeat='background-repeat:no-repeat;
		background-size:100% 100%;';
		$fixed='fixed';
	}else{
		$bing_data=get_curl('http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1');
		$bing_arr=json_decode($bing_data,true);
		if (!empty($bing_arr['images'][0]['url'])) {
			saveSetting('ui_backgroundurl', 'http://cn.bing.com'.$bing_arr['images'][0]['url']);
			saveSetting('ui_bing_date', date("Ymd"));
			$CACHE->clear();
			$backgroundimage=$bing_arr['images'][0]['url'];
			$repeat='background-repeat:no-repeat;
			background-size:100% 100%;';
			$fixed='fixed';
		}else{
			$backgroundimage='images/'.$bjname.'bj.png';
		}
	}
}else{
	$backgroundimage='images/'.$bjname.'bj.png';
}

if($ismobile==true && $conf['ui_style2'])
	$ui_style=$conf['ui_style2'];
else
	$ui_style=$conf['ui_style'];
echo'
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assets/login-css/login.css" rel="stylesheet" >
    <link href="assets/login-css/alert.css" rel="stylesheet" />
    <script src="assets/login-css/jquery.min.js"></script>
    <script src="assets/login-css/findpwd.js"></script>
    <script src="assets/login-css/alert.js"></script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
	</head>
';
?>