<?php
if(!defined('IN_CRONLITE'))exit();
$title="秒赞墙";
include_once(TEMPLATE_ROOT."head.php");
echo'<div class="col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
<div class="text-center ">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-fw fa-pencil"></i> <strong>秒赞墙 - 此页面显示最新50个位添加的ＱＱ账号</strong>
</div></div>'?>
<?php //获取最新QQ列表
$liukay=$DB->query("select qq,time from ".DBQZ."_qq order by id desc limit 50");
while ($lingku = $DB->fetch($liukay))
{
echo '
<div class="tab-pane active" id="search-tab-projects">
<table class="table table-striped table-borderless table-vcenter">
<tbody>
<tr>
<td class="text-center ">
<img height="85" width="85" src="http://q4.qlogo.cn/headimg_dl?dst_uin='.$lingku['qq'].'&amp;spec=100" alt="Avatar" class="img-circle img-thumbnail  ">
</td>
<td>
<p>
<i class="fa fa-qq"></i>&nbsp;&nbsp;<strong>'.$lingku['qq'].'</strong>
</p>
<p>
<i class="fa fa-clock-o"></i><small>'.$lingku['time'].'</small>
</p>
</td>
<td>
<h2>
<a target="_blank" href="http://cqy.lyue.cc/'.$lingku['qq'].'" class="btn btn-square btn-primary" style="font-size:12px;">加好友</a><a target="_blank" href="http://user.qzone.qq.com/'.$lingku['qq'].'" class="btn btn-square btn-primary" style="font-size:12px;">看空间</a>
</h2>
</td>
</tr>
</tr>
</tbody>
</table>
</div>';}?>
<?php
echo '</div></div>';
?>
<?php
include TEMPLATE_ROOT."foot.php";
?>