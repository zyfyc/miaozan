<?php
if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');
$qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1"); //获取QQ数量
$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1"); //获取用户数量
/*
$qqjobs=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE 1");
$signjobs=$DB->count("SELECT count(*) from ".DBQZ."_signjob WHERE 1");
$wzjobs=$DB->count("SELECT count(*) from ".DBQZ."_wzjob WHERE 1");
$zongs=$qqjobs+$signjobs+$wzjobs; //获取总任务数量
$info['times'] //系统累计运行的次数
$yxts=ceil((time()-strtotime($conf['build']))/86400); //本站已运行多少天
*/
$url='//'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; 
$url= dirname($url);
if($is_fenzhan==1) $logoname = DBQZ;else $logoname = ''; 
if(!file_exists(ROOT.'images/'.$logoname.'logo.png')) $logoname='';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo $conf['description']?>">
    <meta name="keywords" content="<?php echo $conf['keywords']?>">
    <title><?php echo $conf['sitename'].$conf['sitetitle']?></title>
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="stylesheet" href="assets/xh1/css/normalize.css">
    <link rel="stylesheet" href="assets/xh1/css/bootstrap.min.css">
    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:600,700,400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="assets/xh1/css/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/xh1/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/xh1/css/slider-pro.css">
    <link rel="stylesheet" href="assets/xh1/css/owl.carousel.css">
    <link rel="stylesheet" href="assets/xh1/css/owl.theme.css">
    <link rel="stylesheet" href="assets/xh1/css/owl.transitions.css">
    <link rel="stylesheet" href="asstes/css/animate.css">
    <link rel="stylesheet" href="assets/xh1/css/style.css">
    <link rel="stylesheet" href="assets/xh1/css/responsive.css" />
    <link rel="stylesheet" href="assets/xh1/css/color.css" id="colors" />

    <!--[if lt IE 9]>
        <script src="assets/xh1/js/html5shiv.min.js"></script>
        <script src="assets/xh1/js/respond.min.js"></script>
        <script type="text/javascript" src="js/selectivizr.js"></script>
    <![endif]-->
</head>

<body>

    <!-- =============================
                    Header
    ================================== -->
    <header>
        <!-- Navigation Menu start-->
        <nav class="navbar blete-main-menu" role="navigation">
            <div class="container">

                <!-- Navbar Toggle -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Logo -->
                    <a class="navbar-brand" href="#"><img class="logo" id="logo" src="images/<?php echo $logoname?>logo.png" alt="<?php echo $conf['sitename']?>"></a>

                </div>
                <!-- Navbar Toggle End -->

                <!-- navbar-collapse start-->
                <div id="nav-menu" class="navbar-collapse collapse" role="navigation">
                    <ul class="nav navbar-nav blete-menu-wrapper">
                        <li class="active">
                            <a href="#">首页</a>
                        </li>
                        <li>
                            <a href="index.php?mod=login">马上登陆</a>
                        </li>
                        <li>
                            <a href="index.php?mod=reg">立即注册</a>
                        </li>
                    </ul>
                </div>
                <!-- navbar-collapse end-->

            </div>
        </nav>
        <!-- Navigation Menu end-->
    </header>
    <!-- Header End -->


    <!-- =============================
                Main Slider
    ================================== -->
    <section class="slider-pro blete-slider" id="blete-slider">
        <div class="sp-slides">

            <!-- Slides -->
            <div class="sp-slide blete-main-slides">
                <div class="blete-img-overlay"></div>

                <img class="sp-image" src="assets/xh1/images/bg.jpg" alt="Slider 1"/>

                <h1 class="sp-layer blete-slider-text-big"
                data-position="center" data-show-transition="left" data-hide-transition="right" data-show-delay="1500" data-hide-delay="200">
                做最好的云端秒赞平台
                </h1>

                <p class="sp-layer"
                data-position="center" data-vertical="15%" data-show-delay="2000" data-hide-delay="200" data-show-transition="left" data-hide-transition="right">
                    <span class="blete-highlight-text">致力于</span> 帮助更多的QQ空间用户提供稳定高效的服务
                </p>
            </div>
            <!-- Slides End -->

            <!-- Slides -->
            <div class="sp-slide blete-main-slides">
            <div class="blete-img-overlay"></div>
                <img class="sp-image" src="assets/xh1/images/bg1.jpg" alt="Slider 2"/>

                <h1 class="sp-layer blete-slider-text-big"
                 data-position="center" data-show-transition="left" data-hide-transition="right" data-show-delay="1500" data-hide-delay="200">
                   做最好的云端秒赞平台
                </h1>

                <p class="sp-layer"
                 data-position="center" data-vertical="15%" data-show-delay="2000" data-hide-delay="200" data-show-transition="left" data-hide-transition="right">
                    <span class="blete-highlight-text">致力于</span> 帮助更多的QQ空间用户提供稳定高效的服务 
                </p>
            </div>
            <!-- Slides End -->

            <!-- Slides -->
            <div class="sp-slide blete-main-slides">
                <div class="blete-img-overlay"></div>

                <img class="sp-image" src="assets/xh1/images/bg2.jpg" alt="Slider 3"/>

                <h1 class="sp-layer blete-slider-text-big"
                data-position="center" data-show-transition="left" data-hide-transition="right" data-show-delay="1000" data-hide-delay="200">
                   做最好的云端秒赞平台 
                </h1>

                <p class="sp-layer"
                data-position="center" data-vertical="15%" data-show-delay="2000" data-hide-delay="200" data-show-transition="left" data-hide-transition="right">
                   <span class="blete-highlight-text">致力于</span> 帮助更多的QQ空间用户提供稳定高效的服务
                </p>

            </div>
            <!-- Slides End -->

        </div>
    </section>
    <!-- Main Slider End -->

    <!-- =============================
                    About Section
    ================================== -->
    <section id="about" class="blete-section-wrapper">
        <div class="container">
            <div class="row">
                <div class="blete-what-we-do">

                    <div class="col-md-3 col-sm-3 col-xs-12 blete-blurb-round-icon wow bounceInLeft">
                        <div class="blete-icon">
                            <i class="fa fa-key"></i>
                        </div>
                        <h3>账号安全</h3>
                        <p>360网站卫士全局防SQL注入、IP禁访配置、网址屏蔽配置.</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-12 blete-blurb-round-icon wow bounceInLeft" data-wow-delay=".5s">
                        <div class="blete-icon">
                            <i class="fa fa-laptop"></i>
                        </div>
                        <h3>离线托管</h3>
                        <p>强大的任务运行机制，分布式响应功能，提升运行效率，并力求将服务器负载降到最低.</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-12 blete-blurb-round-icon wow bounceInRight" data-wow-delay=".5s">
                        <div class="blete-icon">
                            <i class="fa fa-home"></i>
                        </div>
                        <h3>稳定高效</h3>
                        <p>秒赞协议分为触屏版以及PC版，双协议秒赞，更实用，更稳定.</p>
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-12 blete-blurb-round-icon wow bounceInRight" data-wow-delay=".5s">
                        <div class="blete-icon">
                            <i class="fa fa-html5"></i>
                        </div>
                        <h3>全平台支持</h3>
                        <p>支持ACE、SAE等应用引擎，支持SQLite和MySQL两种数据库.</p>
                    </div>

                </div>

            </div>
        </div>
    </section>
        <!-- Container -->
        <div class="container">
            <div class="row">



            </div>
        </div>
        <!-- Container End -->

        <!-- Featured Works Slider -->
        <div class="container-fluid">
            <div class="row-fluid">

                <div class="blete-portfolio-work-slider-section wow fadeIn" data-wow-duration="2s">
                    <div id="featured-work-slider" class="owl-carousel blete-portfolio-works-slider">


                    </div>
                </div>
            </div>
        </div>
        <!-- Featured Works Slider -->

    </section>
    <!-- Featured Work End -->



    <!-- =============================
                Portfolio Section
    ================================== -->
        <div class="container">
            <div class="row">
   </div>
        </div>

        <!-- Works -->
        <div class="blete-portfolio-works wow fadeIn" data-wow-duration="2s">

            <!-- Filter Button Start -->
 
            <!-- Filter Button End -->

            <div class="blete-portfolio-items">

                <!-- Portfolio Items -->

            </div>
        </div>
        <!-- Works End -->


    </section>
    <!-- Portfolio Section End -->

    <!-- =============================
                Custom Section
    ================================== -->

        <div class="container">
            <div class="row">

                <div class="col-md-6 col-sm-6 col-xs-12 blete-custom-sec-img wow bounceInLeft">
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12 blete-custom-sec-text wow bounceInRight">

                </div>
            </div>
        </div>
    </section>
    <!-- Custom Section End -->


    <!-- =============================
            Testimonial Section
    ================================== -->
    <section id="testimonials" class="blete-testimonial-section">


        <div class="blete-parallax-overlay"></div>

        <div class="blete-testimonial-wrapper wow bounceIn">
            <div class="container">
                <div class="row">

                    <!-- Testimonial Slider -->
                    <div id="blete-testimonial" class="owl-carousel blete-testimonial">

                        <!-- Slides -->
                        <div class="blete-testimonial-slides col-md-8 col-sm-10 col-xs-12 col-md-offset-2 col-sm-offset-1">
                            <p class="blete-client-info">秒赞</p>
							<p>24H秒赞、挂Q功能本平台免费使用，操作简单无需安装软件，安卓/苹果IOS通用，VIP会员服务全网最具性价比，功能全面为您秒赞好友说说，不漏掉每一条动态，为您秒评论好友说说，让Ta时时刻刻感受到你的存在，增加您和好友的亲密度.</p>  
                        </div>
                        <!-- Slides End -->

                        <!-- Slides -->
                        <div class="blete-testimonial-slides col-md-8 col-sm-10 col-xs-12 col-md-offset-2 col-sm-offset-1">
                            <p class="blete-client-info">功能</p>
							<p>多功能、双协议，24小时稳定运行，无需安装软件，操作简单快速上手，已研发QS点赞协议保证不漏赞，采用高配置独立服务器，极速秒赞，全天24小时监控执行，完美离线使用.</p>
                        </div>
                        <!-- Slides End -->

                        <!-- Slides -->
                        <div class="blete-testimonial-slides col-md-8 col-sm-10 col-xs-12 col-md-offset-2 col-sm-offset-1">
                            <p class="blete-client-info">追求</p>
							<p>我们始终坚持以用户需求为导向，为追求用户体验设计，提供最完善的秒赞服务，我们将不断地超越自我，挑战自我！</p>
                        </div>
                        <!-- Slides End -->

                    </div>
                    <!-- Testimonial Slider End -->

                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial End -->


    <!-- =============================
            Pricing Section
    ================================== -->
    <section id="pricing" class="blete-pricing-section">
        <div class="container">
            <div class="row">

                <!-- Section Header -->
                <div class="col-md-12 col-sm-12 col-xs-12 blete-section-header wow fadeInDown">
                    <h2><span class="blete-highlight-text">VIP会员</span></h2>
                    <div class="blete-section-divider"></div>
                    <p class="col-md-8 col-sm-10 col-xs-12 col-md-offset-2 col-sm-offset-1">VIP用户可获得更好的使用体验和更多的特权功能</p>
                </div>
                <!-- Section Header End -->

                <div class="blete-pricing-wrapper">

                    <!-- Plans -->
                    <div class="col-md-4 col-sm-4 col-xs-12 blete-pricing-plans wow bounceInLeft pricing-plan-one">
                        <div class="blete-pricing-titles">
                            <h2>月付VIP</h2>
                            <p><span>$5元/</span>30天</p>
                        </div>
                        <div class="blete-pricing-service-name">
                            <ul>
                                <li>享用VIP专属服务器</li>
                                <li>频率可设置最低1分钟</li>
                                <li>开启基础VIP功能</li>
                                <li>可使用单项好友检测</li>
                            </ul>
                        </div>

                        <a href="#" class="blete-signup-btn">购买</a>
                    </div>
                    <!-- Plans End -->

                    <!-- Plans -->
                    <div class="col-md-4 col-sm-4 col-xs-12 blete-pricing-plans blete-recommended-pricing wow fadeInUp" data-wow-duration="1s">
                        <div class="blete-pricing-titles">
                            <h2>季度VIP</h2>
                            <p><span>$12元/</span>90天</p>
                        </div>
                        <div class="blete-pricing-service-name">
                            <ul>
                                <li>享用VIP专属服务器</li>
                                <li>享受秒赞10秒频率</li>
                                <li>开启全部VIP功能</li>
                                <li>可使用单项好友检测</li>
                            </ul>
                        </div>

                        <a href="#" class="blete-signup-btn">购买</a>
                    </div>
                    <!-- Plans End -->

                    <!-- Plans -->
                    <div class="col-md-4 col-sm-4 col-xs-12 blete-pricing-plans wow bounceInRight">
                        <div class="blete-pricing-titles">
                            <h2>年费VIP</h2>
                            <p><span>$36元/</span>365天</p>
                        </div>
                        <div class="blete-pricing-service-name">
                            <ul>
                                <li>享用VIP专属服务器</li>
                                <li>享受秒赞10秒频率</li>
                                <li>开启全部VIP功能</li>
                                <li>最新功能优先使用权</li>
                            </ul>
                        </div>

                        <a href="#" class="blete-signup-btn">购买</a>
                    </div>
                    <!-- Plans End -->

                </div>
            </div>
        </div>
    </section>
    <!-- Pricing End -->


    <!-- =============================
                Contact Section
    ================================== -->
    <section id="contact" class="blete-section-wrapper blete-contact-section" data-stellar-background-ratio="0.5">
    <div class="blete-parallax-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="blete-contact-details">

                    <!-- Address Area -->
                    <div class="col-md-5 col-sm-4 col-xs-12 blete-contact-address wow bounceInLeft">     
                    </div>

                    <!-- Address Area End -->

                    <!-- Contact Form -->
                    <div class="col-md-7 col-sm-8 col-xs-12 blete-contact-form wow bounceInRight">
                        <div id="contact-result"></div>
                        <div id="contact-form">    
                    </div>
                    <!-- Contact Form End -->

                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section End -->


   <!-- =============================
                Footer Section
    ================================= -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h3><?php echo $conf['sitename']?></h3>
                    <ul>
                        <li><span>提供快速专业的QQ空间秒赞秒评服务 <?php echo $conf['sitename']?>,独家高端稳定平台，是您不二的选择.</span></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h3>系统帮助</h3>
                    <ul>
                        <li><a href="index.php?mod=help"></a></li>
                        <li><a href="index.php?mod=help"></a></li>
                        <li><a href="index.php?mod=help"></a></li>
                        <li><a href="index.php?mod=help"></a></li>
                        <li><a href="index.php?mod=help"></a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h3>自助服务</h3>
                    <ul>
                        <li><a href="index.php?mod=search&q=<?php echo $conf['kfqq']?>">秒赞认证</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h3>关于我们</h3>
                    <ul>
                      <p><i class="fa fa-phone"></i>站长QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" target="_blank"><?php echo $conf['kfqq']?></a></p>
					  <p><i class="fa fa-envelope"></i><?php echo $conf['kfqq']?>@qq.com</p>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
    <!-- Footer End -->
    <div class="thn">
         <div class="container thn">
            <div class="row">
                <div class="blete-footer-content">

                    <h6 class="blete-copyright-info">©2017  <a href="http://www.92xhao.cn/" target="_blank" title="模板之家">筱豪</a></h6>

                </div>
            </div>
        </div>
    </div>


    <!-- =============================
                SCRIPTS
    ================================== -->
   <script src="assets/xh1/js/jquery-1.11.3.min.js"></script>
    <script src="assets/xh1/js/bootstrap.min.js"></script>
    <script src="assets/xh1/js/modernizr.min.js"></script>
    <script src="assets/xh1/js/jquery.easing.1.3.js"></script>
    <script src="assets/xh1/js/jquery.scrollUp.min.js"></script>
    <script src="assets/xh1/js/jquery.easypiechart.js"></script>
    <script src="assets/xh1/js/jquery.countTo.js"></script>
    <script src="assets/xh1/js/isotope.pkgd.min.js"></script>
    <script src="assets/xh1/js/jflickrfeed.min.js"></script>
    <script src="assets/xh1/js/jquery.fitvids.js"></script>
    <script src="assets/xh1/js/jquery.stellar.min.js"></script>
    <script src="assets/xh1/js/jquery.waypoints.min.js"></script>
    <script src="assets/xh1/js/wow.min.js"></script>
    <script src="assets/xh1/js/jquery.nav.js"></script>
    <script src="assets/xh1/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/xh1/js/smooth-scroll.min.js"></script>
    <script src="assets/xh1/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/xh1/js/jquery.sliderPro.min.js"></script>
    <script src="assets/xh1/js/owl.carousel.min.js"></script>
    <script src="assets/xh1/js/custom.js"></script>

</body>
</html>
