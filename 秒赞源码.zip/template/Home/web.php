<?php
if(!defined('IN_CRONLITE'))exit();
$title="站点搭建";
include_once(TEMPLATE_ROOT."head.php");
echo'<div class="col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-fw fa-pencil"></i> <strong>站点搭建</strong>
</div>
<div class="widget-content padded">
<div class="form-group">
<label class="label label-primary">搭建分站</label>
<p>搭建费100元，之后无需再续费，挂Q数量无限，无需域名和服务器即可在线开通，可绑定域名，不提供源码。</p>
</div>
<div class="form-group">
<label class="label label-primary">购买主站</label>
<p>商业版源码，完整开源，费用288元，绑定一个顶级域名，不限制二级域名使用，包含免签约在线支付接口，更新维护二年。</p>
<p class="text-danger">购买程序源码均赠送可用于Android系统的APP。</p>
</div>
<div class="form-group">
<label class="label label-primary">主站和分站的区别？</label>
<p>分站：开放部分功能，站点依靠在主站，不提供源码不可修改界面，适合小型个人站点，利润无限，可无限收取下级；</p>
<p>主站：开放所有功能，提供源码搭建秒赞系统，可开设分站、招收代理商、设置广告位等，每2年收取授权费，适合商业运营，利润无限；</p>
</div>
<div class="form-group">
<label class="label label-primary">演示站点</label>
<p>与本站功能、界面一致。</p>
</div>
<div class="form-group">
<label class="label label-primary">购买方式</label>
<p>QQ：'.$conf['kfqq'].'，直接说事，不议价。</p>
</div>
</div>
</div>
</div>';
include TEMPLATE_ROOT."foot.php";
?>