<?php
if(!defined('IN_CRONLITE'))exit();
$title="用户中心";
include_once(TEMPLATE_ROOT."head.php");
$qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1"); //获取QQ数量
$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1"); //获取用户数量

?>
<?php $gg=$conf['gg'];
echo '<div class="col-sm-6 col-lg-6">
<div class="widget">
<div class="widget-content themed-background text-light-op w h">
网站公告
</div>
'.$gg.'
</div>
</div>'?>
<?php echo'<div class="col-sm-6 col-lg-6">
                            <a  class="widget">
                                <div class="widget-content themed-background text-light-op w h">
                                    <span class="pull-right text-muted">QQ:'.$row['qq'].'</span> UID:'.$row['userid'].'
                                </div>
                                <div class="widget-content border-bottom text-center themed-background-muted">';?>
                                    <?php echo'<img src="//q4.qlogo.cn/headimg_dl?dst_uin='?><?php if($islogin==1) echo $row['qq']?><?php if($islogin==0) echo $conf['kfqq']?><?php echo'&spec=100" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">'?>
                                    <?php echo'<h2 class="widget-heading h3 text-dark">
                                        '.$row['user'].'</h2>
                                    <span class="text-muted"><strong>用户权限：</strong>'?><?php echo''.usergroup().''?>
									<?php echo'</span>
                                </div>
                                <div class="widget-content widget-content-full-top-bottom">
                                    <div class="row text-center">
                                        <div class="col-xs-6 push-inner-top-bottom border-right">
                                            <h3 class="widget-heading">
                                                <i class="fa fa-user text-dark push-bit"></i>
												<br>'?>
												<?php echo'<font size="2">用户名</font><br>
                                                <small>'?><?php if ($islogin==1) echo $row['user']?><?php if($islogin==0) echo 'No Login'?><?php echo'</small></h3>'?>
                                        <?php echo'</div>
                                        <div class="col-xs-6 push-inner-top-bottom">
                                            <h3 class="widget-heading">
                                                <i class="fa fa-qq text-dark push-bit"></i>
                                                <br>'?>
												<?php echo'<font size="2">QQ数量</font><br>
                                                <small>'?><?php echo''.$row['qqnum'].'个</small></h3>
                                        </div>
                                    </div>
                                </div>
								<div class="widget-content widget-content-full-top-bottom">
                                    <div class="row text-center">
                                        <div class="col-xs-6 push-inner-top-bottom border-right">
                                            <h3 class="widget-heading">
                                                <i class="fa fa-dollar text-dark push-bit"></i>
                                                <br>'?>
												<?php echo'<font size="2">'.$conf['coin_name'].'</font><br>
                                                <small>'?><?php echo''.$row['coin'].'个</small></h3>
                                        </div>
                                        <div class="col-xs-6 push-inner-top-bottom">
                                            <h3 class="widget-heading">
                                                <i class="fa fa-dollar text-dark push-bit"></i>
                                                <br><font size="2">VIP信息</font><br>
                                                <small>'?><?php if($isvip==1) echo'<font color="green">'.$row['vipdate'].'</font>'?><?php if($isvip==2) echo '<font color="red">永久VIP</font>'?><?php if($isvip==0) echo '非VIP'?><?php echo'</small></h3>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                        '?>

<?php echo'
<div class="col-sm-12 col-md-12 col-lg-6">
<div class="widget">
<div class="widget-content themed-background text-light-op w h">
<span class="pull-right text-muted"><a href="http://wpa.qq.com/msgrd?v=3&amp;uin='?><?php echo $conf['kfqq']?><?php echo'&amp;site=qq&amp;menu=yes" target="_blank">举报!</a></span>
商业广告
</div>
<div class="widget-content border-bottom">'?>
<?php echo $conf['bottom'];?><?php echo'</div></div></div>'?>
<?php echo'

<div class="col-sm-12 col-md-12 col-lg-6">
<div class="widget">
       <div class="widget-content themed-background text-light-op w h">
          <a href="index.php?mod=mzq" ui-sref="mzq" class="pull-right label label-danger">QQ秒赞墙</a>
          <div class="panel-title">最新秒赞QQ</div>
       </div>
       <div data-height="180" data-scrollable="" class="list-group">
          <div class="list-group-item bb">
             <div class="media-box">
'?>
<?php //获取最新QQ列表
$liukay=$DB->query("select qq,time from ".DBQZ."_qq order by id desc limit 7");
while ($lingku = $DB->fetch($liukay))
{
echo '
<div class="list-group-item bb">
             <div class="media-box">
			 <div class="pull-left">
                   <img src="http://q1.qlogo.cn/g?b=qq&nk='.$lingku['qq'].'&s=100" alt="Image" class="media-box-object img-circle thumb35">
                </div>
				<div class="media-box-body clearfix">
                   <a target="_blank" href="cqy.php?'.$lingku['qq'].'" class="label label-info pull-right" style="margin-top:8px;">加为好友</a>
                   <strong class="media-box-heading text-primary">
                      <span class="circle circle-success circle-lg text-left"></span>'.$lingku['qq'].'</strong>
                   <p class="mb-sm">
                      <small><i class="fa fa-clock-o"></i> '.$lingku['time'].'</small>
                   </p>
                </div>
</div>
          </div>
';
}
?>
<?php echo '
</div>
</div>
</div>
</div>
</div>
'?>

<?php
include TEMPLATE_ROOT."foot.php";
?>