<?php global $zym_decrypt;$zym_decrypt['�֮�����î����֯�þ��Į���֥����']=base64_decode('ZGVmaW5lZA==');$zym_decrypt['���������֔֋����Ď�֋��È������']=base64_decode('ZnVuY3Rpb25fZXhpc3Rz');$zym_decrypt['Į�����������þ�������ĥ������ċ']=base64_decode('c3lzX2dldGxvYWRhdmc=');$zym_decrypt['����֯È���Ë���å��֋��þ������']=base64_decode('c2hvd21zZw=='); ?>
<?php
 if(!$GLOBALS['zym_decrypt']['�֮�����î����֯�þ��Į���֥����'](base64_decode('SU5fQ1JPTkxJVEU=')))exit();$title="代理后台";$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li class="active"><a href="#"><i class="icon fa fa-cog"></i>代理后台</a></li>';include TEMPLATE_ROOT.base64_decode('aGVhZC5waHA=');echo base64_decode('PGRpdiBjbGFzcz0iY29sLW1kLTEwIGNvbC1tZC1vZmZzZXQtMSBjb2wtbGctOCBjb2wtbGctb2Zmc2V0LTIiIHJvbGU9Im1haW4iPg==');if ($isdaili==1){echo '<div class="panel panel-primary">';echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSIgYWxpZ249ImNlbnRlciI+5oiR55qE5Luj55CG5L+h5oGvPC9oMz48L2Rpdj48ZGl2IGNsYXNzPSJwYW5lbC1ib2R5Ij4=');echo base64_decode('PGxpIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPuS7o+eQhuetiee6p++8mjxmb250IGNvbG9yPSJvcmFuZ2UiPumHkeeJjOS7o+eQhjwvZm9udD48L2xpPg==');echo base64_decode('PGxpIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPui0puaIt+WJqeS9meWPr+eUqOS9memine+8mjxmb250IGNvbG9yPSJyZWQiPg==').$row['daili_rmb'].'</font> RMB</li>';echo base64_decode('PGxpIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPuS7o+eQhu+8se+8se+8mjxmb250IGNvbG9yPSJyZWQiPg==').$row['qq'].'</font> <a href="index.php?mod=userinfo">[修改]</a></li>';echo base64_decode('PC9kaXY+PC9kaXY+');echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwgcGFuZWwtcHJpbWFyeSI+PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSIgYWxpZ249ImNlbnRlciI+5Y2h5a+G566h55CGPC9oMz48L2Rpdj48ZGl2IGNsYXNzPSJwYW5lbC1ib2R5Ij4=');echo base64_decode('PGEgaHJlZj0iaW5kZXgucGhwP21vZD1hZG1pbi1rbWxpc3QyJmtpbmQ9MSIgY2xhc3M9ImJ0biBidG4tZGVmYXVsdCBidG4tYmxvY2siPuWFheWAvOWNoeWNoeWvhueuoeeQhjwvYT4KPGEgaHJlZj0iaW5kZXgucGhwP21vZD1hZG1pbi1rbWxpc3QyJmtpbmQ9MiIgY2xhc3M9ImJ0biBidG4tZGVmYXVsdCBidG4tYmxvY2siPlZJUOWNoSDljaHlr4bnrqHnkIY8L2E+CjxhIGhyZWY9ImluZGV4LnBocD9tb2Q9YWRtaW4ta21saXN0MiZraW5kPTQiIGNsYXNzPSJidG4gYnRuLWRlZmF1bHQgYnRuLWJsb2NrIj7phY3pop3ljaHljaHlr4bnrqHnkIY8L2E+');echo base64_decode('PC9kaXY+PC9kaXY+');if($conf['alipay_api']||$conf['tenpay_api']||$conf['wxpay_api']||$conf['qqpay_api']){echo '<div class="panel panel-primary">';echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSIgYWxpZ249ImNlbnRlciI+5Zyo57q/5YWF5YC85L2Z6aKdPC9oMz48L2Rpdj48ZGl2IGNsYXNzPSJwYW5lbC1ib2R5Ij4=');echo base64_decode('PGRpdiBjbGFzcz0iZm9ybS1ncm91cCI+CjxpbnB1dCB0eXBlPSJ0ZXh0IiBjbGFzcz0iZm9ybS1jb250cm9sIiBuYW1lPSJ2YWx1ZSIgYXV0b2NvbXBsZXRlPSJvZmYiIHBsYWNlaG9sZGVyPSLovpPlhaXopoHlhYXlgLznmoTkvZnpop0iPjwvZGl2PjxkaXYgY2xhc3M9ImZvcm0tZ3JvdXAgdGV4dC1jZW50ZXIiPg==');if($conf['alipay_api'])echo '<button type="submit" class="btn btn-default" id="buy_alipay"><img src="images/icon/alipay.ico" class="logo">支付宝</button>&nbsp;';if($conf['qqpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_qqpay"><img src="images/icon/qqpay.ico" class="logo">QQ钱包</button>&nbsp;';if($conf['wxpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_wxpay"><img src="images/icon/wechat.ico" class="logo">微信支付</button>&nbsp;';if($conf['tenpay_api'])echo '<button type="submit" class="btn btn-default" id="buy_tenpay"><img src="images/icon/tenpay.ico" class="logo">财付通</button>&nbsp;';echo base64_decode('PC9kaXY+');echo base64_decode('PC9kaXY+PC9kaXY+');}?>
<script>
$(document).ready(function(){
$("#buy_alipay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	ajax.get("ajax.php?mod=shop&act=pay&type=alipay&shopid=11&qq="+value, "html", function(data) {
		$('#myDiv').html(data);
		$('#shop').modal('show');
	});
});
$("#buy_qqpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	ajax.get("ajax.php?mod=shop&act=pay&type=qqpay&shopid=11&qq="+value, "html", function(data) {
		$('#myDiv').html(data);
		$('#shop').modal('show');
	});
});
$("#buy_wxpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	ajax.get("ajax.php?mod=shop&act=pay&type=wxpay&shopid=11&qq="+value, "html", function(data) {
		$('#myDiv').html(data);
		$('#shop').modal('show');
	});
});
$("#buy_tenpay").click(function(){
	var value=$("input[name='value']").val();
	if(value=='' || value==0){alert('充值金额不能为空');return false;}
	ajax.get("ajax.php?mod=shop&act=pay&type=tenpay&shopid=11&qq="+value, "html", function(data) {
		$('#myDiv').html(data);
		$('#shop').modal('show');
	});
});
});
</script>
<?php
 $qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1");$qqjobs=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE 1");$signjobs=$DB->count("SELECT count(*) from ".DBQZ."_signjob WHERE 1");$wzjobs=$DB->count("SELECT count(*) from ".DBQZ."_wzjob WHERE 1");$zongs=$qqjobs+$signjobs+$wzjobs;$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1");echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwgcGFuZWwtcHJpbWFyeSI+PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSI+6L+Q6KGM5pel5b+XOiZuYnNwJm5ic3A8YSBocmVmPSJpbmRleC5waHA/bW9kPWFsbCI+6K+m57uGPj48L2E+PC9oMz48L2Rpdj48ZGl2IGNsYXNzPSJwYW5lbC1ib2R5Ij7ns7vnu5/lhbHmnIk8Zm9udCBjb2xvcj0iI2ZmMDAwMCI+').$zongs.'</font>条任务<br>共有<font color="#ff0000">'.$qqs.'</font>个QQ正在挂机<br>系统累计运行了<font color="#ff0000">'.$info['times'].'</font>次<br>上次运行:<font color="#ff0000">'.$info['last'].'</font><br>当前时间:<font color="#ff0000">'.$date.'</font></div>';if($GLOBALS['zym_decrypt']['���������֔֋����Ď�֋��È������'](base64_decode('c3lzX2dldGxvYWRhdmc='))){echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSI+57O757uf6LSf6L29OjwvaDM+PC9kaXY+');$f=$GLOBALS['zym_decrypt']['Į�����������þ�������ĥ������ċ']();echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtYm9keSI+');echo "1min:{$f[0]}";echo "|5min:{$f[1]}";echo "|15min:{$f[2]}";echo base64_decode('PC9kaXY+');}echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtaGVhZGluZyI+PGgzIGNsYXNzPSJwYW5lbC10aXRsZSI+5pWw5o2u57uf6K6hOjwvaDM+PC9kaXY+');echo base64_decode('PGRpdiBjbGFzcz0icGFuZWwtYm9keSI+');echo base64_decode('57O757uf5YWx5pyJ').$users.'个用户<br/>';include(ROOT.base64_decode('aW5jbHVkZXMvY29udGVudC90b25namkucGhw'));echo base64_decode('PC9kaXY+PC9kaXY+');}else {$GLOBALS['zym_decrypt']['����֯È���Ë���å��֋��þ������'](base64_decode('5Luj55CG5ZCO5Y+w55m75b2V5aSx6LSl44CC6K+35Lul5Luj55CG6Lqr5Lu9IDxhIGhyZWY9ImluZGV4LnBocD9tb2Q9bG9naW4mZGFpbGk9MSI+6YeN5paw55m75b2VPC9hPu+8jOaIluiBlOezu+ermemVv+i0reS5sOS7o+eQhui6q+S7ve+8gQ=='),3);}include TEMPLATE_ROOT.base64_decode('Zm9vdC5waHA=');?>