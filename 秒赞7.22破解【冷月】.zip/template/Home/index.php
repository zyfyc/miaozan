﻿<?php
if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');
$qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1"); //获取QQ数量
$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1"); //获取用户数量

$qqjobs=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE 1");
$signjobs=$DB->count("SELECT count(*) from ".DBQZ."_signjob WHERE 1");
$wzjobs=$DB->count("SELECT count(*) from ".DBQZ."_wzjob WHERE 1");
$zongs=$qqjobs+$signjobs+$wzjobs; //获取总任务数量
$info['times']; //系统累计运行的次数

$yxts=ceil((time()-strtotime($conf['build']))/86400); //本站已运行多少天
$url='//'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
$url= dirname($url);
if($is_fenzhan==1) $logoname = DBQZ;else $logoname = '';
if(!file_exists(ROOT.'images/'.$logoname.'logo.png')) $logoname='';

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $conf['sitename'].$conf['sitetitle']?></title>
<meta name="description" content="<?php echo $conf['description']?>">
<meta name="keywords" content="<?php echo $conf['keywords']?>">
<meta name="generator" content="CH23" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href='https://apps.bdimg.com/libs/fontawesome/4.4.0/css/font-awesome.min.css' rel="stylesheet">
<link rel="stylesheet" href='https://apps.bdimg.com/libs/bootstrap/3.3.4/css/bootstrap.min.css'/>
<link rel="stylesheet" href='assets/CH23/css/app.css' />
</head>

<body>

<section class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-6 col-xs-6 logo">
                <a href="#"><i class="fa fa-thumbs-o-up"></i><?php echo $conf['sitename']?></a>
            </div>
            <div class="col-md-10 col-sm-6 col-xs-6 nav-top">
                <ul>
                    <li class="link" style="margin-left:10px;"><a href="index.php?mod=reg">注册</a></li>
                    <li class="link" style="margin-left:10px;"><a href="index.php?mod=login">登录</a></li>
                    <li class="hidden-sm hidden-xs"><a href="http://www.xuanyangsq.cn" rel="nofollow"><i class="fa fa-search-plus"></i> 正版查询</a></li>
                    <li class="hidden-sm hidden-xs"><a href="index.php?mod=dlyz"><i class="fa fa-search"></i> 代理验证</a></li>
                    <li class="hidden-sm hidden-xs"><a href="index.php?mod=user"><i class="fa fa-user"></i> 用户中心</a></li>
                    <li class="hidden-sm hidden-xs"><a href="#"><i class="fa fa-home"></i> 首页</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="index-bg">
    <div class="container">
            <div class="index-bg-text">
                <h1>
                    <p><?php echo $conf['sitename']?></p>
					<h3>稳定实时／离线使用／简单上手</h3>
                </h1>
                <p class="i">致力为广大用户打造QQ空间离线稳定点赞平台</p>
				<?php if($islogin==1){?>
				<a href="index.php?mod=user" class="btn btn-lg btn-success btn-more">欢迎回来:<?php echo $row['user']?></a>
				<?php }else{?>
				<a href="index.php?mod=login" class="btn btn-lg btn-info btn-more">立即登录</a>
                <a href="index.php?mod=reg" class="btn btn-lg btn-info btn-more">立即注册</a>
				<?php } ?>

            </div>
    </div>
</section>

<section class="index-service">
    <div class="container">
        <h2>专业提供优质的秒赞秒评等离线服务</h2>
        <div class="row">
            <div class="col-md-4">
                <h3>稳定使用</h3>
                <p>无需秒赞软件，无需设备挂机！支持自动更新，完美离线使用，快来一起秒赞吧。</p>
            </div>
            <div class="col-md-2" style="border-right:1px solid #eee">
                <span class="fa fa-thumbs-o-up"></span>
            </div>
            <div class="col-md-4 col-md-offset-1">
                <h3>分布执行</h3>
                <p>分布多台服务器各自执行各自功能，再也无需担心因为平台QQ增多而影响到效率。</p>
            </div>
            <div class="col-md-1">
                <span class="fa fa-rocket"></span>
            </div>
        </div>
		        <div class="row" style="margin-top:30px;">
            <div class="col-md-4">
                <h3>节省流量</h3>
                <p>不再需要消耗流量下载秒赞软件，不再需要消耗流量挂机，直接平台一键操作！</p>
            </div>
            <div class="col-md-2" style="border-right:1px solid #eee">
                <span class="fa fa-wifi"></span>
            </div>
            <div class="col-md-4 col-md-offset-1">
                <h3>设备兼容</h3>
                <p>采用响应式设计，无论电脑、手机、平板均可使用，都会自动适应您的设备。</p>
            </div>
            <div class="col-md-1">
                <span class="fa fa-laptop"></span>
            </div>
        </div>
    </div>
</section>

<section class="index-device">
    <div class="container">
        <h2>因为稳定 他们信赖<p>我们已有<?php echo $users;?>位用户和<?php echo $qqs;?>个QQ</p></h2>
        <ul>
            <div>
                <?php
                    $liukay=$DB->query("select qq,time from ".DBQZ."_qq order by id desc limit 24");
                    while ($lingku = $DB->fetch($liukay)){
                ?>
                    <div class="col-sm-2 col-xs-4 scrollpoint sp-effect1">
                        <div class="media">
                            <a class="pull-lefts" title="QQ：<?php echo $lingku['qq'] ;?> 添加时间：<?php echo $lingku['time'] ;?>"><img class="media-object img-circle" src="//q1.qlogo.cn/g?b=qq&nk=<?php echo $lingku['qq'] ;?>&s=100" alt="<?php echo $lingku['qq'] ;?>"></a>
                        </div>
                    </div>
                <?php } ?>
		    </div>
</section>
<section class="index-process">
    <div class="container">
        <div class="row">
            <h2><?php echo $conf['sitename']?>简约而不简单</h2>
            <div class="col-md-2">
                <i><span class="glyphicon glyphicon">①</span></i>
                <p>注册<?php echo $conf['sitename']?></p>
            </div>
            <div class="col-md-2">
                <i><span class="glyphicon glyphicon">②</span></i>
                <p>登陆<?php echo $conf['sitename']?></p>
            </div>
            <div class="col-md-2">
                 <i><span class="glyphicon glyphicon">③</span></i>
                <p>添加您的QQ账号</p>
            </div>
            <div class="col-md-2">
                  <i><span class="glyphicon glyphicon">④</span></i>
                <p>免费开启秒赞服务</p>
            </div>
            <div class="col-md-2">
                 <i><span class="glyphicon glyphicon">⑤</span></i>
                <p>开始您的离线之旅</p>
            </div>
            <div class="col-md-2">
                  <i><span class="glyphicon glyphicon">⑥</span></i>
                <p>向好友推荐本站</p>
            </div>
        </div>
    </div>
</section>
<section class="index-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-1 col-sm-6">
                <dl>
                    <dt>相关链接</dt>
                    <dd><a href="http://www.xuanyangsq.cn/" rel="nofollow">授权认证</a></dd>
					<dd><a href="index.php?mod=user">用户中心</a></dd>
                    <dd><a href="index.php?mod=reg">我要注册</a></dd>
                    <dd><a href="index.php?mod=login">我要登陆</a></dd>
                </dl>
            </div>
            <div class="col-md-4 col-sm-6">
                <dl>
                    <dt>站点信息</dt>
                    <dd>运营天数：<?php echo $yxts;?>个</dd>
					<dd>用户数量：<?php echo $users;?>个</dd>
                    <dd>扣扣数量：<?php echo $qqs;?>个</dd>
                    <dd>站长扣扣：<?php echo $conf['kfqq']?></dd>
                </dl>
            </div>
            <div class="col-md-3 hidden-sm hidden-xs">
                <dl>
                    <dt>联系我们</dt>
                    <dd>
                        <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $conf['kfqq']?>&amp;site=qq&amp;menu=yes">
                            <img border="0" src="assets/CH23/images/qqzx.png" alt="联系站长" title="联系站长">
                        </a>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
</section>
<section class="footer">
    Copyright &copy; 2018 <a href="./"><?php echo $conf['sitename']?></a>版权所有
</body>
</html>