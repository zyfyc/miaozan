<!-- Start: Header -->
    <div id="page-wrapper" class="page-loading">
        <div class="preloader">
            <div class="inner">
                <div class="preloader-spinner themed-background hidden-lt-ie10">
                </div>
                <h3 class="text-primary visible-lt-ie10">
                    <strong>LiuYue-Ajax..</strong></h3>
            </div>
        </div>
        <div id="page-container" class="header-fixed-top sidebar-visible-lg-full enable-cookies">

            <div id="sidebar">
                <div id="sidebar-brand" class="themed-background">
<a href="#" class="sidebar-title">
<style>
strong{font-family:"微软雅黑",Georgia,Serif;}
</style>
<i class="fa fa-thumbs-up"></i> <span class="sidebar-nav-mini-hide"><strong><?php echo $conf['sitename']?></strong></span>
</a>
</div>
                <div id="sidebar-scroll">
                    <div class="sidebar-content">
                        <ul class="sidebar-nav">
                        <?php if($islogin==1) {?>
<li>
	<li>
		<a id="yonghu" class="<?php echo ''.checkIfActive("user").'' ?>" onclick="activeselect(this)" href="index.php?mod=user">
			<i class="fa fa-gittip sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">用户中心</span>
		</a>
	</li>
</li>
<?php if($isadmin==1 || $isdeputy==1){?>
<li>
	<li>
		<a id="houtai" class="<?php echo ''.checkIfActive("admin").'' ?>" onclick="activeselect(this)" href="index.php?mod=admin">
			<i class="fa fa-wrench sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">后台管理</span>
		</a>
	</li>
</li>
<?php }?>

<!-- PHP:判断开始 是否代理 -->
<?php if($isdaili==1){?>
<li>
	<li>
		<a id="houtai" class="<?php echo ''.checkIfActive("admin-adili").'' ?>" onclick="activeselect(this)" href="index.php?mod=admin-daili">
			<i class="fa fa-wrench sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">代理后台</span>
		</a>
	</li>
</li>
<?php }?>
<!-- PHP:判断结束 是否代理 -->

<?php if(OPEN_SIGN==1){?>
<li>
	<li>
		<a id="qiandao" class="<?php echo ''.checkIfActive("list-sign").'' ?>" onclick="activeselect(this)" href="index.php?mod=list-sign">
			<i class="fa fa-cloud sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">自动签到</span>
		</a>
	</li>
</li>
<?php }?>
<li>
	<li>
		<a id="qiandao" class="<?php echo ''.checkIfActive("chat").'' ?>" onclick="activeselect(this)" href="index.php?mod=chat">
			<i class="fa fa-commenting sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">交友聊天</span>
		</a>
	</li>
</li>

<li>
	<li>
		<a id="qiandao" class="<?php echo ''.checkIfActive("qqlist").checkIfActive("list-qq").'' ?>" onclick="activeselect(this)" href="index.php?mod=qqlist">
			<i class="fa fa-qq sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">ＱＱ管理</span>
		</a>
	</li>
<li class="<?php echo ''.checkIfActive("qqlist").checkIfActive("list-qq").'' ?>">
<a  href="javascript:void(0)" id="other" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-navicon sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">已添加QQ</span></a>
<ul>

<?php
$gls=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE qq='{$qq}'");
$pagesize=$conf['pagesize'];
if (!isset($_GET['page'])) {
	$page = 1;
	$pageu = $page - 1;
} else {
	$page = $_GET['page'];
	$pageu = ($page - 1) * $pagesize;
}
$act=isset($_GET['act'])?$_GET['act']:null;
$qq=daddslashes($_GET['qq']);
$qqrow=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
	if($qq=daddslashes($_GET['qq']))
		$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' order by id desc limit $pageu,$pagesize");
$rs=$DB->query("SELECT * FROM ".DBQZ."_qq WHERE uid='{$uid}' order by id desc limit $pageu,$pagesize");
while($myrow = $DB->fetch($rs))
{
$i++;
$pagesl = $i + ($page - 1) * $pagesize;
echo '<li>
<a href="index.php?mod=list-qq&qq='.$myrow['qq'].$link.'" title="进入任务管理"><i class="fa fa-qq"></i> '.$myrow['qq'].$link.'</a>
</li>
';}

?>
</ul>
</li>
</li>
<li class="sidebar-separator">
<i class="fa fa-ellipsis-h"></i>
</li>
<li>
	<li>
		<a id="vip" class="<?php echo ''.checkIfActive("shop").'' ?>" onclick="activeselect(this)" href="index.php?mod=shop">
			<i class="fa fa-shopping-cart sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">自助商城</span>
		</a>
	</li>
</li>
<li>
<li>
	<a id="vip" class="<?php echo ''.checkIfActive("dama").'' ?>" onclick="activeselect(this)" href="index.php?mod=dama">
		<i class="fa fa-send sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">协助打码</span>
	</a>
</li>
</li>
<li>
<li>
	<a id="web" class="<?php echo ''.checkIfActive("web").'' ?>" onclick="activeselect(this)" href="index.php?mod=web">
		<i class="fa fa-internet-explorer sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">网站搭建</span>
	</a>
</li>
</li>
<li>
<li>
	<a id="web" class="<?php echo ''.checkIfActive("mzq").'' ?>" onclick="activeselect(this)" href="index.php?mod=mzq">
		<i class="fa fa-bookmark sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">ＣＱＹ墙</span>
	</a>
</li>
</li>
<li>
<li>
<!-- PHP：判断开始 - 是否副站长 !-->
<?php if($isdeputy==1){?>
<!-- PHP：判断结束 - 是否副站长 !-->
<li>
	<a id="fuzhan" class="<?php echo ''.checkIfActive("admin").'' ?>" onclick="activeselect(this)" href="index.php?mod=admin">
		<i class="fa fa-wrench  sidebar-nav-icon"></i>
		<span class="sidebar-nav-mini-hide">副站后台</span>
	</a>
</li>
<?php }?>
</li>
</li>

<li>
<a href="javascript:void(0)" id="other" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-navicon sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">其他功能</span></a>
<ul>
<!-- 如有需要，自行添加 -->
<li >
<a id="info" class="<?php echo ''.checkIfActive("userinfo").'' ?>" onclick="activeselect(this)" href="index.php?mod=userinfo"><i class="fa fa-user sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">个人资料</span></a>
</li>
<?php if(OPEN_CRON==1){?>
<li>
	<li>
		<a id="qiandao" class="<?php echo ''.checkIfActive("syslist").checkIfActive("list-wz").'' ?>" onclick="activeselect(this)" href="index.php?mod=list-wz">
			<i class="fa fa-cloud sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">网址监控</span>
		</a>
	</li>
</li>
<?php }?>
</ul>
</li>
<li>
<a id="freevip" class="<?php echo ''.checkIfActive("free").'' ?>" onclick="activeselect(this)" href="index.php?mod=free"><i class="fa fa-coffee sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">领取免费会员</span></a>
</li>

<li >
<a id="qd" class="<?php echo ''.checkIfActive("qd").'' ?>" onclick="activeselect(this)" href="index.php?mod=qd"><i class="fa fa-table sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">每日签到有好礼</span></a>
</li>

<li>
<a id="yq" class="<?php echo ''.checkIfActive("invite").'' ?>" onclick="activeselect(this)" href="index.php?mod=invite"><i class="fa fa-user-plus sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">邀请好友领Vip</span></a>
</li>

<li>
<a id="bz" class="<?php echo ''.checkIfActive("help").'' ?>" onclick="activeselect(this)" href="index.php?mod=help"><i class="fa fa-heart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">平台使用帮助</span></a>
</li>
<li>
<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes"><i class="fa fa-comments sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">联系站长</span></a>
</li>
<?php }?>
<?php if($islogin==0) {?>
<li>
	<li>
		<a id="denglu" class="<?php echo ''.checkIfActive("login").'' ?>" onclick="activeselect(this)" href="index.php?mod=login">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">登陆</span>
		</a>
	</li>
</li>
<li>
	<li>
		<a id="zhuce" class="<?php echo ''.checkIfActive("lyreg").'' ?>" onclick="activeselect(this)" href="index.php?mod=lyreg">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">注册</span>
		</a>
	</li>
</li>
<li>
	<li>
		<a id="zhaohui" class="<?php echo ''.checkIfActive("findpwd").'' ?>" onclick="activeselect(this)" href="index.php?mod=findpwd">
			<i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">找回密码</span>
		</a>
	</li>
</li>
<li>
<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes"><i class="fa fa-power-off sidebar-nav-icon"></i>
			<span class="sidebar-nav-mini-hide">联系站长</span></a>
</li>
<?php }?>
                        </ul>
                    </div>
                </div>
                <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
<div class="progress progress-mini push-bit">
<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
</div>
<div class="text-center">
<small class="hidden-xs"><a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $conf['kfqq']?>&amp;site=qq&amp;menu=yes" target="_blank">站长QQ：<?php echo $conf['kfqq']?></a><br></small>
<small><span id="year-copy">2015-17</span> © <a href="#" target="_blank"><?php echo $conf['sitename']?></a><br/>程序版本：7141</small>
</div>
</div>
            </div>
            <div id="main-container">
                <header class="navbar navbar-inverse navbar-fixed-top">

<ul class="nav navbar-nav-custom">

<li>
<a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');this.blur();">
<i class="fa fa-ellipsis-v fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
<i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>菜单
</a>
</li>
<li>
<a href="javascript:void(0)" onclick="javascript:history.go(-1);">
<i class="fa fa-reply fa-fw animation-fadeInRight"></i> 返回
</a>
</li>

</ul>


<ul class="nav navbar-nav-custom pull-right">
<?php if($conf['ui_flat']==0) {?>
<li>
<form action="index.php" method="get" class="navbar-form-custom" role="search">
<input type="hidden" name="mod" value="search">
<input type="text" id="top-search" name="q" onkeyup="value=value.replace(/[^1234567890-]+/g,'')" class="form-control" placeholder="搜索秒赞QQ..">
</form>
</li>
<?php }?>
<li class="dropdown">
<a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
<img src="../favicon.png" alt="avatar">
</a>
<ul class="dropdown-menu dropdown-menu-right">
<li class="dropdown-header text-center">
<strong><?php echo $row['user']?></strong>
</li>
<?php if($islogin==1){?>
<li>
<a href="index.php?mod=userinfo">
<i class="fa fa-inbox fa-fw pull-right"></i>
个人资料
</a>
</li>
<li>
<a href="index.php?mod=set&my=mm">
<i class="fa fa-pencil-square fa-fw pull-right"></i>
密码修改
</a>
</li>
<li class="divider">
</li>
<li>
<li>
<a href="index.php?mod=help">
<i class="fa fa-info fa-fw pull-right"></i>
使用教程
</a>
</li>
<li class="divider">
</li>
<li>
<li>
<a href="index.php?my=loginout">
<i class="fa fa-power-off fa-fw pull-right"></i>
注销登录
</a>
</li>
<?php }?>
<?php if($islogin==0) {?>
<li>
<a href="index.php?mod=login">
<i class="fa fa-power-off fa-fw pull-right"></i>
马上登陆
</a>
</li>
<li>
<a href="index.php?mod=lyreg">
<i class="fa fa-power-off fa-fw pull-right"></i>
马上注册
</a>
</li>
<?php }?>
</ul>
</li>
</ul>
</header>
<div id="page-content">
		<div id="myDiv"></div>
			<div class="main pjaxmain">
				<div class="content-header">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="header-section">
                                    <h1><?php echo $title ?></h1>
                                </div>
                            </div>
                        </div>
				</div>
<div class="row">
<?php unset($already);?>