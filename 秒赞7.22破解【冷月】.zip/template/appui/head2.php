﻿<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');

$sitename=$conf['sitename'];

if($title=='首页' || empty($title))
$titlename=$sitename.' '.$conf['sitetitle'];
else
$titlename=$title.'|'.$sitename.' '.$conf['sitetitle'];

?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="charset" content="utf-8">
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $titlename?></title>
<meta name="keywords" content="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $conf['keywords']?>" />
<meta name="description" content="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $conf['description']?>" />
<link rel="shortcut icon" href="images/favicon.ico">
	<link href="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $cdnserver?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $cdnserver?>assets/css/login.css" rel="stylesheet" >
    <link href="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $cdnserver?>assets/css/alert.css" rel="stylesheet" />
    <script src="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $cdnserver?>assets/vendor/js/jquery-2.1.4.min.js"></script>
    <script src="<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $cdnserver?>assets/js/alert.js"></script>
</head>
<body>