<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();

if($islogin==1){
	$image=trim($_POST['image']);
	$data=get_curl('http://qr.flyqy.cn/AddQQ_Ajax.php?image='.urlencode($image));
	$arr=json_decode($data,true);
	if($arr['code']==1) {
		exit('{"code":0,"msg":"succ","url":"'.$arr['url'].'"}');
	}elseif(array_key_exists('msg',$arr)){
		exit('{"code":-1,"msg":"'.$arr['msg'].'"}');
	}else{
		exit('{"code":-1,"msg":"'.$data.'"}');
	}
}else{
	exit('{"code":-1,"msg":"登录失败，可能是密码错误或者身份失效了，请重新登录！"}');
}

?>