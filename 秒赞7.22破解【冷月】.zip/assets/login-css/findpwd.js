var yunyan={
	post: function(url, parameter, callback, dataType, ajaxType) {
		if(!dataType) dataType='json';
		$.ajax({
			type: "POST",
			url: url,
			async: true,
			dataType: dataType,
			json: "callback",
			data: parameter,
			success: function(data) {
				if (callback == null) {
					return;
				} 
				callback(data);
			},
		});
	}
}
function getqrpic(){
yunyan.post("login.mz?xz=findpwd","act=getqr",function(rs){
if (rs.code==0){
$('#qrcode').attr('src', "data:image/png;base64,"+rs.data);
$('#msg').text("请使用手机QQ扫描二维码");
window.qrsig=rs.sig;
window.run=window.setInterval(qrlogin,3000); 
}
});
}
function qrlogin() {	
	clearInterval(window.run);
	yunyan.post("login.mz?xz=findpwd","act=qrlogin&qrsig="+window.qrsig,function(rs){
		if (rs.code==0){
			$('#msg').text("已经为您重置新密码为：["+rs.pwd+"]");
			swal('重置成功','您的新密码为：'+rs.pwd,'success');
		}else if (rs.code==-2){
			$('#msg').text(rs.msg);
			getqrpic();
			window.run=window.setInterval(qrlogin,3000); 
		}else if (rs.code==-1001){
			$('#msg').text(rs.msg);
			swal('重置失败',rs.msg,'error');
			window.run=window.setInterval(qrlogin,3000); 
		}else{
			$('#msg').text(rs.msg);
			window.run=window.setInterval(qrlogin,3000); 
		}
	});
}