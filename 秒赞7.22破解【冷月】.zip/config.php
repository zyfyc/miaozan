<?php
/*数据库配置*/
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'lymcn', //数据库用户名
	'pwd' => '123123', //数据库密码
	'dbname' => 'lymcn', //数据库名
	'dbqz' => 'wjob' //数据表前缀
);

/*系统配置*/
define('CACHE_FILE', 0); //缓存方式(0为数据库1为文件)
define('CC_Defender', 1); //防CC攻击开关
?>