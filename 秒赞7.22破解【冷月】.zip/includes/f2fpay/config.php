<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

$config = array (
	//签名方式,默认为RSA2(RSA2048)
	'sign_type' => "RSA2",

	//支付宝公钥
	'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuIdq2Bq79ORlpHocUZ0oD3FreHb2PVOSHgBAmjMCnYGDoLfGk+Dvbo04DWz3HCr/vDMkEnRWiG6CJoo7B3F5y4qDpt2TfQbFoZ+zBlHG7ImGtoltFBFyrYzEA9ojZ5fZO/bbmDfg2NjUKLmc6qgYKgJbMIErLU49Pyux3GQnb0KckuaQ6cpm4fdbFVj9VW2bVSoUGTsKUjufcvq1k5QZeY2mDnDZ9scPnVuP3C9i2MyvvUq9tWgaM8fD58eU7ds558gQ8GIq22+Yneu1q376n7usJ8TRDBfqh7MLkBmTtRIxolmf0VTTwT0zi5p9gtn/eUhhACnDJxh85H3WHC+FqwIDAQAB",

	//商户私钥
	'merchant_private_key' => "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCaGd2g0G1yN7BvLl6enbbECn2KzO6VbcLooddTkS0QGcWyay9Zfl+VDOoVxtLfzP/vk/oidWS4DoOMxxXBKg9vYgzsYTDmhVOf8MxN/sjjKRyhzj3t+1RTlOsjxCqqq8YgxZj9p3Otj0i7H6AOMcJP9nIqBvloe1+A9Q1ifZi2aKKrzyx3GM3npez8FiZjY/9q7EdChlQjtXQ2dAq5CkulLR6dwBbsSPNvxFXxXEUpCMwFOMXlSvpYZhdZXhEiBDxixW49vGhTE3xOxbIOwNewreq3mjF48drKMYhZnjTq5GzIS3KHeKwi2fq/dR55ZKaCunLiz/02iiFL7bNPknW9AgMBAAECggEAKdBw8ez8daykxFZpuFKFQEa0cBBRgNyKscMQgY14E9FacqJg88C1wOUDM6uCltWycNjPW8BM9yCBE5cF0SdPjuKlLRLmSPbOjSyy00saSYFjUoh7B3NWG2PiNg9JoIwBs+zKKbHhUqv5iUT4kkFwP3BY5AyGapJnhL95xUrdQElSSCEKjaE4psmWggxbnhAJhlwRWAI5bmFz3Zkyvkxky5uK2aOPxRzI9QePvzmC+XZBRJH2rTS3hWLsdA5sLd9meK0nWuu440j5bkfVfUFjY7My4jrKFsqrFiXampn0AV9SgAJHnr3oLmKUS1yjMfSmerqHyirjVmCu8EONNUsFoQKBgQDQdg6msKEs9CJ6ll8LBXgtVkNQWZmBi4QQdcc/ezMaocWJ8Fd/6/D79r016+4ua1qv+jkT5TKSxZMNHnyAXx3E1yg+djAoOwrRWsyxpDxalEWibkyGfvHfVx6StX7t25gBoKUNol3y+eaWkVqZyxqWVPyxbulJ3iZ7lmJtmvSXhQKBgQC9PkUKSwbc0rdpTe907mqf4H7gInigxsPR5NnC6eWZq6hTjF1E1cDApFZVdh3M/eV3FZc8bXuuh1+S46xepTjkZ7Ozf+2CzcSfgTSs56lnktjoDxAUA56rJw0EhQ/+s7GJS3v18kiIH67t/d1FSaaUHEdt6x4AeVdDK72bhV3O2QKBgBVS/kyu5M3ka2J+31oRRSneGSSvBbTqwKeuZKNpxuCCi+KAY3MCf7RGmTRa3hKBiNVXk18lovbAnzpIVBQNps3r9IHvNR3obELeNvI1Crd5U2Y6Qjm/4p4mG0qGpmVOgU4pULkEUvf3+E6Or+XrkNyv9OlxnwufXfBmgcsUftDBAoGAcRqDZuh6fIZP6lcTE77e6Rjim5DeqbDCHnN5lt32RMbsfqq4n8hlQH23v7Itk3P3rhmwXwRMVH5CJ+d9AMAc5Z35MAH4cSIMLwyo7+IxRF7m1qMSB/Q147MeO6JPcfnx1M3Rk6gvo3PUOBdvJNclAQZ5xn8sWjorZlEBLK8j5tkCgYEAuf8B2694EJNUxDy2EcRxqO+yLffxmGBdoZpLeoqBuV0QGckcyRhA8FufM6K+RJCC6p9biikYd3kW/5tAek8Q6bvMRCBcLCYL8ypTYYk7JQLruTzLAHWXi5nwbLAd40yz8IDa+JCT8RK+FRsoVZIpkdYbbd/IoRoAMTBR371JD9I=",

	//编码格式
	'charset' => "UTF-8",

	//支付宝网关
	'gatewayUrl' => "https://openapi.alipay.com/gateway.do",

	//应用ID
	'app_id' => "2017090908643182",

	//异步通知地址,只有扫码支付预下单可用
	'notify_url' => $siteurl.'other/f2fpay_notify.php',

	//最大查询重试次数
	'MaxQueryRetry' => "10",

	//查询间隔
	'QueryDuration' => "3"
);