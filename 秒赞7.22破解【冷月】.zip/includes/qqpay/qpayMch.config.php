<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/


/**
 * qpayMch.config.php
 * Created by HelloWorld
 * vers: v1.0.0
 * User: Tencent.com
 */
class QpayMchConf
{
    /**
     * QQ钱包商户号
     */
    const MCH_ID = '1405050601';
    /**

    /**
     * API密钥。
     * QQ钱包商户平台(http://qpay.qq.com/)获取
     */
    const MCH_KEY = '123456';

}