;
(function($,document,window,undefined){
	$.fn.downList = function(option){
		var name = $(this).attr("id");
		return this.hover(function(){
			var self = this;
			var offset = $(self).offset();
			var height = $(self).height();
			var width = $(self).width();
			var left = offset.left;
			var top = offset.top+height;
			$('#'+name+'_list').css({
				"display":"block",
				"position":"absolute",
				"left":left,
				"top":top,
				"width":width,
				"text-align":"center",
				"z-index":"999",
			});
		},function(){
			$('#'+name+'_list').css({
				"display":"none",
			});
		});
	}
})(jQuery,document,window);
;
(function($,document,window,undefined){
	$.fn.slider = function(option){
		var name = $(this).attr("id");
		return this.hover(function(){
			var self = this;
			var offset = $(self).offset();
			var height = $(self).height();
			var left = offset.left;
			var top = offset.top+height;
			$('#'+name+'_list').css({
				"display":"block",
				"position":"absolute",
				"left":left,
				"top":top,
			});
		},function(){
			$('#'+name+'_list').css({
				"display":"none",
			});
		});
	}
})(jQuery,document,window);