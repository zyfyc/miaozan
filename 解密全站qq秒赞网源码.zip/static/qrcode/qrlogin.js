// 获取二维码
function getQrPic(findinfo) {
    findinfo = arguments[0] ? arguments[0] : '0';
    var url = '/qq/qrLogin.html?do=getqrpic&r=' + Math.random();
    $.get(url, function (d) {
        if (d.code == 0) { // 0成功，1失败
            $('#qrimg').attr('qrsig', d.qrsig);
            $('#qrimg').html('<img onclick="getQrPic(' + findinfo + ')" style="width: 150px;" src="data:image/png;base64,' + d.urldata + '" title="点击刷新二维码">');
            $('#loginmsg').html('请使用手机QQ扫描二维码');
            clearInterval(interval); // 去除定时任务
            interval = setInterval(function () {
                qrCheck(findinfo);
            }, 3000);
        } else {
            alert(d.msg);
        }
    });
}

// 检查QR
function qrCheck(findinfo) {
    var msg;
    var qrsig = $('#qrimg').attr('qrsig');
    var url = "/qq/qrLogin.html?do=qqlogin&qrsig=" + decodeURIComponent(qrsig) + "&r=" + Math.random();
    if (findinfo == 1) {
        url = url + "&find=1";
    }
    $.get(url, function (d) {
        switch (d.code) { // 0成功，6失败
            case '0':
                if ($("#qrimg").attr("data-lock") === "1") return;
                else $("#qrimg").attr("data-lock", "1");
                clearInterval(interval); // 去除定时任务
                msg = '登陆成功!';
                swal({
                    title: "登陆成功",
                    text: "请完善最后的信息:",
                    type: "input",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    closeOnCancel: false,
                    showLoaderOnConfirm: true,
                    confirmButtonText: "提交",
                    cancelButtonText: "取消",
                    animation: "slide-from-top",
                    inputPlaceholder: "请输入当前QQ的密码"
                }, function (qqpwd) {
                    if (qqpwd === false) { //取消
                        swal("取消成功", "已中断添加QQ的操作！", "warning");
                    } else if (qqpwd === "") {
                        swal.showInputError("请输入密码!");
                        return false
                    } else {
                        var data = "pwd=" + window.btoa(qqpwd) + "&login=" + window.btoa(JSON.stringify(d));
                        TianYa.postData("/qq/add4qr.html", data, function (d) {
                            if (d.type) {
                                swal({
                                    title: d.title,
                                    text: d.msg,
                                    type: d.type,
                                    timer: d.timer,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "OK"
                                }, function () {
                                    if (d.url) {
                                        window.location.href = d.url;
                                    }
                                });
                            } else {
                                alert('返回数据异常，请联系QQ454701103！[qrJs]');
                            }
                        });
                    }
                });
                break;
            case '1':
                clearInterval(interval); // 去除定时任务
                msg = '已过期，可点击二维码进行刷新!';
                break;
            case '2':
                //msg = '使用手机QQ扫描二维码';
                break;
            case '3':
                msg = '扫描成功，请在手机上确认授权登录';
                break;
            case 'find':
                clearInterval(interval); // 去除定时任务
                $("#qrimg").addClass("hide");
                msg = '用户名：<code>' + d.name + '</code>的密码已重置，请使用<code>123456</code>进行登录，并及时在个人资料修改密码！';
                break;
            case 'nofind':
                clearInterval(interval); // 去除定时任务
                $("#qrimg").addClass("hide");
                msg = '未找到此QQ的绑定账户，请使用正确的绑定QQ进行找回信息！';
                break;
            default:
                clearInterval(interval); // 去除定时任务
                msg = d.msg;
                break;
        }
        $('#loginmsg').html(msg);
    });

}
var interval;