/*
 *  Document   : readyReminder.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in Reminder page
 */

var ReadyFindInfo = function() {

    return {
        init: function() {
            /*
             *  Jquery Validation, Check out more examples and documentation at https://github.com/jzaefferer/jquery-validation
             */

            /* Reminder form - Initialize Validation */
            $('#form-findinfo').validate({
                errorClass: 'help-block animation-slideUp', // You can change the animation class for a different entrance animation - check animations page
                errorElement: 'div',
                errorPlacement: function(error, e) {
                    e.parents('.form-group > div').append(error);
                },
                highlight: function(e) {
                    $(e).closest('.form-group').removeClass('has-success has-error').addClass('has-error');
                    $(e).closest('.help-block').remove();
                },
                success: function(e) {
                    e.closest('.form-group').removeClass('has-success has-error');
                    e.closest('.help-block').remove();
                },
                submitHandler: function(form){   //表单提交句柄,为一回调函数，带一个参数：form
                    ajaxSubmitForm();
                },
                rules: {
                    'qq': {
                        required: true,
                        minlength: 5
                    },
                    'code': {
                        required: true,
                        minlength: 4
                    }
                },
                messages: {
                    'qq': '请输入绑定QQ进行找回密码',
                    'code': {
                        required: '请输入图片中的字母进行验证!',
                        minlength: '请输入4位验证码!'
                    }
                }
            });
        }
    };
}();