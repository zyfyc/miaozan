/*
 *  Document   : readyLogin.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in Login page
 */

var ReadyLogin = function () {

    return {
        init: function () {
            /*
             *  Jquery Validation, Check out more examples and documentation at https://github.com/jzaefferer/jquery-validation
             */

            /* Login form - Initialize Validation */
            $('#form-login').validate({
                errorClass: 'help-block animation-slideUp', // You can change the animation class for a different entrance animation - check animations page
                errorElement: 'div',
                errorPlacement: function (error, e) {
                    e.parents('.form-group > div').append(error);
                },
                highlight: function (e) {
                    $(e).closest('.form-group').removeClass('has-success has-error').addClass('has-error');
                    $(e).closest('.help-block').remove();
                },
                success: function (e) {
                    e.closest('.form-group').removeClass('has-success has-error');
                    e.closest('.help-block').remove();
                },
                submitHandler: function (form) {   //表单提交句柄,为一回调函数，带一个参数：form
                    //if ($(".slideunlock-lockable").val() == 0) {
                    //    swal('请拖动滑块完成验证！');
                    //    return;
                    //}
                    ajaxSubmitForm();
                },
                rules: {
                    'user': {
                        required: true,
                        minlength: 1
                    },
                    'pwd': {
                        required: true,
                        minlength: 5
                    }
                },
                messages: {
                    'user': {
                        required: '请输入用户名',
                        minlength: '请继续输入完整的用户名'
                    },
                    'pwd': {
                        required: '请输入密码',
                        minlength: '请继续输入完整的密码'
                    }
                }
            });
        }
    };
}();