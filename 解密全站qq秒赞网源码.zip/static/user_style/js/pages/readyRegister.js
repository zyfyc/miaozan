/*
 *  Document   : readyRegister.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in Register page
 */

var ReadyRegister = function () {

    return {
        init: function () {
            /*
             *  Jquery Validation, Check out more examples and documentation at https://github.com/jzaefferer/jquery-validation
             */

            /* Register form - Initialize Validation */
            $('#form-register').validate({
                errorClass: 'help-block animation-slideUp', // You can change the animation class for a different entrance animation - check animations page
                errorElement: 'div',
                errorPlacement: function (error, e) {
                    e.parents('.form-group > div').append(error);
                },
                highlight: function (e) {
                    $(e).closest('.form-group').removeClass('has-success has-error').addClass('has-error');
                    $(e).closest('.help-block').remove();
                },
                success: function (e) {
                    if (e.closest('.form-group').find('.help-block').length === 2) {
                        e.closest('.help-block').remove();
                    } else {
                        e.closest('.form-group').removeClass('has-success has-error');
                        e.closest('.help-block').remove();
                    }
                },
                submitHandler: function (form) {   //表单提交句柄,为一回调函数，带一个参数：form
                    if ($(".slideunlock-lockable").val() == 0) {
                        swal('请拖动滑块完成验证！');
                        return;
                    }
                    ajaxSubmitForm();
                },
                rules: {
                    'user': {
                        required: true,
                        minlength: 3
                    },
                    'qq': {
                        required: true,
                        minlength: 5
                    },
                    'pwd': {
                        required: true,
                        minlength: 6,
                        maxlength: 16
                    },
                    //'register-password-verify': {
                    //    required: true,
                    //    equalTo: '#register-password'
                    //},
                    //'code': {
                    //    required: true,
                    //    minlength: 4
                    //},
                    'register-terms': {
                        required: true
                    }
                },
                messages: {
                    'user': {
                        required: '请输入一个用户名',
                        minlength: '用户名太短了~~'
                    },
                    'qq': '请输入一个联系QQ号进行绑定',
                    'pwd': {
                        required: '请输入一个登录密码',
                        minlength: '密码限制为6~16位',
                        maxlength: '密码限制为6~16位'
                    },
                    //'register-password-verify': {
                    //    required: 'Please provide a password',
                    //    minlength: 'Your password must be at least 5 characters long',
                    //    equalTo: 'Please enter the same password as above'
                    //},
                    //'code': {
                    //    required: '请输入图片中的字母进行验证!',
                    //    minlength: '请输入4位验证码!'
                    //},
                    'register-terms': {
                        required: '需要先同意用户协议方可继续注册!'
                    }
                }
            });
        }
    };
}();