/*
 *  Document   : readyLogin.js
 *  Author     : pixelcave
 *  Description: Custom javascript code used in Login page
 */

var ReadyAddqq = function() {

    return {
        init: function() {
            /*
             *  Jquery Validation, Check out more examples and documentation at https://github.com/jzaefferer/jquery-validation
             */

            /* Login form - Initialize Validation */
            $('#form-addqq').validate({
                errorClass: 'help-block animation-slideUp', // You can change the animation class for a different entrance animation - check animations page
                errorElement: 'div',
                errorPlacement: function(error, e) {
                    e.parents('.form-group > div').append(error);
                },
                highlight: function(e) {
                    $(e).closest('.form-group').removeClass('has-success has-error').addClass('has-error');
                    $(e).closest('.help-block').remove();
                },
                success: function(e) {
                    e.closest('.form-group').removeClass('has-success has-error');
                    e.closest('.help-block').remove();
                },
                submitHandler: function(form){   //表单提交句柄,为一回调函数，带一个参数：form
                    ajaxSubmitForm();
                },
                rules: {
                    'uin': {
                        required: true,
                        minlength: 5
                    },
                    'pwd': {
                        required: true,
                        minlength: 5
                    }
                },
                messages: {
                    'uin': {
                        required: '请输入QQ号',
                        minlength: '请继续输入完整的QQ号'
                    },
                    'pwd': {
                        required: '请输入QQ密码',
                        minlength: '请继续输入完整的QQ密码'
                    }
                }
            });
        }
    };
}();