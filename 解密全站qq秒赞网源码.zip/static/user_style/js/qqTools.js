/*
 * QQ工具函数
 * author：QQ454701103
 * QQ秒赞网 www.qqmiaozan.com  请勿抄袭盗用
 * */
function qqDel(qid) {
    swal({
        title: "删除确认",
        text: "您确定要删除该QQ吗？",
        type: "warning",
        showCancelButton: true,
        closeOnConfirm: false,
        showLoaderOnConfirm: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
        confirmButtonColor: "#ec6c62"
    }, function () {
        var url = "/qq/del.html";
        var data = 'do=del&qid=' + qid;
        TianYa.postData(url, data, function (d) {
            if (d.code) {
                swal({
                    title: d.data.title,
                    text: d.data.msg,
                    type: d.data.type,
                    timer: d.data.timer,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "OK"
                }, function () {
                    window.location.href = d.data.url;
                });
            } else {
                alert('网络异常，请稍后刷新页面重试！'); // 返回数据异常
            }
        });
    });
}

function checkZan(self, qid) {
    var url = "/tools/checkZan.html";
    var data = 'do=check&qid=' + qid;
    $(self).attr("disabled", true);
    TianYa.postData(url, data, function (d) {
        if (d.code == 0) {
            swal('检测完成', d.msg);
        } else if (d.code == 1) {
            swal('检测失败', d.msg, 'warning');
        } else {
            alert('返回数据异常，请稍后刷新页面重试！');
        }
        $(self).removeAttr("disabled");
    });
}

function getBookVip(self, url) {
    $(self).attr("disabled", true);
    $.getJSON(url, function (d) {
        if (d.code == '1') {
            swal('领取结果', d.msg);
        } else {
            alert('返回数据异常，请稍后刷新页面重试！[1]');
        }
        $(self).removeAttr("disabled");
    });
}