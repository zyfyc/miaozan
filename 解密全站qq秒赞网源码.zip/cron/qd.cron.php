<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isqd>0 and (nextqd<'$now' or nextqd IS NULL) and skeyzt=0 limit 30");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}qd.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}

if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

exit('Ok!');