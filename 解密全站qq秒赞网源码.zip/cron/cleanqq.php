<?php
error_reporting(E_ALL & ~E_NOTICE);
header('Content-Type: text/html; charset=UTF-8');
// 清理秒赞服务器数据
$mysql = require("../application/database.php");
$dbhost = $mysql['hostname'] . ':' . $mysql['hostport'];
$dbuser = $mysql['username'];
$dbpassword = $mysql['password'];
$dbmysql = $mysql['database'];
if ($con = mysqli_connect($dbhost, $dbuser, $dbpassword)) {
    mysqli_select_db($con, $dbmysql);
} else {
    exit('数据库链接失败！');
}
mysqli_query($con, "set names utf8");
mysqli_query($con, "update qqmz_qqs set zannet = '0' where zannet>0 and skeyzt = 1 and `autolog` LIKE '%更新失败%';"); // 状态码过期的重置秒赞net为0
mysqli_query($con, "update qqmz_qqs set zannet = '0' where iszan=0 and zannet>0;"); // 关闭秒赞的更改net为0
mysqli_query($con, "update qqmz_qqs set iszan = '0' where zannet = 0 and iszan>0;"); // 所有秒赞net=0的关闭秒赞功能iszan=0
// mysqli_query($con, "update qqmz_qqs set isreply=0,isshuo=0,isdel=0,isqd=0,isht=0,isly=0,isvipqd=0,iszyzan=0,iszf=0,ists=0,islz=0,isdelly=0,isqb=0,isqt=0,isqunqd=0,ishzqd=0,isxzqd=0,isqipao=0,shuonet='0',replynet='0',zfnet='0' where zannet < 100"); // 在免费秒赞服务器或net=0的qq关闭vip功能

exit('ok del sid');