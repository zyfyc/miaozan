<?php
include_once "base.php";
$n = is_numeric($_GET['n']) ? $_GET['n'] : exit('No Net!');
$rs = $db->query("SELECT id FROM " . DB_PREFIX . "sszs where status=0 order by id asc limit 1");
$i = 0;
if ($row = $rs->fetch()) {
    @get_curl2("{$nurl}ssz.run.php?key={$_GET['key']}&id={$row['id']}");
}

exit(date("H:i:s"));

function get_curl2($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}