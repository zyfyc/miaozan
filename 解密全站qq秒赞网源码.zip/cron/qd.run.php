<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isqd>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];
    $do = $row['isqd'];
    $con = get_con($row['qdcon']);
    $lid = '10729'; // 签到类型ID

    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    //if ($do == 2) {
        $qzone->qiandao(1, $con);
    //} else {
    //    $qzone->qiandao(0, $con);
    //}
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set nextqd='$next_day' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}
