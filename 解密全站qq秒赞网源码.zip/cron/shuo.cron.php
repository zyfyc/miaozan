<?php
include_once "base.php";
$n = is_numeric($_GET['n']) ? $_GET['n'] : exit('No Net!');
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where shuonet='$n' and isshuo>0 and (nextshuo<'$now' or nextshuo IS NULL) and skeyzt=0");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}shuo.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}

if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

exit('Ok!');