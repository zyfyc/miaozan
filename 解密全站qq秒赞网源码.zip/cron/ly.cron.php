<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isly>0 and (nextly<'$now' or nextly IS NULL) and skeyzt=0 limit 40");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}ly.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}

if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

exit('Ok!');