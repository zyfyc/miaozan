<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isqunqd=2 and skeyzt=0 and (nextqunqd < '$now' or nextqunqd IS NULL) limit 5");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}qunqd.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit('Ok!');