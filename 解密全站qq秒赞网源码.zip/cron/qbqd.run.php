<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and (isqb>0 or issyqd>0) and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];
    include_once "tools.class.php";
    $qzone = new tools($uin, $sid, $skey, $pskey);
	if($row['isqb']>0){
		$qzone->qbqd();
	}
	if($row['issyqd']>0){
		$qzone->qqgame();
	}
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set nextqb='$next_day' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}
