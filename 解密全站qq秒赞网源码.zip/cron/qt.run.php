<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isqt>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];

    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    if ($shuos = $qzone->getnew()) {
        foreach ($shuos as $shuo) {
            $albumid = '';
            $lloc = '';
            if($shuo['original']['cell_pic']){
				$albumid=$shuo['original']['cell_pic']['albumid'];
				$lloc=$shuo['original']['cell_pic']['picdata'][0]['lloc'];
			}
            if ($shuo['pic']) {
                $albumid = $shuo['pic']['albumid'];
                $lloc = $shuo['pic']['picdata'][0]['lloc'];
            }
            if (!empty($albumid)) {
                $touin = $shuo['userinfo']['user']['uin'];
                $qtrs = $db->query("SELECT id FROM " . DB_PREFIX . "quanrens where uin='$uin' and albumid='$albumid' and lloc='$lloc' limit 1");
                // print_r( $qtrs);exit;
                if (!$qtrs->fetch()) {
                    $url = "http://app.photo.qq.com/cgi-bin/app/cgi_annotate_face?g_tk=" . $qzone->gtk2;
                    $post = "format=json&uin=$uin&hostUin=$touin&faUin=$fauin&faceid=&oper=0&albumid=$albumid&lloc=$lloc&facerect=10_10_50_50&extdata=&inCharset=GBK&outCharset=GBK&source=qzone&plat=qzone&facefrom=moodfloat&faceuin=$fauin&writeuin=$uin&facealbumpage=quanren&qzreferrer=http://user.qzone.qq.com/$uin/infocenter?via=toolbar";
                    $json = $qzone->get_curl($url, $post, 'http://user.qzone.qq.com/' . $uin . '/infocenter?via=toolbar', $qzone->cookie);
                    $json = mb_convert_encoding($json, "UTF-8", "GBK");
                    $arr = json_decode($json, true);
                    if (!@array_key_exists('code', $arr)) {
                        $qzone->error[] = "圈{$touin}的图{$lloc}失败，原因：获取结果失败！";
                    } elseif ($arr['code'] == 0) {
                        $db->exec("INSERT INTO " . DB_PREFIX . "quanrens (uin,albumid,lloc,addtime) VALUE('$uin','$albumid','$lloc','$now')");
                        $qzone->msg[] = "圈{$touin}的图{$lloc}成功";
                    } else {
                        $db->exec("INSERT INTO " . DB_PREFIX . "quanrens (uin,albumid,lloc,addtime) VALUE('$uin','$albumid','$lloc','$now')");
                        $qzone->error[] = "圈{$touin}的图{$lloc}失败，原因：" . $arr['message'];
                    }
                } else {
                    $qzone->msg[] = "{$touin}的图{$lloc}已经圈过！";
                }
            }
            // echo $albumid.'<br/>';
            // echo $lloc.'<hr/>';
        }
    }

    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set lastqt='$next_15min' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}