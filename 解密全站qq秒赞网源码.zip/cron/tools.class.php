<?php
class tools
{
    public $msg;
    public $error;
    public $skeyzt;
    public $touin;
    public $db;
    public function __construct($uin, $sid, $skey, $pskey=null, $superkey=null)
    {
        $this->uin = $uin;
        $this->sid = urlencode($sid);
        $this->skey = $skey;
        $this->gtk = $this->getGTK($skey);
        $this->new_gtk = $this->getGTK($pskey);
        $this->gtk2 = $this->getGTK2($skey);
        $this->cookie = 'uin=o0' . $uin . '; skey=' . $skey . ';';
        $this->pc_cookie = 'uin=o0' . $uin . '; skey=' . $skey . '; p_uin='. $uin .'; p_skey=' . $pskey . ';';
    }

    public function qunqd($list = 0, $lat = 0, $lgt = 0) {
        $url = 'http://qun.qzone.qq.com/cgi-bin/get_group_list?groupcount=4&count=4&format=json&callbackFun=_GetGroupPortal&uin=' . $this->uin . '&g_tk=' . $this->gtk . '&ua=Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F31.0.1650.63%20Safari%2F537.36';
        $url2 = 'http://qiandao.qun.qq.com/cgi-bin/sign';
        $data = $this->get_curl($url, 0, 'http://qun.qzone.qq.com/group', $this->pc_cookie);
        preg_match('/_GetGroupPortal_Callback\((.*?)\)\;/is', $data, $json);
        $arr = json_decode($json[1], true);
        //print_r($arr);exit;
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $i = 0;
            foreach ($arr['data']['group'] as $row) {
//                if (in_array($row['groupid'], $list)) {
//                    continue;
//                }
                $i++;
                if ($i > 30) {
                    break;
                }
                if ($lat && $lgt) {
                    $data = $this->get_curl('http://qiandao.qun.qq.com/cgi-bin/get_lbs_location?lat=' . $lat . '&lgt=' . $lgt . '&s=1&n=1&gpstype=1&gc=' . $row['groupid'], 0, 'http://qiandao.qun.qq.com/index.html', $this->pc_cookie);
                    $arr = json_decode($data, true);
                    if ($arr['info'][0]) {
                        $addstr = '&poi=' . urlencode($arr['info'][0]['city'] . ' · ' . $arr['info'][0]['name']) . '&lat=' . $arr['info'][0]['lat'] . '&lgt=' . $arr['info'][0]['lgt'] . '&seckey=' . $arr['info'][0]['seckey'];
                    } else {
                        $addstr = null;
                        $lat = 0;
                        $lgt = 0;
                    }
                } else {
                    $addstr = '';
                }
                $post = 'gc=' . $row['groupid'] . '&is_sign=0&from=1&bkn=' . $this->gtk . $addstr;
                $data = $this->get_curl($url2, $post, 'http://qiandao.qun.qq.com/index.html?groupUin=' . $row['groupid'] . '&appID=100729587', $this->pc_cookie);
                $arr = json_decode($data, true);
                if (array_key_exists('ec', $arr) && $arr['ec'] == 0) {
                    if (array_key_exists('name_list', $arr)) {
                        $this->msg[] = '群：' . $row['groupid'] . ' 签到成功！累计签到' . $arr['conti_count'] . '天,签到排名为' . $arr['rank'] . '名.';
                    } elseif (array_key_exists('conti_count', $arr)) {
                        $this->msg[] = '群：' . $row['groupid'] . ' 今天已签到！累计签到' . $arr['conti_count'] . '天,签到排名为' . $arr['rank'] . '名.';
                    } else {
                        $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：' . $data;
                    }
                } elseif ($arr['ec'] == 1) {
                    $this->skeyzt = 1;
                    $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：SKEY失效！';
                } else {
                    $this->msg[] = '群：' . $row['groupid'] . '签到失败！原因：' . $data;
                }
            }
        } elseif ($arr['code'] == -3000) {
            $this->msg[] = '群签到失败！原因：SKEY已失效。';
        } else {
            $this->msg[] = '群签到失败！原因：' . $arr['message'];
        }
    }

    public function qipao() {
        $str = '<img src="http://imgcache.qq.com/club/item/avatar/img/7/227/pc_list.png" alt="萌萌兔" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/221/pc_list.png" alt="荷韵" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/218/pc_list.png" alt="奥特曼系列" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/209/pc_list.png" alt="帕丁顿熊气泡" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/206/pc_list.png" alt="My Melody" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/205/pc_list.png" alt="乐洋洋" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/202/pc_list.png" alt="温暖围巾" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/201/pc_list.png" alt="烈焰红唇" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/203/pc_list.png" alt="温柔针织" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/191/pc_list.png" alt="哆啦A梦" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/0/190/pc_list.png" alt="可爱鹿晗" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/186/pc_list.png" alt="大眼蛙" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/7/187/pc_list.png" alt="郭斯特" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/182/pc_list.png" alt="酷企鹅XO" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/178/pc_list.png" alt="冬日情怀" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/169/pc_list.png" alt="金属齿轮" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/155/pc_list.png" alt="热刺" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/152/pc_list.png" alt="野原新之助" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/0/150/pc_list.png" alt="女孩萌萌哒" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/146/pc_list.png" alt="求带走" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/142/pc_list.png" alt="搞怪万圣节" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/138/pc_list.png" alt="疯狂的校车" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/132/pc_list.png" alt="搞怪彼格梨" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/133/pc_list.png" alt="麦兜和妈妈" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/126/pc_list.png" alt="多福(Dov）" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/7/127/pc_list.png" alt="奥斯卡(Oscar)" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/125/pc_list.png" alt="夏日BabyQ" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/4/124/pc_list.png" alt="诱人火龙果" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/122/pc_list.png" alt="利物浦" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/0/120/pc_list.png" alt="B.duck" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/118/pc_list.png" alt="游戏机" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/111/pc_list.png" alt="爱情物语" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/112/pc_list.png" alt="汽车人" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/113/pc_list.png" alt="霸天虎" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/109/pc_list.png" alt="机械战警" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/106/pc_list.png" alt="小幺鸡" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/105/pc_list.png" alt="caca插座" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/101/pc_list.png" alt="少女情怀" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/98/pc_list.png" alt="我是小怪兽" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/92/pc_list.png" alt="贱萌冷兔" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/89/pc_list.png" alt="记事本" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/83/pc_list.png" alt="暴走漫画" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/0/80/pc_list.png" alt="我爱妈妈" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/78/pc_list.png" alt="勤劳小蜜蜂" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/76/pc_list.png" alt="温柔的卷纸" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/75/pc_list.png" alt="糖果故事" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/73/pc_list.png" alt="小猫咪" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/71/pc_list.png" alt="雨的秘密" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/69/pc_list.png" alt="愚你同乐" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/7/67/pc_list.png" alt="午后时光" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/63/pc_list.png" alt="放飞心情" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/61/pc_list.png" alt="粉色物语" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/58/pc_list.png" alt="BabyQ" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/12/pc_list.png" alt="微笑河马" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/52/pc_list.png" alt="我爱仔仔" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/11/pc_list.png" alt="浪花朵朵" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/3/3/pc_list.png" alt="活力篮球" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/1/1/pc_list.png" alt="泡泡鱼" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/5/pc_list.png" alt="素食主义" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/8/38/pc_list.png" alt="冬日浓情" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/5/35/pc_list.png" alt="一米阳光" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/29/pc_list.png" alt="我是出众派" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/4/24/pc_list.png" alt="奋斗青年" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/26/pc_list.png" alt="卖萌大过天" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/19/pc_list.png" alt="荷塘月色" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/4/14/pc_list.png" alt="阳光海滩" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/9/9/pc_list.png" alt="贱是种态度" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/2/2/pc_list.png" alt="西部牛仔" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/4/4/pc_list.png" alt="悦动音符" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/6/6/pc_list.png" alt="清新柠檬" width="176" height="110">
<img src="http://imgcache.qq.com/club/item/avatar/img/7/7/pc_list.png" alt="随心漂游" width="176" height="110">';
        preg_match_all('!<img src="http://imgcache.qq.com/club/item/avatar/img/(.*?)/(.*?)/pc_list.png" alt="(.*?)" width="176" height="110">!i', $str, $matchs);
        $rand = array_rand($matchs[2], 1);
        $id = $matchs[2][$rand];
        $name = $matchs[3][$rand];
        $url = 'http://logic.content.qq.com/bubble/setup?format=json&id=' . $id . '&g_tk=' . $this->new_gtk . '&_=' . time() . '4000';
        $json = $this->get_curl($url, 0, $url, $this->pc_cookie);
        $arr = json_decode($json, true);
        if (array_key_exists('ret', $arr) && $arr['ret'] == 0) {
            if ($arr['data']['ret'] == 0 && $arr['data']['msg'] == 'ok') {
                $resultStr = "更换【{$name}】气泡成功！";
            } elseif ($arr['data']['ret'] == 5002) {
                $resultStr = '气泡更换失败！需参与活动';
            } elseif ($arr['data']['ret'] == 2002) {
                $resultStr = '气泡更换失败！不是会员';
            } else {
                $resultStr = '未知错误！';
            }
        } elseif ($arr['ret'] == -100001) {
            $this->skeyzt = 1;
            $resultStr = '更换气泡失败！SKEY过期';
        } else {
            $resultStr = '更换气泡失败！' . $arr['msg'];
        }
        $this->msg[] = $resultStr;
    }

    /**
     * QQ会员签到
     */
    public function vipqd() {
        $data=$this->get_curl("http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=79968&format=json&g_tk=" . $this->gtk2 ."&cachetime=".time(),0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员面板签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员面板今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员面板签到失败！SKEY过期';
		}elseif($arr['ret']==20101)
			$this->msg[] = $this->uin.' 会员面板签到失败！不是QQ会员！';
		else
			$this->msg[] = $this->uin.' 会员面板签到失败！'.$arr['msg'];

		$data=$this->get_curl("http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=23314&format=json&g_tk=" . $this->gtk2 ."&cachetime=".time(),0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员网页版签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员网页版今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员网页版签到失败！SKEY过期';
		}elseif($arr['ret']==20101)
			$this->msg[] = $this->uin.' 会员网页版签到失败！不是QQ会员！';
		else
			$this->msg[] = $this->uin.' 会员网页版签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?actid=52002&rand=0.27489888'.time().'&g_tk='.$this->gtk2.'&format=json',0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员手机端签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员手机端今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员手机端签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员手机端签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=54963&isLoadUserInfo=1&format=json&g_tk='.$this->gtk2,0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员积分签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员积分今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员积分签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员积分签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=23074&format=json&g_tk='.$this->gtk2,0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员积分手机端签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员积分手机端今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员积分手机端签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员积分手机端签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://pay.qun.qq.com/cgi-bin/group_pay/good_feeds/gain_give_stock?gain=1&bkn='.$this->gtk,0,'http://m.vip.qq.com/act/qun/jindou.html',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ec',$arr) && $arr['ec']==0)
			$this->msg[] = $this->uin.' 免费领金豆成功！';
		elseif($arr['ec']==1010)
			$this->msg[] = $this->uin.' 今天已经领取过金豆了！';
		else
			$this->msg[] = $this->uin.' 领金豆失败！'.$arr['em'];

		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=27754&_='.time(),0,'http://vip.qq.com/',$this->cookie);//超级会员每月成长值
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=27755&_c=page&_='.time(),0,'http://vip.qq.com/',$this->cookie);//超级会员每月积分
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22894&_c=page&_='.time(),0,'http://vip.qq.com/',$this->cookie);//每月分享积分
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22249&_c=page&format=json&_='.time(),0,'http://vip.qq.com/',$this->cookie);//每周薪水积分
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22887&_c=page&format=json&_='.time(),0,'http://vip.qq.com/',$this->cookie);//每周邀请好友积分
    }

    /**
     * 绿钻签到、抽奖
     */
    public function lzqd() {
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_feedback_send_lottery.fcg?activeid=110&rnd=' . time() . '157&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/fuliwo/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            if ($arr['data']['alreadysend'] == 1) {
                $this->msg[] = '您今天已经签到过了！';
            } else {
                $this->msg[] = '绿钻签到成功！';
            }
        } elseif ($arr['code'] == -200017) {
            $this->msg[] = '你不是绿钻无法签到！';
        } else {
            $this->msg[] = '绿钻签到失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=73&rnd=' . time() . '029&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/Installment_lv8/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻签到2成功！';
        } elseif ($arr['code'] == -200006) {
            $this->msg[] = '绿钻签到2今天已签到！';
        } else {
            $this->msg[] = '绿钻签到2失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=128&rnd=' . time() . '029&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/Installment_lv8/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻签到3成功！';
        } elseif ($arr['code'] == -200006) {
            $this->msg[] = '绿钻签到3今天已签到！';
        } elseif ($arr['code'] == 200004) {
            $this->msg[] = '你不是绿钻无法签到！';
        } else {
            $this->msg[] = '绿钻签到3失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=130&rnd=' . time() . '029&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/Installment_lv8/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻签到4成功！';
        } elseif ($arr['code'] == -200006) {
            $this->msg[] = '绿钻签到4今天已签到！';
        } elseif ($arr['code'] == 200004) {
            $this->msg[] = '你不是绿钻无法签到！';
        } else {
            $this->msg[] = '绿钻签到4失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=138&rnd=' . time() . '029&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/Installment_lv8/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻签到5成功！';
        } elseif ($arr['code'] == -200006) {
            $this->msg[] = '绿钻签到5今天已签到！';
        } elseif ($arr['code'] == 200004) {
            $this->msg[] = '你不是绿钻无法签到！';
        } else {
            $this->msg[] = '绿钻签到5失败！';
        }
        $url = 'http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_draw_lottery.fcg?activeid=159&rnd=' . time() . '482&g_tk=' . $this->gtk . '&uin=' . $this->uin . '&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
        $data = $this->get_curl($url, 0, 'http://y.qq.com/vip/fuliwo/index.html', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '绿钻抽奖成功！';
        } elseif ($arr['code'] == 200008) {
            $this->msg[] = '您没有抽奖机会！';
        } else {
            $this->msg[] = '绿钻抽奖失败！';
        }
    }

    /**
     * QQ钱包签到
     */
    public function qbqd() {
        $url="http://iyouxi.vip.qq.com/ams3.0.php?g_tk=".$this->gtk2."&pvsrc=102&ozid=511022&vipid=&actid=32961&format=json&t=".time()."8777&cache=3654";
		$data = $this->get_curl($url,0,'http://youxi.vip.qq.com/m/wallet/activeday/index.html?_wv=3&pvsrc=102',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='钱包签到成功！';
		}elseif($arr['ret']==37206){
			$this->msg[]='钱包签到失败！你没有绑定银行卡';
		}elseif($arr['ret']==10601){
			$this->msg[]='你今天已钱包签到！';
		}elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[]='钱包签到失败！SKEY已失效';
		}else{
			$this->msg[]='钱包签到失败！'.$arr['msg'];
		}

		$url="http://proxy.vac.qq.com/cgi-bin/srfentry.fcgi?ts=".time()."9813&g_tk=".$this->gtk."&data={%2210752%22:{%22giveOpt%22:0}}&pt4_token=";
		$data = $this->get_curl($url,0,'https://i.qianbao.qq.com/wallet/recharge/dist/m/index_v4.html?_wv=1031&noTab=1&tab=fee&payChannel=task_activity&source=sng_308803&taskPlugin=1&pvsrc=311&bottom=50',$this->cookie);
		$arr = json_decode($data, true);
		$arr = $arr['10752'];
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='钱包签到2成功！';
		}elseif($arr['ret']==-4){
			$this->msg[]='钱包签到2失败！你没有绑定银行卡';
		}elseif($arr['ret']==-5){
			$this->msg[]='你今天已钱包签到2！';
		}else{
			$this->msg[]='钱包签到2失败！'.$arr['msg'];
		}

		$url="http://proxy.vac.qq.com/cgi-bin/srfentry.fcgi?ts=".time()."9813&g_tk=".$this->gtk."&data={%2210975%22:{%22sIn%22:{%22uin%22:0}}}&pt4_token=";
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		$arr = $arr['10975'];
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='钱包签到3成功！积分+5，连续签到'.$arr['data']['sOut']['continueDays'].'天';
		}elseif($arr['ret']==1){
			$this->msg[]='你今天已钱包签到3！';
		}else{
			$this->msg[]='钱包签到3失败！'.$arr['msg'];
		}

		$url="http://iyouxi3.vip.qq.com/ams3.0.php?g_tk=".$this->gtk2."&pvsrc=102&s_p=1%7Chttp%7C&s_v=0&ozid=511022&vipid=&actid=133339&sid=&format=json&t=".time()."8777&cache=3654";
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='钱包消费领取成长值成功！';
		}elseif($arr['ret']==37206){
			$this->msg[]='钱包消费领取成长值失败！你没有绑定银行卡';
		}elseif($arr['ret']==70051){
			$this->msg[]='您今天还未消费！建议：向自己的QQ小号发送1分钱红包即可！';
		}elseif($arr['ret']==10601){
			$this->msg[]='钱包消费领取成长值已完成！';
		}elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[]='钱包签到失败！SKEY已失效';
		}else{
			$this->msg[]='钱包消费领取成长值失败！'.$arr['msg'];
		}
    }

    /**
     * 图书签到
     */
    public function tsqd() {
        $url = "http://ubook.3g.qq.com/8/user/myMission?k1={$this->skey}&u1=o0{$this->uin}";
        $data = $this->get_curl($url, 0, 'http://ubook.qq.com/8/mymission.html');
        $arr = json_decode($data, true);
        if ($arr['isLogin'] == 'True' && $arr['signMap']['code'] == 0) {
            $this->msg[] = '图书签到成功！';
        } elseif ($arr['signMap']['code'] == -2) {
            $this->msg[] = '图书今日已经签到！';
        } elseif ($arr['isLogin'] == 'False') {
            $this->msg[] = '图书签到失败！SKEY过期！';
        } else {
            $this->msg[] = '图书签到失败！数据异常';
        }
		$url = "http://novelsns.html5.qq.com/ajax?m=task&type=sign&t=".time()."586";
		$data = $this->get_curl($url,0,$url,$this->cookie.'Q-H5-ACCOUNT='.$this->uin.'; Q-H5-SKEY='.$this->skey.'; luin='.$this->uin.'; Q-H5-USERTYPE=1');
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='小说书架签到成功！已连续签到'.$arr['continuousDays'].'天,总共签到'.$arr['totalDays'].'天';
		}elseif($arr['ret']==-2){
			$this->msg[]='您今天已经签到过了！已连续签到'.$arr['continuousDays'].'天,总共签到'.$arr['totalDays'].'天';
		}else{
			$this->msg[]='小说书架签到失败！'.$arr['msg'];
		}
    }

    /**
     * 黄钻签到
     */
    public function hzqd() {
        $url = 'http://vip.qzone.qq.com/fcg-bin/v2/fcg_mobile_vip_site_checkin?t=0.89457'.time().'&g_tk='.$this->new_gtk.'&qzonetoken=423659183';
		$post = 'uin='.$this->uin.'&format=json';
		$referer='http://h5.qzone.qq.com/vipinfo/index?plg_nld=1&source=qqmail&plg_auth=1&plg_uin=1&_wv=3&plg_dev=1&plg_nld=1&aid=jh&_bid=368&plg_usr=1&plg_vkey=1&pt_qzone_sig=1';
		$data = $this->get_curl($url,$post,$referer,$this->pc_cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻签到成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻签到失败！SKEY已失效';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻签到失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻签到失败！'.$data;
		}

		$url = 'https://h5.qzone.qq.com/proxy/domain/activity.qzone.qq.com/fcg-bin/fcg_huangzuan_daily_signing?t=0.'.time().'906035&g_tk='.$this->new_gtk.'&qzonetoken=-1';
		$post = 'option=sign&uin='.$this->uin.'&format=json';
		$data = $this->get_curl($url,$post,$url,$this->pc_cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻公众号签到成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻公众号签到失败！SKEY已失效';
		}elseif($arr['code']==-90002){
			$this->msg[]='黄钻公众号签到失败！非黄钻用户无法签到';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻公众号签到失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻公众号签到失败！'.$data;
		}
    }

    /**
     * 星钻签到+抽奖
     */
    public function xzqd() {
        $url = 'http://starvip.qq.com/fcg-bin/v2/fcg_mobile_starvip_site_checkin?g_tk=' . $this->gtk . '&r=0.06027948' . time();
        $post = 'format=json&uin=' . $this->uin;
        $data = $this->get_curl($url, $post, 'http://xing.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '星钻签到成功！成长值+' . $arr['data']['add'];
        } elseif ($arr['code'] == -10000) {
            $this->msg[] = '每天只需要签到一次哦！';
        } elseif ($arr['code'] == -3000) {
            $this->skeyzt = 1;
            $this->msg[] = '星钻签到失败！SKEY过期';
        } else {
            $this->msg[] = '星钻签到失败！' . $arr['message'];
        }
        $url = 'http://starvip.qq.com/fcg-bin/v2/fcg_qzact_lottery?g_tk=' . $this->gtk . '&r=0.00463036' . time();
        $post = 'actid=369&ruleid=2048&format=json&uin=' . $this->uin;
        $data = $this->get_curl($url, $post, 'http://xing.qq.com/', $this->cookie);
        $arr = json_decode($data, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '星钻抽奖成功！抽奖结果：' . $arr['data'][0]['name'] . $arr['data'][0]['cdkey'];
        } elseif ($arr['code'] == -10000) {
            $this->msg[] = '您已经用完了所有的抽奖机会！';
        } elseif ($arr['code'] == -3000) {
            $this->skeyzt = 1;
            $this->msg[] = '星钻抽奖失败！SKEY过期';
        } else {
            $this->msg[] = '星钻抽奖失败！' . $arr['message'];
        }
    }
	public function qqgame(){
		$url = 'https://reader.sh.vip.qq.com/cgi-bin/common_async_cgi?g_tk='.$this->gtk.'&plat=1&version=6.6.6&param=%7B%22key0%22%3A%7B%22param%22%3A%7B%22bid%22%3A13792605%7D%2C%22module%22%3A%22reader_comment_read_svr%22%2C%22method%22%3A%22GetReadAllEndPageMsg%22%7D%7D';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ecode',$arr) && $arr['ecode']==0){
			$this->msg[]='QQ手游加速0.2天成功！';
		}else{
			$this->msg[]='QQ手游加速失败！'.$data;
		}
	}
    public function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            if ($referer == 1) {
                curl_setopt($ch, CURLOPT_REFERER, 'https://mobile.qzone.qq.com/');
            } else {
                curl_setopt($ch, CURLOPT_REFERER, $referer);
            }
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1);
        }
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $httpheader[] = 'Accept:application/json';
        $httpheader[] = 'Accept-Language:zh-CN,zh;q=0.8';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }
    private function getGTK($skey)
    {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
    private function getGTK2($skey)
    {
        $salt = 5381;
        $md5key = 'tencentQQVIP123443safde&!%^%1282';
        $hash = array();
        $hash[] = $salt << 5;
        for ($i = 0; $i < strlen($skey); $i++) {
            $ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
            $ASCIICode = hexdec(bin2hex($ASCIICode));
            $hash[] = ($salt << 5) + $ASCIICode;
            $salt = $ASCIICode;
        }
        $md5str = md5(implode($hash) . $md5key);
        return $md5str;
    }
}