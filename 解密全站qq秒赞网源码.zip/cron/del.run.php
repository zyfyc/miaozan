<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}'  and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];
    $do = $row['isdel'];

    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    if ($do == 2) {
        $qzone->shuodel(1);
    } else {
        $qzone->shuodel(0);
    }
    if ($qzone->delend) {
        $db->exec("update " . DB_PREFIX . "qqs set isdel='0' where qid='$qid'");
    }
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set nextdel='$next_15min' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}
