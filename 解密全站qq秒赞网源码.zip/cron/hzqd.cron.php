<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where ishzqd>0 and (lasthzqd<'$now' or lasthzqd IS NULL) and skeyzt=0 limit 10");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}hzqd.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}

if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    print_r($get);
}

exit('Ok!');