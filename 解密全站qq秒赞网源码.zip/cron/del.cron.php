<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isdel>0 and (nextdel<'$now' or nextdel IS NULL) and skeyzt=0 limit 50");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}del.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}

if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

exit('Ok!');