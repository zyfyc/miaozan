<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isdelly>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];

    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    $qzone->delly();
    if ($qzone->delend) {
        $db->exec("update " . DB_PREFIX . "qqs set isdelly='0' where qid='$qid'");
    }
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set nextdelly='$next_30min' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}