<?php
include_once "base.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isreply>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];
    $do = $row['isreply'];
    $con = get_con($row['replycon']);

    $roster = $db->query("SELECT * FROM " . DB_PREFIX . "roster where qid='{$qid}' limit 1"); // 获取黑白名单
    $roster = $roster->fetch();
    if ($roster['reply_type']) { // 检查是否开启黑白模式，0普通，1白，2黑
        $qq_list = explode(',', $roster['reply_list']);
    }
    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    if ($do == 2) {
        $qzone->reply(1, $con, $roster['reply_type'], $qq_list);
    } else {
        $qzone->reply(0, $con, $roster['reply_type'], $qq_list);
    }
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set nextreply='$next' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}