<?php
include_once "base.php";
function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
        $hash &= 0x7fffffff;
    }
    return $hash & 0x7fffffff; //计算g_tk
}

function sendly2($self_uin, $qq, $skey, $p_skey, $con) {
    $gtk = getGTK($p_skey);
    $cookie = 'uin=o0' . $qq . '; skey=' . $skey . '; p_skey=' . $p_skey . ';';
    $url = "http://m.qzone.qq.com/cgi-bin/new/add_msgb?g_tk=" . $gtk;
    $post = 'qzreferrer=http%3A%2F%2Fctc.qzs.qq.com%2Fqzone%2Fmsgboard%2Fmsgbcanvas.html%23page%3D1&content=' . urlencode($con) . '&hostUin=' . $self_uin . '&uin=' . $qq . '&format=json&inCharset=utf-8&outCharset=utf-8&iNotice=1&ref=qzone&json=1&g_tk=' . $gtk;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $header2 = [
        'Accept: application/json',
        'Connection: keep-alive',
    ];
    curl_setopt($ch, CURLOPT_REFERER, "http://cnc.qzs.qq.com/qzone/msgboard/msgbcanvas.html");
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X; en-us) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header2);
    curl_setopt($ch, CURLOPT_POST, 1);
    // curl_setopt($ch, CURLOPT_HEADER, TRUE);//显示head信息
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    if ($_GET['get'] == 1) {
        echo $ret;
        // echo '【post】' . $post;
    }
}

$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT qq FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isly>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $self_uin = $row['qq'];

    $rs2 = $db->query("SELECT qq,skey,pskey FROM `qqmz_qqs` WHERE skeyzt = '0' AND zannet > '0' ORDER BY rand() LIMIT 1");
    while ($qq = $rs2->fetch()) {
        $con = get_con();
        sendly2($self_uin, $qq['qq'], $qq['skey'], $qq['pskey'], $con);
    }
    @$db->exec("update " . DB_PREFIX . "qqs set nextly='$next_30min' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}
