<?php
include_once 'base.php';
$qid =is_numeric($_GET['qid'])? $_GET['qid'] : exit('No Qid!');
$rs =$db->query("SELECT qq,uid,sid,skey,pskey,superkey,iszan,passwd FROM " . DB_PREFIX . "qqs where qid='{$qid}' and iszan=2 and skeyzt=0 limit 1");
if ($row =$rs->fetch()){
	$uin =$row['qq'];
	$sid =$row['sid'];
	$skey =$row['skey'];
	$pskey =$row['pskey'];
	include_once 'qzone.class.php';
	$qzone =new qzone($uin, $sid, $skey, $pskey);
	$qzone->like(1);
	if ($qzone->skeyzt){
		$data =["code" => 1, "msg" => "该QQ状态码已失效，请更新后再来使用"];
	}else {
		$data =["code" => 0, "msg" => $qzone->msg];
	}
}else {
	$data =["code" => 1, "msg" => "此QQ未开启秒赞功能或状态码已失效"];
}
$json =json_encode($data, JSON_UNESCAPED_UNICODE);
die($json);