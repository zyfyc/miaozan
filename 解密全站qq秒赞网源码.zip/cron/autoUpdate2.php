<?php
/**
 * 监控文件，定时执行数据库中等待更新的QQ
 * @Author 天涯<454701103@qq.com>
 * 如需修改和引用，请保留此头部信息！
 * UpDateTime: 2016年08月07日
 */

include_once "base.php";

// 取出待更新的数据，每次20条
$sql = "SELECT uid,qq,passwd FROM " . DB_PREFIX . "qqs WHERE `autolog` LIKE '%未成功打码%' and skeyzt=1 limit 10";
$rs = $db->query($sql);
// 逐条执行返回的Array数据
while ($row = $rs->fetch()) {
    $url = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . HOSTURL . '/qq/qqUpdateApi.html';
    $post = "do=update&uid={$row['uid']}&uin={$row['qq']}&pwd=".urlencode($row['passwd']);
    $ret = get_curl($url, $post);
    $arr = json_decode($ret, true);
    // 判断是否成功
    if (array_key_exists('code',$arr) && $arr['code'] == 0) {
        $log = "系统后台通过【{$arr['dama']}】方式更新QQ状态码成功！";
        $sql = "autolog='{$log}',lastauto='{$now}',uptime='{$now}',skeyzt='0'";
        $db->exec("UPDATE " . DB_PREFIX . "qqs SET {$sql} WHERE qq='{$row['qq']}'"); // 更新QQ数据
    } else {
        // 更新失败
        $log = '自动更新失败：' . $arr['msg'];
        $db->exec("UPDATE " . DB_PREFIX . "qqs SET autolog=\"{$log}\",lastauto='{$now}' WHERE qq='{$row['qq']}'");
    }
    echo $row['qq'].$log . '<br/>';
}
echo "----End";