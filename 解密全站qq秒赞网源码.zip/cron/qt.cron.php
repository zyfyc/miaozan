<?php
include_once "base.php";
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isqt>0 and (lastqt<'$now' or lastqt IS NULL) and skeyzt=0 limit 30");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}qt.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}
exit('Ok!');