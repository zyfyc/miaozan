<?php
include_once "base.php";
$id = is_numeric($_GET['id']) ? $_GET['id'] : exit('No Id2!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "sszs where id='{$id}' and status=0 limit 1");
$num = isset($config['ssz_num']) ? $config['ssz_num'] : 300;


if ($row = $rs->fetch()) {
    $db->exec("update " . DB_PREFIX . "sszs set status=1 where id='{$id}' limit 1");
    $qq_rs = $db->query("SELECT qid,qq,skey,pskey FROM " . DB_PREFIX . "qqs where skeyzt=0 limit {$num}");
    $res = array();
    $mh = curl_multi_init();//创建多个curl语柄
    $randServer = array('w.cnc.', 'w.');
    while ($qq_row = $qq_rs->fetch()) {
        $g_tk = get_gtk($qq_row['pskey']);
        $url = "http:///" . $randServer[rand(0, 1)] . "qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk={$g_tk}";
        $post = "qzreferrer=" . urlencode("http://user.qzone.qq.com/{$qq_row['uin']}") . "&opuin={$qq_row['qq']}&unikey=" . urlencode("http://user.qzone.qq.com/{$row['uin']}/mood/{$row['ssid']}") . "&curkey=" . urlencode("http://user.qzone.qq.com/{$row['uin']}/mood/{$row['ssid']}") . "&from=1&appid=311&typeid=0&abstime=1482976894&fid={$row['ssid']}&active=0&fupdate=1&format=json&";
        //$post = "qzreferrer=" . urlencode("http://user.qzone.qq.com/{$row['uin']}/311") . "&opuin={$qq_row['qq']}&unikey=" . urlencode("http://user.qzone.qq.com/{$row['uin']}/mood/{$row['ssid']}.1") . "&curkey=" . urlencode("http://user.qzone.qq.com/{$row['uin']}/mood/{$row['ssid']}.1") . "&from=-100&fupdate=1&face=0";
        $cookie = "uin=o0{$qq_row['qq']}; skey={$qq_row['skey']}; p_uin=o0{$qq_row['qq']}; p_skey={$qq_row['pskey']};";
        $k = $qq_row['qid'];
        $conn[$k] = curl_init($url);
        curl_setopt($conn[$k], CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($conn[$k], CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($conn[$k], CURLOPT_POST, 1);
        curl_setopt($conn[$k], CURLOPT_POSTFIELDS, $post);
        curl_setopt($conn[$k], CURLOPT_COOKIE, $cookie);
        curl_setopt($conn[$k], CURLOPT_TIMEOUT, 3);//设置超时时间
        curl_setopt($conn[$k], CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36');
        curl_setopt($conn[$k], CURLOPT_MAXREDIRS, 7);//HTTp定向级别
        curl_setopt($conn[$k], CURLOPT_HEADER, 0);//这里不要header，加块效率
        curl_setopt($conn[$k], CURLOPT_ENCODING, "gzip");
        curl_setopt($conn[$k], CURLOPT_RETURNTRANSFER, 1);
        curl_multi_add_handle($mh, $conn[$k]);
    }

    // 执行批处理句柄
    $active = null;
    do {
        $mrc = curl_multi_exec($mh, $active);//当无数据，active=true
    } while ($mrc == CURLM_CALL_MULTI_PERFORM);//当正在接受数据时
    while ($active && $mrc == CURLM_OK) {//当无数据时或请求暂停时，active=true
        //if (curl_multi_select($mh) != -1) {
        do {
            $mrc = curl_multi_exec($mh, $active);
        } while ($mrc == CURLM_CALL_MULTI_PERFORM);
        // }
    }

    foreach ($conn as $k => $v) {
        curl_error($v);
        $res[$k] = curl_multi_getcontent($v);//获得返回信息
        $header[$k] = curl_getinfo($v);//返回头信息
        curl_multi_remove_handle($mh, $v);//释放资源
        curl_close($v);//关闭语柄
    }
    curl_multi_close($mh);

    $total = $suc = $failed = 0;
    foreach ($res as $ret) {
        $total++;
        $arr = json_decode($ret, true);
        if (isset($arr['code']) && $arr['code'] == 0) {
            $suc++;
        } else {
            $failed++;
        }
    }
    echo "总共{$total}个.，成功{$suc}个，失败{$failed}个！";
} else {
    exit('ID Error2!');
}

function get_gtk($skey)
{
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += (($hash << 5) & 0xffffffff) + ord($skey[$i]);
    }
    return $hash & 0x7fffffff;
}