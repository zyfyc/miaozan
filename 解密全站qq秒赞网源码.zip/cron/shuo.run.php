<?php
include_once "base.php";

$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where qid='{$qid}' and isshuo>0 and skeyzt=0 limit 1");
if ($row = $rs->fetch()) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $pskey = $row['pskey'];
    $do = $row['isshuo'];
    $next = date("Y-m-d H:i:s", time() + 60 * $row['shuorate']);

    $con = get_con($row['shuoshuo']);
    $pic = $row['shuopic'];
    if ($pic == 1) {
        $rows = file('data/pic.txt');
        shuffle($rows);
        $pic = $rows[0];
        $type = 0;
    } else {
        $type = stripos('z' . $pic, 'http') ? 0 : 1;
    }
    $pic = trim($pic);
    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $pskey);
    if ($do == 2) {
        $qzone->shuo(1, $con, $pic, $sname);
    } else {
        $qzone->shuo(0, $con, $pic, $sname);
    }
    include_once "update.php";
    $db->exec("update " . DB_PREFIX . "qqs set lastshuo='$now',nextshuo='$next' where qid='$qid'");
    exit('Ok!');
} else {
    exit('Qid Error!');
}
