<?php
include_once "base.php";
$n = is_numeric($_GET['n']) ? $_GET['n'] : exit('No Net!');
$rs = $db->query("SELECT * FROM " . DB_PREFIX . "qqs where zannet='$n' and iszan=2 and skeyzt=0");
$i = 0;
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}zan.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}&uid={$row['uid']}{$look}";
    $i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

echo '<style>* {margin: 0px;padding: 0px;}</style>';
exit(date("H:i:s") . '_' . $i . '_' . $n);