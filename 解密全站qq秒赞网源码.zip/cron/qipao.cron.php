<?php
include_once "base.php";
$n = is_numeric($_GET['n']) ? $_GET['n'] : 1;
$limit = ($n - 1) * 100;
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where isqipao>0 and skeyzt=0 order by qid DESC limit {$limit},100");
$i = 0;
$now2 = date("H:i:s");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}qipao.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
    $i = $i + 1;
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    echo "<pre>";
    print_r($get);
}

//echo '<style>* {margin: 0px;padding: 0px;}</style>';
exit($now2 . '_' . $i . '_' . $n);