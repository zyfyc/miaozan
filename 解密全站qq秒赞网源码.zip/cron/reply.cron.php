<?php
include_once "base.php";
$n = is_numeric($_GET['n']) ? $_GET['n'] : exit('No Net!');
$rs = $db->query("SELECT qid FROM " . DB_PREFIX . "qqs where replynet='$n' and isreply>0 and skeyzt=0 and (nextreply<'$now' or nextreply IS NULL)");
while ($row = $rs->fetch()) {
    $urls[] = "{$nurl}reply.run.php?key=" . $_GET['key'] . "&qid={$row['qid']}{$look}";
}
if ($urls) {
    $get = duo_curl($urls);
}
if ($_GET['get'] == 1) {
    print_r($get);
}

exit('Ok!');