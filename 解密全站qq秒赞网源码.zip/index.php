<?php
/*QQ秒赞网 www.qqmiaozan.com*/
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
    die('require PHP > 5.4.0 !');
}
// [ 应用入口文件 ]
require_once "other/360_safe3.php";
// 定义应用目录
define('APP_PATH', __DIR__ . '/application/');
//检查是否安装并获取数据库信息
if (!file_exists(APP_PATH . 'database.php')) {
    header("Location:/install/");
    exit();
}
// 加载框架引导文件
require __DIR__ . '/framework/start.php';