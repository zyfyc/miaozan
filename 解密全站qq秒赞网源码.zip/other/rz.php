<?php
error_reporting(0);
date_default_timezone_set('PRC');
header("Content-type:text/html;charset=utf-8");
if (empty ($_GET ["uin"])) { // 判断是否包含参数
    $qq = '10000';
} else {
    $qq = $_GET ["uin"];
}
if (preg_match("/^[1-9]*[1-9][0-9]*$/", $qq)) { //过滤字符
} else {
    echo('也是6');
    exit;
}
$mysql = require_once '../application/database.php';
try {
    $DB = new PDO("mysql:host={$mysql['hostname']};dbname={$mysql['database']};port={$mysql['hostport']}", $mysql['username'], $mysql['password']);
} catch (Exception $e) {
    exit('链接数据库失败:' . $e->getMessage());
}

//$result = mysqli_query("select qq from qqmz_qqs order by rand() limit 6");
$result2 = $DB->query("select qq from qqmz_qqs where qq='$qq' and iszan>0 limit 1");

//while ($rs = mysqli_fetch_assoc($result)) {
//    $arr[] = $rs;
//}
// echo $arr[1]['qq'];exit;
// print_r($arr);exit;

// 获取查询结果
$row = $result2->fetch();
// echo $row;exit;
// if ($row != 1) { // 判断是否含有用户
// // exit ( '没有该用户' );
// }
$time = date('Y-m-d H:i', time());
// 获取QQ昵称
$str = file_get_contents('http://feeds.qzone.qq.com/cgi-bin/cgi_rss_out?uin=' . $qq);

/*
 * 以下是取中间文本的函数 getSubstr=调用名称 $str=预取全文本 $leftStr=左边文本 $rightStr=右边文本
 */
function getQQNickname($str, $leftStr, $rightStr) {
    $left = strpos($str, $leftStr);
    // echo '左边:'.$left;
    $right = strpos($str, $rightStr, $left);
    // echo '<br>右边:'.$right;
    if ($left < 0 or $right < $left)
        return '';
    return substr($str, $left + strlen($leftStr), $right - $left - strlen($leftStr));
}

// echo getQQNickname($str,'[CDATA[',']]></title>');

?>
<html>
<head>
    <title>QQ:<?php echo "$qq" ?>的秒赞认证页面 - QQ秒赞网,24小时离线秒赞秒评</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="description" content="QQ秒赞网认证，提供认证查询，轻松辨别好友是否正在离线秒赞"/>
    <meta name="keywords" content="QQ秒赞,离线秒赞,免费秒赞,QQ秒赞网"/>
    <!--[if lte IE 8]>
    <script src="/static/renzheng/css/ie/html5shiv.js"></script><![endif]-->
    <script src="/static/renzheng/js/jquery.min.js"></script>
    <script src="/static/renzheng/js/skel.min.js"></script>
    <script src="/static/renzheng/js/init.js"></script>
    <noscript>
        <link rel="stylesheet" href="/static/renzheng/css/skel.css"/>
        <link rel="stylesheet" href="/static/renzheng/css/style.css"/>
        <link rel="stylesheet" href="/static/renzheng/css/style-desktop.css"/>
    </noscript>
    <!--[if lte IE 8]>
    <link rel="stylesheet" href="/static/renzheng/css/ie/v8.css"/><![endif]-->
    <!--[if lte IE 9]>
    <link rel="stylesheet" href="/static/renzheng/css/ie/v9.css"/><![endif]-->
    <script>
        var _hmt = _hmt || [];
        (function () {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?40b758abd81264c7adc13c09d695584c";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
</head>
<body>

<!-- Nav -->
<nav id="nav">
    <ul class="container">
        <li><a href="/">返回首页</a></li>
		<li><a href="/"><?php echo $_SERVER['HTTP_HOST']?></a></li>
    </ul>
</nav>
<!-- Home -->
<div class="wrapper style1 first">
    <article class="container" id="top">
        <div class="row">
            <div class="4u">
                <span class="image fit"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $qq ?>&spec=100" alt="QQ秒赞认证头像"/></span>
            </div>
            <div class="8u">
                <header>
                    <?php
                    if (!$_GET ["uin"]) {
                        echo <<<END
    <form action="?" method="get" >
        <input name="uin" type="text" onkeyup="value=value.replace(/[^1234567890-]+/g,'')" placeholder="输入要查询的QQ号码" />
      <button type="submit" class="button big scrolly" style=" margin-top: 20px;">秒赞认证查询</button>
</form>
END;
                        exit;
                    }
                    ?>
                    <h1>
                        <strong><?php
                            $str = getQQNickname($str, '[CDATA[', ']]></title>');
                            if (strstr($str, 'gb2312')) {
                                echo 'Not Found！';
                            } else {
                                echo $str;
                            }
                            ?></strong>
                    </h1>
                </header>
                <p>
                    <strong>QQ：<?php echo "$qq"; ?></strong><?php
                    if ($row == 0) {
                        echo " 目前没有在本网站开启离线秒赞功能，此次秒赞认证不通过。<br /><br />查询时间：$time";
                    } else {
                        echo " 已在[QQ秒赞网]提交了托管服务，可进行24小时不间断说说秒赞！<br /><img src=\"/static/renzheng/images/mzrz.png\" alt=\"QQ秒赞网24小时离线秒赞\" /><br /><br />查询时间：$time<br /><button class=\"button big scrolly\" style=\" margin-top: 20px;font-size: small;background-color: #FF6347;\"><a href=\"http://wpa.qq.com/msgrd?v=3&uin=$qq&site=www.qqmiaozan.com&menu=yes\">添加Ta为好友</a></button>";
                    }
                    ?>

                </p>
                <form action="?" method="get">
                    <input name="uin" type="text" onKeyUp="value=value.replace(/[^1234567890-]+/g,'')" placeholder="输入要查询的QQ号码"/>
                    <button type="submit" class="button big scrolly" style=" margin-top: 20px;">秒赞认证查询</button>
                </form>
            </div>
        </div>
    </article>
</div>
<!-- Work -->
<div class="wrapper style2">
    <article id="work">
        <footer>
            <p>©2016-2017 QQ秒赞网. All Rights Reserved.</p>
        </footer>
    </article>
</div>
</body>
</html>
