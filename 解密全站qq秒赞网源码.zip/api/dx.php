<?php
header('Content-Type: text/html; charset=UTF-8');
error_reporting(0);

function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
        $hash&=0x7fffffff;
    }
    return $hash & 0x7fffffff; //计算g_tk
}
session_start();
$uin = $_REQUEST['uin'];
$skey = $_REQUEST['skey'];
$p_skey = $_REQUEST['p_skey'];
$gtk = getGTK($skey);
$gtk2 = getGTK($p_skey);
$cookie2 = 'uin=o0' . $uin . '; skey=' . $skey . '; p_skey=' . $p_skey . ';';
$cookie = 'uin=o0' . $uin . '; skey=' . $skey;
$url = "http://mobile.qzone.qq.com/friend/mfriend_list?g_tk=" . $gtk . "&res_uin=" . $uin . "&res_type=normal&format=json&count_per_page=10&page_index=0&page_type=0&mayknowuin=&qqmailstat=";
$json = get_curl($url, 0, 1, $cookie);
$json = mb_convert_encoding($json, "UTF-8", "UTF-8");
$arr = json_decode($json, true);
if ($arr['code'] == - 3000) {
    exit('{"code":-1,"msg":"QQ登陆码过期请更新！"}');
}
$hycount = count($arr['data']['list']);
$dxrow['code'] = 0;
$dxrow['msg'] = 'suc';
$n = 1;
$i = 0;
// foreach ($arr['data']['list'] as $row) {
    // $touin = $row['uin'];
    // $i++;
    // if (!isset($_SESSION["o" . $uin]["$touin"])) {
        // $url = "http://m.qzone.com/friendship/get_friendship?g_tk={$gtk}&fromuin={$uin}&touin={$touin}&isReverse=1&res_type=4&refresh_type=1&format=json";
        // $json = get_curl($url, 0, 1, $cookie);
        // $arr = json_decode($json, true);
        // if ($ship = $arr['data']['friendShip']) {
            // $addtime = $ship[0]['add_friend_time'];
            // $_SESSION['o' . $uin]["$touin"] = $addtime;
            // if ($addtime == - 1) {
                // $dxrow['dxrow'][] = $row;
                // $_SESSION['qqmz_dxrow']["$uin"][] = $row;
            // }
        // }
        // $n++;
    // }
    // if ($n > 10) break;
// }
// $data2='#';
//下面是好友度判断法
// foreach ($arr['data']['list'] as $row) {
    // $touin = $row['uin'];
    // $i++;
	// // $data2.=$touin.'#';
    // if (!isset($_SESSION["o" . $uin]["$touin"])) {
        // $url = "http://r.qzone.qq.com/cgi-bin/friendship/cgi_friendship?activeuin={$touin}&passiveuin={$uin}&situation=1&g_tk={$gtk2}";
		// $data = preg_replace("/\s/","",get_curl($url, 0, 'http://cnc.qzs.qq.com/qzone/v8/pages/friendship/friendship.html', $cookie2));
		// preg_match('/_Callback\((.*)\);/',$data,$json);
		// $arr = json_decode($json[1],true);
		// // print_r($arr);exit;
        // if ($addtime = $arr['data']['addFriendTime']) {
            // $_SESSION['o' . $uin]["$touin"] = $addtime;
            // if ($addtime == - 1) {
                // $dxrow['dxrow'][] = $row;
                // $_SESSION['qqmz_dxrow']["$uin"][] = $row;
            // }
        // }else{
			// if ($arr['data']['intimacyScore'] <= 50) {
				// $dxrow['dxrow'][] = $row;
                // $_SESSION['qqmz_dxrow']["$uin"][] = $row;
			// }
			// $_SESSION['o' . $uin]["$touin"] = 1;
		// }
        // $n++;
    // }
    // if ($n > 30) break;
// }
// qq秀判断法
foreach ($arr['data']['list'] as $row) {
    $touin = $row['uin'];
    $i++;
	// $data2.=$touin.'#';
    if (!isset($_SESSION["o" . $uin]["$touin"])) {
        $url = "http://client.show.qq.com/cgi-bin/qqshow_client_showinfo?g_tk={$gtk2}&omode=4&uin={$uin}&touin={$touin}&cmd=10413";
		$data = get_curl($url, 0, "http://client.show.qq.com/?opuin={$uin}&ptlang=2052&page=home&status=guest&guestuin={$touin}&gueststyle=1&guestsex=M&uin={$uin}&sex=M", $cookie2);
		$arr = json_decode($data,true);
		// print_r($arr);exit;
        if ($arr['code']=='-1') {
            $_SESSION['o' . $uin]["$touin"] = 1;
                $dxrow['dxrow'][] = $row;
                $_SESSION['qqmz_dxrow']["$uin"][] = $row;
        }else{
			$_SESSION['o' . $uin]["$touin"] = 1;
		}
        $n++;
    }
    if ($n > 30) break;
}
if ($i == $hycount) {
    $dxrow['finish'] = 1;
} else {
    $dxrow['finish'] = 0;
}
$dxrow['count'] = $i;
// $dxrow['count2'] = $data2;
$dxrow['dxcount'] = count($_SESSION['qqmz_dxrow']["$uin"]);
exit(json_encode($dxrow));
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
    $header2 = array(
        'Accept: application/json',
        'Connection: keep-alive',
    );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, 1);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, "http://h5.qzone.qq.com/mqzone/index");
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X; en-us) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header2);
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}
