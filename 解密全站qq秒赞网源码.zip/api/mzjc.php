<?php
// www.qqmiaozan.com 2016年12月26日
error_reporting(0);
function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
        $hash &= 0x7fffffff;
    }
    return $hash & 0x7fffffff; //计算g_tk
}

function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $head = 0, $ua = 0, $nobaody = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $header[] = "Accept:application/json";
    $header[] = "Accept-Encoding:gzip,deflate,sdch";
    $header[] = "Accept-Language:zh-CN,zh;q=0.8";
    $header[] = "Connection:keep-alive";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($head) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, "https://mobile.qzone.qq.com/");
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    $ret = mb_convert_encoding($ret, "UTF-8", "UTF-8");
    return $ret;
}


$uin = $_GET['uin'] ? $_GET['uin'] : exit('No Uin!');
$skey = $_GET['skey'] ? $_GET['skey'] : exit('No Skey!');
$pskey = $_GET['pskey'] ? $_GET['pskey'] : exit('No pskey!');

$gtk = getGTK($pskey);
$cookie = 'uin=o0' . $uin . '; skey=' . $skey . '; p_skey=' . $pskey . ';';
// 获取说说列表
$url = 'http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin='.$uin.'&ftype=0&sort=0&pos=0&num=5&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk='.$gtk;
$json = get_curl($url, 0, 1, $cookie);
// echo $json;die;
$arr = json_decode($json, true);
// echo $json.'<hr/>';
// echo '<pre>';
// print_r($arr);exit;
$uins = [];
$jsonarr = [];
if (@array_key_exists('code',$arr) && $arr['code']==0) {
    // 获取好友列表
    $furl = "https://mobile.qzone.qq.com/friend/mfriend_list?g_tk={$gtk}&res_uin={$uin}&res_type=normal&format=json";
    $fjson = get_curl($furl, 0, 1, $cookie);
    $farr = json_decode($fjson, true);
    //exit(print_r($farr));
    $nfarr = [];
    if (!isset($farr['data']['list'])) {
        exit('{"code":-1,"msg":"状态吗过期，请更新后再使用！"}');
    }
    foreach ($farr['data']['list'] as $row) {
        $nfarr["$row[uin]"]['uin'] = $row['uin'];
        $nfarr["$row[uin]"]['groupid'] = $row['groupid'];
        $nfarr["$row[uin]"]['name'] = $row['nick'];
        $nfarr["$row[uin]"]['remark'] = $row['remark'];
    }
    $n = 0;
    foreach ($arr['msglist'] as $row) {
        $newuins = [];
        $zanurl = "http://users.qzone.qq.com/cgi-bin/likes/get_like_list_app?uin={$uin}&unikey=".urlencode($row['key1'])."&begin_uin=0&query_count=0&if_first_page=1&g_tk={$gtk}&format=json";
        $zanjson = get_curl($zanurl, 0, $zanurl, $cookie);
        $zanjson = str_replace([
            '&quot;',
            '_Callback(',
            ');',
        ], [
            '',
            '',
            '',
        ], $zanjson);
        $zanjson = mb_convert_encoding($zanjson, "UTF-8", "UTF-8");
        $zanarr = json_decode($zanjson, true);
        foreach ($zanarr['data']['like_uin_info'] as $zrow) {
            $fuin = $zrow['fuin'];
            if (isset($nfarr["$fuin"]['mz'])) {
                $nfarr["$fuin"]['mz'] = $nfarr["$fuin"]['mz'] + 1;
            } else {
                $nfarr["$fuin"]['mz'] = 1;
                $uins[] = $fuin;
            }
        }
        $n++;
        if ($n > 9) {
            break;
        }
    }
    $mz = 0;
    foreach ($nfarr as $k => $v) {
        if (isset($v['mz'])) {
            $mz++;
            $narr[$k] = $v['mz'];
        } else {
            $narr[$k] = 0;
        }
    }
    array_multisort($narr, SORT_DESC, $nfarr);
    $jsonarr['code'] = 0;
    $jsonarr['msg'] = 'suc';
    $jsonarr['mzcount'] = $mz;
    $jsonarr['uins'] = $uins;
    $jsonarr['gpnames'] = $farr['data']['gpnames'];
    $jsonarr['friend'] = $nfarr;
    exit(json_encode($jsonarr));
} else {
    exit('{"code":-1,"msg":"QQ状态码已过期，请更新QQ后再来使用！"}');
}