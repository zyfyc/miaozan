<?php
if(empty($_SERVER['HTTP_REFERER'])){
	exit('404 Not Found');
}
function get_curl($url,$post=0,$cookie=0,$header=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	$httpheader[] = "Accept:application/json";
	$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
	$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
	$httpheader[] = "Connection:close";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, 1);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	curl_setopt($ch, CURLOPT_REFERER, $url);
	curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0');
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
function getGTK($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
        $hash&=0x7fffffff;
    }
    return $hash & 0x7fffffff; //计算g_tk
}
session_start();
include_once "conn.php";
$qid=is_numeric($_POST['qid'])?$_POST['qid']:exit('{"code":-1,"msg":"QID不能空"}');
$uid=is_numeric($_POST['uid'])?$_POST['uid']:exit('{"code":-1,"msg":"uid不能空"}');
$date=date("Y-m-d");
$result = mysql_query("SELECT * FROM {$tableqz}qqs where qid='{$qid}' and skeyzt=0 limit 1");
if(!$row=mysql_fetch_array($result)){
	exit('{"code":-1,"msg":"QID'.$qid.'过期"}');
}
$count = mysql_query("select count(id) from {$tableqz}rqlog where uid='{$uid}' and addtime='{$date}'");//统计使用次数
$row2=mysql_fetch_array($count);
if($row2[0] > '499'){
	exit('{"code":-6,"msg":"额度已用完"}');
}
$uin=$_POST['uin'];
$gtk=getGTK($row['pskey']);
$cookie='pt2gguin=o0'.$row['qq'].'; uin=o0'.$row['qq'].'; skey='.$row['skey'].'; p_skey='.$row['pskey'].'; p_uin=o0'.$row['qq'].';';
$url='http://mobile.qzone.qq.com/combo?g_tk='.$gtk.'&hostuin='.$uin.'&action=1&g_f=&refresh_type=1&res_type=2&format=json';
$res=get_curl($url,0,$cookie);
// echo $url.'<br/>'.$cookie.'<br/>'.$ret;exit;
$_SESSION['o_'.$uin][$row['qq']]=1;
@mysql_query("insert into {$tableqz}rqlog(uid,qq,addtime) values('{$uid}','{$uin}','{$date}')");
exit('{"code":0,"msg":"'.$row['qq'].'访问成功！"}');