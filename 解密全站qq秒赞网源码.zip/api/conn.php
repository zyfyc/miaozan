<?php
error_reporting(E_ALL & ~E_NOTICE);
@header('Content-Type: text/html; charset=UTF-8');
@ignore_user_abort(true);
@set_time_limit(0);

$mysql = require("../application/database.php");
$dbhost = $mysql['hostname'] . ':' . $mysql['hostport'];
$dbuser = $mysql['username'];
$dbpassword = $mysql['password'];
$dbmysql = $mysql['database'];
if ($con = mysqli_connect($dbhost, $dbuser, $dbpassword)) {
    mysqli_select_db($con, $dbmysql);
} else {
    exit('数据库链接失败！');
}
mysqli_query($con, "set names utf8");
$tableqz = $mysql['prefix'];
$result = mysqli_query($con, "select * from {$tableqz}webconfigs");
while ($row = mysqli_fetch_array($result)) {
    $config[$row['vkey']] = $row['value'];
}
