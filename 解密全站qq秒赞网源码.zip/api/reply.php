<?php
if (empty($_SERVER['HTTP_REFERER'])) {
    exit('404 Not Found');
}
session_start();
include_once "conn.php";
$qid = is_numeric($_POST['qid']) ? $_POST['qid'] : exit('{"code":-1,"msg":"QID不能空"}');
$uid = is_numeric($_POST['uid']) ? $_POST['uid'] : exit('{"code":-1,"msg":"uid不能空"}');
$content = $_POST['content'] ? $_POST['content'] : exit('{"code":-1,"msg":"content不能空"}');
$date = date("Y-m-d");
$result = mysqli_query($con, "SELECT * FROM {$tableqz}qqs where qid='{$qid}' and skeyzt=0 limit 1");
if (!$row = mysqli_fetch_array($result)) {
    exit('{"code":-1,"msg":"QID' . $qid . '过期"}');
}
$count = mysqli_query($con, "select count(id) from {$tableqz}replylog where uid='{$uid}' and addtime='{$date}'");//统计使用次数
$row2 = mysqli_fetch_array($count);
if ($row2[0] > '20') {
    exit('{"code":-6,"msg":"额度已用完"}');
}

$cell = $_POST['cell'];
$uin = $_POST['uin'];
$appid = '311';
$typeid = '0';
$curkey = urlencode('http://user.qzone.qq.com/' . $uin . '/mood/' . $cell);
$uinkey = urlencode('http://user.qzone.qq.com/' . $uin . '/mood/' . $cell);
$from = '1';
$abstime = time();
$cellid = $cell;

include_once "../cron/qzone.class.php";
$qzone = new qzone($row['qq'], $row['sid'], $row['skey'], $row['pskey']);
if (!$row['skeyzt']) {
    $qzone->error = [];
    $qzone->pcreply($content, $uin, $cellid, $from);
    if ($qzone->skeyzts) {
        $_SESSION['o_' . $cell][$row['qq']] = 0;
        mysqli_query($con, "UPDATE {$tableqz}qqs SET skeyzt='1' WHERE qid='{$qid}'");
        exit('{"code":-3,"msg":"' . $row['qq'] . '的SKEY已过期！"}');
    }
    if ($error = $qzone->error[0]) {
        exit('{"code":-4,"msg":"' . $error . '"}');
    } else {
        $_SESSION['o_' . $cell][$row['qq']] = 1;
        mysqli_query($con, "insert into {$tableqz}replylog(uid,qq,cell,addtime) values('{$uid}','{$uin}','{$cell}','{$date}')");
        exit('{"code":0,"msg":"已开始执行！"}');
    }
} else {
    exit('{"code":-3,"msg":"' . $row['qq'] . '的SKEYZT已过期！"}');
}
