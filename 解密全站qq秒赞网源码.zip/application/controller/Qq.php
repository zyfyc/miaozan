<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;

class Qq extends Controller {
    private $user;

    private function getGTK($skey) {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
            $hash &= 0x7fffffff;
        }
        return $hash & 0x7fffffff; //计算g_tk
    }

    /**
     * 打码兔
     * @param $uin string QQ号
     * @param $sig string sig码
     * @return string|bool 返回验证码结果
     */
    private function dama2($uin, $cap_cd, $sig, $sess) {
		vendor('Dama2Web');
		$dama = new \Dama2Web(config('dama_user'), config('dama_pwd'));
		//通过url打码。返回数组
		$url='http://captcha.qq.com/cap_union_new_getcapbysig?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999).'&rand=0.02398118'.time().'&sess='.$sess.'&vsig='.$sig.'&ischartype=1';
		$data = get_curl($url);
		$a = $dama->decodeBase64($data, 23); // 英文码
		if ($a['result'] == 'IERROR') { // 有ierror说明可能是中文码
			$a = $dama->decodeBase64($data, 62); // 中文码
			if ($a['ret'] == 0 && $a['result'] != 'ERROR') {
				return $a['result'];
			}
		} elseif ($a['ret'] == 0 && $a['result'] != 'ERROR') {
			return $a['result'];
		}
		return false;
    }

	/**
     * 超人打码
     * @param $uin string QQ号
     * @param $sig string sig码
     * @return string|bool 返回验证码结果
     */
    private function chaorendama($uin, $cap_cd, $sig, $sess) {
		vendor('Chaorendama');
		$dama = new \Chaorendama(config('dama_user'), config('dama_pwd'));
		//通过url打码。返回数组
		$url='http://captcha.qq.com/cap_union_new_getcapbysig?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999).'&rand=0.02398118'.time().'&sess='.$sess.'&vsig='.$sig.'&ischartype=1';
		$data = get_curl($url);
		$result = $dama->recv_byte($data);
		if (is_array($result)) {
			return $result['result'];
		} else {
			return false;
		}
    }

	/**
     * 若快打码
     * @param $uin string QQ号
     * @param $sig string sig码
     * @return string|bool 返回验证码结果
     */
    private function ruokuaidama($uin, $cap_cd, $sig, $sess) {
		vendor('Ruokuaidama');
		$dama = new \Ruokuaidama(config('dama_user'), config('dama_pwd'));
		//通过url打码。返回数组
		$url='http://captcha.qq.com/cap_union_new_getcapbysig?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999).'&rand=0.02398118'.time().'&sess='.$sess.'&vsig='.$sig.'&ischartype=1';
		$data = get_curl($url);
		$result = $dama->recv_byte($data);
		if (is_array($result)) {
			return $result['result'];
		} else {
			return false;
		}
    }

    /**
     * QQ添加页面获取二维码以及登录
     * @return string Json数据
     */
    public function qrLogin() {
        $do = input("param.do");
        $find = input("get.find");
        vendor("QzoneQrcode");
        $login = new \QzoneQrcode();
        if ($do == 'qqlogin') {
            $qrsig = input("param.qrsig") ? input("param.qrsig") : die('Need Qrsig');
            $data = $login->qqlogin($qrsig);
            // 如果是找回密码就执行以下操作
            if ($find == 1 && $data['code'] == 0) {
                // 密码重置123456
                db("users")->where("qq='{$data['uin']}'")->setField("pwd", '305dc2ef435361ad8cebedff0636076b');
                // 获取用户名
                $user = db("users")->field("user")->where("qq='{$data['uin']}'")->find();
                if ($user) {
                    return json([
                        "code" => 'find',
                        "name" => $user['user'],
                    ]);
                } else {
                    return json([
                        "code" => 'nofind',
                    ]);
                }
            }
            // End 找回密码
        } elseif ($do == 'getqrpic') {
            $data = $login->getqrpic();
        } else {
            die('参数错误');
        }
        return json($data);
    }

    /**
     * 秒赞和秒评的黑白名单
     */
    public function roster() {
        $qid = input('param.qid', '', 'get_safe_str');
        $type = input('post.type', '', 'get_safe_str');
        $list = input('post.qqlist', '', 'get_safe_str');
        if (preg_match("/[\x7f-\xff]/", $list)) {
            get_exit('请正确填写QQ名单！');
        }
        if (db("roster")->where("qid='$qid'")->find()) { // 检查是否存在记录
            if (input("post.do") == 'zan') {
                if (!$list) { // QQ列表为空就把模式关闭
                    $data['zan_type'] = 0;
                } else {
                    $data['zan_type'] = $type;
                }
                $data['zan_list'] = $list;
                db("roster")->where("qid='$qid'")->update($data);
            } else {
                if (!$list) { // QQ列表为空就把模式关闭
                    $data['reply_type'] = 0;
                } else {
                    $data['reply_type'] = $type;
                }
                $data['reply_list'] = $list;
                db("roster")->where("qid='$qid'")->update($data);
            }
            get_exit('修改成功！');
        } else {
            if (input("post.do") == 'zan') {
                $data['qid'] = $qid;
                $data['zan_type'] = $type;
                $data['zan_list'] = $list;
                db("roster")->where("qid='$qid'")->insert($data);
            } else {
                $data['qid'] = $qid;
                $data['reply_type'] = $type;
                $data['reply_list'] = $list;
                db("roster")->where("qid='$qid'")->insert($data);
            }
            get_exit('添加成功！');
        }
    }

    /**
     * 已添加的QQ列表
     */
    public function qqlist() {
        $this->islogin();
        $row = db("qqs")->field('*')->where("uid='{$this->user['uid']}'")->select();
        $this->assign('qqrow', $row);
        if (!$row) {
            $art = '<script>swal({title:"温馨提示",text:"您当前还暂未添加QQ，无法使用功能，是否添加？",type:"warning",showCancelButton:true,confirmButtonColor:"#DD6B55",confirmButtonText:"添加",cancelButtonText:"暂不",closeOnConfirm:false,closeOnCancel:true},function(isConfirm){if(isConfirm){window.location.href="/qq/add.html"}else{return false;}});</script>';
            $this->assign('noqqart', $art);
        }
        return $this->fetch();
    }

    /**
     * QQ功能信息页面
     */
    public function info() {
        $this->islogin();
        $qid = is_numeric(input("param.qid")) ? input("param.qid") : '0';
        $row = $this->qqcheck($qid);

        // 基础功能列表
        $tools = [
            'zan'   => [
                'name' => '说说秒赞',
                'tip'  => '24H离线秒赞好友动态',
                'set'  => 1,
            ],
            'reply' => [
                'name' => '说说秒评',
                'tip'  => '24H离线秒评好友动态',
            ],
            'zf'    => [
                'name' => '转发说说',
                'tip'  => '自动转发指定QQ的说说',
            ],
            'qt'    => [
                'name' => '说说圈图',
                'tip'  => '在好友的图文说说中圈出自己增加曝光率(频率15分钟)',
            ],
            'shuo'  => [
                'name' => '自动说说',
                'tip'  => '定时发随机说说可带图片',
            ],
            'qd'    => [
                'name' => '空间签到',
                'tip'  => '每天进行QQ空间的微笑签到',
            ],
            'del'   => [
                'name' => '删除说说',
                'tip'  => '每15分钟删除10条说说，仅保留最新10条',
            ],
            'delly' => [
                'name' => '清空留言',
                'tip'  => '每15分钟删除10条留言，清空后自动关闭',
            ],
        ];
        $this->assign('tools', $tools);
        // End 基础功能列表
        // 扩展功能列表
        $tools2 = [
			'syqd' => [
                'name' => '手Q游戏',
                'tip'  => '手游签到获取0.2活跃天',
            ],
            'vipqd' => [
                'name' => '会员签到',
                'tip'  => '将每天的QQ会员成长值领满',
            ],
            'qb'    => [
                'name' => '钱包签到',
                'tip'  => 'QQ钱包签到领取0.2活跃天',
            ],
            'ht'    => [
                'name' => '花藤服务',
                'tip'  => '每日花藤各项进行浇灌',
            ],
            'ts'    => [
                'name' => '图书签到',
                'tip'  => '腾讯读书频道的每日签到',
            ],
            'qunqd' => [
                'name' => 'Q群签到',
                'tip'  => 'QQ群每日签到，领取对应群内奖励',
            ],
            'qipao' => [
                'name' => '百变气泡',
                'tip'  => '随机更换聊天气泡，目前频率1分钟',
            ],
            'lz'    => [
                'name' => '绿钻签到',
                'tip'  => '获取5点绿钻成长值+抽奖机会',
            ],
            'hzqd'  => [
                'name' => '黄钻签到',
                'tip'  => '获取2点黄钻成长值',
            ],
            'xzqd'  => [
                'name' => '星钻签到',
                'tip'  => '获取2点星钻成长值',
            ],
        ];
        $this->assign('tools2', $tools2);
        // End 扩展功能列表
        // 互刷功能列表
        $tools3 = [
            'ly'    => [
                'name' => '互刷留言',
                'tip'  => '功能需要开启空间访问和留言权限',
            ],
            'zyzan' => [
                'name' => '互赞主页',
                'tip'  => '功能需要开启空间访问权限',
            ],
        ];
        $this->assign('tools3', $tools3);
        // End 互刷功能列表
        $this->assign('qqrow', $row);
        if ($row['skeyzt'] != 0) {
            $msg = '<script>swal({title:"温馨提示",text:"当前QQ的状态码已过期，无法正常使用功能，是否更新？",type:"warning",showCancelButton:true,confirmButtonColor:"#DD6B55",confirmButtonText:"更新",cancelButtonText:"暂不",closeOnConfirm:false,closeOnCancel:true},function(isConfirm){if(isConfirm){window.location.href="/qq/add.html?uin=' . $row["qq"] . '"}else{return false;}});</script>';
            $this->assign('msg', $msg);
        } elseif ($row['iszan'] == 0 || $row['zannet'] == 0) {
            $msg = '<script>swal({title:"温馨提示",text:"当前QQ的秒赞功能尚未开启，导致无法自动更新QQ状态码，是否开启？",type:"warning",showCancelButton:true,confirmButtonColor:"#DD6B55",confirmButtonText:"开启",cancelButtonText:"暂不",closeOnConfirm:false,closeOnCancel:true},function(isConfirm){if(isConfirm){window.location.href="/qq/funcData/qid/' . $row["qid"] . '/xz/zan.html"}else{return false;}});</script>';
            $this->assign('msg', $msg);
        }
        return $this->fetch();
    }

    /**
     * 删除已添加的QQ
     */
    public function del() {
        $qid = input("post.qid");
        $row = $this->qqcheck($qid);
        if (input("post.do") == 'del') { // 删除QQ
            db("qqs")->where("qid='{$qid}'")->delete();
            $data = [
                'title' => '删除成功！',
                'msg'   => '将跳转至用户中心...',
                'type'  => 'success',
                'timer' => '3000',
                'url'   => url('index/user'),
            ];
        } else {
            die; // 未定义操作
        }
        return [
            'code' => '0',
            'data' => $data,
        ];
    }

    /**
     * QQ功能设置
     * 快捷开关
     */
    public function funcChange() {
        $qid = input("post.qid");
        $row = $this->qqcheck($qid);

        if (input("post.do") == 'change') { // 修改功能
            $name = input("post.modid"); // 功能名称
            if (!get_isvip($this->user['vip'], $this->user['vipend']) and $name != 'zan' and $name != 'wx') { // 非VIP无法使用秒赞以外的功能
                $data = [
                    'title' => '设置失败',
                    'msg'   => '对不起，此功能仅VIP可使用！',
                    'type'  => 'warning',
                ];
            } elseif ($name == 'qt' && $this->user['vip'] != 3) { // 如果是圈图功能则需要年费，vip!=3 将拒绝
                $data = [
                    'title' => '设置失败',
                    'msg'   => '对不起，此功能需要年费VIP等级！',
                    'type'  => 'warning',
                ];
            } else {
                // 通过上方等级判断后，执行对应操作
                // 需要高级设置的功能进行页面跳转
                // retrun code=1 为跳转设置，2为自动开关
                if ($name == 'zan' || $name == 'reply' || $name == 'zf' || $name == 'shuo' || $name == 'qd') {
                    return [
                        'code' => '1',
                        'data' => [
                            'url' => url('qq/funcData', 'qid=' . $qid . '&xz=' . $name),
                        ],
                    ];
                } else { // 下方为code=2
                    if (array_key_exists("is{$name}", $row)) { // 检查是否有此项功能
                        if ($row["is{$name}"]) { // 大于0为已开启
                            db('qqs')->where("qid='{$qid}'")->setField("is{$name}", '0');
                            $tips = '关闭';
                        } else {
                            if ($name == 'vipqd' || $name == 'lz' || $name == 'zyzan' || $name == 'qt' || $name == 'qunqd' || $name == 'del') {
                                db('qqs')->where("qid='$qid'")->setField("is{$name}", '2');
                            } else {
                                db('qqs')->where("qid='$qid'")->setField("is{$name}", '1');
                            }
                            $tips = '开启';
                        }
                        $data = [
                            'title' => $tips . '成功',
                            'msg'   => '已' . $tips . '成功！',
                            'type'  => 'success',
                            'timer' => '2000',
                        ];
                    } else {
                        die('funcNameErr'); // 传入的功能名称错误
                    }
                }
            }
        } else {
            die; // 未定义操作
        }
        return [
            'code' => '2',
            'data' => $data,
        ];
    }

    /**
     * 秒赞数据修改
     */
    public function zanData() {
        $this->islogin();
        $qid = is_numeric(input("param.qid")) ? input("param.qid") : 0;
        $net = is_numeric(input("param.net")) ? input("param.net") : 0; // 0关闭，1免费，2vip，3极速，4超极速
        $row = $this->qqcheck($qid);
        $do = input("post.do");
        if ($do == 'zan') {
            if ($net > 0) { // 判断是否开启功能
                if ($net > 4 || $net < 0) {
                    get_exit('请选择一个合适的服务器');
                } elseif ($net == 2 && !get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此服务器需要开通本站VIP才能使用！", url('shop/vip'));
                } elseif ($net == 3 && ($this->user['vip'] < 2 || $this->user['vip'] == 4)) {
                    get_exit("对不起，极速服务器需要VIP季度会员才能使用！");
                } elseif ($net == 4 && $this->user['vip'] == 0) {
                    get_exit("对不起，此服务器需要VIP会员才能使用！");
                }
                $freezan = config('freezan'); //免费服务器数
                $vipzan = config('zannet'); //vip服务器数
                $jisuzan = config('zannet_jisu'); //极速服务器数
                if ($net == 1) {
                    $i = 1;
                    $netnum = $freezan;
                } elseif ($net == 2) {
                    $i = 100;
                    $netnum = $vipzan;
                } elseif ($net == 3) {
                    $i = 200;
                    $netnum = $jisuzan;
                } else {
                    $i = 400;
                    $netnum = 18;
                }
                $freedata = [];
                for ($net = $i; $net < $i + $netnum; $net++) {
                    $num = db('qqs')->where("zannet={$net}")->count('qid'); // 当前服务器数的人数
                    $freedata["$net"] = $num;
                }
                $min = min($freedata); // 最少的人数量
                if ($min >= config('netnum')) {
                    if ($this->user['vip'] == 0) {
                        get_exit('当前服务器已经人数爆满，建议开通VIP后使用更畅快的服务器，也可等待免费系统的定时清理！');
                    } else {
                        get_exit('当前服务器已经人数爆满，请选择其他的服务器进行使用！');
                    }
                }
                $net = array_search($min, $freedata); // 检查出人数最少的服务器号
                $data['iszan'] = 2;
                $data['zannet'] = $net;
            } else {
                $data['iszan'] = 0;
                $data['zannet'] = 0;
            }
//            var_dump($data);die;
            db("qqs")->where("qid='$qid'")->update($data);
            get_exit('秒赞设置成功！');
        } else {
            get_exit('秒赞设置失败，请刷新页面后重新！');
        }
    }

    /**
     * QQ功能的数据修改
     */
    public function funcData() {
        $this->islogin();
        $qid = is_numeric(input("param.qid")) ? input("param.qid") : '0';
        $row = $this->qqcheck($qid);
        $net = is_numeric(input("post.net")) ? input("post.net") : '0';
        $rate = is_numeric(input("post.rate")) ? input("post.rate") : '15';
        if (input("param.xz") == 'zan' || input("param.xz") == 'reply') {
            $roster = db('roster')->field('*')->where("qid='{$qid}'")->find();
        } else {
            $roster = [];
        }
        if ($do = input("post.do")) {
            $is = is_numeric(input("post.is")) ? input("post.is") : '0';
            if ($do == 'reply') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $data['isreply'] = $is;
                $con = input('post.content', '', 'get_safe_str');
                $data['replycon'] = $con;
                $data['replynet'] = $net;
                if (!$is) {
                    $data['replynet'] = 0;
                }
                db("qqs")->where("qid='$qid'")->update($data);
                $this->assign('alert', get_exit('秒评设置成功！', 1));
                $row = db("qqs")->field('*')->where("qid='$qid'")->find();
            } elseif ($do == 'zf') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $data['iszf'] = $is;
                $data['zfnet'] = $net;
                $data['zfrate'] = $rate;
                $con = input('post.content', '', 'get_safe_str');
                $zfok = input('post.zfok', '', 'get_safe_str');

                $data['zfcon'] = $con;
                if (!$is) {
                    $data['zfnet'] = 0;
                }
                db("qqs")->where("qid='$qid'")->update($data);
                $this->assign('alert', get_exit('转发设置成功！', 1));
                $row = db("qqs")->field('*')->where("qid='$qid'")->find();
            } elseif ($do == 'zfupdate') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $id = is_numeric(input("post.id")) ? input("post.id") : '0';
                $data['zfdate'] = input('post.date', '', 'get_safe_str');
                db("zfdates")->where("id='$id'")->update($data);
            } elseif ($do == 'zfadd') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $data['uin'] = $row['qq'];
                $data['zfuin'] = input('post.uin', '', 'get_safe_str');
                $data['zfdate'] = input('post.date', '', 'get_safe_str');
                db("zfdates")->insert($data);
            } elseif ($do == 'shuo') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $data['isshuo'] = $is;
                $rate = is_numeric(input("post.rate")) ? input("post.rate") : '90';
                $con = input('post.content', '', 'get_safe_str');
                $shuopic = input('post.shuopic', '', 'get_safe_str');

                $data['shuoshuo'] = $con;
                $data['shuopic'] = $shuopic;
                $data['shuorate'] = $rate;
                $data['shuonet'] = $net;
                if (!$is) {
                    $data['shuonet'] = 0;
                }
                db("qqs")->where("qid='$qid'")->update($data);
                $this->assign('alert', get_exit('自动说说设置成功！', 1));
                $row = db("qqs")->field('*')->where("qid='$qid'")->find();
            } elseif ($do == 'qd') {
                if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                    get_exit("对不起，此功能仅VIP能使用");
                }
                $data['isqd'] = $is;
                $con = input('post.content', '', 'get_safe_str');
                $data['qdcon'] = $con;
                db("qqs")->where("qid='$qid'")->update($data);
                $this->assign('alert', get_exit('空间签到设置成功！', 1));
                $row = db("qqs")->field('*')->where("qid='$qid'")->find();
            }
        }
        /*删除转发QQ的列表*/
        if (input("param.do") == 'delzf') {
            if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
                get_exit("对不起，此功能仅VIP能使用");
            }
            $id = is_numeric(input("param.id")) ? input("param.id") : '0';
            db('zfdates')->where("uin='" . $row['qq'] . "' and id='$id'")->delete();
        }
        /*转发需要的数据*/
        if (input("param.xz") == 'zf') {
            $zfrows = db('zfdates')->field('*')->where("uin='" . $row['qq'] . "'")->select();
        } else {
            $zfrows = [];
        }
        $this->assign('zfrows', $zfrows);
        /*end转发需要的数据*/
        $this->assign('qqrow', $row);
        $this->assign('roster', $roster);
        $this->assign('xz', input("param.xz"));
        return $this->fetch();
    }

    /**
     * 添加QQ
     * 账号密码登录方式
     * code=1 需要验证码 0成功 2失败
     */
    public function add() {
        $this->islogin();
        if (input("post.do") == 'add') {
            $uin = is_numeric(input("post.uin")) ? input("post.uin") : 0;
            $pwd = input("post.pwd");
            $cap_cd = input('post.cap_cd');
            $sess = input('post.sess');
            $code = input('post.code');
            $sig = input('post.sig');
            if (!$uin || !$pwd) {
                $data = [
                    'code'  => 2,
                    'title' => '添加失败',
                    'msg'   => 'QQ号和密码不能为空',
                    'type'  => 'error',
                ];
            } elseif (!preg_match("/^[1-9][0-9]{4,11}$/", $uin)) {
                $data = [
                    'code'  => 2,
                    'title' => '添加失败',
                    'msg'   => 'QQ号码不正确',
                    'type'  => 'error',
                ];
            } else {
                $data = $this->qqlogin($uin, $pwd, $code, $cap_cd, $sig, $sess);
            }
            return json($data);
        }
        $this->assign('uin', input("param.uin"));
        return $this->fetch();
    }

    /**
     * 添加QQ
     * QRCode登录方式
     */
    public function add4qr() {
        $this->islogin();
        if (request()->isAjax()) {
            $login_data = json_decode(base64_decode(input("post.login")), true);
            $pwd = base64_decode(input("post.pwd"));
            $uin = $login_data['uin'];
            $sid = $login_data['sid'];
            $skey = $login_data['skey'];
            $pskey = $login_data['pskey'];
            $superkey = $login_data['superkey'];
            if (!$uin || !$pwd) {
                if (!$uin) {
                    $data = [
                        'code'  => '1',
                        'title' => '添加失败',
                        'msg'   => '缺少QQ参数，请重新添加',
                        'type'  => 'error',
                    ];
                    trace(input("post.login"), 'add4qrError1');
                } else {
                    $data = [
                        'code'  => '1',
                        'title' => '添加失败',
                        'msg'   => '缺少密码参数，请重新添加',
                        'type'  => 'error',
                    ];
                    trace(input("post.pwd"), 'add4qrError2');
                }
            } elseif (!preg_match("/^[1-9][0-9]{4,11}$/", $uin)) {
                $data = [
                    'code'  => '1',
                    'title' => '添加失败',
                    'msg'   => 'QQ号码不正确:' . $uin,
                    'type'  => 'error',
                ];
            } else {
                if ($skey && $pskey && $superkey) {
                    $data = $this->addsave($uin, $sid, $skey, $pskey, $superkey, $pwd);
                } else {
                    $data = [
                        'code'  => '1',
                        'title' => '缺少信息',
                        'msg'   => '请尝试重新添加QQ',
                        'type'  => 'error',
                    ];
                }
            }
        } else {
            $data = [
                'code'  => '1',
                'title' => '请求出错',
                'msg'   => '请求出错',
                'type'  => 'error',
            ];
        }
        return json($data);
    }

    /**
     * Cron文件远程更新接口
     * @return string Json code =1 更新失败， code=2 缺少参数， code=0 更新成功
     */
    public function qqUpdateApi() {
        if (input('param.do') == 'update') {
            $uin = is_numeric(input('param.uin')) ? input('param.uin') : 0;
            $pwd = input('param.pwd');
            $this->user['uid'] = input('param.uid');
            if (!$uin || !$pwd) {
                $data = [
                    "code" => 2,
                    "msg"  => "QQ号和密码不能为空!",
                ];
            } elseif (!preg_match("/^[1-9][0-9]{4,11}$/", $uin)) {
                $data = [
                    "code" => 2,
                    "msg"  => "请输入正确的QQ号!",
                ];
            } else {
                $data = $this->qqlogin($uin, $pwd);
                $ret = db('qqs')->field('zannet,iswx')->where("qq='" . $uin . "'")->find();
                // 需要验证码，使用打码功能
                if ($data['code'] == 1) {
                    if ($ret['zannet'] > config('freezan') && config('dama_onoff') == 1) { // 判断是否vip服务器
						if(config('dama_api')==3){
							$vcode = $this->ruokuaidama($uin, $data['cap_cd'], $data['sig'], $data['sess']);
						}elseif(config('dama_api')==2){
							$vcode = $this->chaorendama($uin, $data['cap_cd'], $data['sig'], $data['sess']);
						}else{
							$vcode = $this->dama2($uin, $data['cap_cd'], $data['sig'], $data['sess']);
						}
                        if ($vcode) {
                            $data = $this->qqlogin($uin, $pwd, $vcode, $data['cap_cd'], $data['sig'], $data['sess']);
                        } else {
                            $data = [
                                "code" => 2,
                                "msg"  => "未成功打码!",
                            ];
                        }
                        $data['dama'] = '自动打码';
                    } else {
                        $data = [
                            "code" => 2,
                            "msg"  => "出现验证码，请手动输入验证码!",
                            "dama" => "FreeDm",
                        ];
                    }
                } else {
                    $data['dama'] = '老用户免码';
                }
                // code=2 代表更新失败需要验证码，判断是否开启推送功能，发送提醒
                if ($data['code'] != 0 && $ret['iswx'] == 1) {
                    action('Wechat/guoqiPush', [
                        'uid' => $this->user['uid'],
                        'qq'  => $uin,
                    ]);
                }
            }
        } else {
            $data = [
                "code" => 2,
                "msg"  => "do参数错误!",
            ];
        }
        return json($data);
    }

    private function qqlogin($uin, $pwd, $code = 0, $cap_cd = 0, $sig = 0, $sess = 0) {
		if($this->login_api){
			$post = array('uin'=>$uin, 'pwd'=>$pwd, 'code'=>$code, 'cap_cd'=>$cap_cd, 'sig'=>$sig, 'sess'=>$sess);
			$data = get_curl($this->login_api, http_build_query($post));
		}else{
			$login = new \app\model\Qqlogin($uin, $pwd, $code, $cap_cd, $sig, $sess);
			$data = $login->json;
		}
        $arr = json_decode($data, true);
        if ($arr['code'] == -1) {
            // 需要输入验证码 code=1
            $data = [
                'code' => 1,
                'uin'  => $uin,
                'sig'  => $arr['sig'],
				'cap_cd'  => $arr['cap_cd'],
				'sess'  => $arr['sess'],
                'msg'  => '需要手动输入验证码',
            ];
        } elseif ($arr['code'] == -3) {
            $data = [
                'code'  => 2,
                'title' => '添加失败[1]',
                'msg'   => $arr['msg'],
                'type'  => 'error',
            ];
        } else {
            if ($arr['skey'] && $arr['pskey'] && $arr['superkey']) {
                $data = $this->addsave($uin, $arr['sid'], $arr['skey'], $arr['pskey'], $arr['superkey'], $pwd);
            } else {
                $data = [
                    'code'  => 2,
                    'title' => '添加失败[2]',
                    'msg'   => '请尝试使用扫码模式添加QQ',
                    'type'  => 'error',
                ];
            }
        }
        return $data;
    }

    /**
     * 保存QQ数据到库
     * @return array code=0成功，2失败
     */
    private function addsave($uin, $sid, $skey, $pskey, $superkey, $pwd) {
        // 存在记录就是更新，不存在就是新增
        if ($row = db("qqs")->field('qid,iszan')->where("qq='$uin' and uid='" . $this->user['uid'] . "'")->find()) {
            $data['sid'] = $sid;
            $data['skey'] = $skey;
            $data['pskey'] = $pskey;
            $data['superkey'] = $superkey;
            $data['qq'] = $uin;
            $data['passwd'] = $pwd;
            $data['skeyzt'] = 0;
            $data['uptime'] = date("Y-m-d H:i:s");
            // 如果是触屏改为PC，触屏不运行赞的
            if ($row['iszan']) {
                $data['iszan'] = 2;
            }
            $data['autolog'] = '您已手动更新QQ信息!';
            $data['lastauto'] = $data['uptime'];
            db("qqs")->where("qid='$row[qid]'")->update($data); // 保存新数据
            $data = [
                "code"  => 0,
                'title' => '更新成功',
                'msg'   => '跳转至' . $uin . '的设置页面...',
                'type'  => 'success',
                'url'   => url('qq/info', 'qid=' . $row['qid']),
                'timer' => '2000',
            ];
        } else {
            $count = db("qqs")->where("uid='" . $this->user['uid'] . "'")->count('qid');
            // 判断是否是分站进行添加QQ，再计算分站已添加QQ数量
            if ($webid = config('fenzhan')['id']) {
                $fzcount = db("qqs")->where("webid='{$webid}'")->count('qid');
            }
            // End判断分站
            if ($count >= $this->user['peie']) {
                $data = [
                    'code'  => 2,
                    'title' => '添加失败',
                    'msg'   => "对不起，你最大允许添加" . $this->user['peie'] . "个QQ！购买配额可增加数量！",
                    'url'   => url('shop/peie'),
                    'type'  => 'warning',
                ];
            } elseif ($webid && $fzcount >= config('fenzhan')['qqlimit']) { // 判断是否超过分站配额
                $data = [
                    'code'  => 2,
                    'title' => '添加失败',
                    'msg'   => "该网站配额数量已达上线，请联系站长进行扩容后再添加QQ！",
                    'url'   => url('index/user'),
                    'type'  => 'warning',
                ];
            } else {
                if (db("qqs")->field('uid')->where("qq='$uin'")->find()) { // 如果qqs里有本次添加的QQ记录，就删除旧记录
                    db('qqs')->where("qq='$uin'")->delete();
                }
                $data['uid'] = $this->user['uid'];
                $data['qq'] = $uin;
                $data['sid'] = $sid;
                $data['skey'] = $skey;
                $data['pskey'] = $pskey;
                $data['superkey'] = $superkey;
                $data['passwd'] = $pwd;
                $data['skeyzt'] = 0;
                $data['webid'] = config('fenzhan')['id'] ? config('fenzhan')['id'] : 0; // 0为主站
                $data['addtime'] = date("Y-m-d H:i:s");
                if (db("qqs")->insert($data)) {
                    $row = db("qqs")->field('qid')->where("qq='$uin'")->find();
                    $data = [
                        "code"  => 0,
                        'title' => '添加成功',
                        'msg'   => '跳转至' . $uin . '的设置页面...',
                        'type'  => 'success',
                        'url'   => url('qq/info', 'qid=' . $row['qid']),
                        'timer' => '2000',
                    ];
                } else {
                    $data = [
                        'code'  => 2,
                        'title' => '数据save失败',
                        'msg'   => '请重新添加QQ',
                        'type'  => 'error',
                    ];
                }
            }
        }
        return $data;
    }

    /**
     * 检查QID是否为当前登陆用户添加的
     */
    private function qqcheck($qid) {
        if (is_numeric($qid)) {
            if (!$qid || !$row = db("qqs")->field('*')->where("qid='$qid' and uid='" . $this->user['uid'] . "'")->find()) {
                get_exit(0, url('index/user'));
            } else {
                return $row;
            }
        } else {
            get_exit("QID错误！");
        }
    }

    /**
     * 检查是否已经登录
     */
    private function islogin() {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI']; //增加一个来源地址，方便登陆后回跳
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }

    public function __construct() {
        parent::__construct();
        $sid = cookie('user_sid');
		$this->login_api = '';
        if (is_md5($sid)) {
            if ($user = db("users")->field("*")->where("sid='$sid'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                // 已添加的QQ赋值到模板，方便base调用
                $qlist = db("qqs")->field('qid,qq,skeyzt')->where("uid='" . $this->user['uid'] . "'")->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
    }
}