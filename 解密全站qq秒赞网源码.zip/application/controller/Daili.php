<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Db;
class Daili extends Controller
{
    private $user;
    public function index()
    {
        return $this->fetch();
    }
    public function km()
    {
        $xz = input('param.xz');
        $kid = is_numeric(input('param.kid')) ? input('param.kid') : '0';
        if ($this->user['daili'] == 1) {
            $zhekou = config('daili_by_zhekou');
        } elseif ($this->user['daili'] == 2) {
            $zhekou = config('daili_hj_zhekou');
        } elseif ($this->user['daili'] == 3) {
            $zhekou = config('daili_bj_zhekou');
        } elseif ($this->user['daili'] == 4) {
            $zhekou = config('daili_zs_zhekou');
        } else {
            die('daiLiError');
        }
        $zhekou = $zhekou / 10;
        if (input('param.do') == 'del' && $kid) {
            get_exit('系统目前禁止退回卡密。');
            if (!($kmrow = db('kms')->field('*')->where("kid='{$kid}' and daili='" . $this->user['uid'] . '\'')->find())) {
                $this->assign('alert', get_exit('要删除的卡密不存在！', 1));
                $kid = 0;
            } else {
                if (!$kmrow['isuse']) {
                    $ms = $kmrow['ms'];
                    if ($kmrow['kind'] == 1) {
                        if ($ms == 10) {
                            $rmb = ceil(config('price_10peie') * $zhekou);
                        } elseif ($ms == 5) {
                            $rmb = ceil(config('price_5peie') * $zhekou);
                        } elseif ($ms == 3) {
                            $rmb = ceil(config('price_3peie') * $zhekou);
                        } else {
                            $ms = 1;
                            $rmb = ceil(config('price_1peie') * $zhekou);
                        }
                    } elseif ($kmrow['kind'] == 0) {
                        if ($ms == 127) {
                            $rmb = ceil(config('price_0vip') * $zhekou);
                        } elseif ($ms == 12) {
                            $rmb = ceil(config('price_12vip') * $zhekou);
                        } elseif ($ms == 6) {
                            $rmb = ceil(config('price_6vip') * $zhekou);
                        } elseif ($ms == 3) {
                            $rmb = ceil(config('price_3vip') * $zhekou);
                        } else {
                            $ms = 1;
                            $rmb = ceil(config('price_1vip') * $zhekou);
                        }
                    }
                    if (db('kms')->where("kid='{$kid}'")->delete()) {
                        db('users')->where('uid=\'' . $this->user['uid'] . '\'')->setInc('rmb', $rmb);
                        $this->assign('user', db('users')->field('*')->where('uid=\'' . $this->user['uid'] . '\'')->find());
                        $this->assign('alert', get_exit('删除卡密成功，由于此卡密没有使用，成功退还' . $rmb . '元到你账户！', 1));
                    } else {
                        $this->assign('alert', get_exit('卡密删除失败！', 1));
                    }
                } else {
                    if (db('kms')->where("kid='{$kid}'")->delete()) {
                        $this->assign('alert', get_exit('删除卡密成功！', 1));
                    } else {
                        $this->assign('alert', get_exit('卡密删除失败！', 1));
                    }
                }
            }
        }
        if (input('post.do') == 'add') {
            $num = is_numeric($_POST['num']) ? $_POST['num'] : '1';
            $ms = is_numeric($_POST['ms']) ? $_POST['ms'] : '1';
            if ($xz == 'peie') {
                $kind = 1;
            } elseif ($xz == 'sy') {
                $kind = 2;
            } else {
                $kind = 0;
            }
            if ($kind == 1) {
                if ($ms == 10) {
                    $rmb = ceil(config('price_10peie') * $zhekou);
                } elseif ($ms == 5) {
                    $rmb = ceil(config('price_5peie') * $zhekou);
                } elseif ($ms == 3) {
                    $rmb = ceil(config('price_3peie') * $zhekou);
                } else {
                    $ms = 1;
                    $rmb = ceil(config('price_1peie') * $zhekou);
                }
            } else {
                if ($ms == 127) {
                    $rmb = ceil(config('price_0vip') * $zhekou);
                } elseif ($ms == 12) {
                    $rmb = ceil(config('price_12vip') * $zhekou);
                } elseif ($ms == 6) {
                    $rmb = ceil(config('price_6vip') * $zhekou);
                } elseif ($ms == 3) {
                    $rmb = ceil(config('price_3vip') * $zhekou);
                } else {
                    $ms = 1;
                    $rmb = ceil(config('price_1vip') * $zhekou);
                }
            }
            if ($this->user['rmb'] >= $rmb * $num) {
                $msg = '<ul class=\'list-group\'>
				<li class=\'list-group-item active\'>成功生成以下卡密</li>';
                for ($i = 0; $i < $num; $i++) {
                    $data = array();
                    $data['kind'] = $kind;
                    $data['daili'] = $this->user['uid'];
                    $data['km'] = $this->getkm(12);
                    $data['ms'] = $ms;
                    $data['isuse'] = 0;
                    $data['addtime'] = date('Y-m-d H:i:s');
                    if ($this->user['rmb'] >= $rmb) {
                        if (db('kms')->insert($data)) {
                            db('users')->where('uid=\'' . $this->user['uid'] . '\'')->setDec('rmb', $rmb);
                            $this->assign('user', db('users')->field('*')->where('uid=\'' . $this->user['uid'] . '\'')->find());
                            $msg .= "<li class='list-group-item'>{$data['km']}</li>";
                        } else {
                            $msg .= '<li class=\'list-group-item list-group-item-danger\' style=\'color:red;\'>卡密生成失败！</li>';
                        }
                    } else {
                        $msg .= '<li class=\'list-group-item list-group-item-danger\' style=\'color:red;\'>账户余额不足！</li>';
                    }
                }
                $msg .= '</ul>';
            } else {
                $msg = '<ul class=\'list-group\'>
				<li class=\'list-group-item list-group-item-danger\'>账户余额不足，请先充值！</li></ul>';
            }
            $this->assign('msg', $msg);
        }
        if (input('post.do') == 'search' && ($s = input('post.key', '', 'get_safe_str'))) {
            $where = "km like '%{$s}%' and kms.daili='" . $this->user['uid'] . '\'';
            if ($xz == 'peie') {
                $where .= ' and kind=1';
            } elseif ($xz == 'sy') {
                $where .= ' and kind=2';
            } else {
                $where .= ' and kind=0';
            }
            $rows = Db::view('Kms', '*')->view('Users', 'user,qq', 'Users.uid=Kms.daili')->where($where)->limit(12)->order('kid desc')->select();
            $p = 1;
            $pages = 1;
            $count = 1;
        } else {
            $p = is_numeric(input('param.p')) ? input('param.p') : '1';
            $start = 12 * ($p - 1);
            $next = $p + 1;
            $limit = "{$start},12";
            if ($xz == 'peie') {
                $where['kind'] = 1;
            } elseif ($xz == 'sy') {
                $where['kind'] = 2;
            } else {
                $where['kind'] = 0;
            }
            $where['daili'] = $this->user['uid'];
            $count = db('kms')->where($where)->count('kid');
            unset($where['daili']);
            $where['Kms.daili'] = $this->user['uid'];
            $pages = ceil($count / 12);
            $rows = Db::view('Kms', '*')->view('Users', 'user,qq', 'Users.uid=Kms.daili')->where($where)->limit($limit)->order('kid desc')->select();
            if ($p - 1 > 0) {
                $start = $p - 1;
            } else {
                $start = 1;
            }
            if ($p + 5 < $pages) {
                $end = $p + 5;
            } else {
                $end = $pages;
            }
            $this->assign('end', $end);
            $this->assign('start', $start);
        }
        $this->assign('xz', $xz);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        $this->assign('zhekou', $zhekou);
        return $this->fetch();
    }
    private function getkm($len = 12)
    {
        $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $strlen = strlen($str);
        $randstr = '';
        for ($i = 0; $i < $len; $i++) {
            $randstr .= $str[mt_rand(0, $strlen - 1)];
        }
        return $randstr;
    }
    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field('*')->where("sid='{$sid}'")->find()) {
                if (!$user['daili']) {
                    get_exit('你还没有代理商权限！', url('Shop/daili'));
                } else {
                    $this->user = $user;
                    $this->assign('user', $this->user);
                }
            } else {
                get_exit('请登录后再进行操作！', url('index/login'));
            }
        } else {
            get_exit('请登录后再进行操作！', url('index/login'));
        }
    }
}