<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Db;
class Shua extends Controller
{
    private $user;
    private $userip;
    public function reply()
    {
        $this->islogin();
        $date = date('Y-m-d');
        if ($this->user['vip'] == '4' or $this->user['vip'] == '1' or $this->user['vip'] == '0') {
            get_exit('对不起，此功能仅季度和以上vip用户可使用');
        }
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        if (!$qid || !($row = db('qqs')->field('*')->where("qid='{$qid}' and uid='{$this->user['uid']}'")->find())) {
            get_exit('请从QQ功能列表中点击刷队形按钮来使用功能！');
        }
        $pos = 0;
        $qq = $row['qq'];
        $skey = $row['skey'];
        $gtk = $this->getGTK($skey);
        $cookie = 'uin=o0' . $qq . '; skey=' . $skey . ';';
        $url = 'http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin=' . $qq . '&ftype=0&sort=0&pos=' . $pos . '&num=5&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk=' . $gtk;
        $json = get_curl($url, 0, 0, $cookie);
        $json = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            if ($arr['msglist']) {
                foreach ($arr['msglist'] as $row) {
                    $shuolist[] = array('tid' => "{$row['tid']}", 'content' => "{$row['content']}");
                }
            } else {
                get_exit('您还没有发表任何说说~~');
            }
        } else {
            get_exit('SID/Skey过期，请更新');
        }
        $this->assign('shuolist', $shuolist);
        $this->assign('cell', $_GET['cell']);
        $this->assign('uin', $qq);
        $list = db('qqs')->field('qq,qid,uid,sid,skey,pskey')->where('skeyzt=0 and zannet>0 and zannet < 100')->order('rand()')->limit(10)->select();
        $this->assign('arr', $list);
        $this->assign('liked', 0);
        $this->assign('i', 1);
        $this->assign('uid', $this->user['uid']);
        $count = db('replylog')->where("uid='{$this->user['uid']}' and addtime='{$date}'")->count('uid');
        $this->assign('count', $count);
        return $this->fetch();
    }
    public function quanquan()
    {
        $this->islogin();
        if (input('post.do') == 'quanquan') {
            if (is_numeric($_POST['qq'])) {
                $url = "http://www.zhuimore.com/quan.php?jx={$_POST['qq']}";
                $res = get_curl($url);
                if (strstr($res, 'ok')) {
                    get_exit('提交成功！');
                } else {
                    get_exit('提交失败！');
                }
            } else {
                get_exit('请填写正确内容！');
            }
        }
		$qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        if ($qid) {
			$row = db('qqs')->field('*')->where("qid='{$qid}' and uid='{$this->user['uid']}'")->find();
            $this->assign('uin', $row['qq']);
        }
        return $this->fetch();
    }
    public function rq()
    {
        $this->islogin();
        $date = date('Y-m-d');
        if ($this->user['vip'] == '4' or $this->user['vip'] == '1' or $this->user['vip'] == '0') {
            get_exit('对不起，此功能仅季度和以上vip用户可使用');
        }
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        if (!$qid || !($row = db('qqs')->field('*')->where("qid='{$qid}' and uid='{$this->user['uid']}'")->find())) {
            get_exit('请从QQ的功能设置页面中中点击刷人气按钮');
        }
        $qq = $row['qq'];
        $this->assign('uin', $qq);
        $list = db('qqs')->field('qid,uid,sid,skey,qq')->where('skeyzt=0 and zannet>0')->order('rand()')->limit(25)->select();
        $this->assign('arr', $list);
        $this->assign('liked', 0);
        $this->assign('i', 1);
        $this->assign('uid', $this->user[uid]);
        $count = db('rqlog')->where("uid='{$this->user['uid']}' and addtime='{$date}'")->count('uid');
        $this->assign('count', $count);
        return $this->fetch();
    }
    public function sz()
    {
        $this->islogin();
        $date = date('Y-m-d');
        if ($this->user['vip'] == '4' or $this->user['vip'] == '1' or $this->user['vip'] == '0') {
            get_exit('对不起，此功能仅季度和以上vip用户可使用');
        }
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        if (!$qid || !($row = db('qqs')->field('*')->where("qid='{$qid}' and uid='{$this->user['uid']}'")->find())) {
            get_exit('请从功能列表中点击刷赞按钮');
        }
        $pos = 0;
        $qq = $row['qq'];
        $skey = $row['skey'];
        $gtk = $this->getGTK($skey);
        $cookie = 'uin=o0' . $qq . '; skey=' . $skey . ';';
        $url = 'http://sh.taotao.qq.com/cgi-bin/emotion_cgi_feedlist_v6?hostUin=' . $qq . '&ftype=0&sort=0&pos=' . $pos . '&num=5&replynum=0&code_version=1&format=json&need_private_comment=1&g_tk=' . $gtk;
        $json = get_curl($url, 0, 0, $cookie);
        $json = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            if ($arr['msglist']) {
                foreach ($arr['msglist'] as $row) {
                    $shuolist[] = array('tid' => "{$row['tid']}", 'content' => "{$row['content']}");
                }
            } else {
                get_exit('您还没有发表任何说说~~');
            }
        } else {
            get_exit('SID/Skey过期，请更新');
        }
        $this->assign('shuolist', $shuolist);
        $this->assign('cell', $_GET['cell']);
        $this->assign('uin', $qq);
        $list = db('qqs')->field('qq,qid,uid,sid,skey,pskey')->where('skeyzt=0 and zannet>0')->order('rand()')->limit(25)->select();
        $this->assign('arr', $list);
        $this->assign('liked', 0);
        $this->assign('i', 1);
        $this->assign('uid', $this->user['uid']);
        $count = db('szlog')->where("uid='{$this->user['uid']}' and addtime='{$date}'")->count('uid');
        $this->assign('count', $count);
        return $this->fetch();
    }
    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }
    public function getGTK($skey)
    {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field(array('*'))->where("sid='{$sid}'")->find()) {
                $this->user = $user;
                $this->assign('user', $user);
                $qlist = db('qqs')->field('qid,qq,skeyzt')->where('uid=\'' . $this->user['uid'] . '\'')->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
    }
}