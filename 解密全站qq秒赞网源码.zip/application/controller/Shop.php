<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Config;
class Shop extends Controller
{
    private $user;
    public function signRsa($data)
    {
        $priKey = file_get_contents(APP_PATH . 'rsa_private_key.pem');
        $res = openssl_get_privatekey($priKey);
        openssl_sign($data, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);
        return $sign;
    }
    public function ad()
    {
        $price = explode('|', config('price_ad1'));
        $this->assign('price', $price);
        return $this->fetch();
    }

	public function epay_submit() {
        $this->islogin();
        if (request()->isPost()) {
            // 支付方式
            $paytype = input('route.paytype');
            //$param 综合参数
            $param = explode(',', input('post.param'));
            //根据不同参数设置商品名称
            if ($param[0] == 'vip') {
                $title = 'VIP会员';
            } elseif ($param[0] == 'peie') {
                $title = '挂机配额';
            } elseif ($param[0] == 'rmb') {
                $title = '余额充值';
            } elseif ($param[0] == 'ad') {
                $title = '广告位';
            } else {
                $title = '代理商权限';
            }
            $pirce = input('post.price');
            //自定义订单号，此处仅作举例
            $year_code = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
            $out_trade_no = $year_code[intval(date('Y')) - 2015] . strtoupper(dechex(date('m'))) . date('d') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));

			$aid = is_numeric(input('post.aid')) ? input('post.aid') : 0; // 如果不是广告位是没有这个参数的（aid=0）
			// 写入订单到数据库
			$check = db("Pay")->insert([
                'out_trade_no' => $out_trade_no,
                'money'        => $pirce,
                'status'       => 0,
                'callback'     => $paytype,
                'url'          => 'epay',
                'param'        => serialize([
                    'type' => $param[0],
                    'uid'  => $param[1],
                    'aid'  => $aid,
                ]),
                'create_time'  => time(),
                'update_time'  => time(),
            ]);
			if (!$check) {
                exception('创建订单出错！');
            }

			$parameter = array(
				"pid" => config('fenzhan.id') ? config('fenzhan.pay_appid') : config('pay_appid'),
				"type" => $paytype,
				"notify_url"	=> 'http://'.$_SERVER['HTTP_HOST'].'/shop/epay_notify.html',
				"return_url"	=> 'http://'.$_SERVER['HTTP_HOST'].'/shop/epay_notify.html',
				"out_trade_no"	=> $out_trade_no,
				"name"	=> $title,
				"money"	=> $pirce,
				"sitename"	=> config('fenzhan.web_name') ? config('fenzhan.web_name') : config('web_name')
			);
			//建立请求
			vendor('epay.epay_submit');
			$config['partner'] = config('fenzhan.id') ? config('fenzhan.pay_appid') : config('pay_appid');
			$config['key'] = config('fenzhan.id') ? config('fenzhan.pay_appkey') : config('pay_appkey');
			$alipaySubmit = new \AlipaySubmit($config);
			$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "正在跳转");
			echo $html_text;
            exit;
        } else {
            return $this->display('http Err');
        }
    }

    /**
     * 支付回调接收
     * 成功输出success字符串
     */
    public function epay_notify() {
        $order = input('get.');
		vendor('epay.epay_notify');
		$config['partner'] = config('fenzhan.id') ? config('fenzhan.pay_appid') : config('pay_appid');
		$config['key'] = config('fenzhan.id') ? config('fenzhan.pay_appkey') : config('pay_appkey');
		$alipayNotify = new \AlipayNotify($config);
		$verify_result = $alipayNotify->verifyNotify();
        if($verify_result) {//验证成功
            //获取订单信息
            $payinfo = db("Pay")->field(true)->where(['out_trade_no' => $order['out_trade_no']])->find();
            if ($payinfo && $payinfo['status'] == 0) {
                $check = $this->apishop($payinfo['money'], unserialize($payinfo['param']));
                if ($check !== false) {
                    db("Pay")->where(['out_trade_no' => $order['out_trade_no']])->setField([
                        'update_time' => time(),
                        'status'      => 1,
                    ]);
                }
            }
			if (!empty($_SERVER['HTTP_REFERER'])) {
				$this->redirect(url('index/user'), 302);
				die;
			}
			return $this->display('success');
        } else {
            return $this->display('订单验证失败' . $verify_result);
        }
    }

    public function index()
    {
        if (request()->isPost()) {
            $paytype = input('route.paytype') ? input('route.paytype') : die('type Err！');
            
            if ($paytype == 'alipay' && config('alipay_api') == 2 || $paytype == 'tenpay' && config('tenpay_api') == 2 || $paytype == 'qqpay' && config('qqpay_api') == 2 || $paytype == 'wxpay' && config('wxpay_api') == 2 || config('fenzhan.pay_auto')==1)
            {
				$type = $paytype;
                $paytype = 'epay';
				$payment['epay']['partner'] = config('fenzhan.id') ? config('fenzhan.pay_appid') : config('pay_appid');
				$payment['epay']['key'] = config('fenzhan.id') ? config('fenzhan.pay_appkey') : config('pay_appkey');
				config($payment);
            } elseif ($paytype == 'alipay' && request()->isMobile() && config('payment.aliwappay')['partner'] != '') {
                $paytype = 'aliwappay';
            }
            $param = explode(',', input('post.param'));
            if ($param[0] == 'vip') {
                $title = 'VIP会员';
            } elseif ($param[0] == 'peie') {
                $title = '挂机配额';
            } elseif ($param[0] == 'rmb') {
                $title = '余额充值';
            } elseif ($param[0] == 'daili') {
                $title = '代理商权限';
            } elseif ($param[0] == 'ad') {
                $title = '广告位';
            } else {
                $title = '未知商品名';
            }
            $aid = is_numeric(input('post.aid')) ? input('post.aid') : 0;
            $pay = new \think\Pay($paytype, config('payment.' . $paytype));
            $order_no = $pay->createOrderNo();
            $vo = new \think\Pay\PayVo();
            $vo->setBody('QQ秒赞网付费增值服务购买，增加专属特权')->setFee(input('post.price'))->setOrderNo($order_no)->setTitle('QQ秒赞网' . $title)->setCallback('shop/pay')->setUrl(url('index/user'))->setParam(array('type' => $param[0], 'uid' => $param[1], 'aid' => $aid));
            if (input('route.isapp') == 'app') {
                $signStr = 'service="mobile.securitypay.pay"&partner="' . config('payment.alipay')['partner'] . '"&_input_charset="utf-8"&notify_url="' . $vo->getCallback() . '"&out_trade_no="' . $order_no . '"&subject="' . $title . '"&payment_type="1"&seller_id="' . config('payment.alipay')['email'] . '"&total_fee="' . input('post.price') . '"&body="QQ秒赞网付费增值服务购买，增加专属特权"';
                $sign = urlencode($this->signRsa($signStr));
                $payData = $signStr . '&sign="' . $sign . '"&sign_type="RSA"';
                echo $payData;
            } else {
                echo $pay->buildRequestForm($vo);
            }
        } else {
            return $this->fetch();
        }
    }
    public function notify()
    {
        trace('支付宝回调start', 'log');
        $apitype = input('param.apitype');
        $pay = new \think\Pay($apitype, config('payment.' . $apitype));
        if (request()->isPost() && !empty($_POST)) {
            $notify = $_POST;
        } elseif (request()->isGet() && !empty($_GET)) {
            $notify = $_GET;
            unset($notify['method']);
            unset($notify['apitype']);
        } else {
            die('Access Denied#1');
        }
        if ($pay->verifyNotify($notify)) {
            $info = $pay->getInfo();
            if ($info['status']) {
                $payinfo = db('Pay')->field(true)->where(array('out_trade_no' => $info['out_trade_no']))->find();
                if ($payinfo['status'] == 0 && $payinfo['callback']) {
                    session('pay_verify', true);
                    $check = $this->pay($payinfo['money'], unserialize($payinfo['param']));
                    if ($check !== false) {
                        db('Pay')->where(array('out_trade_no' => $info['out_trade_no']))->setField(array('update_time' => time(), 'status' => 1));
                    }
                }
				if (input('param.method') == 'return') {
                    $this->redirect($payinfo['url'], 302);
                    die;
                }
                $pay->notifySuccess();
            } else {
                $this->error('支付失败！');
            }
        } else {
            exception('Access Denied#2');
        }
    }
    public function qrcode()
    {
        $money = input('post.price');
        $param = explode(',', input('post.param'));
        if ($param[0] == 'vip') {
            $title = 'VIP会员';
        } elseif ($param[0] == 'peie') {
            $title = '挂机配额';
        } elseif ($param[0] == 'rmb') {
            $title = '余额充值';
        } elseif ($param[0] == 'daili') {
            $title = '代理商权限';
        } elseif ($param[0] == 'ad') {
            $title = '广告位';
        } else {
            $title = '未知商品名';
        }
        $aid = is_numeric(input('post.aid')) ? input('post.aid') : 0;
        vendor('WxPayPubHelper.WxPayPubHelper');
        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter('body', 'QQ秒赞网' . $title);
        $timeStamp = time();
        $out_trade_no = 'WX00' . $timeStamp;
        $unifiedOrder->setParameter('out_trade_no', "{$out_trade_no}");
        $unifiedOrder->setParameter('total_fee', $money * 100);
        $unifiedOrder->setParameter('notify_url', 'http://' . $_SERVER['HTTP_HOST'] . '/shop/wx_notify.html');
        $unifiedOrder->setParameter('trade_type', 'NATIVE');
        $unifiedOrderResult = $unifiedOrder->getResult();
        if ($unifiedOrderResult['return_code'] == 'FAIL') {
            echo '通信出错：' . $unifiedOrderResult['return_msg'] . '<br>';
        } elseif ($unifiedOrderResult['result_code'] == 'FAIL') {
            echo '错误代码：' . $unifiedOrderResult['err_code'] . '<br>';
            echo '错误代码描述：' . $unifiedOrderResult['err_code_des'] . '<br>';
        } elseif ($unifiedOrderResult['code_url'] != NULL) {
            $code_url = $unifiedOrderResult['code_url'];
            $check = db('Pay')->insert(array('out_trade_no' => $out_trade_no, 'money' => $money, 'status' => 0, 'callback' => 'wx', 'url' => 'wx', 'param' => serialize(array('type' => $param[0], 'uid' => $param[1], 'aid' => $aid)), 'create_time' => time(), 'update_time' => time()));
            if (!$check) {
                exception('创建订单出错！');
            }
        }
        $this->assign('out_trade_no', $out_trade_no);
        $this->assign('code_url', $code_url);
        $this->assign('money', $money);
        return $this->fetch();
    }
    public function getQrcode()
    {
        $out_trade_no = input('post.out_trade_no', '', 'get_safe_str');
        if (!$out_trade_no) {
            die;
        }
        $data = db('Pay')->field('status')->where("out_trade_no='{$out_trade_no}'")->find();
        if ($data['status'] == 1) {
            $arr = array('success' => '1');
        } else {
            $arr = array('success' => '0');
        }
        echo json_encode($arr);
    }
    public function wx_notify()
    {
        trace('微信回调start', 'log');
        vendor('WxPayPubHelper.WxPayPubHelper');
        $notify = new \Notify_pub();
        $xml = file_get_contents('php://input');
        $notify->saveData($xml);
        trace(base64_encode($xml), 'log');
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter('return_code', 'FAIL');
            $notify->setReturnParameter('return_msg', '签名失败');
        } else {
            $notify->setReturnParameter('return_code', 'SUCCESS');
            $notify->setReturnParameter('return_msg', 'OK');
        }
        $returnXml = $notify->returnXml();
        echo $returnXml;
        $arr = $notify->getData();
        if ($arr) {
            if ($notify->data['return_code'] == 'FAIL') {
                db('Pay')->where("out_trade_no='{$arr['out_trade_no']}'")->setField('url', '通讯出错' . $xml);
                die;
            } elseif ($notify->data['result_code'] == 'FAIL') {
                db('Pay')->where("out_trade_no='{$arr['out_trade_no']}'")->setField('url', '业务出错' . $xml);
                die;
            }
            $row = db('Pay')->field('*')->where("out_trade_no='{$arr['out_trade_no']}'")->find();
            if ($row) {
                if ($row['status'] == 1) {
                    die('订单已充值');
                }
                session('pay_verify', true);
                session('pay_type', 'wx');
                $check = $this->pay($row['money'], unserialize($row['param']));
                if ($check !== false) {
                    db('Pay')->where(array('out_trade_no' => $arr['out_trade_no']))->setField(array('update_time' => time(), 'status' => 1));
                } else {
                    die('充值操作出错');
                }
            } else {
                die('无此订单');
            }
        } else {
            die;
        }
    }
    public function qpay()
    {
        if (request()->isPost()) {
            $money = input('post.price');
            $param = explode(',', input('post.param'));
            if ($param[0] == 'vip') {
                $title = 'VIP会员';
            } elseif ($param[0] == 'peie') {
                $title = '挂机配额';
            } elseif ($param[0] == 'rmb') {
                $title = '余额充值';
            } elseif ($param[0] == 'daili') {
                $title = '代理商权限';
            } elseif ($param[0] == 'ad') {
                $title = '广告位';
            } else {
                $title = '未知商品名';
            }
            $aid = is_numeric(input('post.aid')) ? input('post.aid') : 0;
            $timeStamp = time();
            $out_trade_no = 'QPay00' . $timeStamp;
            vendor('QPay.QPay');
            $QPay = new \QPay();
            $QPay->setParams('ver', '2.0');
            $QPay->setParams('charset', '1');
            $QPay->setParams('bank_type', '0');
            $QPay->setParams('desc', 'QQ秒赞网' . $title);
            $QPay->setParams('pay_channel', '1');
            $QPay->setParams('bargainor_id', $QPay->appid);
            $QPay->setParams('sp_billno', $out_trade_no);
            $QPay->setParams('total_fee', $money * 100);
            $QPay->setParams('fee_type', '1');
            $QPay->setParams('notify_url', $QPay->notify_url);
            $url = $QPay->getPayUrl();
            $check = db('Pay')->insert(array('out_trade_no' => $out_trade_no, 'money' => $money, 'status' => 0, 'callback' => 'qpay', 'url' => 'qpay', 'param' => serialize(array('type' => $param[0], 'uid' => $param[1], 'aid' => $aid)), 'create_time' => time(), 'update_time' => time()));
            if (!$check) {
                exception('创建订单出错！');
            }
            $this->assign('out_trade_no', $out_trade_no);
            $this->assign('code_url', $url);
            $this->assign('money', $money);
            return $this->fetch();
        } else {
            die('need Post');
        }
    }
    public function qpaynotify()
    {
        $arr = input('get.');
        if ($arr['pay_result'] == 0) {
            $sign = $arr['sign'];
            vendor('QPay.QPay');
            $QPay = new \QPay();
            if ($QPay->isTenpaySign($arr, $sign)) {
                $row = db('Pay')->field('*')->where("out_trade_no='{$arr['sp_billno']}'")->find();
                if ($row) {
                    if ($row['status'] == 1) {
                        die('success');
                    }
                    session('pay_verify', true);
                    session('pay_type', 'qpay');
                    $check = $this->pay($row['money'], unserialize($row['param']));
                    if ($check !== false) {
                        db('Pay')->where(array('out_trade_no' => $arr['sp_billno']))->setField(array('update_time' => time(), 'status' => 1));
                    } else {
                        die('充值操作出错');
                    }
                } else {
                    die('数据库无此订单');
                }
            } else {
                die('签名错误');
            }
        } else {
            die('尚未支付');
        }
    }
    private function pay($money, $param)
    {
        trace($money . '#UID:' . $param['uid'], 'log');
        if (session('pay_verify') == true) {
            session('pay_verify', null);
            $this->apishop($money, $param);
        } else {
            exception('Access Denied#');
        }
    }
    private function apishop($price, $order = array())
    {
        $uid = $order['uid'];
        $type = $order['type'];
        if ($row = db('users')->field('*')->where("uid='{$uid}'")->find()) {
            if ($type == 'vip') {
                if (get_isvip($row['vip'], $row['vipend'])) {
                    switch ($price) {
                        case 1:
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 2 day', strtotime($row['vipend'])));
                            $vip = '2天';
                            break;
                        case config('price_1vip'):
                            if ($row['vip'] == 4) {
                                $udata['vip'] = 1;
                            }
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 1 months', strtotime($row['vipend'])));
                            $vip = '一个月';
                            break;
                        case config('price_3vip'):
                            $udata['vip'] = 2;
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 3 months', strtotime($row['vipend'])));
                            $vip = '三个月';
                            break;
                        case config('price_6vip'):
                            $udata['vip'] = 2;
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 6 months', strtotime($row['vipend'])));
                            $vip = '六个月';
                            break;
                        case config('price_12vip'):
                            $udata['vip'] = 3;
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 12 months', strtotime($row['vipend'])));
                            $vip = '一年';
                            break;
                        default:
                            die('无对应vip物品');
                    }
                } else {
                    switch ($price) {
                        case 1:
                            $udata['vip'] = 4;
                            $udata['vipstart'] = date('Y-m-d');
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 2 day'));
                            $vip = '2天';
                            break;
                        case config('price_1vip'):
                            $udata['vip'] = 1;
                            $udata['vipstart'] = date('Y-m-d');
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 1 months'));
                            $vip = '一个月';
                            break;
                        case config('price_3vip'):
                            $udata['vip'] = 2;
                            $udata['vipstart'] = date('Y-m-d');
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 3 months'));
                            $vip = '三个月';
                            break;
                        case config('price_6vip'):
                            $udata['vip'] = 2;
                            $udata['vipstart'] = date('Y-m-d');
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 6 months'));
                            $vip = '六个月';
                            break;
                        case config('price_12vip'):
                            $udata['vip'] = 3;
                            $udata['vipstart'] = date('Y-m-d');
                            $udata['vipend'] = date('Y-m-d', strtotime('+ 12 months'));
                            $vip = '一年';
                            break;
                        default:
                            die('无对应vip物品');
                    }
                }
                db('users')->where("uid='{$uid}'")->update($udata);
                $vip = '续费' . $vip . '秒赞VIP服务';
                $this->sendshopmail($row['qq'] . '@qq.com', $row['user'], $vip, $udata['vipend'], 'vip');
            } elseif ($type == 'peie') {
                switch ($price) {
                    case config('price_1peie'):
                        $peie = 1;
                        break;
                    case config('price_3peie'):
                        $peie = 3;
                        break;
                    case config('price_5peie'):
                        $peie = 5;
                        break;
                    case config('price_10peie'):
                        $peie = 10;
                        break;
                    default:
                        die('无对应peie物品');
                }
                db('users')->where("uid='{$uid}'")->setInc('peie', $peie);
                $peie2 = '增加' . $peie . '个配额数量可用于挂机';
                $this->sendshopmail($row['qq'] . '@qq.com', $row['user'], $peie2, $row['peie'] + $peie, 'peie');
            } elseif ($type == 'daili') {
                switch ($price) {
                    case config('daili_by_rmb'):
                        $data['daili'] = 1;
                        $data['rmb'] = config('daili_by_give');
                        break;
                    case config('daili_hj_rmb'):
                        $data['daili'] = 2;
                        $data['rmb'] = config('daili_hj_give');
                        break;
                    case config('daili_bj_rmb'):
                        $data['daili'] = 3;
                        $data['rmb'] = config('daili_bj_give');
                        break;
                    case config('daili_zs_rmb'):
                        $data['daili'] = 4;
                        $data['rmb'] = config('daili_zs_give');
                        break;
                    default:
                        die('无对应daili物品');
                }
                db('users')->where("uid='{$uid}'")->update($data);
                $daili = '开通代理商权限';
                $this->sendshopmail($row['qq'] . '@qq.com', $row['user'], $daili, 0, 'daili');
            } elseif ($type == 'rmb') {
                db('users')->where("uid='{$uid}'")->setInc('rmb', $price);
                $price2 = '充值' . $price . '元';
                $this->sendshopmail($row['qq'] . '@qq.com', $row['user'], $price2, $row['rmb'] + $price, 'rmb');
            } elseif ($type == 'ad') {
                $adprice = explode('|', config('price_ad1'));
                $aid = $order['aid'];
                $ad = db('ad')->field('*')->where("aid='{$aid}'")->find();
                if ($ad && ($ad['exttime'] <= date('Y-m-d') || $ad['uid'] == 0)) {
                    $addata['uid'] = $uid;
                    $addata['content'] = '该广告位已被成功购买，请及时修改内容！';
                    $addata['url'] = '/index/adm.html';
                    $addata['addtime'] = date('Y-m-d');
                    switch ($price) {
                        case $adprice[0]:
                            $addata['exttime'] = date('Y-m-d', strtotime('+ 1 months'));
                            break;
                        case $adprice[1]:
                            $addata['exttime'] = date('Y-m-d', strtotime('+ 3 months'));
                            break;
                        case $adprice[2]:
                            $addata['exttime'] = date('Y-m-d', strtotime('+ 6 months'));
                            break;
                        case $adprice[3]:
                            $addata['exttime'] = date('Y-m-d', strtotime('+ 12 months'));
                            break;
                        default:
                            die('无对应AD广告位');
                    }
                    db('ad')->where("aid='{$aid}'")->update($addata);
                } else {
                    die('您购买的广告位已被其他人购买，请联系站长进行退款');
                }
            } else {
                die('No Find Type');
            }
        }
    }
    /*public function admin()
    {
        $this->islogin();
        if (input('post.do') == 'admin_pay') {
            $pay_pwd = md5(md5($_POST['pay_pwd']) . md5('QQ454701103'));
            if ($pay_pwd != config('pay_pwd')) {
                die('PWD Error');
            }
            $money = input('post.price', '', 'get_safe_str');
            $param['uid'] = input('post.uid', '', 'get_safe_str');
            $param['type'] = input('post.type', '', 'get_safe_str');
            echo $this->apishop($money, $param);
            die;
        }
        return $this->fetch();
    }*/
    public function duihuan()
    {
        $this->islogin();
        if ($do = input('post.do') and $row = db('users')->field('*')->where('uid=\'' . $this->user['uid'] . '\'')->find()) {
            $point = input('post.point', '', 'get_safe_str');
            if ($this->user['jf'] >= $point) {
                if ($do == 'vip') {
                    if (get_isvip($row['vip'], $row['vipend'])) {
                        switch ($point) {
                            case 2:
                                if ($row['vip'] == 4) {
                                    $udata['vip'] = 1;
                                }
                                $udata['vipend'] = date('Y-m-d', strtotime('+ 1 day', strtotime($row['vipend'])));
                                break;
                            default:
                                die('无对应兑换物品@1');
                        }
                    } else {
                        switch ($point) {
                            case 2:
                                $udata['vip'] = 4;
                                $udata['vipstart'] = date('Y-m-d');
                                $udata['vipend'] = date('Y-m-d', strtotime('+ 1 day'));
                                break;
                            default:
                                die('无对应兑换物品@2');
                        }
                    }
                    db('users')->where('uid=\'' . $this->user['uid'] . '\'')->update($udata);
                } elseif ($do == 'peie') {
                    switch ($point) {
                        case 100:
                            $peie = '1';
                            break;
                        default:
                            die('无对应兑换物品@3');
                    }
                    db('users')->where('uid=\'' . $this->user['uid'] . '\'')->setInc('peie', $peie);
                }
                db('users')->where('uid=\'' . $this->user['uid'] . '\'')->setDec('jf', $point);
                $msg = '物品兑换成功!';
            } else {
                $msg = '积分不足，兑换失败!';
            }
            $this->assign('msg', $msg);
        }
        return $this->fetch();
    }
    public function vip()
    {
        $this->islogin();
        if (input('post.do') == 'vip') {
            $km = input('post.km', '', 'get_safe_str');
            if (!($row = db('kms')->field('*')->where("km='{$km}' and (kind=0 or kind=2)")->find())) {
                $msg = 'VIP卡卡密不存在!';
            } else {
                if ($row['isuse']) {
                    $msg = '此VIP卡卡密已经被使用!';
                } elseif (get_isvip($this->user['vip'], $this->user['vipend']) && $row['kind'] == 2) {
                    $msg = '你已经是VIP，不能使用试用卡!';
                } else {
                    $data['isuse'] = 1;
                    $data['uid'] = $this->user['uid'];
                    $data['usetime'] = date('Y-m-d H:i:s');
                    db('kms')->where("kid='{$row['kid']}'")->update($data);
                    if ($row['kind'] == 2) {
                        $udata['vip'] = 1;
                        $udata['vipstart'] = date('Y-m-d');
                        $udata['vipend'] = date('Y-m-d', strtotime("+ {$row['ms']} days"));
                        db('users')->where('uid=\'' . $this->user['uid'] . '\'')->update($udata);
                        $msg = '成功续费' . $row['ms'] . '天VIP，你的VIP到期日期:' . $udata['vipend'];
                    } elseif (get_isvip($this->user['vip'], $this->user['vipend'])) {
                        if ($row['ms'] > 11) {
                            $udata['vip'] = 3;
                        } elseif ($row['ms'] > 2 and $this->user['vip'] != 3) {
                            $udata['vip'] = 2;
                        } elseif ($this->user['vip'] == 4) {
                            $udata['vip'] = 1;
                        }
                        $udata['vipend'] = date('Y-m-d', strtotime("+ {$row['ms']} months", strtotime($this->user['vipend'])));
                        db('users')->where('uid=\'' . $this->user['uid'] . '\'')->update($udata);
                        $msg = '成功续费' . $row['ms'] . '个月VIP，你的VIP到期日期:' . $udata['vipend'];
                    } else {
                        if ($row['ms'] > 11) {
                            $udata['vip'] = 3;
                        } elseif ($row['ms'] > 2) {
                            $udata['vip'] = 2;
                        } else {
                            $udata['vip'] = 1;
                        }
                        $udata['vipstart'] = date('Y-m-d');
                        $udata['vipend'] = date('Y-m-d', strtotime("+ {$row['ms']} months"));
                        db('users')->where('uid=\'' . $this->user['uid'] . '\'')->update($udata);
                        $msg = "成功开通{$row['ms']}个月VIP，你的VIP到期日期:{$udata['vipend']}";
                    }
                }
            }
            $this->assign('alert', get_exit($msg, 1));
        }
        return $this->fetch();
    }
    public function peie()
    {
        $this->islogin();
        if (input('post.do') == 'peie') {
            $km = input('post.km', '', 'get_safe_str');
            if (!($row = db('kms')->field('*')->where("km='{$km}' and kind=1")->find())) {
                get_exit('配额卡卡密不存在！');
            } else {
                if ($row['isuse']) {
                    get_exit('此增加配额卡密已经被使用！');
                } else {
                    $data['isuse'] = 1;
                    $data['uid'] = $this->user['uid'];
                    $data['usetime'] = date('Y-m-d H:i:s');
                    db('kms')->where("kid='{$row['kid']}'")->update($data);
                    db('users')->where('uid=\'' . $this->user['uid'] . '\'')->setInc('peie', $row['ms']);
                    $msg = "成功增加{$row['ms']}个配额";
                    $this->assign('alert', get_exit($msg, 1));
                }
            }
        }
        return $this->fetch();
    }
    public function rmb()
    {
        $this->islogin();
        return $this->fetch();
    }
    public function web()
    {
        return $this->fetch();
    }
    public function daili()
    {
        $this->islogin();
        return $this->fetch();
    }
    private function sendshopmail($to, $user, $str1, $str2, $type = 0, $qudao = '官网')
    {
        $time = date('Y-m-d H:i:s');
        $webname = config('fenzhan.web_name') ? config('fenzhan.web_name') : config('web_name');
        if (config('mail_type') == 2) {
            $url = 'http://sendcloud.sohu.com/webapi/mail.send_template.json';
            if ($type == 'vip') {
                $title = 'VIP开通成功';
                $str2 = 'VIP服务有效期至：' . $str2;
            } elseif ($type == 'peie') {
                $title = '配额增加成功';
                $str2 = '配额目前共有：' . $str2;
            } elseif ($type == 'rmb') {
                $title = '余额充值成功';
                $str2 = '当前余额为：' . $str2;
            } else {
                $title = '代理商开通成功';
                $str2 = '代理后台已可使用，感谢您对本网站的支持，祝您财源滚滚';
            }
            $tpl = config('sendcloud_tpl_vip');
            $param = array('api_user' => config('sendcloud_apiuser_shop'), 'api_key' => config('sendcloud_apikey'), 'from' => config('sendcloud_from'), 'fromname' => $webname, 'substitution_vars' => "{\"to\": [\"{$to}\"],\"sub\":{\"%qudao%\": [\"{$qudao}\"],\"%time%\": [\"{$time}\"],\"%str1%\": [\"{$str1}\"],\"%str2%\": [\"{$str2}\"],\"%user%\":[\"{$user}\"]}}", 'subject' => $webname . $title, 'template_invoke_name' => $tpl);
            $options = array('http' => array('method' => 'POST', 'content' => http_build_query($param)));
            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);
        } else {
            $title = $webname . '支付成功通知';
            $content = "{$user}，您好，您在本网站购买的服务已经成功开通，请登录网站进行查看使用，感谢您的支持！";
            Vendor('Mail');
            $mail = new \MySendMail();
            if (config('mail_port') == '465') {
                $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'), true);
            } else {
                $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'));
            }
            $mail->setFrom(config('mail_user'), config('web_name'));
            $mail->setReceiver($to);
            $mail->setMail($title, $content);
            $result = $mail->sendMail();
        }
        return $result;
    }
    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }
    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field(array('*'))->where("sid='{$sid}'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                $qlist = db('qqs')->field('qid,qq,skeyzt')->where('uid=\'' . $this->user['uid'] . '\'')->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
		if(config('fenzhan.pay_auto')==1){
			$data['alipay_api'] = 2;
			$data['tenpay_api'] = 2;
			$data['qqpay_api'] = 2;
			$data['wxpay_api'] = 2;
			config($data);
		}
        Config::load(APP_PATH . 'payconfig.php');
    }
}