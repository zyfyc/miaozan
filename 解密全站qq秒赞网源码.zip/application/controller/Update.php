<?php
namespace app\controller;

use think\Controller;
use think\Db;

class update extends Controller
{
	public function index()
	{
		$ver = config('qqmz_ver');
		$array = update_version($ver);
		if(!$array) {
			$updateinfo = '啊哦，更新服务器开小差了，请稍候再试。';
		}
		elseif ($array['code']==1) {
			$updateinfo = $array['msg']."<hr/><a href=\"updatenow.html\">点击这里开始升级</a>";
			$chanageinfo = $array['uplog'];
		} else {
			$updateinfo = $array['msg'];
		}
		$this->assign('updateinfo', $updateinfo);
		$this->assign('chanageinfo', $chanageinfo);
		return $this->fetch();
	}

	public function updatenow()
	{
		$ver = config('qqmz_ver');
		$array = update_version($ver);
		$RemoteFile = $array['file'];
		$ZipFile = './other/Archive.zip';
		if (copy($RemoteFile,$ZipFile)) {
			Vendor('PclZip', '.php');
			$archive = new \PclZip($ZipFile);
			if ($archive->extract(PCLZIP_OPT_PATH, './', PCLZIP_OPT_REPLACE_NEWER) == 0) {
				$updatenowinfo = "<p>远程升级文件不存在,升级失败</p>";
			} else {
				$sqlfile = './update.sql';
				$sqls = file_get_contents($sqlfile);
				if ($sqls) {
					$sqls = str_replace("qqmz_", config("database.prefix"), $sqls);
					$sqls = explode(";", $sqls);
					$num = count($sqls);
					$error = '';
					foreach ($sqls as $sql) {
						if ($sql = trim($sql)) {
							if (!db()->execute("$sql")) {
								$error .= '执行('.$sql.')时出现错误:'.$this->error.'<br/>';
							}
						}
					}
					unlink($sqlfile);
				} else {
					$num = '0';
				}
				$updatenowinfo = "<p color=red>升级完成！执行SQL成功，共导入{$num}条数据！</p>".$error;
			}
			unlink($ZipFile);
		} else {
			get_exit('无法下载更新包文件！');
		}
		delDirAndFile($updatedir);
		$this->assign('updatenowinfo', $updatenowinfo);
		return $this->fetch();
	}

	public function __construct()
	{
		parent::__construct();
		if (request()->action() != 'login') {
			if (config('adminpwd') && session('admin_pwd') == config('adminpwd')) {
			} else {
				get_exit(0, url('/adm/login'));
			}
		}
	}
} ?>