<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
class Tools extends Controller
{
    private $user;
    public function index()
    {
        return $this->fetch();
    }
    public function checkZan()
    {
        $this->islogin();
        $qid = is_numeric(input('post.qid')) ? input('post.qid') : '0';
        $row = $this->qqcheck($qid);
        if ($row['iszan'] != 2) {
            $msg = array('code' => 0, 'msg' => '未开启秒赞功能，无法检测');
        } else {
            $arr = $this->doCheckZan($qid);
            if ($arr['code']) {
                $msg = $arr;
            } else {
                if (strstr($arr['msg']['1'], '没有要赞')) {
                    $msg = array('code' => 0, 'msg' => '恭喜，当前QQ暂未被QQ空间限制点赞，本次检测正确率80%');
                } else {
                    $arr2 = $this->doCheckZan($qid);
                    if ($arr2['code']) {
                        $msg = $arr2;
                    } else {
                        if (strstr($arr2['msg']['1'], '没有要赞')) {
                            $msg = array('code' => 0, 'msg' => '恭喜，当前QQ暂未被QQ空间限制点赞，本次检测正确率90%');
                        } elseif (count($arr2['msg']) > 4) {
                            $msg = array('code' => 0, 'msg' => 'Oh No！当前QQ可能已被QQ空间限制点赞，本次检测正确率80%，等待一段时间后会恢复，别心急~');
                        } else {
                            if (count($arr2['msg']) > 2) {
                                $msg = array('code' => 0, 'msg' => 'Oh No！当前QQ可能已被QQ空间限制点赞，本次检测正确率60%，等待一段时间后会恢复，别心急~');
                            } else {
                                $msg = array('code' => 0, 'msg' => '恭喜，当前QQ暂未被QQ空间限制点赞，本次检测正确率70%');
                            }
                        }
                    }
                }
            }
        }
        return json($msg);
    }
    private function doCheckZan($qid)
    {
        $url = "http://{$_SERVER['HTTP_HOST']}/cron/checkZan.php?qid={$qid}&key=tianyage";
        $json = @file_get_contents($url);
        $arr = json_decode($json, true);
        return $arr;
    }
    public function mobileqq()
    {
        $this->islogin();
        if (\think\Request::instance()->isGet()) {
            $qqrows = db('qqs')->field('qq,skey,pskey')->where("uid='{$this->user['uid']}' and skeyzt=0")->select();
            $this->assign('qqrows', $qqrows);
        } else {
            $data = base64_decode(base64_decode($_POST['data']));
            $arr = explode('@', $data);
            $qq = $arr[0];
            $skey = '@' . $arr[1];
            $pskey = $arr[2];
            $cookie = 'uin=o0' . $qq . '; skey=' . $skey . '; p_skey=' . $pskey . ';';
            $gtk = $this->getGTK($skey);
            $url = 'http://cgi.vip.qq.com/online/set?p_tk=&g_tk_type=1&sid=&beg=0&end=24&type=Y&g_tk=' . $gtk;
            $json = get_curl($url, 0, $url, $cookie, 0, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36');
            $arr = json_decode($json, true);
            if ($arr['ret'] == '0') {
                get_exit('加速完成！');
            } elseif ($arr['ret'] == '-7') {
                get_exit('加速异常，请更新此QQ后再来使用！');
            } else {
                get_exit('加速失败，原因：' . $arr['msg']);
            }
        }
        return $this->fetch();
    }
    public function dxjc()
    {
        $this->islogin();
        if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
            get_exit('对不起，此功能仅VIP能使用');
        }
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        $row = $this->qqcheck($qid);
        session_start();
        if (input('param.do') == 'clear') {
            session_unset();
            get_exit('检测数据已重置！', url('/tools/dxjc', 'qid=' . $qid));
        }
        $cookie = 'uin=o0' . $row['qq'] . '; skey=' . $row['skey'] . '; p_uin=o0' . $row['qq'] . '; p_skey=' . $row['pskey'] . ';';
        $gtk = $this->getGTK($row['pskey']);
        $url = 'http://mobile.qzone.qq.com/friend/mfriend_list?g_tk='.$gtk.'&res_uin='.$row['qq'].'&res_type=normal&format=json&count_per_page=10&page_index=0&page_type=0&mayknowuin=&qqmailstat=';
        $json = get_curl($url, 0, 1, $cookie);
        $json = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
        $arr = json_decode($json, true);
        if (!@array_key_exists('code', $arr)) {
            get_exit('获取好友列表失败，请稍候重试！');
        } elseif ($arr['code'] == -3000) {
            get_exit('SKEY已过期，请更新后再检测！');
        } elseif ($arr['code'] == -10000) {
            get_exit('腾讯服务器繁忙，请稍后再来尝试！');
        }
        $this->assign('json', $json);
        $this->assign('qqrow', $row);
        $this->assign('dxrow', $_SESSION['qqmz_dxrow']["{$row['qq']}"]);
        $this->assign('arr', $arr['data']['list']);
        return $this->fetch();
    }
    public function mzjc()
    {
        $this->islogin();
        if (!get_isvip($this->user['vip'], $this->user['vipend'])) {
            get_exit('对不起，此功能仅VIP能使用');
        }
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : '0';
        $row = $this->qqcheck($qid);
        $url = "http://{$_SERVER['HTTP_HOST']}/api/mzjc.php?uin={$row['qq']}&skey={$row['skey']}&pskey={$row['pskey']}";
        $json = @file_get_contents($url);
        $arr = json_decode($json, true);
        if (!@array_key_exists('code', $arr)) {
            get_exit('获取秒赞好友失败，请稍候重试！');
        } elseif ($arr['code'] != 0) {
            get_exit($arr['msg']);
        } elseif ($arr['code'] == -10000) {
            get_exit('腾讯服务器繁忙，请稍后再来尝试！');
        }
        $array = array();
        $nrow = array();
        foreach ($arr['friend'] as $nrow) {
            if ($nrow['mz']) {
                $array[$nrow['groupid']]['mzcount'] = $array[$nrow['groupid']]['mzcount'] + 1;
            }
            $array[$nrow['groupid']][] = $nrow;
        }
        $this->assign('qqrow', $row);
        $this->assign('gpnames', $arr['gpnames']);
        $this->assign('fcount', count($arr['friend']));
        $this->assign('mzcount', $arr['mzcount']);
        $this->assign('friend', $array);
        return $this->fetch();
    }
	public function daigua()
    {
		$blackarr=array('稳定代挂中','<font color=red>密码错误</font>','<font color=red>ＱＱ冻结</font>','<font color=red>请关闭设备锁</font>');
        $this->islogin();
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : exit('NO QID');
        $row = $this->qqcheck($qid);
		if (request()->isPost() && $qid) {
			$func=$_POST['func_0'].','.$_POST['func_1'].','.$_POST['func_2'].','.$_POST['func_3'].','.$_POST['func_4'].','.$_POST['func_5'];
			$pwd=authcode($row['pwd'],'ENCODE','CLOUDKEY');
			$data=get_curl($this->daiguaurl.'api/submit.php?act=add&id='.$row['qqlevel'].'&km='.$_POST['km'].'&uin='.$row['qq'].'&pwd='.urlencode($pwd).'&func='.urlencode($func));
			$arr=json_decode($data,true);
			if($arr['code']==1) {
				db("qqs")->where("qid='$qid'")->update(array('qqlevel'=>$arr['id']));
				get_exit($arr['msg']);
			}elseif(array_key_exists('msg',$arr)){
				get_exit($arr['msg']);
			}else{
				exit($data);
			}
		}
        if($row['qqlevel']) {
			$data=get_curl($this->daiguaurl.'api/submit.php?act=query&id='.$row['qqlevel']);
			$arr=json_decode($data,true);
			if($arr['code']==1) {
				$func=explode(',',$arr['data']);
				if($arr['enddate']>=date("Y-m-d")) {
					$kminput='<div class="form-group">
	<label>QQ代挂配额激活码(可空):</label><br>
	<input type="text" class="form-control" name="km" value="" placeholder="输入激活码以续期">
	</div>';
					$msg='<b>QQ:'.$row['qq'].'</b> 已开通等级代挂功能，到期日期：<font color=red>'.$arr['enddate'].'</font><br/>代挂状态：<u>'.$blackarr[$arr['black']].'</u><br/>
				注：QQ被冻结或者密码修改，请及时更新密码，在本站更新密码后在此页面提交一次即可。<br/>漏挂的扣扣，当天冻结的扣扣更改密码之后请<a href="'.url('tools/fill','qid='.$row['qid']).'">点此提交补挂</a>！';
				} else {
					$kminput='<div class="form-group">
	<label>*QQ代挂配额激活码:</label><br>
	<input type="text" class="form-control" name="km" value="" placeholder="输入激活码以续期">
	</div>';
					$msg='<b>QQ:'.$row['qq'].'</b> 的等级代挂功能已过期（到期日期：<font color=red>'.$arr['enddate'].'</font>），如需继续使用请及时续费！<br/>
				输入激活码可以为您的QQ续期。';
				}
			}elseif($arr['code']==-1){
				$kminput='<div class="form-group">
	<label>*QQ代挂配额激活码:</label><br>
	<input type="text" class="form-control" name="km" value="" placeholder="输入激活码">
	</div>';
				$msg='首次开通请购买并输入代挂激活码，激活码将和你的QQ绑定。开通前请确保关闭设备锁和<a href="https://aq.qq.com/cn2/safe_service/device_lock" target="_blank" rel="noreferrer">登录保护</a>！';
			}else{
				exit($data);
			}
		}else{
			$kminput='<div class="form-group">
	<label>*QQ代挂配额激活码:</label><br>
	<input type="text" class="form-control" name="km" value="" placeholder="输入激活码">
	</div>';
			$msg='首次开通请购买并输入代挂激活码，激活码将和你的QQ绑定。开通前请确保关闭设备锁和<a href="https://aq.qq.com/cn2/safe_service/device_lock" target="_blank" rel="noreferrer">登录保护</a>！';
		}
		$this->assign('qqrow', $row);
        $this->assign('msg', $msg);
		$this->assign('kminput', $kminput);
		$this->assign('func', $func);
        return $this->fetch();
    }
	public function fill()
    {
        $this->islogin();
        $qid = is_numeric(input('param.qid')) ? input('param.qid') : exit('NO QID');
        $row = $this->qqcheck($qid);
		if (request()->isPost() && $qid) {
			$func=implode(',',$_POST['bgid']);
			$data=get_curl($this->daiguaurl.'api/submit.php?act=fill&id='.$row['qqlevel'].'&uin='.$row['qq'].'&func='.urlencode($func));
			$arr=json_decode($data,true);
			if($arr['code']==1) {
				get_exit($arr['msg']);
			}elseif(array_key_exists('msg',$arr)){
				get_exit($arr['msg']);
			}else{
				exit($data);
			}
		}
		$this->assign('qqrow', $row);
        return $this->fetch();
    }
    public function mzlist()
    {
        $this->islogin();
        $list1 = db('qqs')->field('qq,uptime,zannet,iszan')->where('iszan=\'2\' and zannet<\'50\' and skeyzt=0')->order('uptime desc')->limit(100)->select();
		$list2 = db('qqs')->field('qq,uptime,zannet,iszan')->where('iszan=\'2\' and zannet>=\'100\' and zannet<\'150\' and skeyzt=0')->order('uptime desc')->limit(100)->select();
		$list3 = db('qqs')->field('qq,uptime,zannet,iszan')->where('iszan=\'2\' and zannet>=\'200\' and zannet<\'250\' and skeyzt=0')->order('uptime desc')->limit(100)->select();
        $this->assign('list1', $list1);
		$this->assign('list2', $list2);
		$this->assign('list3', $list3);
        return $this->fetch();
    }
    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }
    private function getGTK($skey)
    {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
    private function qqcheck($qid)
    {
        if (is_numeric($qid)) {
            if (!$qid || !($row = db('qqs')->field('*')->where("qid='{$qid}' and uid='" . $this->user['uid'] . '\'')->find())) {
                get_exit('QQ号读取错误，请刷新重试！');
            } else {
                return $row;
            }
        } else {
            get_exit('QID错误！');
        }
    }
    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field('*')->where("sid='{$sid}'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                $qlist = db('qqs')->field('qid,qq,skeyzt')->where('uid=\'' . $this->user['uid'] . '\'')->order('qid desc')->select();
                $this->assign('qlist', $qlist);
				if(config('daiguaapi')==1){
					$this->daiguaurl=config('daiguaurl');
				}elseif(config('daiguaapi')==2){
					$this->daiguaurl='http://www.52dg.net/';
				}else{
					$this->daiguaurl='http://auth.v8daigua.com/';
				}
            }
        } else {
            $this->assign('user', 0);
        }
    }
}