<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Db;
use think\Cache;

class Adm extends Controller
{
	    public function ssz()
    {
        // 是否删除QQ
        $act = input("post.act");
        if ($act == 'del') {
            $id = input("post.id/d");
            db("sszs")->where("id='{$id}'")->limit(1)->delete();
        } elseif ($act == 'lh') {
            $uin = input("post.uin");
            if (preg_match('/^\d{5,10}$/', $uin)) {
                db("ssz_lhs")->insert(array('uin' => $uin));
            }
        } elseif ($act == 'jh') {
            $uin = input("post.uin");
            if (preg_match('/^\d{5,10}$/', $uin)) {
                db("ssz_lhs")->where("uin='{$uin}'")->delete();
            }
        } elseif ($act == 'num') {
            $num = input("post.num/d");
            db("webconfigs")->execute("insert into " . config("database.prefix") . "webconfigs set `vkey`='ssz_num',`value`='{$num}' on duplicate key update `value`='{$num}'");
        }
        // 是否搜索QQ
        if (input("post.do") == 'search' && $uin = is_numeric(input("post.uin")) ? input("post.uin") : '0') {
            $rows = db("sszs")->field("*")->where("uin like '%{$uin}%'")->order('id desc')->limit(12)->select();
            $p = 1;
            $pages = 1;
            $count = 1;
            $sple = 0;
        } else {
            $p = is_numeric(input("param.p")) ? input("param.p") : '1';
            $start = 12 * ($p - 1);
            $next = $p + 1;
            $limit = "{$start},12";
            $count = db("qqs")->count('qid');
            $pages = ceil($count / 12);
            $rows = db("sszs")->field("*")->order('id desc')->limit(12)->select();
            if (($p - 1) > 0) {
                $start = $p - 1;
            } else {
                $start = 1;
            }
            if (($p + 5) < $pages) {
                $end = $p + 5;
            } else {
                $end = $pages;
            }
            $this->assign('end', $end);
            $this->assign('start', $start);
        }
        foreach ($rows as $k => $row) {
            $rows[$k]['lh'] = 0;
            if (db("ssz_lhs")->where("uin='{$row['uin']}'")->find()) {
                $rows[$k]['lh'] = 1;
            }
        }
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();
    }

    public function fzadd()
    {
        if (request()->isPost()) {
            $uid = input('post.uid');
            if (input('post.outtime') < date("Y-m-d")) {
                get_exit("分站到期时间不能早于当前");
            } elseif (strlen(input('post.web_url')) < 3) {
                get_exit("绑定域名不合法");
            } elseif (!$row = db("users")->field('uid')->where("uid='$uid'")->find()) {
                get_exit("你所输入的UID不存在");
            }
            $data = input('post.');
            $data['pay_auto'] = 1;
            $data['price_1vip'] = config('price_1vip');
            $data['price_3vip'] = config('price_3vip');
            $data['price_6vip'] = config('price_6vip');
            $data['price_12vip'] = config('price_12vip');
            $data['price_1peie'] = config('price_1peie');
            $data['price_3peie'] = config('price_3peie');
            $data['price_5peie'] = config('price_5peie');
            $data['price_10peie'] = config('price_10peie');
            $data['addtime'] = date("Y-m-d");
            db('fenzhan')->insert($data);
            get_exit('添加分站成功');
        }
        return $this->fetch();
    }

    public function fzset()
    {
        $fid = is_numeric(input("param.fid")) ? input("param.fid") : exit('非法操作！');
        if (!$row = db("fenzhan")->field('*')->where("id='$fid'")->find()) {
            $this->assign('alert', get_exit("分站不存在！", 1));
        } elseif (request()->isPost() && $fid) {
            $data = input('post.');
            //if ($_POST['active'] == 1) {//判断是否需要拉黑
            //    db('qqs')->where("webid='$fid'")->delete(); // 删除分站下所有qq
            //    db('users')->where("webid='$fid'")->delete(); // 删除分站下所有用户
            //}
            db("fenzhan")->where("id='$fid'")->update($data);
            $this->assign('alert', get_exit("保存成功！", 1));
        } elseif (input('route.type') == 'del') {
            db('fenzhan')->where("id='$fid'")->delete(); // 删除分站信息
            db('qqs')->where("webid='$fid'")->delete(); // 删除分站下所有qq
            db('users')->where("webid='$fid'")->delete(); // 删除分站下所有用户
            get_exit('删除成功！');
        }
        $this->assign('fz', $row);
        return $this->fetch();
    }

    public function fzlist()
    {
        $fzs = db("fenzhan")->field(true)->select();
        $this->assign('fzs', $fzs);
        return $this->fetch();
    }

    public function net()
    {
        return $this->fetch();
    }

    public function order()
    {
        if ($orderId = input("get.oid")) {
            $orderList = db("pay")->field("*")->where("out_trade_no LIKE '%{$orderId}%'")->select();
            $this->assign('olist', $orderList);
            $this->assign('oid', $orderId);
        }
        $list = db('pay')->where("status>0")->order('create_time desc')->paginate(10);
        $this->assign('list', $list);
        return $this->fetch();
    }

    /*删除3个月内未登录的账号与添加的秒赞QQ*/
    public function delNoUser()
    {
        $users = db("users")->field("uid")->where("lasttime<'2016-01-06 00:00:00'")->select();
        foreach ($users as $user) {
            $qqrow = db("qqs")->where("uid='{$user['uid']}'")->delete();
            echo 1;
        }
//        db("users")->where("lasttime<'2016-01-06 00:00:00'")->delete();
        get_exit('删除完成');
    }

    /*获取秒赞售后群里的无效成员*/
    public function qundel()
    {
        $data = input('post.qqlist', '', 'get_safe_str');
        if ($data) {
            $arr = explode("\n", $data);
            foreach ($arr as $qq) {
                // echo $qq . '#' . '<br/>';
                $qqrow = db("qqs")->field("uid")->where("qq='{$qq}'")->find();//查找qq号是否已托管
                if ($qqrow) {
                    $user = db("users")->field("vip")->where("uid='{$qqrow['uid']}'")->find();
                    /*判断是否是免费用户*/
                    if ($user['vip'] == 0) {
                        echo $qq . '#' . '<br/>';
                    }
                } else {
                    /*进入此处的为未托管的qq号，踢出群*/
                    echo $qq . '##' . '<br/>';
                }
            }
            die;
            // get_exit('完成');
        }
        return $this->fetch();
    }

    /*删除群内指定QQ*/
    public function qunDelQq()
    {
        $data = input('post.qqlist', '', 'get_safe_str');
        if ($data) {
            $arr = explode("\n", $data);
            foreach ($arr as $qq) {
                $gc = '216402510';
                $skey = '@wdd123v3O';
                $cookie = 'pt2gguin=o0454701103; uin=o0454701103; skey=@wdd123v3O; p_uin=o0454701103; p_skey=ls97Kt9e123DwCQl3ucX8uI2p3aydHZSCUe61233Vg_;';
                $gtk = $this->getGTK($skey);
                $ua = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36";
                $url = "http://qun.qq.com/cgi-bin/qun_mgr/delete_group_member";
                $post = "gc={$gc}&ul={$qq}&flag=0&bkn={$gtk}";
                $referer = "http://qun.qq.com/member.html";
                $json = get_curl($url, $post, $referer, $cookie, 0, $ua);
                $data = json_decode($json, true);
                if ($data['ec'] == 0) {
                    $msg[] = $qq . '删除成功！';
                } else {
                    $msg[] = $qq . '删除失败！';
                }
            }
            print_r($msg);
            die;
        }
        return $this->fetch();
    }

    public function getGTK($skey)
    {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ((($hash << 5) & 0x7fffffff) + ord($skey[$i])) & 0x7fffffff;
            $hash &= 0x7fffffff;
        }
        return $hash & 0x7fffffff; //计算g_tk
    }

    public function notice()
    {
        $title = $_POST['title'];
        $con = $_POST['con'];

        if (input("post.do") == 'new') {
            $data['title'] = $title;
            $data['con'] = $con;
            $data['addtime'] = time();
            db("gonggao")->insert($data);
            delDirAndFile('./runtime/cache', 0);
            $this->assign('alert', get_exit("公告添加成功"));
        } elseif (input("post.do") == 'old') {
            $ggid = intval(input("post.ggid"));
            $data['title'] = $title;
            $data['con'] = $con;
            // print_r($data);exit;
            db("gonggao")->where("id='$ggid'")->update($data);
            delDirAndFile('./runtime/cache', 0);
            $this->assign('alert', get_exit("公告修改成功"));
        } elseif (input("param.do") == 'del') {
            $ggid = intval(input("param.ggid"));
            db("gonggao")->where("id='$ggid'")->delete();
            delDirAndFile('./runtime/cache', 0);
            $this->assign('alert', get_exit("公告删除成功"));
        }
        if ($ggid = input('param.ggid')) {
            $gglist2 = db("gonggao")->field('*')->where("id='$ggid'")->find();
        } else {
            $gglist = db("gonggao")->field('*')->limit(15)->order('id desc')->select();
        }
        $this->assign('gglist', $gglist);
        $this->assign('gglist2', $gglist2);
        // print_r($gglist2);exit;
        $this->assign('xz', input("param.xz"));
        return $this->fetch();
    }

    public function userset()
    {
        $uid = is_numeric(input("param.uid")) ? input("param.uid") : exit('非法操作！');
        if (request()->isPost() && $uid) {
            if ($_POST['resetpwd']) {
                $_POST['pwd'] = '305dc2ef435361ad8cebedff0636076b';
            }
            if ($_POST['active'] == 1) {//判断是否需要拉黑
                db('qqs')->where("uid='$uid'")->delete(); // 删除名下所有qq
                db('chats')->where("uid='$uid'")->delete(); // 删除所有发言
                $_POST['sid'] = 'qq454701103'; // 修改cookie
            }
            unset($_POST['resetpwd']);
            db("users")->where("uid='$uid'")->update($_POST);
            $this->assign('alert', get_exit("保存成功！", 1));
        }
        if (!$row = db("users")->field('*')->where("uid='$uid'")->find()) {
            $this->assign('alert', get_exit("用户不存在！", 1));
        }
        $this->assign('user_res', $row);
        return $this->fetch();
    }

    public function qqset()
    {
        $qid = is_numeric(input("param.qid")) ? input("param.qid") : exit('非法操作！');
        if (request()->isPost() && $qid) {
            db("qqs")->where("qid='{$qid}'")->update($_POST);
            $this->assign('alert', get_exit("保存成功！", 1));
        }
        if (!$row = db("qqs")->field('*')->where("qid='{$qid}'")->find()) {
            $this->assign('alert', get_exit("QQ不存在！", 1));
        }
        $this->assign('qq_res', $row);
        return $this->fetch();
    }

    public function login()
    {
        if (request()->isPost()) {
            $pwd = md5(md5($_POST['pwd']) . md5('QQ454701103'));
            if ($pwd == config('adminpwd')) {
                session("admin_pwd", $pwd);
                get_exit(0, url('index'));
            } else {
                get_exit("密码不正确！");
            }
        }
        return $this->fetch();
    }

    public function logout()
    {
        session('admin_pwd', null);
        get_exit('注销成功！', '/');
    }

    public function index()
    {
        if (input("param.do") == 'delendvip') {
            if ($rows = db("users")->field('uid')->where("vip>0 and vipend <= '" . date("Y-m-d") . "'")->order('uid desc')->select()) {
                foreach ($rows as $row) {
                    $uid = $row['uid'];
                    db("qqs")->execute("update qqmz_qqs set iszan=0,zannet=0,replynet=0,shuonet=0,isdel=0,isqd=0,isht=0,isly=0,isvipqd=0,iszyzan=0,zfnet=0,ists=0,islz=0,isdelly=0,isqb=0,isqt=0,isqunqd=0,ishzqd=0,isxzqd=0,isqipao=0 where uid='{$uid}'");
                    db('users')->where("uid='$uid'")->setField('vip', '0');
                    // db('qqs')->where("uid='$uid'")->delete();
                }
                $this->assign('alert', get_exit("已成功清理VIP到期用户！", 1));
            } else {
                $this->assign('alert', get_exit("暂时没有待清理的用户！", 1));
            }
        } elseif (input("param.do") == 'delendqq') {
            if ($rows = db("qqs")->field('qid')->where("skeyzt=1")->order('qid desc')->select()) {
                foreach ($rows as $row) {
                    db('qqs')->where("qid='" . $row['qid'] . "'")->delete();
                }
                $this->assign('alert', get_exit("成功清理失效QQ！", 1));
            }
            $this->assign('alert', get_exit("没有失效QQ！", 1));
        }
        if (!$allmoney = Cache::get('money_today')) {
            $orders = db("pay")->field("*")->where("status>0")->where("create_time>" . strtotime(date("Y-m-d")))->select();
            $allmoney = 0;
            foreach ($orders as $order) {
                $allmoney += $order['money'];
            }
            Cache::set('money_today', $allmoney, 1800);
        }
        $this->assign('money_today', $allmoney);
        if (!$allmoney = Cache::get('money_all')) {
            $orders = db("pay")->field("money")->where("status>0")->select();
            $allmoney = 0;
            foreach ($orders as $order) {
                $allmoney += $order['money'];
            }
            Cache::set('money_all', $allmoney, 3600);
        }
        $this->assign('money_all', $allmoney);
        return $this->fetch();
    }

    public function set()
    {
        if (request()->isPost()) {
            if (input("post.do") == 'testmail') {
                $mail = $_POST['mail'];
                $msg = $this->sendmail($mail, '秒赞测试邮箱配置', '收到这封邮件，说明你的邮箱配置正确，能正常发送邮件！');
                get_exit($msg, 2);
            } else {
                if (empty($_POST['adminpwd'])) {
                    unset($_POST['adminpwd']);
                } else {
                    $_POST['adminpwd'] = md5(md5($_POST['adminpwd']) . md5('QQ454701103'));
                }
                if (empty($_POST['pay_pwd'])) {
                    unset($_POST['pay_pwd']);
                } else {
                    $_POST['pay_pwd'] = md5(md5($_POST['pay_pwd']) . md5('QQ454701103'));
                }
                foreach ($_POST as $k => $value) {
                    db("webconfigs")->execute("insert into " . config("database.prefix") . "webconfigs set `vkey`='$k',`value`='$value' on duplicate key update `value`='$value'");
                }
                get_exit('保存成功');
            }
        }
        load_webconfig(); //加载网站配置
        $this->assign('xz', input("param.xz"));
        return $this->fetch();
    }

    public function ad()
    {
        if (request()->isPost()) {
            if (input("param.do") == 'add') {
                $aid = intval(input("post.aid"));
                $data['aid'] = $aid;
                $data['uid'] = 0;
                $data['content'] = '广告位招租';
                $data['addtime'] = '2017-01-01';
                $data['exttime'] = '2017-01-01';
                db("ad")->insert($data);
                delDirAndFile('./runtime/cache', 0);
                get_exit('添加成功');
            } elseif (input("param.do") == 'edit') {
                $aid = intval(input("param.aid"));
                $data['aid'] = $aid;
                $data['uid'] = input("post.uid");
                $data['content'] = input("post.content");
                $data['url'] = input("post.url");
                $data['color'] = input("post.color");
                $data['addtime'] = input("post.addtime");
                $data['exttime'] = input("post.exttime");
                db("ad")->where("aid='{$aid}'")->update($data);
                delDirAndFile('./runtime/cache', 0);
                get_exit('保存成功');
            }
        } elseif (input("param.do") == 'del' && $aid = intval(input("param.aid"))) {
            db('ad')->where("aid='$aid'")->delete();
            delDirAndFile('./runtime/cache', 0);
            get_exit('删除成功');
        }
        // 广告内容
        $ads = db("ad")->field("*")->order("aid ASC")->select();
        $first = db("ad")->field("aid")->order('aid desc')->limit(1)->value('aid');
        $this->assign('ads', $ads);
        $this->assign('first', $first ? $first + 1 : 1);
        return $this->fetch();
    }

    public function qqlist()
    {
        // 是否删除QQ
        if (input("param.do") == 'del' && $qid = is_numeric(input("param.qid")) ? input("param.qid") : '0') {
            db('qqs')->where("qid='$qid'")->delete();
            $this->assign('alert', get_exit("删除成功！", 1));
        }
        // 是否搜索QQ
        if (input("post.do") == 'search' && $uin = is_numeric(input("post.uin")) ? input("post.uin") : '0') {
            $rows = Db::view('Qqs', '*')
                ->view('Users', 'vip,vipend,user', 'Users.uid=Qqs.uid')
                ->where("Qqs.qq like '%{$uin}%'")
                ->limit(12)
                ->order('qid desc')
                ->select();
            $p = 1;
            $pages = 1;
            $count = 1;
            $sple = 0;
        } else {
            $p = is_numeric(input("param.p")) ? input("param.p") : '1';
            $start = 12 * ($p - 1);
            $next = $p + 1;
            $limit = "{$start},12";
            $count = db("qqs")->count('qid');
            $pages = ceil($count / 12);
            $rows = Db::view('Qqs', '*')
                ->view('Users', 'vip,vipend,user', 'Users.uid=Qqs.uid')
                ->limit($limit)
                ->order('qid desc')
                ->select();
            if (($p - 1) > 0) {
                $start = $p - 1;
            } else {
                $start = 1;
            }
            if (($p + 5) < $pages) {
                $end = $p + 5;
            } else {
                $end = $pages;
            }
            $this->assign('end', $end);
            $this->assign('start', $start);
        }
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();
    }

    public function userlist()
    {
        $xz = input("param.xz");
        $uid = is_numeric(input("param.uid")) ? input("param.uid") : '0';
        if (input("post.act") == 'fzz') {
            $is = input("post.is/d") ? 1 : 0;
            db('users')->where("uid='$uid'")->setField('is_fzz', $is);
        }
        if (input("param.do") == 'del' && $uid) {
            db('qqs')->where("uid='$uid'")->delete();
            db('users')->where("uid='$uid'")->delete();
        } elseif (input("param.do") == 'active' && $uid) {
            db('users')->where("uid='$uid'")->setField('active', '1');
        }
        if (input("post.do") == 'search' && $s = input('post.key', '', 'get_safe_str')) {
            $where = "uid='{$s}' or user like'%{$s}%' or qq like'%{$s}%'";
            if ($xz == 'vip') {
                $where = "($where) and vip>0 and vipend > '" . date("Y-m-d") . "'";
            }
            $rows = db("users")->field('*')->where($where)->limit(12)->order("(case when uid='{$s}' then 8 else 0 end)+(case when user like '%{$s}%' then 3 else 0 end)+(case when qq like '%{$s}%' then 1 else 0 end) desc")->select();
            $p = 1;
            $pages = 1;
            $count = 1;
        } else {
            $p = is_numeric(input("param.p")) ? input("param.p") : '1';
            $start = 12 * ($p - 1);
            $next = $p + 1;
            $limit = "$start,12";
            if ($xz == 'vip') {
                $where .= "vip>0 and vipend > '" . date("Y-m-d") . "'";
            }
            $count = db("users")->where($where)->count('uid');
            $pages = ceil($count / 12);
            $rows = db("users")->field('*')->where($where)->limit($limit)->order('uid desc')->select();
            if (($p - 1) > 0) {
                $start = $p - 1;
            } else {
                $start = 1;
            }
            if (($p + 5) < $pages) {
                $end = $p + 5;
            } else {
                $end = $pages;
            }
            $this->assign('end', $end);
            $this->assign('start', $start);
        }
        $this->assign('xz', $xz);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();
    }

    public function km()
    {
        $xz = input("param.xz");
        $kid = is_numeric(input("param.kid")) ? input("param.kid") : '0';
        if (input("param.do") == 'del' && $kid) {
            db('kms')->where("kid='$kid'")->delete();
        }
        if (input("post.do") == 'add') {
            $num = is_numeric($_POST['num']) ? $_POST['num'] : '1';
            $ms = is_numeric($_POST['ms']) ? $_POST['ms'] : '1';
            if ($xz == 'peie') {
                $kind = 1;
            } elseif ($xz == 'sy') {
                $kind = 2;
            } else {
                $kind = 0;
            }
            $msg = "<ul class='list-group'>
			<li class='list-group-item active'>成功生成以下卡密</li>";
            for ($i = 0; $i < $num; $i++) {
                $data = [];
                $data['kind'] = $kind;
                $data['daili'] = 1;
                $data['km'] = $this->getkm(12);
                $data['ms'] = $ms;
                $data['isuse'] = 0;
                $data['addtime'] = date("Y-m-d H:i:s");
                if (db("kms")->insert($data)) {
                    $msg .= "<li class='list-group-item'>{$data['km']}</li>";
                }
            }
            $msg .= "</ul>";
            $this->assign('msg', $msg);
        }
        if (input("post.do") == 'search' && $s = input('post.key', '', 'get_safe_str')) {
            $where = "km like '%$s%'";
            if ($xz == 'peie') {
                $where .= " and kind=1";
            } elseif ($xz == 'sy') {
                $where .= " and kind=2";
            } else {
                $where .= " and kind=0";
            }
            $rows = Db::view('Kms', '*')
                ->view('Users', '*', 'Users.uid=Kms.daili')
                ->where($where)->limit(12)->order('kid desc')->select();
            $p = 1;
            $pages = 1;
            $count = 1;
        } else {
            $p = is_numeric(input("param.p")) ? input("param.p") : '1';
            $start = 12 * ($p - 1);
            $next = $p + 1;
            $limit = "$start,12";
            if ($xz == 'peie') {
                $where = "kind=1";
            } elseif ($xz == 'sy') {
                $where = "kind=2";
            } else {
                $where = "kind=0";
            }
            $count = db("kms")->where($where)->count('kid');
            $pages = ceil($count / 12);
            $rows = Db::view('Kms', '*')
                ->view('Users', [
                    'user' => 'uuser',
                    'uid' => 'uuid',
                ], 'Users.uid=Kms.daili')
                ->where($where)->limit($limit)->order('kid desc')->select();
            if (($p - 1) > 0) {
                $start = $p - 1;
            } else {
                $start = 1;
            }
            if (($p + 5) < $pages) {
                $end = $p + 5;
            } else {
                $end = $pages;
            }
            $this->assign('end', $end);
            $this->assign('start', $start);
        }
        $this->assign('xz', $xz);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();
    }

    public function dllist()
    {
        $uid = is_numeric($_REQUEST['uid']) ? $_REQUEST['uid'] : '0';
        $rmb = is_numeric($_REQUEST['rmb']) ? $_REQUEST['rmb'] : '0';
        if ($uid && !$row = db("users")->field('uid')->where("uid='$uid'")->find()) {
            $this->assign('alert', get_exit('用户不存在！', '1'));
            $uid = 0;
        }
        if (input("param.do") == 'del' && $uid) {
            db('users')->where("uid='$uid'")->setField('daili', '0');
        }
        if (input("post.do") == 'add' && $uid) {
            db('users')->where("uid='$uid'")->setField('daili', '1');
            $this->assign('alert', get_exit('成功添加UID:' . $uid . '用户为代理！', '1'));
        } elseif (input("post.do") == 'cz' && $uid && $rmb) {
            db('users')->where("uid='$uid'")->setInc('rmb', $rmb);
            $this->assign('alert', get_exit('成功为UID:' . $uid . '代理充值' . $rmb . '元！', '1'));
        } elseif (input("post.do") == 'kc' && $uid && $rmb) {
            db('users')->where("uid='$uid'")->setDec('rmb', $rmb);
            $this->assign('alert', get_exit('成功扣除UID:' . $uid . '代理' . $rmb . '元！', '1'));
        }
        $p = is_numeric(input("param.kid")) ? input("param.kid") : '1';
        $start = 10 * ($p - 1);
        $next = $p + 1;
        $limit = "$start,10";
        $count = db("users")->where("daili>0")->count('uid');
        $pages = ceil($count / 10);
        $rows = db("users")->field('*')->where("daili>0")->limit($limit)->order('uid desc')->select();
        if (($p - 1) > 0) {
            $start = $p - 1;
        } else {
            $start = 1;
        }
        if (($p + 5) < $pages) {
            $end = $p + 5;
        } else {
            $end = $pages;
        }
        $this->assign('end', $end);
        $this->assign('start', $start);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();

    }

    private function getkm($len = 12)
    {
        $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $strlen = strlen($str);
        $randstr = '';
        for ($i = 0; $i < $len; $i++) {
            $randstr .= $str[mt_rand(0, $strlen - 1)];
        }
        return $randstr;
    }

    private function sendmail($to, $title, $content)
    {
        Vendor('Mail');
        $mail = new \MySendMail();
        // 判断是否用SSL链接
        if (config('mail_port') == '465') {
            $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'), true);
        } else {
            $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'));
        }
        $mail->setFrom(config('mail_user'), config('web_name'));
        $mail->setReceiver($to);
        $mail->setMail($title, $content);
        $mail->sendMail();
        return '发送完成，请查收';
    }

    public function __construct()
    {
        parent::__construct();
        if (request()->action() != 'login') {
            if (config('adminpwd') && session('admin_pwd') == config('adminpwd')) {
                // 已登录
            } else {
                get_exit(0, url('login'));
            }
        }
    }
}