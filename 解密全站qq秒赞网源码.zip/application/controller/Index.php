<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Db;

class Index extends Controller
{
    private $user;

    public function ssz()
    {
        $errorInfo = null;
        $successInfo = null;
        if (request()->isPost()) {
            $uin = input('post.uin');
            if (!preg_match('/^\d{5,10}$/', $uin)) {
                $errorInfo = "QQ号码不正确";
            } elseif (db("ssz_lhs")->where("uin='{$uin}'")->find()) {
                $errorInfo = "对不起，此QQ已被禁止使用此功能！";
            } else {
                if (input("post.sz")) {
                    $ssid = input("post.ssid");
                    if (strlen($ssid) < 10 || !preg_match('/^[a-z0-9]+$/', $ssid)) {
                        $errorInfo = "说说ID不正确";
                    } elseif ($row = db("sszs")->field("*")->where("uin='{$uin}' and (TO_DAYS(now()) - TO_DAYS(addtime)) < 7")->find()) {
                        $data = date("Y-m-d", strtotime("+7 days", strtotime($row['addtime'])));
                        $errorInfo = "刷赞失败！免费用户每QQ每周只可使用一次！您的下次使用时间[{$data}]";
                    } else {
                        $data = array(
                            'uin' => $uin,
                            'ssid' => $ssid,
                            'addtime' => date("Y-m-d")
                        );
                        db('sszs')->insert($data);
                        $successInfo = "成功提交！您可以在1-3分钟内刷新说说查看赞数！";
                    }

                } else {
                    if ($ssList = $this->getSSList($uin)) {
                        if ($ssList['code'] == -4009) {
                            $errorInfo = "主人设置了空间访问权限";
                        } elseif ($ssList['code'] == 0) {
                            $successInfo = "获取说说成功";
                            $this->assign('ssList', $ssList['data']['vFeeds']);
                        }
                    } else {
                        $errorInfo = "服务器繁忙，请稍后再试！";
                    }
                }
            }
        }
        $this->assign('successInfo', $successInfo);
        $this->assign('errorInfo', $errorInfo);
        return $this->fetch();
    }

    private function getSSList($uin, $times = 0)
    {
        if ($res = db("qqs")->field("*")->where("skeyzt=0")->find()) {
            $g_tk = $this->get_gtk($res['pskey']);
            $cookie = "uin=o0{$res['qq']}; skey={$res['skey']}; p_uin=o0{$res['qq']}; p_skey={$res['pskey']};";
            $url = "https://mobile.qzone.qq.com/list?g_tk={$g_tk}&format=json&list_type=shuoshuo&action=0&res_uin={$uin}&count=20";
            $ret = get_curl($url, null, null, $cookie);
            $arr = json_decode($ret, true);
            if (!$ret || isset($arr['code']) && $arr['code'] == -3000) {
                db('qqs')->where("qid='{$res['qid']}'")->setField('skeyzt', '1');
                return $this->getSSList($uin, $times + 1);
            } elseif (isset($arr['code'])) {
                return $arr;
            }
        }
        return false;
    }

    private function get_gtk($skey)
    {
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += (($hash << 5) & 0xffffffff) + ord($skey[$i]);
        }
        return $hash & 0x7fffffff;
    }

    public function app()
    {
        include APP_PATH . 'txprotect.php';
        $app = [];
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')) {
            $app['phone'] = 'iOS';
            $app['down'] = 'itms-services://?action=download-manifest&url=https://www.qqmiaozan.com/static/app/qqmz.app.plist';
        } else {
            $app['phone'] = 'Android';
            $app['down'] = '/static/app/qqmz.apk';
        }
        $this->assign('app', $app);
        return $this->fetch();
    }

    /**
     * 用户广告位管理
     * @return mixed
     */
    public function adm()
    {
        $this->islogin();
        if (request()->isPost()) {
            $aid = input('route.aid');
            $res = db("ad")->field("aid")->where("uid='{$this->user['uid']}' And aid='{$aid}'")->find();
            if ($res) {
                $data = request()->only('content,url,color');
                db("ad")->where("uid='{$this->user['uid']}' And aid='{$aid}'")->update($data);
                delDirAndFile('./runtime/cache', 0);
                get_exit('修改成功！');
            } else {
                get_exit('你没有权限修改此广告位！');
            }
        }
        $ads = db('ad')->field("*")->where("uid='{$this->user['uid']}'")->select();
        $this->assign('ads', $ads);
        return $this->fetch();
    }

    /**
     * 发送说说
     * @param $uid
     * @return bool
     */
    private function sendshuo($uid)
    {
        $qq = db("qqs")->field('qq,sid,skey,pskey')->where("uid='" . $uid . "'")->limit(1)->find();
        if (!$qq) {
            get_exit('暂未添加QQ，无法发言[1]');
        }
        // print_r($qq);die;
        $qzone = new \app\model\Qzone($qq['qq'], $qq['sid'], $qq['skey'], $qq['pskey']);
        // 随机图片
        $pic = 'http://i4.buimg.com/1949/719d39fd30bcb40c.jpg';
        if ($pic == 1) {
            $row = file('cron/data/pic.txt');
            shuffle($row);
            $pic = $row[0];
            $type = 0;
        } else {
            $type = stripos('z' . $pic, 'http') ? 0 : 1;
        }
        $pic = trim($pic);
        $res = $qzone->shuo(0, '各位秒赞注意啦，全部转移到最稳定的QQ秒赞网！！！点击网址进入 http://suo.im/kgv72 点不开的可以复制网址到浏览器中打开！http://suo.im/kgv72 签到送VIP会员', $pic, 0);
        if (!$res) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 滑动解锁验证
     * @return bool|string
     */
    public function yz()
    {
        if (request()->isAjax()) {
            session('lock', input('get.k'));
            return 'ok';
        }
        return false;
    }

    /**
     * 检查是否包含敏感词汇,判断返回值大于0说明包含敏感词
     * @param $content
     * @return int
     */
    private function blackList($content)
    {
        // 定义敏感词
        $keyword = [
            '.com',
            '.cn',
            '.cc',
            '.tk',
            '卡盟',
            '流量',
            '卡密',
            '免费',
            '出售',
            '兼职',
            '涮钻',
            '刷钻',
            '空间人气',
            '爱奇艺',
            '业务',
            '永久',
            '彩虹',
            '搭建',
            '要的加',
            '转移',
            '送',
            '小柯',
            '网名',
            '看我',
            '勇九',
            '不要钱',
            '1723931667',
            '1106619206',
            '3423931667',
            '1601996526',
        ];
        $content2 = preg_replace('/\W/', '', $content);
        if (strstr($content2, '1723931667') || strstr($content2, '3423931667')) {
//            if (!$this->sendshuo($this->user['uid'])) {
//                get_exit('填写内容异常，请重新填写！');
//            }
            get_exit('填写内容异常，请重新填写！[2]');
        }
        $m = 0;
        for ($i = 0; $i < count($keyword); $i++) {    //根据数组元素数量执行for循环
            //应用substr_count检测内容中是否包含敏感词
            if (substr_count($content, $keyword [$i]) > 0) {
                $m++;
            }
        }
        return $m; //返回变量值，根据变量值判断是否存在敏感词
    }

    /**
     * 聊天系统
     */
    public function chat()
    {
        $this->islogin();
        if (input('post.do') == 'look') { // 查看旧聊天记录
            $id = is_numeric($_POST['id']) ? $_POST['id'] : '1';
            if ($id == 1) {
                exit('{"code":-1,"msg":"没有更多聊天内容了！"}');
            }
            $rows = Db::view('Chats', '*')
                ->view('Users', 'vip,user,qq', 'Users.uid=Chats.uid')
                ->where('id<' . $id)
                ->limit(5)
                ->order('id desc')
                ->select();
            $array['code'] = 0;
            $array['data'] = $rows;
            exit(json_encode($array));
        } elseif (input('post.do') == 'new') { // 获取最新消息
            $id = is_numeric($_POST['id']) ? $_POST['id'] : '0';
            $rows = Db::view('Chats', '*')
                ->view('Users', 'vip,user,qq', 'Users.uid=Chats.uid')
                ->where('id>' . $id)
                ->order('id asc')
                ->select();
            $array['code'] = 0;
            $array['data'] = $rows;
            exit(json_encode($array));
        } elseif (input('post.do') == 'send') { // 发送信息
            // 无添加QQ的禁止发言
            $qq = db('qqs')->field("qid")->where("uid='{$this->user['uid']}' And zannet>0")->limit(1)->find();
            if (!$qq) {
                get_exit('请先添加一个QQ以便获取头像');
            }
            // End 无添加QQ的禁止发言
            $con = input('post.content', '', 'get_safe_str');
            if (!$con) {
                get_exit('聊天内容不能为空');
            } elseif ($this->user['active'] == 2 || cookie('black')) {
                cookie('black', 1, 1800);
                get_exit('您发布的内容中包含违规词汇已被系统临时禁言，稍后审核无违规后将解除禁言！');
            } elseif (!session('lock') || session('lock') != input('post.k')) {
                get_exit('验证错误，请拖动滑块进行验证！');
            } elseif ($con == cookie('lastcon')) {
                get_exit('提醒：相似内容的连续发言将永久封号');
            } elseif (cookie('send') > 1) {
                get_exit('请勿频繁发送消息...');
            }
            session('lock', null);
            // 检查敏感词
            $black = $this->blackList($con);
            if ($black == 1) {
                get_exit('内容包含敏感词汇，请修改后提交！');
            } elseif ($black > 1) {
                $udata['active'] = 2; // 修改状态为2，禁言
                db('users')->where("uid='{$this->user['uid']}'")->update($udata);
                $data['state'] = 1; // 内容改为需审核状态
            }
            // End 检测
            cookie('lastcon', $con);
            $data['uid'] = $this->user['uid'];
            $data['content'] = $con;
            $data['addtime'] = date("Y-m-d H:i:s");
            db("chats")->insert($data);
            cookie('send', cookie('send') + 1, 900); // 限制15分钟的发言速度
            $this->assign('go', 1); // 发送信息的直接跳转到页面最底部
        }
        $p = is_numeric(input('get.p')) ? input('get.p') : '1';
        $start = 15 * ($p - 1);
        $next = $p + 1;
        $limit = "$start,50";
        $count = db("chats")->count('id');
        $pages = ceil($count / 15);
        $rows = Db::view('Chats', '*')
            ->view('Users', 'vip,user,qq', 'Users.uid=Chats.uid')
            ->where('state=0')
            ->limit($limit)
            ->order('id desc')
            ->select();
        if (!$lastchat = $rows[0]['id']) {
            $lastchat = 0;
        }
        $this->assign('lastchat', $lastchat);
        $rows = array_reverse($rows);
        if (!$startchat = $rows[0]['id']) {
            $startchat = 1;
        }
        $this->assign('startchat', $startchat);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();
    }

    /**
     * 用户资料查看和修改
     */
    public function userInfo()
    {
        $this->islogin();
        if (request()->isPost()) {
            $pwd = input("post.pwd");
            if (strlen($pwd) < 5) {
                get_exit("新密码太短了!");
            }
            $pwd = $this->getMd5Pwd($pwd);
            $data['pwd'] = $pwd;
            db("users")->where("uid='{$this->user['uid']}'")->update($data);
            foreach ($_POST as $k => $value) {
                db("webconfigs")->execute("insert into " . config("database.prefix") . "webconfigs set `vkey`='$k',`value`='$value' on duplicate key update `value`='$value'");
            }
            get_exit('修改成功', 2);
        }
        return $this->fetch();
    }

    /**
     * 首页
     */
    public function index()
    {
        include APP_PATH . 'txprotect.php';
        return $this->fetch();
    }

    /**
     * 用户中心
     */
    public function user()
    {
        $this->islogin();
        $qqcount = db("qqs")->where("uid='" . $this->user['uid'] . "'")->count('qid');
        if ($qqcount == 0) {
            $art = '<script>swal({title:"温馨提示",text:"您当前还暂未添加QQ，无法使用功能，是否添加？",type:"warning",showCancelButton:true,confirmButtonColor:"#DD6B55",confirmButtonText:"添加",cancelButtonText:"暂不",closeOnConfirm:false,closeOnCancel:true},function(isConfirm){if(isConfirm){window.location.href="/qq/add.html"}else{return false;}});</script>';
            $this->assign('noqqart', $art);
        }
        $gonggao = db("gonggao")->field('*')->order('id desc')->limit(5)->cache(true)->select(); // 公告
        $this->assign('gonggao', $gonggao);

        $ads = db("ad")->field('*')->order('aid asc')->limit(5)->cache(true)->select();
        $this->assign('ads', $ads);
//        //积分排行榜
//        $jfrow = db("users")->field('jf,user')->order('jf desc')->limit(5)->select();
//        $this->assign('jfrow', $jfrow);
//        // 签到排行榜
//        $qdrow = db("users")->field('qd_lx,qd_max,user')->order('qd_lx desc')->limit(5)->select();
//        $this->assign('qdrow', $qdrow);
//        $qqrow = db("qqs")->field('qq,addtime')->where('iszan=2')->order('qid desc')->limit(6)->select();
//        $this->assign('qqrow', $qqrow);
        return $this->fetch();
    }

    /**
     * 登录
     */
    public function login()
    {
        include APP_PATH . 'txprotect.php';
        if (request()->isPost()) {
            if (!request()->isAjax()) {
                die();
            }
            $user = input('post.user', '', 'get_safe_str');
            $pwd = input('post.pwd') ? input('post.pwd') : die('请填写密码');
            $pwd = $this->getMd5Pwd($pwd);
            if (!$row = db("users")->field('user')->where("user='$user'")->find()) {
                $data = [
                    'title' => '登录失败',
                    'msg' => '用户名不存在！',
                    'type' => 'warning',
                ]; // 用户名不存在
            } elseif (!$row = db("users")->field('*')->where("user='$user' and pwd='$pwd'")->find()) {
                $data = [
                    'title' => '登录失败',
                    'msg' => '用户名的密码不正确！',
                    'type' => 'warning',
                ]; // 用户名的密码不正确
            } else {
                if ($row['active'] == 1) {
                    $data = [
                        'title' => '登录限制',
                        'msg' => '该账号存在违规操作，已被限制登录！',
                        'type' => 'error',
                    ]; // 账号封禁
                    return [
                        'code' => '2',
                        'data' => $data,
                    ];
                } else {
                    $newsid = $this->getSid();
                    $data['sid'] = $newsid;
                    $data['lastip'] = request()->ip(0, true);
                    $data['lasttime'] = date("Y-m-d H:i:s");
                    db("users")->where("uid='{$row['uid']}'")->update($data);
                    cookie('user_sid', $newsid, 3600 * 24 * 2);
                    $user_login = [
                        'user' => $user,
                        'pwd' => input('post.pwd'),
                    ];
                    cookie('user_login', json_encode($user_login), 3600 * 24 * 7);
                    if (session('referurl')) { // 来源登录成功，并跳转
                        $url = session('referurl');
                        session('referurl', null);
                    } else {
                        $url = 'user.html';
                    }
                    $data = [
                        'title' => '登录成功',
                        'msg' => '跳转中,请稍后...',
                        'type' => 'success',
                        'url' => $url,
                        'timer' => '500',
                    ];
                }
            }
            return [
                'code' => '1',
                'data' => $data,
            ];
        } else {
            // if ($this->user['uid']) {
            // $this->redirect('index/user');
            // }
            return $this->fetch();
        }
    }

    /**
     * 注册
     */
    public function reg()
    {
        include APP_PATH . 'txprotect.php';
        if (request()->isPost()) {
            $user = input('post.user') ? input('post.user') : die('请填写用户名');
            $pwd = input('post.pwd') ? input('post.pwd') : die('请填写密码');
            $qq = is_numeric(input('post.qq')) ? input('post.qq') : die('QQ填写错误');
            $userIp = request()->ip(0, true);
            if (!session('lock') || session('lock') != input('post.k')) {
                $data = [
                    'title' => '验证错误',
                    'msg' => '请拖动滑块进行验证后再提交注册！',
                    'type' => 'warning',
                ];
            } elseif (db("users")->field('uid')->where("qq='$qq'")->find()) {
                $data = [
                    'title' => '注册失败',
                    'msg' => '此QQ已经绑定其他帐号！',
                    'type' => 'warning',
                ];
            } elseif (db("users")->field('uid')->where("user='$user'")->find()) {
                $data = [
                    'title' => '注册失败',
                    'msg' => '用户名已存在，请重新填写！',
                    'type' => 'warning',
                ];
            } elseif (strlen($pwd) < 5) {
                $data = [
                    'title' => '注册失败',
                    'msg' => '密码过短，请重新填写！',
                    'type' => 'warning',
                ];
            } elseif ($this->blackList($user) > 0) {
                $data = [
                    'title' => '注册失败',
                    'msg' => '用户名包含敏感词汇，请修改后提交！',
                    'type' => 'warning',
                ];
            } else {
                session('captcha_code', null);
                $now = date("Y-m-d H:i:s");
                $regdata['user'] = $user;
                $regdata['pwd'] = $this->getMd5Pwd($pwd);
                $regdata['sid'] = $this->getSid();
                $regdata['peie'] = config('regpeie');
                $regdata['rmb'] = config('regrmb');
                $regdata['qq'] = $qq;
                $regdata['city'] = get_ip_city($userIp);
                $regdata['regip'] = $userIp;
                $regdata['lastip'] = $userIp;
                $regdata['regtime'] = $now;
                $regdata['lasttime'] = $now;
                $regdata['webid'] = config('fenzhan')['id'] ? config('fenzhan')['id'] : 0; // 0为主站
                if ($uid = db("users")->insertGetId($regdata)) {
                    cookie('user_sid', $regdata['sid']);
                    $data = [
                        'title' => '注册成功',
                        'msg' => '欢迎使用QQ秒赞网！',
                        'type' => 'success',
                        'url' => 'user.html',
                        'timer' => '5000',
                    ];
                } else {
                    $data = [
                        'title' => '注册失败',
                        'msg' => '创建数据失败，请稍后刷新页面重试！',
                        'type' => 'error',
                    ];
                }
            }
            session('lock', Null);
            return [
                'code' => '1',
                'data' => $data,
            ];
        } else {
            return $this->fetch();
        }
    }

    /**
     * 通过邮件进行设置新的密码
     */
    public function newPwd()
    {
        $now = date("Y-m-d H:i:s");
        $code = input('param.code', '', 'get_safe_str');
        if (!$row = db("mailcode")->field('*')->where("code='{$code}' and kind=1 and endtime>'{$now}'")->find()) {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location:/");
            die;
        } elseif (!$user = db("users")->field('uid')->where("uid='{$row['uid']}'")->find()) {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location:/");
            die;
        }
        if (input('post.do') == 'setpwd') {
            $pwd = input('post.pwd', '', 'get_safe_str');
            $repwd = input('post.repwd', '', 'get_safe_str');
            if (strlen($pwd) < 5) {
                get_exit("密码需要5位以上！");
            } elseif ($pwd != $repwd) {
                get_exit("两次密码不一致！");
            }
            $pwd = $this->getMd5Pwd($pwd);
            db("users")->where("uid='{$user['uid']}'")->setField('pwd', $pwd);
            db("mailcode")->where("uid='{$user['uid']}'")->setField('kind', 2);
            get_exit("密码设置成功，马上登录！", url('index/login'));
        }
        $this->assign('code', $code);
        return $this->fetch();
    }

    /**
     * 找回密码和用户名
     */
    public function findInfo()
    {
        get_exit(0, '/index/findinfoqr.html');
        if (request()->isPost()) {
            $qq = is_numeric(input('post.qq')) ? input('post.qq') : exit('QQ填写错误[findUser]');
            if (input("post.do") == 'findpwd') {
                if (strtolower(session('captcha_code')) != strtolower(input('post.code'))) {
                    $msg = [
                        '1',
                        '验证码错误',
                        '请重新输入进行验证',
                        'warning',
                    ];
                } elseif (!$user = db("users")->field('*')->where("qq='$qq'")->find()) {
                    $msg = [
                        '1',
                        '找回失败',
                        '输入的绑定qq号不存在!',
                        'warning',
                    ];
                } else {
                    session('captcha_code', null);
                    $code = $this->getSid();
                    $data['kind'] = 1;
                    $data['uid'] = $user['uid'];
                    $data['mail'] = $user['qq'] . '@qq.com';
                    $data['code'] = $code;
                    $data['addtime'] = date("Y-m-d H:i:s");
                    $data['endtime'] = date("Y-m-d H:i:s", strtotime("+1 day")); // 过期时间
                    db("mailcode")->insert($data);
                    $this->sendmail($user['qq'] . '@qq.com', $user['user'], $code);
                    $msg = [
                        '0',
                        '找回成功',
                        "重置密码的邮件已经发送至{$data['mail']}，请到邮箱中进行重设密码！",
                        'success',
                    ];
                }
            } else {
                /*这里是找回用户名*/
                if (!$user = db("users")->field('user')->where("qq='$qq'")->find()) {
                    $msg = [
                        '1',
                        '输入的绑定qq号不存在!',
                        '',
                        'warning',
                    ];
                } else {
                    $msg = [
                        '0',
                        '找回成功',
                        "您的用户名为：{$user['user']}",
                        'success',
                    ];
                }
            }
            return json($msg);
        }
        return $this->fetch();
    }

    /**
     * 找回用户信息，Qr模式
     */
    public function findInfoQr()
    {
        return $this->fetch();
    }

    /**
     * 网站用户的每日签到
     */
    public function qd()
    {
        $this->islogin();
        if (input("post.do") == 'qd') {
            $date = date("Y-m-d");
            $ydate = date("Y-m-d", strtotime("- 1 days", time()));
            $now = date("Y-m-d H:i:s");
            $uin = is_numeric(input("post.uin")) ? input("post.uin") : '0';
            if (!$uin) {
                get_exit("请先选择要用于发布签到信息的QQ！");
            } elseif (db("qds")->field('*')->where("uid='" . $this->user['uid'] . "' and adddate='$date'")->find()) {
//                get_exit("你今天已经签到过！");
                $this->assign('msg', "你今天已经签到过！");
            } else {
                if (!$qq = db("qqs")->field('*')->where("uid='" . $this->user['uid'] . "' and qq='$uin'")->find()) {
                    get_exit("此QQ不存在！");
                } else {
                    $qzone = new \app\model\Qzone($qq['qq'], $qq['sid'], $qq['skey'], $qq['pskey']);
                    // 随机图片
                    $pic = urlencode(config('qd_shuopic'));
                    if ($pic == 1) {
                        $row = file('cron/data/pic.txt');
                        shuffle($row);
                        $pic = $row[0];
                        $type = 0;
                    } else {
                        $type = stripos('z' . $pic, 'http') ? 0 : 1;
                    }
                    $pic = trim($pic);

                    if (!$qzone->shuo(0, config('qd_shuoshuo'), $pic, $type)) {
                        // $this->assign('alert',get_exit("签到失败,发布说说失败！",1));
                        // $this->assign('msg',"签到失败，原因：".$qzone->error[0]);
                        $this->assign('msg', "签到失败，请更新QQ{$uin}后再来签到！");
                    } else {
                        if ($row = db("qds")->field('*')->where("uid='" . $this->user['uid'] . "' and adddate='$ydate'")->find()) { //昨天是否签到，true为签到过
                            if (getMonthNum($ydate, $date)) { //到达新月份连续签到值初始化1
                                $data['lx'] = 1;
                            } else {
                                $data['lx'] = $row['lx'] + 1;
                            }
                            $data['uid'] = $this->user['uid'];
                            $data['addtime'] = $now;
                            $data['adddate'] = $date;
                        } else {
                            $data['uid'] = $this->user['uid'];
                            $data['addtime'] = $now;
                            $data['lx'] = 1;
                            $data['adddate'] = $date;
                        }
                        $lx = $data['lx'];
                        if (db("qds")->insert($data)) {
                            /*判断连续签到天数，修改每天定额积分（后台控制）*/
                            $qdarr = qdrule();
                            if (isset($qdarr[$lx])) {
                                $jf = $qdarr[$lx];
                            } elseif ($lx > $qdarr['max']) {
                                $max = $qdarr['max'];
                                $jf = $qdarr[$max];
                            } else {
                                $jf = 0;
                            }
                            /*判断是否达到指定连续签到次数，额外一次奖励（下方代码手动控制）*/
                            if ($lx == 7) {
                                $jf = 3;
                            } elseif ($lx == 15) {
                                $jf = 5;
                            } elseif ($lx == 30) {
                                $jf = 10;
                            }
                            $udata['jf'] = $this->user['jf'] + $jf;
                            if (config('qd_getvip')) { // 判断签到是否增送VIP
                                $num = get_count('qds', "adddate='$date'", 'id');
                                $pm = $num;
                                if (!config('qd_num') || $num <= config('qd_num')) {
                                    if (get_isvip($this->user['vip'], $this->user['vipend'])) {
                                        $ydate = date("Y-m-d", strtotime("+ 1 days", strtotime($this->user['vipend'])));
                                    } else {
                                        $udata['vip'] = 4;
                                        $udata['vipstart'] = $date;
                                        $ydate = date("Y-m-d", strtotime("+ 1 days", time()));
                                    }
                                    $udata['vipend'] = $ydate;
                                    // $this->assign('alert', get_exit("签到成功,你已连续签到{$data['lx']}天！获得{$jf}积分！你是第{$pm}个签到的，获得一天VIP!", 1));
                                    $this->assign('msg', "签到成功,你已连续签到{$data['lx']}天！获得{$jf}积分！你是第{$pm}个签到的，获得一天VIP！");
                                } else {
                                    // $this->assign('alert',get_exit("签到成功,你已连续签到{$data['lx']}天！获得{$jf}积分！由于你是第{$pm}个签到的人，没有获得VIP奖励，请明天早点来!",1));
                                    $this->assign('msg', "签到成功,你已连续签到{$data['lx']}天！获得{$jf}积分！由于你是第{$pm}个签到的，没有获得VIP奖励，明天早点来吧！");
                                }
                            } else {
                                $this->assign('alert', get_exit("签到成功,你已连续签到{$data['lx']}天！获得{$jf}积分！", 1));
                            }
                            $udata['qd_lx'] = $lx; // 保存连续签到天数到Users表
                            $udata['qd_max'] = $this->user['qd_max'] + 1; // Users表的总签到天数自增1天
                            db("users")->where("uid='" . $this->user['uid'] . "'")->update($udata);
                        } else {
                            $this->assign('alert', get_exit("签到失败,请稍后重试！", 1));
                        }
                    }
                }
            }
        }
        //已签到记录，多表查询10条
        $rows = \think\Db::view('qds', '*')
            ->view('users', 'user', 'users.uid=qds.uid')
            ->order('id desc')->limit('10')->select();
        if ($rows) {
            $this->assign('todaylist', $rows);
        }
        return $this->fetch();
    }

    /**
     * 邀请好友页面
     */
    public function invite()
    {
        include APP_PATH . 'txprotect.php';
        $uid = input('param.uid', '', 'get_safe_str');
        if (!$uid) {
            header("Location:/");
            exit();
        }
        if (!$name = db("users")->field('user,uid')->where("uid={$uid}")->find()) {
            header("Location:/");
            exit();
        }
        if (input("post.do") == 'reg') {
            // get_exit("活动暂未开放");

            $uid = input('post.uid', '', 'get_safe_str'); // 邀请人的UID
            $user = input('post.user', '', 'get_safe_str');
            $pwd = input('post.pwd', '', 'get_safe_str');
            $qq = input('post.qq', '', 'get_safe_str');
            $userip = request()->ip(0, true);
            if (!$_POST['code'] || strtolower(session('captcha_code')) != strtolower($_POST['code'])) {
                get_exit("验证码错误!");
            } elseif (db("reg")->field('id')->where("regip='$userip'")->find()) {
                get_exit("您的IP已经注册过了，不能再参加活动!");
            } elseif (db("users")->field('uid')->where("qq='$qq'")->find()) {
                get_exit("此QQ已经注册过!");
            } elseif (db("users")->field('uid')->where("user='$user'")->find()) {
                get_exit("用户名已存在!");
            } elseif (strlen($pwd) < 5) {
                get_exit("密码太简单啦!");
            } else {
                session('captcha_code', md5(rand(100, 500) . time()));
                $now = date("Y-m-d H:i:s");
                $data['user'] = $user;
                $data['pwd'] = md5(md5($pwd) . md5('QQ454701103'));
                $data['sid'] = md5(uniqid() . rand(1, 1000));
                $data['peie'] = config('regpeie');
                $data['qq'] = $qq;
                $data['mail'] = $qq . '@qq.com';
                $data['city'] = get_ip_city($userip);
                $data['regip'] = $userip;
                $data['lastip'] = $userip;
                $data['regtime'] = $now;
                $data['lasttime'] = $now;
                /*开始添加VIP信息*/
                $data['vip'] = 4; // 体验级别
                $data['vipstart'] = date("Y-m-d");
                $data['vipend'] = date("Y-m-d", strtotime("+ 3 day"));
                if (db("users")->insert($data)) {
                    $row = db("users")->field('uid')->where("user='$user' and pwd='$data[pwd]'")->find(); // 查找刚注册的用户信息
                    $data1['uid'] = $uid;
                    $data1['reguid'] = $row['uid']; // 被邀请人UID
                    $data1['regip'] = $userip;
                    $data1['addtime'] = $now;
                    db("reg")->insert($data1); // 增加一条邀请记录
                    get_exit("注册成功，体验VIP已到账，返回登陆!", url('Index/login'));
                } else {
                    get_exit("注册失败！请重试!");
                }
            }
        }
        $this->assign('name', $name);
        return $this->fetch();
    }

    /**
     * 邀请好友活动查询页面
     */
    public function inviteInfo()
    {
        $this->islogin();
        $user = $this->user;
        $date = date("Y-m-d");
        if (input("post.do") == 'reg') {
            if ($user['vip'] > 0) { // 判断是否是VIP
                get_exit("VIP用户暂时无法参与，之后将陆续开放!");
            }
            $count = db("reg")->where("uid='$user[uid]' and addtime='$date'")->count('uid');
            if ($count > 4) {
                if ($user['vip'] > 0) { // 判断是否是VIP
                    $udata['vipend'] = date("Y-m-d", strtotime("+ 3 day", strtotime($user['vipend'])));
                } else {
                    $udata['vip'] = 4;
                    $udata['vipstart'] = date("Y-m-d");
                    $udata['vipend'] = date("Y-m-d", strtotime("+ 3 day"));
                }
                db("users")->where("uid={$user['uid']}")->update($udata);
                get_exit("恭喜本次成功获取到3天VIP时长！");
            } else {
                get_exit("今天的任务还没有达成哦！");
            }
        }
        $rows = db("reg")->field('reguid,addtime,regip')->where("uid={$user['uid']}")->order('id desc')->limit(10)->select();
        $this->assign('list', $rows);
        return $this->fetch();
    }

    /**
     * 注销登录
     */
    public function logout()
    {
        if ($this->user) {
            $newsid = $this->getSid();
            db("users")->where("uid='" . $this->user['uid'] . "'")->setField('sid', $newsid);
        }
        cookie('user_sid', null);
        get_exit(0, '/');
    }

    /**
     * 邮件发送
     * @param $to string 收件人邮箱地址
     * @param $user string 用户name名
     * @param $code string 找回密码的code随机码
     * @return string 返回发送详情
     */
    private function sendmail($to, $user, $code)
    {
        // 后台设置 mail_type=1为本地发送，2为sendCloud接口
        if (config('mail_type') == 1) {
            $title = '秒赞网密码找回邮件';
            $content = "{$user},您好！帮助你找回在&nbsp;" . config('web_name') . "&nbsp;的密码!<br>请点击下面的链接完成设置新密码！<br><a href='http://" . $_SERVER['SERVER_NAME'] . url('newpwd') . "?code={$code}'>http://" . $_SERVER['SERVER_NAME'] . url('newpwd') . "?code={$code}</a><br>(如果链接不能点击，请复制并粘贴到浏览器的地址栏，然后按回车键，该链接48小时内有效。)";
            Vendor('Mail');
            $mail = new \MySendMail();
            // 判断是否用SSL链接
            if (config('mail_port') == '465') {
                $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'), true);
            } else {
                $mail->setServer(config('mail_host'), config('mail_user'), config('mail_pass'), config('mail_port'));
            }
            $mail->setFrom(config('mail_user'), config('web_name'));
            $mail->setReceiver($to);
            $mail->setMail($title, $content);
            $result = $mail->sendMail();
        } else {
            $url = 'http://sendcloud.sohu.com/webapi/mail.send_template.json';
            $param = [
                'api_user' => config('sendcloud_apiuser'),
                'api_key' => config('sendcloud_apikey'),
                'from' => config('sendcloud_from'),
                'fromname' => config('web_name'),
                'substitution_vars' => "{\"to\": [\"{$to}\"],\"sub\":{\"%code%\": [\"{$code}\"],\"%user%\":[\"{$user}\"]}}",
                'subject' => config('web_name') . "密码找回邮件",
                'template_invoke_name' => config('sendcloud_tpl_pwd'),
            ];
            $options = [
                'http' => [
                    'method' => 'POST',
                    'content' => http_build_query($param),
                ],
            ];
            $context = stream_context_create($options);
            $result = @file_get_contents($url, false, $context);
        }
        return $result;
    }

    /**
     * 是否登录判断
     */
    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI']; //增加一个来源地址，方便登陆后回跳
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }

    /**
     * 生成唯一标识符
     * @return string
     */
    public function getSid()
    {
        return md5(uniqid(mt_rand(), true) . microtime());
    }

    /**
     * MD5用户密码
     * @param $pwd string 密码
     * @return string md5
     */
    public function getMd5Pwd($pwd)
    {
        return md5(md5($pwd) . md5('QQ454701103'));
    }

    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db("users")->field("*")->where("sid='$sid'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                // 已添加的QQ赋值到模板，方便base调用
                $qlist = db("qqs")->field('qid,qq,skeyzt')->where("uid='" . $this->user['uid'] . "'")->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
    }
}