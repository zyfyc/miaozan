<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
use think\Db;
class Fz extends Controller
{
    private $user;
    private $vhost;
    public function clear()
    {
        $type = input('route.type') ? input('route.type') : die('Err[1]');
        if ($type == 'nozan') {
            db('qqs')->where("webid='{$this->vhost['id']}' and zannet=0")->delete();
        } elseif ($type == 'free') {
            if ($rows = db('users')->field('uid')->where("webid='{$this->vhost['id']}' and vip=0")->order('uid desc')->select()) {
                foreach ($rows as $row) {
                    $uid = $row['uid'];
                    db('qqs')->where("uid='{$uid}'")->delete();
                }
            } else {
                get_exit('无免费QQ数据可清理');
            }
        } else {
            if ($rows = db('users')->field('uid')->where("webid='{$this->vhost['id']}' and vip=0")->order('uid desc')->select()) {
                foreach ($rows as $row) {
                    $uid = $row['uid'];
                    db('users')->where("uid='{$uid}'")->delete();
                    db('qqs')->where("uid='{$uid}'")->delete();
                }
            } else {
                get_exit('无免费用户数据可清理');
            }
        }
        get_exit('数据清理成功！');
    }
    public function help()
    {
        return $this->fetch();
    }
    public function autoPay()
    {
        $type = input('route.type');
        if ($type) {
            $do = '0';
        } else {
            $do = '1';
        }
        db('fenzhan')->where('uid=' . $this->user['uid'])->setField('pay_auto', $do);
        get_exit(0, '/fz/index.html');
    }
    public function index()
    {
        if (request()->isPost()) {
            $data = request()->except(array('/fz/index_html', 'id', 'uid', 'active', 'qqlimit', 'addtime', 'outtime'));
            db('fenzhan')->where("uid='{$this->user['uid']}'")->update($data);
            get_exit('修改成功！');
        }
        $fzqq = db('qqs')->where("webid='{$this->vhost['id']}'")->count('qid');
        $this->assign('fzqq', $fzqq);
        return $this->fetch();
    }
    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field('*')->where("sid='{$sid}'")->find()) {
                $fz = db('fenzhan')->field(true)->where("uid='{$user['uid']}'")->find();
                if (!$fz['id']) {
                    get_exit('你还没有购买分站！', url('index/user'));
                } else {
                    $this->user = $user;
                    $this->assign('user', $this->user);
                    $this->vhost = $fz;
                    $this->assign('vhost', $fz);
                }
            } else {
                get_exit('请登录后再进行操作！', url('index/login'));
            }
        } else {
            get_exit('请登录后再进行操作！', url('index/login'));
        }
    }
}