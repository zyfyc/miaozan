<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;

use think\Controller;
class Wechat extends Controller
{
    private $user;
    public function payPush($uid, $title)
    {
        vendor('WxTemple');
        $sendMes = new \sendMessage(config('wx_appid'), config('wx_secret'));
        $data = db('users')->field('wx_openid')->where("uid='{$uid}'")->find();
        $openid = $data['wx_openid'];
        if ($openid) {
            return $sendMes->sendPayMsg($openid, $title);
        } else {
            return false;
        }
    }
    public function guoqiPush($uid, $qq)
    {
        vendor('WxTemple');
        $openid = db('wechat')->field('openid')->where("uid='{$uid}'")->find();
        $openid = $openid['openid'];
        if ($openid) {
            $sendMes = new \sendMessage(config('wx_appid'), config('wx_secret'));
            return $sendMes->sendGuoqiMsg($openid, $qq);
        } else {
            return false;
        }
    }
    public function index()
    {
        $this->islogin();
        $ret = db('wechat')->field('openid')->where("uid='{$this->user['uid']}'")->find();
        if ($ret) {
            vendor('WxTemple');
            $wd = new \sendMessage(config('wx_appid'), config('wx_secret'));
            $token = $wd->accessToken;
            if ($this->isGuanzhu($token, $ret['openid'])) {
                $this->assign('code', 1);
            } else {
                $this->assign('code', 2);
            }
        } else {
            $this->assign('code', 2);
        }
        return $this->fetch();
    }
    public function gift()
    {
        $this->islogin();
        if ($this->isWeixinBrowser()) {
            $msg = $this->getFreeVip($this->user);
            return '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">' . $msg;
        } else {
            return '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">请在微信公众号中领取奖励！';
        }
    }
    private function getFreeVip($user)
    {
        if ($this->isOpenid($user['uid'])) {
            if (db('wechat')->field('id')->where('uid=\'' . $user['uid'] . '\' and isgz=0')->find()) {
                $data['isgz'] = 1;
                db('wechat')->where('uid=\'' . $user['uid'] . '\'')->update($data);
                if (get_isvip($user['vip'], $user['vipend'])) {
                    $udata['vipend'] = date('Y-m-d', strtotime('+ 15 day', strtotime($user['vipend'])));
                } else {
                    $udata['vip'] = 1;
                    $udata['vipstart'] = date('Y-m-d');
                    $udata['vipend'] = date('Y-m-d', strtotime('+ 15 day'));
                }
                db('users')->where('uid=\'' . $user['uid'] . '\'')->update($udata);
                $this->payPush($user['uid'], '秒赞会员10天体验');
                $msg = '领取成功，已增加10天VIP时长！';
            } else {
                $msg = '骚年你已经领取过了！((‵□′)) ';
            }
        } else {
            $msg = '请先绑定账号哦~';
        }
        return $msg;
    }
    private function isOpenid($uid)
    {
        $res = db('wechat')->field('id')->where("uid='{$uid}'")->find();
        if ($res) {
            return true;
        } else {
            return false;
        }
    }
    public function saveOpenid()
    {
        $this->islogin();
        if ($this->isOpenid($this->user['uid'])) {
            $this->assign('isopenid', 1);
        } else {
            if ($this->isWeixinBrowser()) {
                $openid = input('param.openid');
                if (isset($openid)) {
                    $find = db('wechat')->field('openid')->where("openid='{$openid}'")->find();
                    if ($find) {
                        die('您当前的微信已经绑定过其他账号，暂时无法重复绑定！');
                    }
                    $data = array('uid' => $this->user['uid'], 'openid' => $openid, 'addtime' => date('Y-m-d H:i:s'));
                    if (db('wechat')->insert($data)) {
                        $this->assign('isopenid', 1);
                    } else {
                        $this->assign('isopenid', 0);
                    }
                } else {
                    $oauthUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.config('wx_appid').'&redirect_uri='.config('wx_redirect_uri').'&response_type=code&scope=snsapi_userinfo&state=mz#wechat_redirect';
                    $this->redirect($oauthUrl, 302);
                    return true;
                }
            } else {
                $this->assign('isopenid', 0);
                $codeUrl = 'http://' . $_SERVER['HTTP_HOST'] . url('saveOpenid', 'sid=' . cookie('user_sid'));
                $this->assign('code_url', $codeUrl);
            }
        }
        return $this->fetch();
    }
    public function getOpenid()
    {
        $code = input('param.code');
        $weixin = file_get_contents('https://api.weixin.qq.com/sns/oauth2/access_token?appid='.config('wx_appid').'&secret='.config('wx_secret').'&code=' . $code . '&grant_type=authorization_code');
        $jsondecode = json_decode($weixin);
        $array = get_object_vars($jsondecode);
        $openid = @$array['openid'];
        $oauthUrl = url('saveOpenid', 'openid=' . $openid);
        $this->redirect($oauthUrl, 302);
    }
    private function isGuanzhu($token, $openid)
    {
        $subscribe_msg = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$token}&openid={$openid}";
        $subscribe_info = file_get_contents($subscribe_msg);
        $subscribe_info = json_decode($subscribe_info);
        if ($subscribe_info->subscribe) {
            return true;
        } else {
            return false;
        }
    }
    private function isWeixinBrowser()
    {
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
            return true;
        }
        return false;
    }
    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }
    public function __construct()
    {
        parent::__construct();
        if (input('param.sid')) {
            cookie('user_sid', input('param.sid'));
        }
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field('*')->where("sid='{$sid}'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                $qlist = db('qqs')->field('qid,qq,skeyzt')->where('uid=\'' . $this->user['uid'] . '\'')->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
    }
}