<?php
/**
 * Created by PhpStorm.
 * User: 宏昌家族<1666806078@qq.com>
 * Date: 2017/3/12
 * Time: 19:55
 */

namespace app\controller;


use think\Controller;

class Fzz extends Controller
{
    public function fzlist()
    {
        $fzs = db("fenzhan")->field(true)->where("kt_uid='" . $this->user['uid'] . "'")->select();
        $this->assign('fzs', $fzs);
        return $this->fetch();
    }

    public function fzset()
    {
        $fid = is_numeric(input("param.fid")) ? input("param.fid") : exit('非法操作！');
        if (!$row = db("fenzhan")->field('*')->where("id='$fid'")->where("kt_uid='" . $this->user['uid'] . "'")->find()) {
            $this->assign('alert', get_exit("分站不存在！", 1));
        } elseif (request()->isPost() && $fid) {
            $data = input('post.');
            //if ($_POST['active'] == 1) {//判断是否需要拉黑
            //    db('qqs')->where("webid='$fid'")->delete(); // 删除分站下所有qq
            //    db('users')->where("webid='$fid'")->delete(); // 删除分站下所有用户
            //}
            db("fenzhan")->where("id='$fid'")->update($data);
            $this->assign('alert', get_exit("保存成功！", 1));
        } elseif (input('route.type') == 'del') {
            db('fenzhan')->where("id='$fid'")->delete(); // 删除分站信息
            db('qqs')->where("webid='$fid'")->delete(); // 删除分站下所有qq
            db('users')->where("webid='$fid'")->delete(); // 删除分站下所有用户
            get_exit('删除成功！');
        }
        $this->assign('fz', $row);
        return $this->fetch();
    }

    public function userset()
    {
        $uid = is_numeric(input("param.uid")) ? input("param.uid") : exit('非法操作！');
        if (request()->isPost() && $uid) {
            if ($_POST['resetpwd']) {
                $_POST['pwd'] = '305dc2ef435361ad8cebedff0636076b';
            }
            if ($_POST['active'] == 1) {//判断是否需要拉黑
                db('qqs')->where("uid='$uid'")->delete(); // 删除名下所有qq
                db('chats')->where("uid='$uid'")->delete(); // 删除所有发言
                $_POST['sid'] = 'qq454701103'; // 修改cookie
            }
            unset($_POST['resetpwd']);
            db("users")->where("uid='$uid'")->update($_POST);
            $this->assign('alert', get_exit("保存成功！", 1));
        }
        if (!$row = db("users")->field('*')->where("uid='$uid'")->find()) {
            $this->assign('alert', get_exit("用户不存在！", 1));
        }
        $this->assign('user_res', $row);
        return $this->fetch();
    }

    public function dllist()
    {
        $uid = is_numeric($_REQUEST['uid']) ? $_REQUEST['uid'] : '0';
        $rmb = is_numeric($_REQUEST['rmb']) ? $_REQUEST['rmb'] : '0';
        if ($uid && !$row = db("users")->field('uid')->where("uid='$uid'")->find()) {
            $this->assign('alert', get_exit('用户不存在！', '1'));
            $uid = 0;
        }
        if (input("param.do") == 'del' && $uid) {
            db('users')->where("uid='$uid'")->setField('daili', '0');
        }
        if (input("post.do") == 'add' && $uid) {
            db('users')->where("uid='$uid'")->setField('daili', '1');
            $this->assign('alert', get_exit('成功添加UID:' . $uid . '用户为代理！', '1'));
        } elseif (input("post.do") == 'cz' && $uid && $rmb) {
            db('users')->where("uid='$uid'")->setInc('rmb', $rmb);
            $this->assign('alert', get_exit('成功为UID:' . $uid . '代理充值' . $rmb . '元！', '1'));
        } elseif (input("post.do") == 'kc' && $uid && $rmb) {
            db('users')->where("uid='$uid'")->setDec('rmb', $rmb);
            $this->assign('alert', get_exit('成功扣除UID:' . $uid . '代理' . $rmb . '元！', '1'));
        }
        $p = is_numeric(input("param.kid")) ? input("param.kid") : '1';
        $start = 10 * ($p - 1);
        $next = $p + 1;
        $limit = "$start,10";
        $count = db("users")->where("daili>0")->count('uid');
        $pages = ceil($count / 10);
        $rows = db("users")->field('*')->where("daili>0")->limit($limit)->order('uid desc')->select();
        if (($p - 1) > 0) {
            $start = $p - 1;
        } else {
            $start = 1;
        }
        if (($p + 5) < $pages) {
            $end = $p + 5;
        } else {
            $end = $pages;
        }
        $this->assign('end', $end);
        $this->assign('start', $start);
        $this->assign('page', $p);
        $this->assign('pages', $pages);
        $this->assign('count', $count);
        $this->assign('list', $rows);
        return $this->fetch();

    }

    public function fzadd()
    {
        if (request()->isPost()) {
            $uid = input('post.uid');
            if (input('post.outtime') < date("Y-m-d")) {
                get_exit("分站到期时间不能早于当前");
            } elseif (strlen(input('post.web_url')) < 3) {
                get_exit("绑定域名不合法");
            } elseif (!$row = db("users")->field('uid')->where("uid='$uid'")->find()) {
                get_exit("你所输入的UID不存在");
            }
            $data = input('post.');
            $data['pay_auto'] = 1;
            $data['kt_uid'] = $this->user['uid'];
            $data['price_1vip'] = config('price_1vip');
            $data['price_3vip'] = config('price_3vip');
            $data['price_6vip'] = config('price_6vip');
            $data['price_12vip'] = config('price_12vip');
            $data['price_1peie'] = config('price_1peie');
            $data['price_3peie'] = config('price_3peie');
            $data['price_5peie'] = config('price_5peie');
            $data['price_10peie'] = config('price_10peie');
            $data['addtime'] = date("Y-m-d");
            db('fenzhan')->insert($data);
            get_exit('添加分站成功');
        }
        return $this->fetch();
    }


    private function islogin()
    {
        if (!$this->user) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }

    public function __construct()
    {
        parent::__construct();
        $sid = cookie('user_sid');
        if (is_md5($sid)) {
            if ($user = db('users')->field(array('*'))->where("sid='{$sid}'")->find()) {
                $this->user = $user;
                $this->assign('user', $this->user);
                $qlist = db('qqs')->field('qid,qq,skeyzt')->where('uid=\'' . $this->user['uid'] . '\'')->order('qid desc')->select();
                $this->assign('qlist', $qlist);
            }
        } else {
            $this->assign('user', 0);
        }
        $this->islogin();

        if (!$this->user['is_fzz']) {
            $referurl = $_SERVER['REQUEST_URI'];
            session('referurl', $referurl);
            get_exit(0, url('index/login'));
        }
    }
}