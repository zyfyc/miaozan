<?php
/*应用配置*/
return [
    'app_debug'               => false,
    // 显示错误信息
    'show_error_msg'          => true,
    'app_multi_module'        => false,
    'qqmz_ver'                => '1010',
    'http_exception_template' => [
        // 定义404错误的重定向页面地址
        404 => APP_PATH . '404.html',
    ],
];