<?php
define('authcode','b3d26b1e3ebdfeb6c2ba6363562bcc6d');

?>