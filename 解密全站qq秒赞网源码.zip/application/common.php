<?php
$_SERVER['SERVER_NAME'] =$_SERVER['HTTP_HOST'] ='www.1666806078.cn';
error_reporting(E_ERROR | E_WARNING | E_PARSE);
require_once 'authcode.php';
require_once 'functions.php';