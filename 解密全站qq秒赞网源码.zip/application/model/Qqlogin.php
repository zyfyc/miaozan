<?php
namespace app\model;

class Qqlogin {
    public $json;

    public function __construct($uin, $pwd, $code = 0, $cap_cd=0, $sig = 0, $sess = 0) {
        $this->uin = $uin;
        $this->pwd = $pwd;
        $this->code = $code;
        $this->sig = $cap_cd;
		$this->sess = $sess;
        if ($code) {
            $this->dovc($sig);
        } else {
            $this->checkvc();
        }
    }

    public function login() {
        if (strpos('s' . $this->code, '!')) {
            $v1 = 0;
        } else {
            $v1 = 1;
        }
        $p = $this->getp();
        $url='http://ptlogin2.qq.com/login?u='.$this->uin.'&verifycode='.strtoupper($this->code).'&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$this->sig.'&p='.$p.'&pt_randsalt=0&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=2-10-'.time().'7584&js_ver=10178&js_type=1&pt_uistyle=40&aid=549000912&daid=5&pt_ttype=1';
        $ret = $this->get_curl($url, 0, 0, 0, 1);
        if (preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr)) {
            $r = explode("','", $arr[1]);
            if ($r[0] == 0) {
				if(strpos($r[2],'mibao_vry')){
					$this->json='{"code":-3,"msg":"请先到QQ安全中心关闭网页登录保护！"}';
					return false;
				}
                preg_match('/skey=@(.{9});/', $ret, $skey);
				preg_match('/superkey=(.*?);/',$ret,$superkey);
                $data = $this->get_curl($r[2], 0, 0, 0, 1);
                if ($data) {
                    preg_match("/p_skey=(.*?);/", $data, $matchs);
                    $pskey = $matchs[1];
                    preg_match('/sid=(.{46})/iU', $data, $sid);//新版sid
                }
                if ($skey[1] && $pskey) {
                    $this->json = '{"code":0,"uin":"' . $this->uin . '","sid":"' . $sid[1] . '","skey":"@' . $skey[1] . '","pskey":"' . $pskey . '","superkey":"' . $superkey[1] . '"}';
                } else {
                    $this->json = '{"code":-3,"msg":"请先关闭QQ登陆保护再来使用"}';
                }
            } elseif ($r[0] == 4) {
                $this->json = '{"code":-3,"msg":"验证码错误!"}';
                $this->checkvc();
            } elseif ($r[0] == 3) {
                $this->json = '{"code":-3,"msg":"密码错误，请重新输入！"}';
            } elseif ($r[0] == 19) {
                $this->json = '{"code":-3,"msg":"您的帐号暂时无法登录，请到 http://aq.qq.com/007 恢复正常使用！"}';
            } else {
                $this->json = '{"code":-3,"msg":"' . str_replace('"', '\'', $r[4]) . '"}';
            }
        } else {
            $this->json = '{"code":-3,"msg":"' . $ret . '"}';
        }
    }

    public function getp() {
        $pwd = htmlspecialchars_decode($this->pwd);
        $url = "http://encode.qqzzz.net/?uin=" . $this->uin . "&pwd=" . strtoupper(md5($pwd)) . "&vcode=" . strtoupper($this->code);
        $data = $this->get_curl($url);
        if ($data) {
            return $data;
        } else {
            exit("<script language='javascript'>alert('获取P值失败，请稍候重试！');history.go(-1);</script>");
        }
    }

    public function dovc($sig) {
        $url='http://captcha.qq.com/cap_union_new_verify';
		$post='aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$this->uin.'&color=&showtype=&lang=2052&cap_cd='.$this->sig.'&rnd=613819&rand=0.7449361890054536&sess='.$this->sess.'&subcapclass=0&vsig='.$sig.'&ans='.$this->code;
		$data=$this->get_curl($url,$post);
		$arr=json_decode($data,true);
		if(array_key_exists('errorCode',$arr) && $arr['errorCode']==0){
			$this->code = $arr['randstr'];
            $this->sig = $arr['ticket'];
            $this->login();
		}elseif($arr['errorCode']==50){
			$this->getvc($this->sig);
		}else{
			exit("<script language='javascript'>alert('验证失败，请重试。');history.go(-1);</script>");
		}
    }

    public function checkvc() {
        $url = 'http://check.ptlogin2.qq.com/check?regmaster=&pt_tea=1&pt_vcode=1&uin=' . $this->uin . '&appid=549000912&js_ver=10132&js_type=1&login_sig=&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&r=0.397176' . time();
        $data = $this->get_curl($url, 0, 1);
        if (preg_match("/ptui_checkVC\('(.*?)'\);/", $data, $arr)) {
            $r = explode("','", $arr[1]);
            if ($r[0] == 1) {
                $this->json = '{"code":-2,"sig":"' . $r[1] . '"}';
                $this->getvc($r[1]);
            } else {
                $this->code = $r[1];
                $this->sig = $r[3];
                $this->login();
            }
        } else {
            $this->json = '{"code":-3,"msg":"判断是否有验证码失败，请稍候重试！"}';
        }
    }

    public function getvc($cap_cd) {
		if(!$this->sess){
			$url='http://captcha.qq.com/cap_union_new_show?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$this->uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999);
			$data=$this->get_curl($url);
			if(preg_match("/O=\"(.*?)\"/", $data, $match1) && preg_match("/z=\"(.*?)\"/", $data, $match2)){
				$this->json='{"code":-1,"cap_cd":"'.$cap_cd.'","sig":"'.$match1[1].'","sess":"'.$match2[1].'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}else{
			$url='http://captcha.qq.com/cap_union_new_getsig';
			$post='aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$this->uin.'&color=&showtype=&cap_cd='.$sig.'&rnd=634076&rand=0.37335288'.time().'&sess='.$this->sess;
			$data=$this->get_curl($url,$post);
			$arr=json_decode($data,true);
			if($arr['vsig']){
				$this->json='{"code":-1,"cap_cd":"'.$cap_cd.'","sig":"'.$arr['vsig'].'","sess":"'.$this->sess.'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}
    }

	public function getvcpic($uin,$cap_cd,$sig,$sess) {
        $url='http://captcha.qq.com/cap_union_new_getcapbysig?aid=549000912&captype=&protocol=http&clientype=1&disturblevel=&apptype=2&noheader=0&uid='.$uin.'&color=&showtype=&lang=2052&cap_cd='.$cap_cd.'&rnd='.rand(100000,999999).'&rand=0.02398118'.time().'&sess='.$sess.'&vsig='.$sig.'&ischartype=1';
		return $this->get_curl($url);
    }

    private function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HEADER, TRUE);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        }
        if ($referer) {
            if ($referer == 1) {
                curl_setopt($ch, CURLOPT_REFERER, "http://m.qzone.com/infocenter?g_f=");
            } else {
                curl_setopt($ch, CURLOPT_REFERER, $referer);
            }
        }
        if ($ua) {
            curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        } else {
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36');
        }
        if ($nobaody) {
            curl_setopt($ch, CURLOPT_NOBODY, 1); // 主要头部
        }
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }
}