<?php

function load_webconfig()
{
    $config = array();
    if ($rows = db('webconfigs')->field(true)->cache(false)->select()) {
        foreach ($rows as $row) {
            $config[$row['vkey']] = $row['value'];
        }
    }
    config($config);
}
load_webconfig();
$domain = $_SERVER['HTTP_HOST'];
if ($domain != config('web_domain')) {
    $res = db('fenzhan')->field('addtime', true)->where("web_url='{$domain}'")->find();
    if ($res['active'] == 0 && $res['outtime'] > date('Y-m-d')) {
        $fz['fenzhan'] = $res;
        config($fz);
    } elseif ($res['active'] == 1) {
        get_exit('该分站已被系统封禁');
    } elseif ($res['outtime'] && $res['outtime'] <= date('Y-m-d')) {
        get_exit('该分站已到期，无法继续访问！请分站管理员及时续费！');
    }
    unset($res);
}