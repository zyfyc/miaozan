<?php
class qq_login{
	public function login_sig(){
		$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=手机QQ空间&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
		$ret = $this->get_curl($url,0,1,0,1);
		preg_match('/pt_login_sig=(.*?);/',$ret,$match);
		return $match[1];
	}
	public function dovc($uin,$sig,$ans){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'QQ不能为空');
		if(empty($sig))return array('saveOK'=>-1,'msg'=>'sig不能为空');
		if(empty($ans))return array('saveOK'=>-1,'msg'=>'验证码不能为空');
		$url='http://captcha.qq.com/cap_union_verify?aid=549000912&uin='.$uin.'&captype=8&ans='.$ans.'&sig='.$sig.'&0.960725'.time();
		$data=$this->get_curl($url);
		if(preg_match("/cap\_InnerCBVerify\((.*?)\);/", $data, $json)){
			$json=str_replace(array('{',':',','),array('{"','":',',"'),$json[1]);
			$arr=json_decode($json,true);
			return $arr;
		}else{
			return array('rcode'=>0,'errmsg'=>'验证失败，请重试。');
		}
	}
	public function getvcpic($uin,$sig){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'QQ不能为空');
		if(empty($sig))return array('saveOK'=>-1,'msg'=>'sig不能为空');
		$url='http://captcha.qq.com/getimgbysig?aid=549000912&uin='.$uin.'&sig='.$sig;
		return $this->get_curl($url);
	}
	public function qqlogin($uin,$pwd,$p,$vcode,$pt_verifysession){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'QQ不能为空');
		if(empty($pwd))return array('saveOK'=>-1,'msg'=>'pwd不能为空');
		if(empty($p))return array('saveOK'=>-1,'msg'=>'密码不能为空');
		if(empty($vcode))return array('saveOK'=>-1,'msg'=>'验证码不能为空');
		if(empty($pt_verifysession))return array('saveOK'=>-1,'msg'=>'pt_verifysession不能为空');
		if(strpos('s'.$vcode,'!')){
			$v1=0;
		}else{
			$v1=1;
		}
		$url='http://ptlogin2.qq.com/login?u='.$uin.'&verifycode='.strtoupper($vcode).'&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$pt_verifysession.'&p='.$p.'&pt_randsalt=0&u1=http%3A%2F%2Fsqq2.3g.qq.com%2Fhtml5%2Fsqq2vip%2Findex.jsp&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=2-10-'.time().'7584&js_ver=10133&js_type=1&login_sig='.$this->login_sig().'&pt_uistyle=32&aid=549000912&pt_ttype=1&daid=5&pt_qzone_sig=0';
		$ret = $this->get_curl($url,0,0,0,1);
		if(preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr)){
			$r=explode("','",str_replace("', '","','",$arr[1]));
			if($r[0]==0){
				if(strpos($r[2],'mibao_vry'))
					return array('saveOK'=>-3,'msg'=>'请先到QQ安全中心关闭网页登录保护！');
				preg_match('/skey=@(.{9});/',$ret,$skey);
				preg_match('/superkey=(.*?);/',$ret,$superkey);
				$data=$this->get_curl($r[2],0,0,0,1);
				if($data) {
					preg_match("/p_skey=(.*?);/", $data, $matchs);
					$pskey = $matchs[1];
					preg_match("/Location: (.*?)\r\n/iU", $data, $matchs);
					$sid=explode('sid=',$matchs[1]);
					$sid=$sid[1];
				}
				if($skey[1] && $pskey){
					return array('saveOK'=>0,'uin'=>$uin,'sid'=>$sid,'skey'=>'@'.$skey[1],'pskey'=>$pskey,'superkey'=>$superkey[1]);
				}else{
					if(!$pskey)
						return array('saveOK'=>-3,'msg'=>'登录成功，获取P_skey失败！'.$r[2]);
					elseif(!$sid)
						return array('saveOK'=>-3,'msg'=>'登录成功，获取SID失败！');
				}
			}elseif($r[0]==4){
				return array('saveOK'=>4,'msg'=>'验证码错误');
			}elseif($r[0]==3){
				return array('saveOK'=>3,'msg'=>'密码错误');
			}elseif($r[0]==19){
				return array('saveOK'=>19,'uin'=>$uin,'msg'=>'您的帐号暂时无法登录，请到 http://aq.qq.com/007 恢复正常使用');
			}else{
				return array('saveOK'=>-6,'msg'=>str_replace('"','\'',$r[4]));
			}
		}else{
			return array('saveOK'=>-2,'msg'=>$ret);
		}
	}
	public function getvc($uin,$sig){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'请先输入QQ号码');
		if(empty($sig))return array('saveOK'=>-1,'msg'=>'SIG不能为空');
		if(!preg_match("/^[1-9][0-9]{4,11}$/",$uin)) exit('{"saveOK":-2,"msg":"QQ号码不正确"}');
		if(strlen($sig)==56){
			$url='http://captcha.qq.com/cap_union_show?captype=3&aid=549000912&uin='.$uin.'&cap_cd='.$sig.'&v=0.0672220'.time();
			$data=$this->get_curl($url);
			if(preg_match("/g\_click\_cap\_sig=\"(.*?)\"/", $data, $arr)){
				return array('saveOK'=>0,'vc'=>$arr[1]);
			}else{
				return array('saveOK'=>-3,'msg'=>'获取验证码失败');
			}
		}else{
			$url='http://captcha.qq.com/getQueSig?aid=549000912&uin='.$uin.'&captype=8&sig='.$sig.'&0.819966'.time();
			$data=$this->get_curl($url);
			if(preg_match("/cap_getCapBySig\(\"(.*?)\"\);/", $data, $arr)){
				return array('saveOK'=>0,'vc'=>$arr[1]);
			}else{
				return array('saveOK'=>-3,'msg'=>'获取验证码失败');
			}
		}
	}
	public function checkvc($uin){
		if(empty($uin))return array('saveOK'=>-1,'msg'=>'请先输入QQ号码');
		if(!preg_match("/^[1-9][0-9]{4,13}$/",$uin)) exit('{"saveOK":-2,"msg":"QQ号码不正确"}');
		$url='http://check.ptlogin2.qq.com/check?regmaster=&pt_tea=1&pt_vcode=1&uin='.$uin.'&appid=549000912&js_ver=10132&js_type=1&login_sig=&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&r=0.397176'.time();
		$data=$this->get_curl($url);
		if(preg_match("/ptui_checkVC\('(.*?)'\);/", $data, $arr)){
			$r=explode("','",$arr[1]);
			if($r[0]==0){
				return array('saveOK'=>0,'uin'=>$uin,'vcode'=>$r[1],'pt_verifysession'=>$r[3]);
			}else{
				return array('saveOK'=>1,'uin'=>$uin,'sig'=>$r[1]);
			}
		}else{
			return array('saveOK'=>-3,'msg'=>'获取验证码失败');
		}
	}
	private function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			curl_setopt($ch, CURLOPT_REFERER, "http://ptlogin2.qq.com/");
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);

		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
}