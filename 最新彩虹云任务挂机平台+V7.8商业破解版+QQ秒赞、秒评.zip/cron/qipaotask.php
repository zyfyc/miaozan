<?php
@chdir(dirname(preg_replace('@\\(.*\\(.*$@', '', __FILE__)));
include_once "../includes/cron.inc.php";
$infoid = 403;
$selfname = 'cron/qipaotask.php';
if (isset($_GET['multi'])) {
    $start = intval($_GET['start']);
    $num = intval($_GET['num']);
    $rs = $DB->query("select * from " . DBQZ . "_qqjob where type='qipao' and zt=0 and fail=0 order by nexttime asc limit {$start},{$num}");
} elseif ($conf['runmodol'] == 0) {
    $nump = $DB->count("select count(*) from " . DBQZ . "_qqjob WHERE type='qipao' and zt=0 and fail=0");
    $xz = ceil($nump / $size);
    if ($xz > 1) {
        for ($i = 0; $i <= $xz; $i++) {
            $start = $i * $size;
            curl_run($siteurl . $selfname . '?key=' . $_GET['key'] . '&multi=on&start=' . $start . '&num=' . $size);
        }
        exit("Successful opening of {$xz} threads!");
    } else {
        $rs = $DB->query("select * from " . DBQZ . "_qqjob where type='qipao' and zt=0 and fail=0 order by nexttime asc");
    }
} else {
    $nump = $DB->count("select count(*) from " . DBQZ . "_qqjob WHERE type='qipao' and zt=0 and fail=0");
    $xz = curl_run($nump / $size);
    $shu = $DB->get_row("SELECT * FROM " . DBQZ . "_info WHERE sysid='{$infoid}' limit 1");
    $shu = $shu['times'];
    $up_shu = $shu + 1;
    if ($shu >= $xz) {
        $DB->query("update " . DBQZ . "_info set times='1' where sysid='{$infoid}'");
        $shu = 0;
    } else {
        $DB->query("update " . DBQZ . "_info set times='" . $up_shu . "' where sysid='{$infoid}'");
    }
    $shu = $shu * $size;
    $rs = $DB->query("select * from " . DBQZ . "_qqjob where type='qipao' and zt=0 and fail=0 order by nexttime asc limit {$shu},{$size}");
}
while ($row = $DB->fetch($rs)) {
    $id = $row['jobid'];
    $qqjob = qqjob_decode($row['qq'], $row['type'], $row['method'], $row['data']);
    if ($qqjob['status'] == 'no') {
        continue;
    }
    $url = $qqjob['url'] . '&runkey=' . md5(RUN_KEY) . '&backurl=' . urlencode($siteurl);
    $curl = curl_init();
    $urlarr = parse_url($url);
    if ($conf['localcron'] == 1 && $urlarr['host'] == $_SERVER['HTTP_HOST']) {
        $url = str_replace('http://' . $_SERVER['HTTP_HOST'] . '/', 'http://127.0.0.1:80/', $url);
        $url = str_replace('https://' . $_SERVER['HTTP_HOST'] . '/', 'https://127.0.0.1:443/', $url);
        $url .= '&localcron=1';
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Host: ' . $_SERVER['HTTP_HOST']));
    }
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($curl, CURLOPT_TIMEOUT, 1);
    curl_setopt($curl, CURLOPT_NOBODY, 1);
    curl_setopt($curl, CURLOPT_NOSIGNAL, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_exec($curl);
    curl_close($curl);
    $nexttime = $time + 10;
    $DB->query("update `" . DBQZ . "_qqjob` set `times`=`times`+1,`lasttime`='{$time}',`nexttime`='{$nexttime}' where `jobid`='{$id}'");
}
$DB->query("update `" . DBQZ . "_info` set `last`='{$date}' where sysid='{$infoid}'");
$DB->query("update `" . DBQZ . "_info` set `times`=`times`+1,`last`='{$date}' where sysid='0'");
$DB->close();
echo "<head><title>success in run</title></head>";
echo $date;