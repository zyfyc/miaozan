<?php
$infoid = 205;
@chdir(dirname(preg_replace('@\\(.*\\(.*$@', '', __FILE__)));
include_once "../includes/cron.inc.php";
require ROOT . "includes/chaoren.class.php";
require ROOT . "qq/getsid/login.class.php";
$szie = 3;
$result = $DB->query("select * from `" . DBQZ . "_qq` where status='0' or status2='0' limit {$szie}");
while ($row = $DB->fetch($result)) {
    $uin = $row['qq'];
    $pwd = authcode($row['pw'], 'DECODE', SYS_KEY);
    $sql = '';
    $login = new qq_login();
    $check = $login->checkvc($uin);
    if ($check['saveOK'] == 0) {
        $vcode = $check['vcode'];
        $pt_verifysession = $check['pt_verifysession'];
    } else {
        $myrow = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE userid='{$row['uid']}' limit 1");
        if ($conf['autoyzm'] == 1 && isvip($myrow['vip'], $myrow['vipdate']) || $conf['autoyzm'] == 2) {
            $chaoren = new Chaorendama($conf['dama_user'], $conf['dama_pass']);
            $array = $login->getvc($uin, $check['sig']);
            if ($array['saveOK'] == 0) {
                $bin = $login->getvcpic($uin, $array['vc']);
                $dama_arr = $chaoren->recv_byte(bin2hex($bin));
                $array = $login->dovc($uin, $array['vc'], $dama_arr['result']);
                if ($array['rcode'] == 0) {
                    $vcode = $array['randstr'];
                    $pt_verifysession = $array['sig'];
                } elseif ($array['rcode'] == 50) {
                    $chaoren->report_err($dama_arr['imgId']);
                    echo $uin . ' Dama Error!<br/>';
                }
            } else {
                echo $uin . ' GetVC Error!<br/>';
            }
        } else {
            $DB->query("UPDATE " . DBQZ . "_qq SET status='4',status2='4' WHERE qq='" . $row['qq'] . "'");
            echo $uin . ' Need Code!<br/>';
            if (!empty($myrow['email']) && $myrow['mail_on'] == 1) {
                send_mail_qqgx($myrow['email'], $uin);
            }
        }
    }
    if (isset($vcode)) {
        $p = get_curl('http://encode.qqzzz.net/?uin=' . $uin . '&pwd=' . strtoupper(md5($pwd)) . '&vcode=' . strtoupper($vcode));
        if ($p == 'error' || $p == '') {
            exit($uin . ' getp failed!<br/>');
        }
        $arr = $login->qqlogin($uin, $pwd, $p, $vcode, $pt_verifysession);
        if (is_array($arr) && $arr['saveOK'] == 0) {
            $sid = $arr['sid'];
            $skey = $arr['skey'];
            $pskey = $arr['pskey'];
            $superkey = $arr['superkey'];
            $DB->query("UPDATE " . DBQZ . "_qq SET sid='{$sid}',skey='{$skey}',pskey='{$pskey}',superkey='{$superkey}',status='1',status2='1',`time`='{$date}' WHERE qq='" . $uin . "'");
            echo $uin . ' Update Success!<br/>';
        } elseif ($arr['saveOK'] == 3) {
            $DB->query("UPDATE " . DBQZ . "_qq SET status='5',status2='5' WHERE qq='" . $row['qq'] . "'");
            $DB->query("UPDATE " . DBQZ . "_qqjob SET fail='1' WHERE qq='" . $row['qq'] . "'");
            $myrow = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE userid='{$row['uid']}' limit 1");
            if (!empty($myrow['email']) && $myrow['mail_on'] == 1) {
                send_mail_qqgx($myrow['email'], $uin);
            }
            echo $uin . ' Invaid Password!<br/>';
        } else {
            $DB->query("UPDATE " . DBQZ . "_qq SET status='5',status2='5' WHERE qq='" . $row['qq'] . "'");
            $DB->query("UPDATE " . DBQZ . "_qqjob SET fail='1' WHERE qq='" . $row['qq'] . "'");
            echo $uin . ' Update failed!<br/>';
            $myrow = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE userid='{$row['uid']}' limit 1");
            if (!empty($myrow['email']) && $myrow['mail_on'] == 1) {
                send_mail_qqgx($myrow['email'], $uin);
            }
        }
        unset($vcode);
        unset($pt_verifysession);
    }
}
$DB->query("update `" . DBQZ . "_info` set `last`='{$date}' where sysid='{$infoid}'");
$DB->query("update `" . DBQZ . "_info` set `times`=`times`+1,`last`='{$date}' where sysid='0'");
$DB->close();
echo "OK!";