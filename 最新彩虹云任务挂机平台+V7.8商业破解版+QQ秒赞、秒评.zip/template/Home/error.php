<?php
@header('Content-Type: text/html; charset=UTF-8');
sysmsg('<h4>'.$_GET['msg'].'</h4>');