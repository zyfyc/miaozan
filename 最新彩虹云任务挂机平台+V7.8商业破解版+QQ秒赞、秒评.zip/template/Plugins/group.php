<?php
if (!defined("IN_CRONLITE")) exit();
$title = "提取群成员";
$breadcrumb = '<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq=' . $_GET['qq'] . '">' . $_GET['qq'] . '</a></li>
<li class="active"><a href="#">提取群成员</a></li>';
include TEMPLATE_ROOT . "head.php";
echo '<div class="col-md-8 col-sm-10 col-xs-12 center-block" role="main">';
if ($islogin == 1) {
	$qq = daddslashes($_GET['qq']);
	if (!$qq) {
		showmsg('参数不能为空！');
	}
	$row = $DB->get_row("SELECT * FROM " . DBQZ . "_qq WHERE qq='{$qq}' limit 1");
	if ($row['uid'] != $uid && $isadmin == 0) {
		showmsg('你只能操作自己的QQ哦！');
	}
	if ($row['status2'] != 1) {
		showmsg('SKEY已过期！');
	}
	$sid = $row['sid'];
	$skey = $row['skey'];
	$gtk = getGTK($skey);
	$cookie = "uin=o0" . $qq . "; skey=" . $skey . ";";
	$ua = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
	$url = 'http://qun.qzone.qq.com/cgi-bin/get_group_list?callbackFun=_GetGroupPortal&uin=' . $qq . '&ua=Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64%3B%20rv%3A25.0)%20Gecko%2F20100101%20Firefox%2F25.0&random=0.946546206453239&g_tk=' . $gtk;
	$data = get_curl($url, 0, 'http://qun.qzone.qq.com/group', $cookie, 0, $ua);
	preg_match("/_GetGroupPortal_Callback\((.*?)\)\;/is", $data, $json);
	$arr = json_decode($json[1], true);
	if (!$arr) {
		showmsg('QQ群列表获取失败！');
	} elseif ($arr["code"] == - 3000) {
		showmsg('SKEY已过期！');
	}
	if (isset($_GET['groupid'])) {
		$groupid = get_curl($_GET['groupid']);
		$gtk = get_curl($skey);
		$cookie = "uin=o0" . $qq . "; skey=" . $skey . ";";
		$ua = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
		$url = 'http://qun.qzone.qq.com/cgi-bin/get_group_member?callbackFun=_GroupMember&uin=' . $qq . '&groupid=' . $groupid . '&neednum=1&r=0.973228807809788&g_tk=' . $gtk . '&ua=Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64%3B%20rv%3A25.0)%20Gecko%2F20100101%20Firefox%2F25.0&ptlang=2052';
		$data = get_curl($url, 0, 'http://qun.qzone.qq.com/group', $cookie, 0, $ua);
		preg_match("/_GroupMember_Callback\((.*?)\)\;/is", $data, $json);
		$arrs = json_decode($json[1], true);
		if (!$arrs) {
			showmsg('QQ群成员获取失败！');
		} elseif ($arrs["code"] == - 3000) {
			showmsg('SKEY已过期！');
		}
	} ?>
<div class="panel panel-primary">
	<div class="panel-heading w h">
		<h3 class="panel-title" align="center">提取群成员</h3>
	</div>
	<div class="panel-body box" align="left">
		<form action="index.php" method="GET">
		<div class="form-group">
		<div class="input-group"><div class="input-group-addon">QQ群列表</div>
		<input type="hidden" name="mod" value="group">
		<input type="hidden" name="qq" value="<?php echo $qq ?>">
		<select name="groupid" class="form-control">
			<?php
	foreach ($arr['data']['group'] as $row) {
		echo '<option value="' . $row['groupid'] . '" ' . ($groupid == $row['groupid'] ? 'selected="selected"' : NULL) . '>' . $row['groupid'] . '_' . $row['groupname'] . '</option>';
	} ?>
			</select>
		</div></div>
		<div class="form-group">
		<input type="submit" class="btn btn-primary btn-block" value="提取群成员">
		</div>
		</form>
	</div>
</div>
<?php if ($arrs) { ?>
<div class="panel panel-success">
	<div class="panel-heading w h">
		<h3 class="panel-title" align="center">群成员列表</h3>
	</div>
	<table class="table table-bordered box">
		<tbody>
			<tr>
			<td><span style="color:silver;"><b>ＱＱ</b></span></td>
			<td><span style="color:silver;"><b>昵称</b></span></td>
			</tr>
			<?php
		echo '<tr><td colspan="2" align="center"><a href="index.php?mod=output&qq=' . $qq . '&groupid=' . $groupid . '&type=group">导出群成员列表为TXT</a></td></tr>';
		foreach ($arrs['data']['item'] as $row) {
			echo '<tr><td uin="' . $row['uin'] . '"><a href="tencent://message/?uin=' . $row['uin'] . '&amp;Site=&amp;Menu=yes">' . $row['uin'] . '</a></td><td>' . $row['nick'] . '</td></tr>';
		} ?>
		</tbody>
	</table>
</div>
<?php
	}
} else {
	showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！', 3);
}
include TEMPLATE_ROOT . "foot.php"; ?>