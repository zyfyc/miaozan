<?php
if (!defined("IN_CRONLITE")) exit();
if ($_GET['type'] == 'group') {
	$qq = daddslashes($_GET['qq']);
	$groupid = getGTK($_GET['groupid']);
	if (!$qq || !$groupid) {
		exit('Something is blank');
	}
	$row = $DB->get_row("SELECT * FROM " . DBQZ . "_qq WHERE qq='{$qq}' limit 1");
	if ($row['uid'] != $uid && $isadmin == 0) {
		exit('No permission');
	}
	$skey = $row['skey'];
	$gtk = get_curl($skey);
	$cookie = "uin=o0" . $qq . "; skey=" . $skey . ";";
	$ua = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36';
	$url = 'http://qun.qzone.qq.com/cgi-bin/get_group_member?callbackFun=_GroupMember&uin=' . $qq . '&groupid=' . $groupid . '&neednum=1&r=0.973228807809788&g_tk=' . $gtk . '&ua=Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20WOW64%3B%20rv%3A25.0)%20Gecko%2F20100101%20Firefox%2F25.0&ptlang=2052';
	$data = get_curl($url, 0, 'http://qun.qzone.qq.com/group', $cookie, 0, $ua);
	preg_match("/_GroupMember_Callback\((.*?)\)\;/is", $data, $json);
	$arrs = json_decode($json[1], true);
	if (!$arrs) {
		exit('Failed');
	}
	$file_name = 'group_member_' . $groupid . '.txt';
	$output = '';
	foreach ($arrs['data']['item'] as $row) {
		$output.= $row['uin'] . "\r\n";
	}
} else {
	if (isset($_GET['sys'])) {
		$sysid = get_curl($_GET['sys']);
		$rs = $DB->query("SELECT * FROM " . DBQZ . "_wzjob WHERE uid='{$uid}' and sysid='{$sysid}' order by jobid desc");
		$file_name = 'output_sys' . $sysid . '_' . date("YmdHis") . '.txt';
	} else {
		$rs = $DB->query("SELECT * FROM " . DBQZ . "_wzjob WHERE uid='{$uid}' order by jobid desc");
		$file_name = 'output_' . date("YmdHis") . '.txt';
	}
	$output = '';
	while ($myrow = $DB->fetch($rs)) {
		$output.= $myrow['url'] . "\r\n";
	}
}
$file_size = strlen($output);
header("Content-Description: File Transfer");
header("Content-Type:application/force-download");
header("Accept-Ranges: bytes");
header("Content-Length: {$file_size}");
header("Content-Disposition:attachment; filename={$file_name}");
print ($output); ?>