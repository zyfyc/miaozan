<?php
/**
 * php zend 解密 
 * 专业解密  
 * https://item.taobao.com/item.htm?id=526538537829
 */

?>
<?php 
if (!defined('IN_CRONLITE')) {
    die;
}
$act = isset($_GET['act']) ? $_GET['act'] : null;
if ($islogin == 1) {
    switch ($act) {
        case 'add':
            $qq = daddslashes($_GET['qq']);
            $jobid = daddslashes($_GET['jobid']);
            $type = daddslashes($_GET['type']);
            if (!$qq || !$type) {
                die('{"code":-1,"msg":"参数不能为空！"}');
            }
            if (OPEN_OTHE == 0 && ($type == 'liuyan' || $type == 'gift')) {
                die('{"code":-1,"msg":"当前站点未开启此功能！"}');
            }
            $row = $DB->get_row('SELECT * FROM ' . DBQZ . "_qq WHERE qq='{$qq}' limit 1");
            if ($row['uid'] != $uid && $isadmin != 1 && $isdeputy != 1) {
                die('{"code":-1,"msg":"你只能操作自己的QQ哦！"}');
            }
            if (in_array($type, $qqSignTasks)) {
                $func = 'qsign';
            } else {
                $func = $type;
            }
            if (in_array($func, $vip_func) && $isvip == 0 && $isadmin == 0) {
                die('{"code":-1,"msg":"抱歉，您还不是网站VIP会员，无法使用此功能。"}');
            }
            $data = qqjob_encode(daddslashes($type));
            $method = daddslashes($_POST['method']);
            $sysid = isset($_POST['sys']) ? intval($_POST['sys']) : 1;
            $start = isset($_POST['start']) ? intval($_POST['start']) : '0';
            $stop = isset($_POST['stop']) ? intval($_POST['stop']) : '24';
            $pl = isset($_POST['pl']) ? intval($_POST['pl']) : '0';
            if ($start > $stop) {
                die('{"code":0,"msg":"运行时间格式错误:开始时间大于结束时间"}');
            }
            $myrow = $DB->get_row('SELECT * FROM ' . DBQZ . "_qqjob WHERE qq='{$qq}' and type='{$type}' limit 1");
            if ($jobid != 0 || ($jobid = $myrow['jobid'])) {
                $sql = 'update `' . DBQZ . "_qqjob` set `method` ='{$method}',`data` ='{$data}',`pl`='{$pl}',`start`='{$start}',`stop`='{$stop}',`sysid`='{$sysid}' where `jobid`='{$jobid}'";
                if ($DB->query($sql)) {
                    die('{"code":1,"msg":"任务已成功修改！"}');
                } else {
                    die('{"code":0,"msg":"任务修改失败！' . $DB->error() . '"}');
                }
            } else {
                if (in_array($type, $qqSignTasks)) {
                    $sign = 1;
                } else {
                    $sign = 0;
                }
                $sql = 'insert into `' . DBQZ . "_qqjob` (`uid`,`qq`,`type`,`sign`,`method`,`data`,`lasttime`,`nexttime`,`pl`,`start`,`stop`,`sysid`) values ('{$uid}','{$qq}','{$type}','{$sign}','{$method}','{$data}','" . time() . '\',\'' . time() . "','{$pl}','{$start}','{$stop}','{$sysid}')";
                if ($DB->query($sql)) {
                    die('{"code":1,"msg":"' . $qqTaskNames[$type] . '任务已成功添加！"}');
                } else {
                    die('{"code":0,"msg":"任务添加失败！' . $DB->error() . '"}');
                }
            }
            break;
        case 'edit':
            $qq = daddslashes($_GET['qq']);
            $type = daddslashes($_GET['type']);
            $jobid = daddslashes($_GET['jobid']);
            $page = daddslashes($_GET['page']);
            $row = $DB->get_row('SELECT * FROM ' . DBQZ . "_qq WHERE qq='{$qq}' limit 1");
            if ($row['uid'] != $uid && $isadmin != 1 && $isdeputy != 1) {
                showmsg('你只能操作自己的QQ哦！', 3);
            }
            if ($jobid) {
                $row1 = $DB->get_row('SELECT *FROM ' . DBQZ . "_qqjob where jobid='{$jobid}' limit 1");
                $qqrow = @unserialize($row1['data']);
                $qq = $row1['qq'];
                $type = $row1['type'];
            } else {
                $qqrow = array('msg' => '您好！我在挂Q，暂时无法回复您。', 'content' => '[随机]', 'img' => '', 'ua' => 'iPhone 6 Plus');
            }
            ?>
<div class="panel panel-primary">
	<div class="panel-heading bk-bg-primary">
		<h6><i class="fa fa-indent red"></i><span class="break"></span>添加<?php 
            echo $qqTaskNames[$type];
            ?>
任务</h6>
		<div class="panel-actions">
			<a href="#" onclick="showlist('qqtask',1)" class="btn-close"><i class="fa fa-times black"></i></a>
		</div>
	</div>
<?php 
            $display_time = '<div class="list-group-item">
<div class="input-group">
<div class="input-group-addon">运行时段:</div>
<select class="form-control" style="width:40%;display:inline;float:none;" id="start" default="' . $row1['start'] . '">
<option value="00">00</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
</select>&nbsp;时-&nbsp;<select class="form-control" style="width:40%;display:inline;float:none;" id="stop" default="' . $row1['stop'] . '">
<option value="24">24</option>
<option value="00">00</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
</select>&nbsp;时</div>
</div>';
            if ($type == 'shuo' || $type == 'zfss') {
                $pl = '600';
            } else {
                $pl = '0';
            }
            $pl = isset($row1['pl']) ? $row1['pl'] : $pl;
            $display_pl = '<div class="list-group-item">
<div class="input-group">
<div class="input-group-addon">运行频率(秒/次)</div>
<input type="text" class="form-control" id="pl" value="' . $pl . '">
</div>
</div>';
            if ($conf['multisys']) {
                $display_sys = '
<div class="list-group-item">
<div class="input-group">
<div class="input-group-addon">服务器</div><select class="form-control" name="sys">';
                $show = explode('|', $conf['show']);
                for ($i = 0; $i < $conf['sysnum']; $i++) {
                    $sysid = $i + 1;
                    $all_sys = $DB->count('SELECT count(*) from ' . DBQZ . "_qqjob WHERE sysid='{$sysid}'");
                    if ($all_sys >= $conf['max']) {
                        $sysnum = -1;
                        $addstr = '已满';
                    } else {
                        $sysnum = $sysid;
                        $addstr = $all_sys . '人';
                    }
                    $display_sys .= '<option value="' . $sysnum . '" ' . ($sysid == $row1['sysid'] ? 'selected="selected"' : NULL) . '>' . $sysid . '号服务器(' . $addstr . ')</option>';
                }
                $display_sys .= '</select><br/></div>
</div>';
            }
            switch ($type) {
                case 'zan':
                    vipfunc_check('zan');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">秒赞协议</div>\r\n<select class=\"form-control\" id=\"method\">\r\n<option value=\"4\">PC版协议New</option>\r\n<option value=\"3\">PC版协议</option>\r\n<option value=\"2\">触屏版协议</option>\r\n</select></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">不秒赞的QQ</div>\r\n<input type=\"text\" class=\"form-control\" id=\"forbid\" value=\"{$qqrow['forbid']}\" placeholder=\"多个QQ号之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\tif(\$('#sys').val()=='-1') {\r\n\t\talert(\"该系统任务数量已满，请重新选择一个系统！\");\r\n\t\treturn false;\r\n\t}\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tmethod:\$('#method').val(),forbid:\$('#forbid').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'pl':
                    vipfunc_check('pl');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">秒评协议</div>\r\n<select class=\"form-control\" id=\"method\">\r\n<option value=\"3\">PC版协议</option>\r\n<option value=\"2\">触屏版协议</option>\r\n</select></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">评论内容</div>\r\n<input type=\"text\" class=\"form-control\" id=\"content\" value=\"{$qqrow['content']}\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<font color=\"blue\">选填内容：<a href=\"#\" onclick=\"Addstr('[随机]');return false\">[随机]</a>，如自定义多条内容请用|隔开</font>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">不秒评的QQ</div>\r\n<input type=\"text\" class=\"form-control\" id=\"forbid\" value=\"{$qqrow['forbid']}\" placeholder=\"多个QQ号之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">只秒评的QQ</div>\r\n<input type=\"text\" class=\"form-control\" id=\"only\" value=\"{$qqrow['only']}\" placeholder=\"多个QQ号之间用|隔开\" placeholder=\"留空则秒评全部\"/>\r\n</div>\r\n</div>\r\n{$display_pl}\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<div class=\"well\">\r\n<font color=\"blue\">提示：<br/><font color=\"green\">频率默认为0，即当前系统的最快运行频率</font><br/>运行频率视自己需要而定。</font><font color=\"red\">发言过于频繁可能会被腾讯禁言！</font>\r\n</div>\r\n<script>\r\nfunction Addstr(str) {\r\n\t\$(\"#content\").val(str);\r\n}\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\tif(\$('#sys').val()=='-1') {\r\n\t\talert(\"该系统任务数量已满，请重新选择一个系统！\");\r\n\t\treturn false;\r\n\t}\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tmethod:\$('#method').val(),pl:\$('#pl').val(),content:\$('#content').val(),forbid:\$('#forbid').val(),only:\$('#only').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'kjqd':
                    vipfunc_check('kjqd');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">签到协议</div>\r\n<select class=\"form-control\" id=\"method\">\r\n<option value=\"2\">触屏版协议</option>\r\n<option value=\"3\">PC版协议</option>\r\n</select></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">签到内容</div>\r\n<input type=\"text\" class=\"form-control\" id=\"content\" value=\"{$qqrow['content']}\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<font color=\"blue\">选填内容：<a href=\"#\" onclick=\"Addstr('[随机]');return false\">[随机]</a>、<a href=\"#\" onclick=\"Addstr('[笑话]');return false\">[笑话]</a>、<a href=\"#\" onclick=\"Addstr('[表情]');return false\">[表情]</a>、<a href=\"#\" onclick=\"Addstr('[时间]');return false\">[时间]</a></font>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<script>\r\nfunction Addstr(str) {\r\n\t\$(\"#content\").val(str);\r\n}\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tmethod:\$('#method').val(),content:\$('#content').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'shuo':
                    vipfunc_check('shuo');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">说说协议</div>\r\n<select class=\"form-control\" id=\"method\">\r\n<option value=\"2\">触屏版协议</option>\r\n<option value=\"3\">PC版协议</option>\r\n</select></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">说说内容</div>\r\n<input type=\"text\" class=\"form-control\" id=\"content\" value=\"{$qqrow['content']}\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<font color=\"blue\">选填内容：<a href=\"#\" onclick=\"Addstr('[随机]');return false\">[随机]</a>、<a href=\"#\" onclick=\"Addstr('[笑话]');return false\">[笑话]</a>、<a href=\"#\" onclick=\"Addstr('[表情]');return false\">[表情]</a>、<a href=\"#\" onclick=\"Addstr('[时间]');return false\">[时间]</a></font>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">图片地址</div>\r\n<input type=\"text\" class=\"form-control\" id=\"img\" value=\"{$qqrow['img']}\" placeholder=\"不需要请留空\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<font color=\"blue\">选填内容：<a href=\"#\" onclick=\"Addstr2('随机');return false\">随机</a>、或自定义图片URL。</font>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">同时删除上一条说说</div>\r\n<select class=\"form-control\" id=\"delete\">\r\n<option value=\"0\">0_否</option>\r\n<option value=\"1\">1_是</option>\r\n</select></div>\r\n</div>\r\n{$display_pl}\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<div class=\"well\">\r\n<font color=\"red\">运行频率视自己需要而定。发言过于频繁可能会被腾讯禁言！</font>\r\n</div>\r\n<script>\r\nfunction Addstr(str) {\r\n\t\$(\"#content\").val(str);\r\n}\r\nfunction Addstr2(str) {\r\n\t\$(\"#img\").val(str);\r\n}\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\tif(\$('#sys').val()=='-1') {\r\n\t\talert(\"该系统任务数量已满，请重新选择一个系统！\");\r\n\t\treturn false;\r\n\t}\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tmethod:\$('#method').val(),content:\$('#content').val(),img:\$('#img').val(),delete:\$('#delete').val(),pl:\$('#pl').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'zfss':
                    vipfunc_check('zfss');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">转发协议</div>\r\n<select class=\"form-control\" id=\"method\">\r\n<option value=\"2\">触屏版协议</option>\r\n<option value=\"3\">PC版协议</option>\r\n</select></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">好友ＱＱ</div>\r\n<input type=\"text\" class=\"form-control\" id=\"uin\" value=\"{$qqrow['uin']}\" placeholder=\"多个QQ号之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">转发原因</div>\r\n<input type=\"text\" class=\"form-control\" id=\"reason\" value=\"{$qqrow['reason']}\" placeholder=\"可留空\"/>\r\n</div>\r\n</div>\r\n{$display_pl}\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<div class=\"well\">\r\n<font color=\"blue\">好友QQ栏若不填写则转发全部好友的说说。</font>\r\n<font color=\"red\">运行频率视自己需要而定，发言过于频繁可能会被腾讯禁言！</font>\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\tif(\$('#sys').val()=='-1') {\r\n\t\talert(\"该系统任务数量已满，请重新选择一个系统！\");\r\n\t\treturn false;\r\n\t}\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tmethod:\$('#method').val(),pl:\$('#pl').val(),uin:\$('#uin').val(),reason:\$('#reason').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'qunqd':
                    vipfunc_check('qsign');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">自定义签到地点</div>\r\n<input type=\"text\" class=\"form-control\" id=\"lat\" value=\"{$qqrow['lat']}\" style=\"width:40%;display:inline;float:none;\" placeholder=\"经度\"/><input type=\"text\" class=\"form-control\" id=\"lgt\" value=\"{$qqrow['lgt']}\" style=\"width:40%;display:inline;float:none;\" placeholder=\"纬度\"/></div>\r\n</div>\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">屏蔽以下群的签到</div>\r\n<input type=\"text\" class=\"form-control\" id=\"forbid\" value=\"{$qqrow['forbid']}\" placeholder=\"多个群号之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<div class=\"well\">\r\n<font color=\"blue\">不使用自定义签到地点请留空，使用自定义签到地点可能会延长签到时间。例如北京天安门的经度:39.908866 纬度:116.397404。<a href=\"http://lbs.qq.com/tool/getpoint/index.html\" target=\"_balnk\">在线地图经度纬度查询</a></font>\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tforbid:\$('#forbid').val(),lat:\$('#lat').val(),lgt:\$('#lgt').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'wenwen':
                    vipfunc_check('qsign');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">屏蔽以下群的签到</div>\r\n<input type=\"text\" class=\"form-control\" id=\"forbid\" value=\"{$qqrow['forbid']}\" placeholder=\"多个群号之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tforbid:\$('#forbid').val(),start:'10'\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'qlsend':
                    vipfunc_check('qsign');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">发送蜜语动作</div>\r\n<select class=\"form-control\" id=\"content\">\r\n<option value=\"1\">爱你</option>\r\n<option value=\"2\">棒棒糖</option>\r\n<option value=\"3\">亲亲</option>\r\n<option value=\"4\">挑逗传情</option>\r\n<option value=\"5\">送花</option>\r\n<option value=\"6\">快理我</option>\r\n<option value=\"7\">想你</option>\r\n<option value=\"8\">大猪头</option>\r\n<option value=\"9\">求抱抱</option>\r\n<option value=\"10\">咬你</option>\r\n</select>\r\n</div>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tcontent:\$('#content').val(),pl:\"9600\"\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case '3gqq':
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n{$display_time}\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<div class=\"well\">\r\n<font color=\"blue\">使用3GQQ需要先关闭设备锁；如开启了QQ等级代挂功能请不要使用3GQQ，以免被挤掉线！</font>\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tstart:\$('#start').val(),stop:\$('#stop').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
                case 'nick':
                    vipfunc_check('qsign');
                    echo "<div class=\"panel-body\">\r\n<form action=\"#\" role=\"form\">\r\n<div class=\"list-group-item\">\r\n<div class=\"input-group\"><div class=\"input-group-addon\">昵称</div>\r\n<input type=\"text\" class=\"form-control\" id=\"nick\" value=\"{$qqrow['nick']}\" placeholder=\"多个昵称之间用|隔开\"/>\r\n</div>\r\n</div>\r\n<p><input type=\"button\" id=\"qqjob_edit\" class=\"btn btn-primary btn-block\" value=\"提交\"/>\r\n<input type=\"reset\" class=\"btn btn-default btn-block\" value=\"重填\" /></p></form>\r\n[ <a href=\"#\" onclick=\"showlist('qqtask',1)\">返回上一页</a> ]\r\n</div>\r\n<script>\r\n\$(document).ready(function(){\r\n\$('#qqjob_edit').click(function()\r\n{\r\n\t\$(\"#qqjob_edit\").val('loading');\r\n\tajax.post(\"ajax.php?mod=qqjob&act=add&qq={$qq}&type={$type}&jobid={$jobid}\",\r\n\t{\r\n\t\tnick:\$('#nick').val()\r\n\t},\"json\",function(arr) {\r\n\t\tif(arr.code==1){\r\n\t\t\talert(arr.msg);\r\n\t\t\tshowlist('qqtask',{$page});\r\n\t\t}else{\r\n\t\t\talert(arr.msg);\r\n\t\t}\r\n\t});\r\n});\r\n});\r\n</script>";
                    break;
            }
            ?>
</div>
<?php 
            break;
    }
} else {
    showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！', 3);
}