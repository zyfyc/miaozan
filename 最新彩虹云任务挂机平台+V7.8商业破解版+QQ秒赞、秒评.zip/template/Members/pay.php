<?php
if (!defined("IN_CRONLITE")) exit();
@header("Content-Type: text/html; charset=UTF-8");
if ($islogin == 1) {
	$type = isset($_GET['type']) ? daddslashes($_GET['type']) : exit('No type!');
	$orderid = isset($_GET['orderid']) ? daddslashes($_GET['orderid']) : exit('No orderid!');
	$row = $DB->get_row("SELECT * FROM " . DBQZ . "_pay WHERE orderid='{$orderid}' limit 1");
	if (!$row['id']) exit('该订单号不存在，请返回来源地重新发起请求！');
	if ($type == 'epay') {
		require_once (SYSTEM_ROOT . "epay/epay.config.php");
		require_once (SYSTEM_ROOT . "epay/epay_submit.class.php");
		$parameter = array("pid" => trim($conf['epay_pid']), "type" => $_GET['type2'], "notify_url" => $siteurl . 'other/epay_notify.php', "return_url" => $siteurl . 'other/epay_return.php', "out_trade_no" => $orderid, "name" => $row['name'], "money" => $row['money'], "sitename" => $conf['sitename']);
		$alipaySubmit = new AlipaySubmit($alipay_config);
		$html_text = $alipaySubmit->buildRequestForm($parameter, "get", "正在跳转");
		echo $html_text;
	} elseif ($type == 'alipay') {
		require_once (SYSTEM_ROOT . "alipay/alipay.config.php");
		require_once (SYSTEM_ROOT . "alipay/alipay_submit.class.php");
		if ($ismobile == true && $conf['alipay2_api'] == 1) {
			$parameter = array("service" => "alipay.wap.create.direct.pay.by.user", "partner" => trim($conf['alipay_pid']), "seller_id" => trim($conf['alipay_account']), "payment_type" => "1", "notify_url" => $siteurl . 'other/alipay_notify.php', "return_url" => $siteurl . 'other/alipay_return.php', "out_trade_no" => $orderid, "subject" => $row['name'], "total_fee" => $row['money'], "_input_charset" => strtolower('utf-8'));
		} else {
			$parameter = array("service" => "create_direct_pay_by_user", "partner" => trim($conf['alipay_pid']), "seller_email" => trim($conf['alipay_account']), "payment_type" => "1", "notify_url" => $siteurl . 'other/alipay_notify.php', "return_url" => $siteurl . 'other/alipay_return.php', "out_trade_no" => $orderid, "subject" => $row['name'], "total_fee" => $row['money'], "_input_charset" => strtolower('utf-8'));
		}
		$alipaySubmit = new AlipaySubmit($alipay_config);
		$html_text = $alipaySubmit->buildRequestForm($parameter, "get", "正在跳转");
		echo $html_text;
	} elseif ($type == 'tenpay') {
		require_once (SYSTEM_ROOT . "tenpay/RequestHandler.class.php");
		$reqHandler = new RequestHandler();
		$reqHandler->init();
		$reqHandler->setKey($conf['tenpay_key']);
		$reqHandler->setGateUrl("https://gw.tenpay.com/gateway/pay.htm");
		$reqHandler->setParameter("partner", trim($conf['tenpay_pid']));
		$reqHandler->setParameter("out_trade_no", $orderid);
		$reqHandler->setParameter("total_fee", $row['money'] * 100);
		$reqHandler->setParameter("return_url", $siteurl . 'other/tenpay_return.php');
		$reqHandler->setParameter("notify_url", $siteurl . 'other/tenpay_notify.php');
		$reqHandler->setParameter("body", $row['name']);
		$reqHandler->setParameter("bank_type", "DEFAULT");
		$reqHandler->setParameter("spbill_create_ip", $clientip);
		$reqHandler->setParameter("fee_type", "1");
		$reqHandler->setParameter("subject", $row['name']);
		$reqHandler->setParameter("sign_type", "MD5");
		$reqHandler->setParameter("service_version", "1.0");
		$reqHandler->setParameter("input_charset", "utf-8");
		$reqHandler->setParameter("sign_key_index", "1");
		$reqUrl = $reqHandler->getRequestURL(); ?>
		<form action="<?php echo $reqHandler->getGateUrl() ?>" method="post" id="tenpay">
		<?php
		$params = $reqHandler->getAllParameters();
		foreach ($params as $k => $v) {
			echo "<input type=\"hidden\" name=\"{$k}\" value=\"{$v}\" />";
		} ?>
		<input type="submit" value="正在跳转"></form><script>document.getElementById("tenpay").submit();</script>
		<?php
	}
} else {
	exit("登录失败，可能是密码错误或者身份失效了，请重新登录！");
}
