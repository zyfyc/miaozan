<?php
 if(!defined('IN_CRONLITE'))exit();$title="后台管理";$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-cogs"></i>网站设置</a></li>';include TEMPLATE_ROOT.'head.php';$my=isset($_POST['my'])?$_POST['my']:$_GET['my'];echo '<div class="col-lg-8 col-sm-10 col-xs-12 center-block" role="main">';if ($isadmin==1){echo '<div class="panel panel-primary">';if($my=='set_config'){echo '<div class="panel-heading w h"><h3 class="panel-title">网站信息配置</h3></div><div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_config">
<div class="form-group">
<label>*站点名称:</label><br>
<input type="text" class="form-control" name="sitename" value="'.$conf['sitename'].'">
</div>
<div class="form-group">
<label>*网站标题栏后缀:</label><br>
<input type="text" class="form-control" name="sitetitle" value="'.$conf['sitetitle'].'">
</div>
<div class="form-group">
<label>*网站关键字:</label><br>
<input type="text" class="form-control" name="keywords" value="'.$conf['keywords'].'">
</div>
<div class="form-group">
<label>*网站描述:</label><br>
<input type="text" class="form-control" name="description" value="'.$conf['description'].'">
</div>
<div class="form-group">
<label>*网站版权:</label><br>
<input type="text" class="form-control" name="copyright" value="'.htmlspecialchars($conf['copyright']).'">
</div>
<div class="form-group">
<label>*网站网址:</label><br>
<input type="text" class="form-control" name="siteurl" value="'.($conf['siteurl']?$conf['siteurl']:$siteurl).'" placeholder="留空则自动获取当前网址">
</div>
<div class="form-group">
<label>*网站客服QQ:</label><br>
<input type="text" class="form-control" name="kfqq" value="'.$conf['kfqq'].'">
</div>
<div class="form-group">
<label>*系统任务数上限:</label><br>
<input type="text" class="form-control" name="max" value="'.$conf['max'].'">
</div>
<div class="form-group">
<label>*列表每页显示个数:</label><br>
<input type="text" class="form-control" name="pagesize" value="'.$conf['pagesize'].'" maxlength="10">
</div>
<div class="form-group">
<label>*批量添加任务上限:</label><br>
<input type="text" class="form-control" name="bulk" value="'.$conf['bulk'].'" maxlength="10">
</div>
<div class="form-group">
<label>本站服务器所在地:</label><br>
<input type="text" class="form-control" name="serverlocal" value="'.$conf['serverlocal'].'" maxlength="11">
<font color="green">仅用于在添加QQ界面显示，不填写即自动获取。当IP所在地不准时可在此填写，以QQ安全中心提示为准</font>
</div>
<!--div class="form-group">
<label>用户添加QQ时添加提醒:</label><br>
<input type="text" class="form-control" name="qqtx" value="'.$conf['qqtx'].'">
<font color="green">使用QQ提醒功能为添加的QQ发送所填写的内容。留空则不发送提醒</font>
</div-->
<div class="form-group">
<!--label>用户添加QQ加群号:</label><br>
<input type="text" class="form-control" name="qqqun" value="'.$conf['qqqun'].'" maxlength="11">
<font color="green">填写群号后，用户添加QQ将自动加该群。留空则不加群</font>
</div-->
<div class="form-group">
<label>用户添加QQ加好友:</label><br>
<input type="text" class="form-control" name="addfriend" value="'.$conf['addfriend'].'" maxlength="11">
<font color="green">填写QQ号后，用户添加QQ将自动加指定好友。留空则不加好友</font>
</div>
<div class="form-group">
<label>用户添加QQ关注部落ID:</label><br>
<input type="text" class="form-control" name="addbuluo" value="'.$conf['addbuluo'].'" maxlength="11">
<font color="green">填写兴趣部落ID，用户添加QQ将自动关注该部落。留空则不关注</font>
</div>
<div class="form-group">
<label>添加QQ自动添加秒赞任务:</label><br><select class="form-control" name="addzan" default="'.$conf['addzan'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
</div>
<div class="form-group">
<label>副站长UID:</label><br>
<input type="text" class="form-control" name="deputy" value="'.$conf['deputy'].'">
<font color="green">填写UID，用“|”隔开。设置的副站长将拥有大部分网站管理权限，但是没有系统设置权限</font>
</div>
<div class="form-group">
<label>注册开关:</label><br><select class="form-control" name="zc" default="'.$conf['zc'].'"><option value="2">2_开放注册(防刷模式)</option><option value="1">1_开放注册</option><option value="0">0_关闭注册</option></select>
<font color="green">建议开启防刷模式，以免被恶意刷注册。主机屋空间请不要开启防刷模式。</font>
</div>
<div class="form-group">
<label>激活账号方式:</label><br><select class="form-control" name="active" default="'.$conf['active'].'"><option value="0">0_不需要激活</option><option value="1">1_绑定手机激活账号</option><option value="2">2_绑定QQ账号激活账号</option><option value="3">3_绑定新浪微博账号激活账号</option></select>
<font color="green">开启账号激活功能后，所有用户需要以指定的方式激活账号后才能使用平台功能。注：之前注册的用户也同样需要激活账号</font>
</div>
<div class="form-group">
<label>网址关键词屏蔽设定:</label><br/><input type="text" class="form-control" name="block" value="'.$conf['block'].'"><font color="green">每个关键词中间用“|”隔开</font>
</div>
<div class="form-group">
<label>添加QQ屏蔽设定:</label><br/><input type="text" class="form-control" name="qqblock" value="'.$conf['qqblock'].'"><font color="green">每个QQ号中间用“|”隔开</font>
</div>
<div class="form-group">
<label>IP地址屏蔽设定:</label><br/><input type="text" class="form-control" name="banned" value="'.$conf['banned'].'"><font color="green">每个IP地址中间用“|”隔开</font>
</div>
<div class="form-group">
<label>反腾讯网址安全监测系统:</label><br><select class="form-control" name="txprotect" default="'.$conf['txprotect'].'"><option value="0">0_关闭</option><option value="1">1_开启</option><option value="2">2_开启特定域名</option></select>
<font color="green">此功能通过对IP段和header特征的拦截，可以屏蔽腾讯管家网址安全检测系统访问，可防举报。开启此功能可以防止腾讯把本站域名拉入黑名单。</font>
</div>
<div id="frame_set" style="'.($conf['txprotect']!=2?'display:none;':null).'">
<div class="form-group">
<label>开启反腾讯网址安全监测的域名:</label><br><input type="text" class="form-control" name="txprotect_domain" value="'.$conf['txprotect_domain'].'" placeholder="cron.sgwap.net,cron.aliapp.com">
<font color="green">多个域名请用英文逗号 , 隔开</font>
</div>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>
<script>
  $("select[name=\'txprotect\']").change(function(){
	  if($(this).val() == 2){
		$("#frame_set").css("display","inherit");
	  }else if($(this).val() == 0){
		alert("警告，如果你的域名还没在QQ上报毒，关闭反检测后可能很快就会报毒！");
		$("#frame_set").css("display","none");
	  }else{
		$("#frame_set").css("display","none");
	  }
  });
</script>';}elseif($my=='ad_config'){$sitename=$_POST['sitename'];$sitetitle=$_POST['sitetitle'];$keywords=$_POST['keywords'];$description=$_POST['description'];$copyright=$_POST['copyright'];$siteurl=$_POST['siteurl'];$kfqq=$_POST['kfqq'];$max=$_POST['max'];$pagesize=$_POST['pagesize'];$zc=$_POST['zc'];$bulk=$_POST['bulk'];$block=$_POST['block'];$banned=$_POST['banned'];$deputy=$_POST['deputy'];$serverlocal=$_POST['serverlocal'];$qqblock=$_POST['qqblock'];$qqqun=$_POST['qqqun'];$addzan=$_POST['addzan'];$addfriend=$_POST['addfriend'];$addbuluo=$_POST['addbuluo'];$active=$_POST['active'];$qqtx=$_POST['qqtx'];$txprotect=$_POST['txprotect'];$txprotect_domain=$_POST['txprotect_domain'];if($sitename==NULL or $pagesize==NULL or $bulk==NULL){showmsg('保存错误,请确保加*项都不为空!',3);}else {saveSetting('sitename', $sitename);saveSetting('sitetitle', $sitetitle);saveSetting('keywords', $keywords);saveSetting('description', $description);saveSetting('copyright', $copyright);saveSetting('siteurl', $siteurl);saveSetting('kfqq', $kfqq);saveSetting('pagesize', $pagesize);saveSetting('zc', $zc);saveSetting('bulk', $bulk);saveSetting('block', $block);saveSetting('banned', $banned);saveSetting('deputy', $deputy);saveSetting('serverlocal', $serverlocal);saveSetting('qqblock', $qqblock);saveSetting('qqqun', $qqqun);saveSetting('addzan', $addzan);saveSetting('addfriend', $addfriend);saveSetting('addbuluo', $addbuluo);saveSetting('active', $active);saveSetting('qqtx', $qqtx);saveSetting('txprotect', $txprotect);saveSetting('txprotect_domain', $txprotect_domain);$ad=$CACHE->clear();if($sysnum>16)$DB->query("INSERT INTO `wjob_info`(`sysid`, `times`) VALUES
('17', '0'),
('18', '0'),
('19', '0'),
('20', '0');");$DB->query($max);if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_func'){echo '<div class="panel-heading w h"><h3 class="panel-title">界面功能配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_func">
<div class="form-group">
<label>是否开启QQ挂机类功能:</label><br><select class="form-control" name="open_qqol" default="'.OPEN_QQOL.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启自动签到功能:</label><br><select class="form-control" name="open_sign" default="'.OPEN_SIGN.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启网址监控功能:</label><br><select class="form-control" name="open_cron" default="'.OPEN_CRON.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启聊天社区功能:</label><br><select class="form-control" name="open_chat" default="'.OPEN_CHAT.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启ＱＱ展示功能:</label><br><select class="form-control" name="open_wall" default="'.OPEN_WALL.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否允许添加QQ代挂类任务:</label><br><select class="form-control" name="open_leve" default="'.OPEN_LEVE.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否允许添加空间代刷类任务:</label><br><select class="form-control" name="open_qzds" default="'.OPEN_QZDS.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启刷赞刷人气功能:<font color=red>(会导致大量QQ失效过快)</font></label><br><select class="form-control" name="open_shua" default="'.OPEN_SHUA.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否允许添加刷留言任务:<font color=red>(会导致大量QQ失效过快或被冻结)</font></label><br><select class="form-control" name="open_othe" default="'.OPEN_OTHE.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启刷说说队形功能:<font color=red>(会导致大量QQ失效过快或被冻结)</font></label><br><select class="form-control" name="open_shua2" default="'.OPEN_SHUAR.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否开启协助打码:</label><br><select class="form-control" name="open_dama" default="'.OPEN_DAMA.'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>';}elseif($my=='ad_func'){saveSetting('open_qqol', $_POST['open_qqol']);saveSetting('open_sign', $_POST['open_sign']);saveSetting('open_cron', $_POST['open_cron']);saveSetting('open_chat', $_POST['open_chat']);saveSetting('open_wall', $_POST['open_wall']);saveSetting('open_othe', $_POST['open_othe']);saveSetting('open_leve', $_POST['open_leve']);saveSetting('open_qzds', $_POST['open_qzds']);saveSetting('open_shua', $_POST['open_shua']);saveSetting('open_shua2', $_POST['open_shua2']);saveSetting('open_dama', $_POST['open_dama']);saveSetting('sjyl', $_POST['sjyl']);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}elseif($my=='set_rw'){echo '<div class="panel-heading w h"><h3 class="panel-title">任务运行与服务器配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_rw">
<div class="form-group">
<label>监控文件运行密钥:</label><br><input type="text" class="form-control" name="cronkey" value="'.$conf['cronkey'].'">
<font color="green">默认为空。设置密钥后，你需要在所有监控文件后面加上 <u>?key=你的密钥</u>，可防止监控文件被恶意执行</font>
</div>
<div class="form-group">
<label>是否使用本地回路:</label><br><select class="form-control" name="localcron" default="'.$conf['localcron'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
<font color="green">开启本地回路能使监控运行更迅速。本地回路主要用于解决开启CDN之后访问IP和源站IP不一样而导致无法监控或监控慢的问题。</font>
</div>
<div class="form-group">
<label>是否强制单线程:</label><br><select class="form-control" name="runmodol" default="'.$conf['runmodol'].'"><option value="0">0_多线程模式(推荐)</option><option value="1">1_强制单线程模式</option></select>
<font color="green">默认多线程模式，运行速度更快，如果多线程模式无法运行任务，可尝试强制单线程，切换到单线程模式后你可能需要加快监控频率。</font>
</div>
<div class="form-group">
<label>每次/每线程运行个数:</label><br/><input type="text" class="form-control" name="interval" value="'.$conf['interval'].'" maxlength="10">
<font color="green">每次运行任务数是指在单个系统内，每运行一次监控文件(jobx.php)所能够执行的任务数。如果开启多线程后则为每个线程的任务数。可以根据自己空间的max_execution_time('.ini_get('max_execution_time').')进行设置。</font>
</div>
<!--div class="form-group">
<label>使用备用获取说说列表接口:</label><br><select class="form-control" name="getss" default="'.$conf['getss'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
<font color="green">如果本站IP被腾讯屏蔽导致大部分QQ获取说说列表失败，请尝试使用备用获取说说列表接口。</font><font color="red">一般不建议使用备用接口。</font>
</div
<div class="form-group">
<label>PCnew协议使用备用获取说说列表接口:</label><br><select class="form-control" name="newpc" default="'.$conf['newpc'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
<font color="green">如果本站IP被腾讯屏蔽导致大部分QQ在使用PCnew协议时获取说说列表失败，请尝试使用PCnew备用获取说说列表接口。</font><font color="red">备用接口会导致重复赞的问题</font>
</div-->
<div class="form-group">
<label>单向检测执行方式:</label><br><select class="form-control" name="dxjc" default="'.$conf['dxjc'].'"><option value="0">模式一(默认)</option><option value="1">模式二</option></select>
<font color="green">模式二使用高并发检测，速度更快，但可能会导致服务器负载过高；模式一采用普通方式检测，速度较慢</font>
</div>
<div class="form-group">
<label>每条说说秒赞秒评时间间隔(秒):</label><br><input type="text" class="form-control" name="sleep" value="'.($conf['sleep']?$conf['sleep']:0).'" maxlength="10">
<font color="green">此处可以调整每条说说点赞/评论的时间间隔（单位：秒），用以解决过于频繁导致的获取赞结果失败。0为不间隔。设置过大会导致访问超时。</font>
</div>
<div class="form-group">
<label>秒赞任务运行时间间隔(秒):</label><br><input type="text" class="form-control" name="sleep2" value="'.($conf['sleep2']?$conf['sleep2']:50).'" maxlength="10">
<font color="green">此处可以调整每运行一次秒赞任务的时间间隔（单位：秒），建议50秒，系统限制最小10秒。</font>
</div>
<!--div class="form-group">
<label>QQ签到类任务运行时间间隔(秒):</label><br><input type="text" class="form-control" name="sleep3" value="'.($conf['sleep3']?$conf['sleep3']:18000).'" maxlength="10">
<font color="green">此处可以调整每运行一次签到类任务的时间间隔（单位：秒），建议18000秒，系统限制最小360秒。</font>
</div>
<div class="form-group">
<label>ＱＱ挂机服务器数量(<=8):</label><br/><input type="text" class="form-control" name="server_qzone" value="'.$conf['server_qzone'].'">
</div>
<div class="form-group">
<label>自动签到服务器数量:</label><br/><input type="text" class="form-control" name="server_wsign" value="'.$conf['server_wsign'].'" disabled>
</div-->
<a id="openadvance" onclick=\'$("#advance").toggle();$("#openadvance").hide();\' style="color:grey;">显示高级功能(仅限网址监控任务)</a>
<div id="advance" style="display:none;">
<div class="form-group">
<label>网址监控系统数量(<=10):</label><br/><input type="text" class="form-control" name="server_wz" value="'.$conf['server_wz'].'">
</div>
<div class="form-group">
<label>每系统任务数上限:</label><br>
<input type="text" class="form-control" name="max" value="'.$conf['max'].'">
</div>
<div class="form-group">
<label>系统执行频率显示设定:</label><br/><input type="text" class="form-control" name="frequency" value="'.$conf['show'].'"><font color="green">分别对应每个服务器，中间用“|”隔开。此处可以修改服务器列表所显示的每个系统的运行频率，实际运行频率由监控频率决定。</font>
</div>
<div class="form-group">
<label><font color="red">[优先级1]</font>有限循环秒刷配置:</label><br/><input type="text" class="form-control" name="seconds" value="'.$conf['seconds'].'">
<font color="green">0为关闭秒刷功能，填写每运行一次监控文件(jobx.php)所连续循环执行的次数。循环次数过多会导致所有任务无法一次性执行完毕。</font>
</div>
<div class="form-group">
<label><font color="red">[优先级2]</font>无限循环秒刷配置:</label><br/><input type="text" class="form-control" name="loop" value="'.$conf['loop'].'">
<font color="green">0为关闭秒刷功能，1为开启。开启后，每运行一次监控文件(jobx.php)可不间断地自动循环运行，最大循环次数因空间而异。</font><br/>
<font color="red">优先级说明：开启优先级1的秒刷配置后优先级2的配置将失效</font>
</div>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>';}elseif($my=='ad_rw'){$cronkey=$_POST['cronkey'];$runmodol=$_POST['runmodol'];$localcron=$_POST['localcron'];$interval=$_POST['interval'];$seconds=$_POST['seconds'];$loop=$_POST['loop'];$dxjc=$_POST['dxjc'];$newpc=$_POST['newpc'];$sleep=$_POST['sleep'];$sleep2=$_POST['sleep2'];$sleep3=$_POST['sleep3'];$max=$_POST['max'];$server_qzone=$_POST['server_qzone']?$_POST['server_qzone']:1;$server_wsign=$_POST['server_wsign']?$_POST['server_wsign']:1;$server_wz=$_POST['server_wz']?$_POST['server_wz']:1;$frequency=$_POST['frequency'];if($interval==NULL or $seconds==NULL or $loop==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('cronkey', $cronkey);saveSetting('runmodol', $runmodol);saveSetting('localcron', $localcron);saveSetting('interval', $interval);saveSetting('seconds', $seconds);saveSetting('loop', $loop);saveSetting('dxjc', $dxjc);saveSetting('newpc', $newpc);saveSetting('sleep', $sleep);saveSetting('sleep2', $sleep2);saveSetting('max', $max);saveSetting('server_wz', $server_wz);saveSetting('show', $frequency);$ad=$CACHE->clear();if($ad){showmsg('修改成功！',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_mail'){echo '<div class="panel-heading w h"><h3 class="panel-title">发信邮箱配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_mail">
<div class="form-group">
<label>邮箱SMTP服务器:</label><br><input type="text" class="form-control" name="mail_stmp" value="'.$conf['mail_stmp'].'">
</div>
<div class="form-group">
<label>邮箱SMTP端口:</label><br><input type="text" class="form-control" name="mail_port" value="'.$conf['mail_port'].'">
</div>
<div class="form-group">
<label>邮箱账号:</label><br><input type="text" class="form-control" name="mail_name" value="'.$conf['mail_name'].'">
</div>
<div class="form-group">
<label>邮箱密码:</label><br><input type="text" class="form-control" name="mail_pwd" value="'.$conf['mail_pwd'].'">
</div>
<font color="green">如果为QQ邮箱需先开通SMTP，且要填写QQ邮箱独立密码。邮箱SMTP服务器可以百度一下，例如QQ邮箱的即为 smtp.qq.com。邮箱SMTP端口默认为25，SSL的端口是465。</font> <a href="http://www.qqzzz.net/wiki/mail_faq.txt">查看邮件发送失败的相关解决方法</a><br/><br/>

<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form><br/>[<a href="index.php?mod=admin-set&my=mailtest">给 '.$conf['mail_name'].' 发一封测试邮件</a>]</div>';}elseif($my=='ad_mail'){$mail_name=$_POST['mail_name'];$mail_pwd=$_POST['mail_pwd'];$mail_stmp=$_POST['mail_stmp'];$mail_port=$_POST['mail_port'];if($mail_name==NULL or $mail_pwd==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('mail_name', $mail_name);saveSetting('mail_pwd', $mail_pwd);saveSetting('mail_stmp', $mail_stmp);saveSetting('mail_port', $mail_port);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='mailtest'){if(!empty($conf['mail_name'])){$result=send_mail($conf['mail_name'],'邮件发送测试。','这是一封测试邮件！<br/><br/>来自：'.$siteurl);if($result==1)showmsg('邮件发送成功！',1);else showmsg('邮件发送失败！'.$result,3);}else showmsg('您还未设置邮箱！',3);}elseif($my=='set_dama'){echo '<div class="panel-heading w h"><h3 class="panel-title">自动打码对接设置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_dama">
<div class="form-group">
<label>是否使用自动打码:</label><br><select class="form-control" name="autoyzm" default="'.$conf['autoyzm'].'"><option value="0">不使用自动打码</option><option value="1">只为VIP用户提供自动打码</option><option value="2">为全部用户提供自动打码</option></select>
</div>
<div id="frame_set" style="'.($conf['autoyzm']==0?'display:none;':null).'">
<div class="form-group">
<label>超人打码平台用户名:</label><br><input type="text" class="form-control" name="dama_user" value="'.$conf['dama_user'].'">
</div>
<div class="form-group">
<label>超人打码平台密码:</label><br><input type="text" class="form-control" name="dama_pass" value="'.$conf['dama_pass'].'">
</div>
</div>
<font color="green">自动打码目前可对接 <a href="http://www.chaorendama.com/" target="_blank">超人打码平台</a>，注册账号后充值点数，并将超人打码的用户名密码填写到上面，即可为需要输入验证码的QQ自动更新SKEY。</font><br/>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form><br/>';if($conf['dama_user'] && $conf['dama_pass']){require SYSTEM_ROOT.'chaoren.class.php';$chaoren=new Chaorendama($conf['dama_user'],$conf['dama_pass']);$result=$chaoren->get_info();echo '<h5>点数查询：</h5>剩余点数：'.$result['left'].'<br/>今日使用点数：'.$result['today'].'<br/>总共使用点数：'.$result['total'];}echo '</div>
<script>
$("select[name=\'autoyzm\']").change(function(){
	if($(this).val() == 0){
		$("#frame_set").css("display","none");
	}else{
		$("#frame_set").css("display","inherit");
	}
});
</script>';}elseif($my=='ad_dama'){$autoyzm=$_POST['autoyzm'];$dama_user=$_POST['dama_user'];$dama_pass=$_POST['dama_pass'];if($autoyzm && ($dama_user==NULL or $dama_pass==NULL)){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('autoyzm', $autoyzm);saveSetting('dama_user', $dama_user);saveSetting('dama_pass', $dama_pass);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_client'){echo '<div class="panel-heading w h"><h3 class="panel-title">安卓客户端配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_client">
<div class="form-group">
<label>APP最新版本号:</label><br><input type="text" class="form-control" name="app_version" value="'.$conf['app_version'].'">
</div>
<div class="form-group">
<label>APP更新说明:</label><br><textarea class="form-control" name="app_log" rows="4">'.$conf['app_log'].'</textarea>
</div>
<div class="form-group">
<label>是否APP启动时弹出内容:</label><br><select class="form-control" name="app_start_is" default="'.$conf['app_start_is'].'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>APP启动时弹出的内容:</label><br><textarea class="form-control" name="app_start" rows="4">'.$conf['app_start'].'</textarea>
</div>
<font color="green">（仅限已定制安卓客户端的站点）在这里可以配置安卓客户端的相关信息，以便本站会员即时更新APP到最新版本。需要更新的APK文件请放置于：网站根目录/myapp.apk 文件名一点要正确！</font><br/><br/>

<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>';}elseif($my=='ad_client'){$app_version=$_POST['app_version'];$app_log=$_POST['app_log'];$app_start_is=$_POST['app_start_is'];$app_start=$_POST['app_start'];if($app_version==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('app_version', $app_version);saveSetting('app_log', $app_log);saveSetting('app_start_is', $app_start_is);saveSetting('app_start', $app_start);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_coin'){echo '<div class="panel-heading w h"><h3 class="panel-title">币种及消费规则设定</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_coin">
<div class="form-group">
<label>虚拟币名称:</label><br><input type="text" class="form-control" name="coin_name" value="'.$conf['coin_name'].'">
</div>
<div class="form-group">
<label>一元(RMB)等于多少虚拟币:</label><br><input type="text" class="form-control" name="rules_0" value="'.$rules[0].'" maxlength="9">
</div>
<div class="form-group">
<label>注册初始送币:</label><br><input type="text" class="form-control" name="rules_1" value="'.$rules[1].'" maxlength="9">
</div>
<div class="form-group">
<label>虚拟币总开关:</label><br><select class="form-control" name="jifen" default="'.$conf['jifen'].'"><option value="1">1_开启</option><option value="0">0_关闭</option></select>
<font color="green">只有开启状态以下设置才会生效</font>
</div>
<div class="form-group">
<label>普通网址任务扣币(条/天):</label><br><input type="text" class="form-control" name="rules_2" value="'.$rules[2].'" maxlength="9">
</div>
<div class="form-group">
<label>网站签到任务扣币(条/天):</label><br><input type="text" class="form-control" name="rules_3" value="'.$rules[3].'" maxlength="9">
</div>
<div class="form-group">
<label>QQ挂机任务扣币(条/天):</label><br><input type="text" class="form-control" name="rules_4" value="'.$rules[4].'" maxlength="9">
</div>
<div class="form-group">
<label>成功协助打码送币:</label><br><input type="text" class="form-control" name="rules_5" value="'.$rules[5].'" maxlength="9">
</div>
<div class="form-group">
<label>被协助打码扣币:</label><br><input type="text" class="form-control" name="rules_6" value="'.$rules[6].'" maxlength="9">
</div>
<div class="form-group">
<label>说说刷队形扣币(每条):</label><br><input type="text" class="form-control" name="rules_7" value="'.$rules[7].'" maxlength="9">
</div>
<div class="form-group">
<label>说说刷赞扣币(每条):</label><br><input type="text" class="form-control" name="rules_8" value="'.$rules[8].'" maxlength="9">
</div>
<div class="form-group">
<label>成功邀请好友奖励:</label><br><input type="text" class="form-control" name="rules_9" value="'.$rules[9].'" maxlength="9">
</div>
<br/><br/>

<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>';}elseif($my=='ad_coin'){$coin_name=$_POST['coin_name'];$jifen=$_POST['jifen'];$rules=array(intval($_POST['rules_0']),intval($_POST['rules_1']),intval($_POST['rules_2']),intval($_POST['rules_3']),intval($_POST['rules_4']),intval($_POST['rules_5']),intval($_POST['rules_6']),intval($_POST['rules_7']),intval($_POST['rules_8']),intval($_POST['rules_9']));if($coin_name==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('coin_name', $coin_name);saveSetting('rules', implode("|",$rules));saveSetting('jifen', $jifen);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_pay'){if(!empty($conf['cronkey']))$ext='&key='.$conf['cronkey'];echo '<div class="panel-heading w h"><h3 class="panel-title">在线支付及卡密购买设定</h3></div>
<div class="panel-body box">
<ul class="nav nav-tabs"><li class="active"><a href="#">支付接口选择</a></li><li><a href="index.php?mod=admin-set&my=set_epay">彩虹易支付设置</a></li></ul>
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_pay">
<div class="form-group">
<label>是否开启卡密自助激活功能:</label><br><select class="form-control" name="open_km" default="'.$conf['open_km'].'"><option value="1">1_开启</option><option value="0">0_关闭</option></select>
</div>
<div class="form-group">
<label><img src="images/icon/alipay.ico" class="logo">支付宝即时到账接口选择:</label><br><select class="form-control" name="alipay_api" default="'.$conf['alipay_api'].'"><option value="0">0_不使用支付宝即时到账</option><option value="1">1_支付宝官方即时到账接口</option><option value="2">2_彩虹易支付免签约接口</option></select>
</div>
<div id="payapi_01" style="'.($conf['alipay_api']!=1?'display:none;':null).'">
<div class="form-group">
<label>*收款人支付宝账号:</label><br>
<input type="text" class="form-control" name="alipay_account" value="'.$conf['alipay_account'].'">
</div>
<div class="form-group">
<label>*合作者身份(PID):</label><br>
<input type="text" class="form-control" name="alipay_pid" value="'.$conf['alipay_pid'].'">
</div>
<div class="form-group">
<label>*安全校验码(Key):</label><br>
<input type="text" class="form-control" name="alipay_key" value="'.$conf['alipay_key'].'">
<a href="https://b.alipay.com/order/productDetail.htm?productId=2015110218012942" target="_blank">申请支付宝即时到账接口</a>
</div>
<div class="form-group">
<label><img src="images/icon/alipay.ico" class="logo">支付宝手机网站支付接口选择:</label><br><select class="form-control" name="alipay2_api" default="'.$conf['alipay2_api'].'"><option value="0">0_不使用支付宝手机网站支付</option><option value="1">1_支付宝官方手机网站支付接口</option></select>
</div>
<div id="payapi_04" style="'.($conf['alipay2_api']!=1?'display:none;':null).'">
<div class="form-group">
<font color="green">相关信息与以上支付宝即时到账接口一致，开启前请确保已开通支付宝手机支付，否则会导致手机用户无法支付！</font><br/>
<a href="https://b.alipay.com/order/productDetail.htm?productId=2015110218008816" target="_blank">申请支付宝手机网站支付</a>
</div>
</div>
</div>
<div class="form-group">
<label><img src="images/icon/tenpay.ico" class="logo">财付通即时到账接口选择:</label><br><select class="form-control" name="tenpay_api" default="'.$conf['tenpay_api'].'"><option value="0">0_不使用财付通即时到账</option><option value="1">1_财付通官方即时到账接口</option><option value="2">2_彩虹易支付免签约接口</option></select>
</div>
<div id="payapi_02" style="'.($conf['tenpay_api']!=1?'display:none;':null).'">
<div class="form-group">
<label>*财付通商户号:</label><br>
<input type="text" class="form-control" name="tenpay_pid" value="'.$conf['tenpay_pid'].'">
</div>
<div class="form-group">
<label>*财付通密钥:</label><br>
<input type="text" class="form-control" name="tenpay_key" value="'.$conf['tenpay_key'].'">
<a href="http://mch.tenpay.com/market/index.shtml" target="_blank">申请财付通即时到账接口</a>
</div>
</div>
<div class="form-group">
<label><img src="images/icon/qqpay.ico" class="logo">QQ钱包即时到账接口选择:</label><br><select class="form-control" name="qqpay_api" default="'.$conf['qqpay_api'].'"><option value="0">0_不使用QQ钱包即时到账</option><option value="1">1_QQ钱包官方即时到账接口</option><option value="2">2_彩虹易支付免签约接口</option></select>
</div>
<div id="payapi_05" style="'.($conf['qqpay_api']!=1?'display:none;':null).'">
<div class="form-group">
<label>*QQ钱包商户号:</label><br>
<input type="text" class="form-control" name="qqpay_pid" value="'.$conf['qqpay_pid'].'">
</div>
<div class="form-group">
<label>*QQ钱包密钥:</label><br>
<input type="text" class="form-control" name="qqpay_key" value="'.$conf['qqpay_key'].'">
<a href="https://qpay.qq.com/" target="_blank">申请QQ钱包即时到账接口</a>
</div>
</div>
<div class="form-group">
<label><img src="images/icon/wechat.ico" class="logo">微信即时到账接口选择:</label><br><select class="form-control" name="wxpay_api" default="'.$conf['wxpay_api'].'"><option value="0">0_不使用微信即时到账</option><option value="1">1_微信官方即时到账接口</option><option value="2">2_彩虹易支付免签约接口</option></select>
</div>
<div id="payapi_03" style="'.($conf['wxpay_api']!=1?'display:none;':null).'">
<font color="green">*微信即时到账相关信息配置请修改includes/wxpay/WxPay.Config.php</font>
</div>
<div id="buyrules" style="'.($conf['alipay_api']==0&&$conf['tenpay_api']==0&&$conf['qqpay_api']==0&&$conf['wxpay_api']==0?'display:none;':null).'">
<h5>在线购买价格设定：</h5>
<div class="form-group">
<label>1天试用VIP会员(元):</label><br><input type="text" class="form-control" name="rules_0" value="'.$buy_rules[0].'" maxlength="9">
</div>
<div class="form-group">
<label>1个月VIP会员(元):</label><br><input type="text" class="form-control" name="rules_1" value="'.$buy_rules[1].'" maxlength="9">
</div>
<div class="form-group">
<label>3个月VIP会员(元):</label><br><input type="text" class="form-control" name="rules_2" value="'.$buy_rules[2].'" maxlength="9">
</div>
<div class="form-group">
<label>6个月VIP会员(元):</label><br><input type="text" class="form-control" name="rules_3" value="'.$buy_rules[3].'" maxlength="9">
</div>
<div class="form-group">
<label>12个月VIP会员(元):</label><br><input type="text" class="form-control" name="rules_4" value="'.$buy_rules[4].'" maxlength="9">
</div>
<div class="form-group">
<label>永久VIP会员(元):</label><br><input type="text" class="form-control" name="rules_5" value="'.$buy_rules[5].'" maxlength="9">
</div>
<div class="form-group">
<label>1个QQ配额(元):</label><br><input type="text" class="form-control" name="rules_6" value="'.$buy_rules[6].'" maxlength="9">
</div>
<div class="form-group">
<label>3个QQ配额(元):</label><br><input type="text" class="form-control" name="rules_7" value="'.$buy_rules[7].'" maxlength="9">
</div>
<div class="form-group">
<label>5个QQ配额(元):</label><br><input type="text" class="form-control" name="rules_8" value="'.$buy_rules[8].'" maxlength="9">
</div>
<div class="form-group">
<label>10个QQ配额(元):</label><br><input type="text" class="form-control" name="rules_9" value="'.$buy_rules[9].'" maxlength="9">
</div>
</div>
<script>
$("select[name=\'alipay_api\']").change(function(){
	if($(this).val() == 1){
		$("#payapi_01").css("display","inherit");
		$("#buyrules").css("display","inherit");
	}else if($(this).val() == 2){
		$("#payapi_01").css("display","none");
		$("#buyrules").css("display","inherit");
	}else{
		$("#payapi_01").css("display","none");
		$("#buyrules").css("display","none");
	}
});
$("select[name=\'tenpay_api\']").change(function(){
	if($(this).val() == 1){
		$("#payapi_02").css("display","inherit");
		$("#buyrules").css("display","inherit");
	}else if($(this).val() == 2){
		$("#payapi_02").css("display","none");
		$("#buyrules").css("display","inherit");
	}else{
		$("#payapi_02").css("display","none");
	}
});
$("select[name=\'qqpay_api\']").change(function(){
	if($(this).val() == 1){
		$("#payapi_05").css("display","inherit");
		$("#buyrules").css("display","inherit");
	}else if($(this).val() == 2){
		$("#payapi_05").css("display","none");
		$("#buyrules").css("display","inherit");
	}else{
		$("#payapi_05").css("display","none");
	}
});
$("select[name=\'wxpay_api\']").change(function(){
	if($(this).val() == 1){
		$("#payapi_03").css("display","inherit");
		$("#buyrules").css("display","inherit");
	}else if($(this).val() == 2){
		$("#payapi_03").css("display","none");
		$("#buyrules").css("display","inherit");
	}else{
		$("#payapi_03").css("display","none");
	}
});
$("select[name=\'alipay2_api\']").change(function(){
	if($(this).val() == 1){
		$("#payapi_04").css("display","inherit");
		$("#buyrules").css("display","inherit");
	}else{
		$("#payapi_04").css("display","none");
	}
});
</script>
<br/>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form>
</div>';}elseif($my=='ad_pay'){$open_km=$_POST['open_km'];$km_link=$_POST['km_link'];$alipay_api=$_POST['alipay_api'];$alipay_pid=$_POST['alipay_pid'];$alipay_key=$_POST['alipay_key'];$alipay2_api=$_POST['alipay2_api'];$alipay_account=$_POST['alipay_account'];$alipay_name=$_POST['alipay_name'];$tenpay_api=$_POST['tenpay_api'];$tenpay_pid=$_POST['tenpay_pid'];$tenpay_key=$_POST['tenpay_key'];$qqpay_api=$_POST['qqpay_api'];$qqpay_pid=$_POST['qqpay_pid'];$qqpay_key=$_POST['qqpay_key'];$wxpay_api=$_POST['wxpay_api'];$buy_rules=array(floatval($_POST['rules_0']),floatval($_POST['rules_1']),floatval($_POST['rules_2']),floatval($_POST['rules_3']),floatval($_POST['rules_4']),floatval($_POST['rules_5']),floatval($_POST['rules_6']),floatval($_POST['rules_7']),floatval($_POST['rules_8']),floatval($_POST['rules_9']));if($open_km==NULL || $alipay_api==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('open_km', $open_km);saveSetting('km_link', $km_link);saveSetting('alipay_api', $alipay_api);saveSetting('alipay_pid', $alipay_pid);saveSetting('alipay_key', $alipay_key);saveSetting('alipay_account', $alipay_account);saveSetting('alipay2_api', $alipay2_api);saveSetting('alipay_name', $alipay_name);saveSetting('tenpay_api', $tenpay_api);saveSetting('tenpay_pid', $tenpay_pid);saveSetting('tenpay_key', $tenpay_key);saveSetting('qqpay_api', $qqpay_api);saveSetting('qqpay_pid', $qqpay_pid);saveSetting('qqpay_key', $qqpay_key);saveSetting('wxpay_api', $wxpay_api);saveSetting('buy_rules', implode("|",$buy_rules));$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_epay'){echo '<div class="panel-heading w h"><h3 class="panel-title">彩虹易支付设置</h3></div>
<div class="panel-body box">
<ul class="nav nav-tabs"><li><a href="index.php?mod=admin-set&my=set_pay">支付接口选择</a></li><li class="active"><a href="#">彩虹易支付设置</a></li></ul>';if(isset($conf['epay_pid'])&& isset($conf['epay_key'])){$data=get_curl($payapi.'api.php?act=query&pid='.$conf['epay_pid'].'&key='.$conf['epay_key'].'&url='.$_SERVER['HTTP_HOST'].'&authcode='.$authcode);$arr=json_decode($data,true);if($arr['code']==-2){showmsg('易支付KEY校验失败！');}}if($arr['code']==1){if($arr['active']==0)showmsg('该商户已被封禁，请咨询QQ1277180438');$key=substr($arr['key'],0,8).'****************'.substr($arr['key'],24,32);echo '
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_epay">
<h4>商户信息查看：</h4>
<div class="form-group">
<label>商户ID</label><br><input type="text" class="form-control" name="pid" value="'.$arr['pid'].'" disabled>
</div>
<div class="form-group">
<label>商户KEY</label><br><input type="text" class="form-control" name="key" value="'.$key.'" disabled>
</div>
<div class="form-group">
<label>商户余额</label>&nbsp;[<a href="index.php?mod=admin-set&my=set_epay_settle">查看结算记录</a>]<br><input type="text" class="form-control" name="money" value="'.$arr['money'].'" disabled>
</div>
<h4>收款账号设置：</h4>
<div class="form-group">
<label>支付宝账号</label><br><input type="text" class="form-control" name="account" value="'.$arr['account'].'">
</div>
<div class="form-group">
<label>支付宝姓名</label><br><input type="text" class="form-control" name="username" value="'.$arr['username'].'">
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form><br/>
<h4><span class="glyphicon glyphicon-info-sign"></span> 注意事项</h4>
1.支付宝账号和姓名请仔细核对，一旦错误将无法结算到账！<br/>2.每笔交易会有'.(100-$arr['money_rate']).'%的手续费，这个手续费是支付宝、微信和财付通收取的，非本接口收取。<br/>3.目前只支持支付宝结算，每天满'.$arr['settle_money'].'元自动结算，如需人工结算需要扣除'.$arr['settle_fee'].'元手续费';}else{echo '
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="set_epay_creat">
<p>该站点还未创建彩虹易支付账号</p>
<input type="submit" class="btn btn-primary btn-block" value="立即初始化彩虹易支付账号"></form>';}echo '</div>';}elseif($my=='set_epay_settle'){$data=get_curl($payapi.'api.php?act=settle&pid='.$conf['epay_pid'].'&key='.$conf['epay_key'].'&limit=20&url='.$_SERVER['HTTP_HOST'].'&authcode='.$authcode);$arr=json_decode($data,true);if($arr['code']==-2){showmsg('易支付KEY校验失败！');}echo '<div class="panel-heading w h"><h3 class="panel-title">彩虹易支付结算记录</h3></div>
	<div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>结算账号</th><th>结算金额</th><th>手续费</th><th>结算时间</th></tr></thead>
          <tbody>';foreach($arr['data'] as $res){echo '<tr><td><b>'.$res['id'].'</b></td><td>'.$res['account'].'</td><td><b>'.$res['money'].'</b></td><td><b>'.$res['fee'].'</b></td><td>'.$res['time'].'</td></tr>';}echo '</tbody>
        </table>
      </div>';}elseif($my=='set_epay_creat'){$data=get_curl($payapi.'api.php?act=add&url='.$_SERVER['HTTP_HOST'].'&authcode='.$authcode);$arr=json_decode($data,true);if($arr['code']==1){saveSetting('epay_pid', $arr['pid']);saveSetting('epay_key', $arr['key']);$CACHE->clear();exit('<script language=\'javascript\'>alert(\'恭喜你成功创建彩虹易支付账号！\');window.location.href=\'index.php?mod=admin-set&my=set_epay\';</script>');}else{showmsg($arr['msg']);}}elseif($my=='ad_epay'){$account=$_POST['account'];$username=$_POST['username'];if($account==NULL || $username==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {$data=get_curl($payapi.'api.php?act=change&pid='.$conf['epay_pid'].'&key='.$conf['epay_key'].'&account='.$account.'&username='.$username.'&url='.$_SERVER['HTTP_HOST'].'&authcode='.$authcode);$arr=json_decode($data,true);if($arr['code']==1){showmsg('修改成功!',1);}else{showmsg($arr['msg']);}}}elseif($my=='set_vip'){function vipfunc_select($func){global $vip_func;foreach(explode('|',$func)as $v){if(in_array($v, $vip_func)){return 'selected';}}return null;}echo '<div class="panel-heading w h"><h3 class="panel-title">配额与VIP规则设定</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_vip">
<h4>网站VIP规则设定：</h4>
<div class="form-group">
<label>是否开启QQ绑定VIP模式:</label><br><select class="form-control" name="vipmode" default="'.$conf['vipmode'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
<font color="green">此模式开启后，每个QQ都需要单独开通VIP，VIP卡密将只能给单个QQ续费。如果网站之前添加了QQ，开启此模式后所有QQ将变成VIP已过期</font>
</div>
<div class="form-group">
<label>多少虚拟币兑换1月VIP:（0为关闭兑换）</label><br><input type="text" class="form-control" name="coin_tovip" value="'.$conf['coin_tovip'].'" maxlength="9">
</div>
<div class="form-group">
<label>多少虚拟币兑换1天试用VIP:（0为关闭兑换）</label><br><input type="text" class="form-control" name="coin_tovip2" value="'.$conf['coin_tovip2'].'" maxlength="9">
</div>
<div class="form-group">
<label>只有VIP才能使用的功能:</label><br><select name="vip_func[]" multiple="multiple" class="form-control" style="height:100px;"><option value="wsign1" '.vipfunc_select('wsign1').'>柯林/DZ自动签到</option><option value="wsign2" '.vipfunc_select('wsign2').'>其它自动签到</option><option value="zan" '.vipfunc_select('zan').'>QQ双协议秒赞</option><option value="pl" '.vipfunc_select('pl').'>QQ双协议秒评</option><option value="shuo|zfss" '.vipfunc_select('shuo|zfss').'>QQ发说说/转发说说</option><option value="del|delly|quantu" '.vipfunc_select('del|delly|quantu').'>删说说/删留言/圈图</option><option value="ht|kjqd" '.vipfunc_select('ht|kjqd').'>花藤挂机/空间签到</option><option value="qsign" '.vipfunc_select('qsign').'>全部QQ签到类任务</option><option value="dx|mzjc" '.vipfunc_select('dx|mzjc').'>单向检测,秒赞检测</option><option value="zyzan|liuyan|gift" '.vipfunc_select('zyzan|liuyan|gift').'>互赞主页,留言等</option><option value="sz|rq|qqz" '.vipfunc_select('sz|rq|qqz').'>刷赞,人气,圈圈赞</option><option value="qqlevel" '.vipfunc_select('qqlevel').'>QQ等级代挂</option><option value="reply" '.vipfunc_select('reply').'>刷说说队形</option><option value="chat" '.vipfunc_select('chat').'>聊天室发言</option></select>
<font color="green">按住Ctrl键可多选</font>
</div>
<hr/>
<h4>网站配额规则设定：</h4>
<div class="form-group">
<label>是否开启添加QQ配额限制:</label><br><select class="form-control" name="peie_open" default="'.$conf['peie_open'].'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div id="peie_open" style="'.($conf['peie_open']==0?'display:none;':null).'">
<div class="form-group">
<label>新用户默认赠送配额:</label><br><input type="text" class="form-control" name="peie_free" value="'.$conf['peie_free'].'" maxlength="9">
</div>
<div class="form-group">
<label>多少虚拟币兑换1个配额:（0为关闭兑换）</label><br><input type="text" class="form-control" name="coin_topeie" value="'.$conf['coin_topeie'].'" maxlength="9">
</div>
</div>
<div id="peie_close" style="'.($conf['peie_open']==1?'display:none;':null).'">
<div class="form-group">
<label>普通用户QQ添加数量上限(0为不限制):</label><br>
<input type="text" class="form-control" name="qqlimit" value="'.$conf['qqlimit'].'" maxlength="10">
</div>
<div class="form-group">
<label>VIP会员QQ添加数量上限(0为不限制):</label><br>
<input type="text" class="form-control" name="qqlimit2" value="'.$conf['qqlimit2'].'" maxlength="10">
</div>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>
<script>
$("select[name=\'peie_open\']").change(function(){
	if($(this).val() == 1){
		$("#peie_open").css("display","inherit");
		$("#peie_close").css("display","none");
	}else{
		$("#peie_close").css("display","inherit");
		$("#peie_open").css("display","none");
	}
});
$("select[name=\'peie_open\']").change(function(){
	if($(this).val() == 1){
		$("#peie_open").css("display","inherit");
		$("#peie_close").css("display","none");
	}else{
		$("#peie_close").css("display","inherit");
		$("#peie_open").css("display","none");
	}
});
</script>';}elseif($my=='ad_vip'){$coin_tovip=$_POST['coin_tovip'];$coin_tovip2=$_POST['coin_tovip2'];$qqlimit=$_POST['qqlimit'];$qqlimit2=$_POST['qqlimit2'];$vip_sys=$_POST['vip_sys'];$vip_func=implode("|",$_POST['vip_func']);$peie_open=$_POST['peie_open'];$peie_free=$_POST['peie_free'];$coin_topeie=$_POST['coin_topeie'];$vipmode =$_POST['vipmode'];if($peie_open==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('coin_tovip', $coin_tovip);saveSetting('coin_tovip2', $coin_tovip2);saveSetting('qqlimit', $qqlimit);saveSetting('qqlimit2', $qqlimit2);saveSetting('vip_coin', '1');saveSetting('vip_func', $vip_func);saveSetting('vip_sys', $vip_sys);saveSetting('peie_open', $peie_open);saveSetting('peie_free', $peie_free);saveSetting('coin_topeie', $coin_topeie);saveSetting('vipmode', $vipmode);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_qd'){echo '<div class="panel-heading w h"><h3 class="panel-title">每日签到与说说尾巴设置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_qd">
<div class="form-group">
<label>签到领VIP:(多少虚拟币换一天VIP，0为不兑换)</label><br><input type="text" class="form-control" name="qd_jifen" value="'.$conf['qd_jifen'].'" maxlength="9">
</div>
<div class="form-group">
<label>用户首次签到获得体验VIP的天数(0为不获得)</label><br><input type="text" class="form-control" name="qd_vipts" value="'.$conf['qd_vipts'].'" maxlength="9">
</div>
<div class="form-group">
<label>每日签到获取虚拟币</label><br><input type="text" class="form-control" name="qd_coin" value="'.$conf['qd_coin'].'" maxlength="9">
</div>
<div class="form-group">
<label>网站签到发说说内容(留空则不发说说):</label><br>
<input type="text" class="form-control" name="qd_ss" value="'.$conf['qd_ss'].'">
</div>
<div class="form-group">
<label>说说图片[Url]:</label><br>
<input type="text" class="form-control" name="qd_pturl" value="'.$conf['qd_pturl'].'">
</div>
<div class="form-group">
<label>自动发表说说尾巴:</label><br>
<input type="text" class="form-control" name="shuotail" value="'.$conf['shuotail'].'">
<font color="green">说说尾巴中包含广告可能会造成禁言</font>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form><br/>
<font color="green">签到领VIP页面,请自行添加地址到首页合适位置,地址为：index.php?mod=qd</font>
</div>';}elseif($my=='ad_qd'){$qd_jifen=$_POST['qd_jifen'];$qd_vipts =$_POST['qd_vipts'];$qd_coin =$_POST['qd_coin'];$qd_ss =$_POST['qd_ss'];$qd_pturl =$_POST['qd_pturl'];$shuotail =$_POST['shuotail'];if($qd_jifen==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('qd_jifen', $qd_jifen);saveSetting('qd_vipts', $qd_vipts);saveSetting('qd_coin', $qd_coin);saveSetting('qd_ss', $qd_ss);saveSetting('qd_pturl', $qd_pturl);saveSetting('shuotail', $shuotail);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_daili'){echo '<div class="panel-heading w h"><h3 class="panel-title">代理拿卡价格配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_daili">
<div class="form-group">
<label>一元(RMB)等于多少虚拟币:</label><br><input type="text" class="form-control" name="rules_0" value="'.$daili_rules[0].'" maxlength="9">
</div>
<div class="form-group">
<label>VIP月卡(RMB/个):</label><br><input type="text" class="form-control" name="rules_1" value="'.$daili_rules[1].'" maxlength="9">
</div>
<div class="form-group">
<label>VIP季度卡(RMB/个):</label><br><input type="text" class="form-control" name="rules_2" value="'.$daili_rules[2].'" maxlength="9">
</div>
<div class="form-group">
<label>VIP半年卡(RMB/个):</label><br><input type="text" class="form-control" name="rules_3" value="'.$daili_rules[3].'" maxlength="9">
</div>
<div class="form-group">
<label>VIP年卡(RMB/个):</label><br><input type="text" class="form-control" name="rules_4" value="'.$daili_rules[4].'" maxlength="9">
</div>
<div class="form-group">
<label>VIP永久卡(RMB/个):</label><br><input type="text" class="form-control" name="rules_5" value="'.$daili_rules[5].'" maxlength="9">
</div>
<div class="form-group">
<label>1个配额价格(RMB):</label><br><input type="text" class="form-control" name="rules_6" value="'.$daili_rules[6].'" maxlength="9">
</div>
<div class="form-group">
<label>3个配额价格(RMB):</label><br><input type="text" class="form-control" name="rules_7" value="'.$daili_rules[7].'" maxlength="9">
</div>
<div class="form-group">
<label>5个配额价格(RMB):</label><br><input type="text" class="form-control" name="rules_8" value="'.$daili_rules[8].'" maxlength="9">
</div>
<div class="form-group">
<label>10个配额价格(RMB):</label><br><input type="text" class="form-control" name="rules_9" value="'.$daili_rules[9].'" maxlength="9">
</div>
<br/><br/>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>';}elseif($my=='ad_daili'){$daili_rules=array(intval($_POST['rules_0']),intval($_POST['rules_1']),intval($_POST['rules_2']),intval($_POST['rules_3']),intval($_POST['rules_4']),intval($_POST['rules_5']),intval($_POST['rules_6']),intval($_POST['rules_7']),intval($_POST['rules_8']),intval($_POST['rules_9']));if($daili_rules==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('daili_rules', implode("|",$daili_rules));$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_api'){if($is_fenzhan==1&&$siterow['api']==0)showmsg('当前分站没有权限修改API设置。');echo '<div class="panel-heading w h"><h3 class="panel-title">签到/QQ挂机模块API配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_api">
<div class="form-group">
<label>QQ等级代挂API接口:</label><br/><select class="form-control" name="qqlevelapi" default="'.$qqlevelapi.'"><option value="1">Ｖ８稳定代挂接口(荐)</option><option value="3">秒赞吧科技全新代挂(荐)</option><option value="10">云挂宝代挂接口</option><option value="11">爱代挂·代挂接口</option><option value="13">138低价稳定代挂接口</option><option value="8">521代挂接口</option><option value="7">稳挂宝代挂接口</option><option value="14">91代挂接口</option><option value="12">新领域代挂接口</option><option value="4">小瑞代挂接口</option><option value="5">鱼儿飞代挂通用接口</option><option value="6">自定义API</option></select>
<div id="frame_set2" style="'.($conf['qqlevelapi']!=6?'display:none;':null).'">
<div class="form-group">
<label>自定义QQ等级代挂API接口:</label><br><input type="text" class="form-control" name="qqlevelapis" value="'.$conf['qqlevelapis'].'" placeholder="http://daigua.qqzzz.net/">
<font color="red">警告：请勿使用非官方认证的代挂接口，以免QQ被盗</font>
</div>
</div>
<font color="green">更改API会导致之前购买的代挂激活码全部无法使用。提示：更改代挂接口之后别忘了更改代挂页面公告</font></div>
<div class="form-group">
<label>签到API服务器:</label><br/><select class="form-control" name="apiserver" default="'.$conf['apiserver'].'"><option value="1">彩虹官方API一号</option><option value="2">彩虹官方API二号</option><option value="3">彩虹官方API三号</option><option value="0">本地API</option></select>
<font color="green">此为各大网站签到类任务的API（不包括QQ里面的签到）</font></div>
<div class="form-group">
<label>QQ挂机类API服务器:</label><br/><select class="form-control" name="qqapiid" default="'.$conf['qqapiid'].'"><option value="0">本地API(推荐)</option><option value="1">官方API一号(小鸟云)需授权</option><option value="2">官方API二号(腾讯云)需授权</option><option value="7">官方API三号(百度云)需授权</option><option value="12">官方API四号(百度云)需授权</option><option value="13">官方API五号(腾讯云)需授权</option><option value="9">秒赞吧挂机API(腾讯云)需授权</option><option value="5">Ｖ８挂机API(需授权)</option><option value="6">幻谷挂机API(需授权)</option><option value="10">凉城挂机API(需授权)</option><option value="11">天成挂机API(需授权)</option><option value="8">随风挂机API(免授权)</option><option value="3">自定义API</option></select>
<div id="frame_set" style="'.($conf['qqapiid']!=3?'display:none;':null).'">
<div class="form-group">
<label>自定义QQ挂机API服务器地址:</label><br><input type="text" class="form-control" name="myqqapi" value="'.$conf['myqqapi'].'" placeholder="http://cloud.sgwap.net/">
</div>
<font color="red"><a href="http://www.qqzzz.net/download.php?remote=true&rand='.time().'">彩虹云任务QQ挂机类API远程版源码(zip)</a></font>&nbsp;<font color="green">多个API地址之间用 | 隔开</font>
</div>
<font color="green">建议选本地API，因为QQ的数量和空间稳定性是呈负相关的。如果你的空间实在无法运行QQ挂机类任务可以尝试使用官方API。官方API是需要域名授权的，授权请联系QQ1277180438</font></div>
<div class="form-group">
<label>QQ登录API服务器:</label><br/><select class="form-control" name="qqloginid" default="'.$conf['qqloginid'].'"><option value="1">官方API一号(ECS)</option><option value="2">官方API二号(SAE)</option><option value="0">本地API</option></select>
<font color="green">QQ登录即为添加QQ与更新sid。如果在添加QQ时出现登录成功但获取sid失败，请在此处更换QQ登录API</font></div>
<div class="form-group">
<label>QQ代刷API接口:</label><br/><select class="form-control" name="shuaapi" default="'.$shuaapiid.'"><option value="1">秒赞吧代刷接口</option><option value="2">易网络代刷接口</option><option value="3">自定义API</option></select>
<div id="frame_set3" style="'.($conf['shuaapi']!=3?'display:none;':null).'">
<div class="form-group">
<label>自定义QQ代刷API接口:</label><br><input type="text" class="form-control" name="shuaapis" value="'.$conf['shuaapis'].'" placeholder="http://daigua.qqzzz.net/">
</div>
</div>
</div>
<div class="form-group">
<label>秒赞检测与获取好友列表API:</label><br/><select class="form-control" name="mzjc_api" default="'.$conf['mzjc_api'].'"><option value="0">本地API</option><option value="1">远程API</option></select>
<font color="green">当本地获取好友列表或秒赞检测无法使用时可以尝试更换远程API</font></div>
<div class="form-group">
<label>单向检测与移动好友API:</label><br/><select class="form-control" name="dx_api" default="'.$conf['dx_api'].'"><option value="0">本地API</option><option value="1">远程API</option></select>
<font color="green">当单向删除好友与移动好友无法使用时可以尝试更换远程API</font></div>
<div class="form-group">
<label>发信API服务器:</label><br/><select class="form-control" name="mail_api" default="'.$conf['mail_api'].'"><option value="0">本地发信</option><option value="1">官方API一号</option><option value="2">官方API二号</option><option value="3">官方API三号</option><option value="4">秒赞吧发信API</option></select>
<font color="green">使用此API后，网站将通过官方发信API发送邮件。建议在当前空间不支持发送邮件时使用。</font></div>
<div class="form-group">
<label>圈圈赞接口:</label><br/>
<input type="text" class="form-control" name="qqz_api" value="'.$conf['qqz_api'].'" placeholder="http://61.135.169.125:3331/">
<font color="green">需精确到端口号，填写样例：http://61.135.169.125:3331/ 留空则使用官方API，如果根目录存在quan.php则会优先使用quan.php</font></div>
<div class="form-group">
<label>静态资源CDN:</label><br/><select class="form-control" name="cdnserver" default="'.$conf['cdnserver'].'"><option value="0">不使用CDN</option><option value="1">秒赞吧-CDN(腾讯云)</option><option value="2">彩虹-CDN(百度云)</option><option value="3">千序-CDN(腾讯云)</option><option value="4">千序SSL-CDN(七牛云)</option></select>
<font color="green">使用CDN可以加速静态资源访问速度，适合速度较慢的主机。HTTPS不支持使用CDN</font></div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form></div>
<script>
$("select[name=\'qqapiid\']").change(function(){
	if($(this).val() == 3){
		$("#frame_set").css("display","inherit");
	}else{
		$("#frame_set").css("display","none");
	}
});
$("select[name=\'qqlevelapi\']").change(function(){
	if($(this).val() == 6){
		$("#frame_set2").css("display","inherit");
	}else{
		$("#frame_set2").css("display","none");
	}
});
$("select[name=\'shuaapi\']").change(function(){
	if($(this).val() == 3){
		$("#frame_set3").css("display","inherit");
	}else{
		$("#frame_set3").css("display","none");
	}
});
</script>
';}elseif($my=='ad_api'){if($is_fenzhan==1&&$siterow['api']==0)showmsg('当前分站没有权限修改API设置。');$qqlevelapi=$_POST['qqlevelapi'];$qqlevelapis=$_POST['qqlevelapis'];$shuaapi=$_POST['shuaapi'];$shuaapis=$_POST['shuaapis'];$apiserver=$_POST['apiserver'];$qqapiid=$_POST['qqapiid'];$qqloginid=$_POST['qqloginid'];$mail_api=$_POST['mail_api'];$mzjc_api=$_POST['mzjc_api'];$dx_api=$_POST['dx_api'];$myqqapi=$_POST['myqqapi'];$qqz_api=$_POST['qqz_api'];$cdnserver=$_POST['cdnserver'];if($apiserver==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('qqlevelapi', $qqlevelapi);saveSetting('qqlevelapis', $qqlevelapis);saveSetting('shuaapi', $shuaapi);saveSetting('shuaapis', $shuaapis);saveSetting('apiserver', $apiserver);saveSetting('qqapiid', $qqapiid);saveSetting('qqloginid', $qqloginid);saveSetting('mail_api', $mail_api);saveSetting('mzjc_api', $mzjc_api);saveSetting('dx_api', $dx_api);saveSetting('myqqapi', $myqqapi);saveSetting('qqz_api', $qqz_api);saveSetting('cdnserver', $cdnserver);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_ui'){echo '<div class="panel-heading w h"><h3 class="panel-title">网站界面风格配置</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_ui">
<div class="form-group">
<label>默认首页设置:</label><br>
<select class="form-control" name="ui_index" default="'.$conf['ui_index'].'"><option value="1">炫彩风格首页</option><option value="0">用户中心作为默认首页</option><option value="2">手机版以用户中心为首页</option></select>
<font color="green">如需修改炫彩风格首页模板请编辑template/Home/index.php</font>
</div>
<div class="form-group">
<label>网站皮肤样式:</label><br>
<select class="form-control" name="ui_style" default="'.$conf['ui_style'].'"><option value="1">V7新版界面(深蓝)</option><option value="7">V7新版界面(浅绿)</option><option value="2">Bootstrap原版</option><option value="3">Skeumorphism UI</option><option value="4">Metro风格Flat UI</option><option value="5">高仿谷歌扁平样式</option><option value="6">Windows8 Metro UI</option></select></div>
<div class="form-group">
<label>手机版皮肤样式:</label><br>
<select class="form-control" name="ui_style2" default="'.$conf['ui_style2'].'"><option value="1">与电脑版相同</option><option value="2">Bootstrap原版</option><option value="3">Skeumorphism UI</option><option value="4">Metro风格Flat UI</option><option value="5">高仿谷歌扁平样式</option><option value="6">Windows8 Metro UI</option></select></div>
<div id="ui_flat" style="'.($conf['ui_style']!=1?'display:none;':null).'">
<div class="form-group">
<label>按钮与边框整体风格:</label><br><select class="form-control" name="ui_flat" default="'.$conf['ui_flat'].'"><option value="0">扁平化</option><option value="1">立体化</option></select>
</div>
</div>
<div id="ui_user" style="'.($conf['ui_style']==1&&$conf['ui_style2']==1?'display:none;':null).'">
<div class="form-group">
<label>是否使用V6经典版用户中心:</label><br>
<select class="form-control" name="ui_user" default="'.$conf['ui_user'].'"><option value="0">否</option><option value="1">是</option></select>
</div>
</div>
<hr/>
<div class="form-group">
<label>网页浮动音乐播放器:</label><br><select class="form-control" name="limhplayer" default="'.$conf['limhplayer'].'"><option value="0">0_关闭</option><option value="1">1_明月浩空播放器(精选专辑)</option><option value="2">2_明月浩空播放器(自定义歌单)</option><option value="3">3_网易云音乐播放器</option></select>
<font color="green">网站左下角的HTML5浮动音乐播放器</font>
<div id="limh_sq" style="'.($conf['limhplayer']!=2?'display:none;':null).'">
<a href="index.php?mod=musicset" target="_blank">点击进入设置播放列表</a>
</div>
</div>
<div id="musicid" style="'.($conf['limhplayer']!=3?'display:none;':null).'">
<div class="form-group">
<label>网易云音乐歌单ID:</label><br/>
<input type="text" class="form-control" name="musicid" value="'.$conf['musicid'].'" placeholder="填写歌单ID">
<font color="green">例如，其中红色部分为歌单ID：http://music.163.com/#/playlist?id=</font><font color="red">34238509</font>
</div>
</div>
<div class="form-group">
<label>是否开启pjax控件:</label><br><select class="form-control" name="ui_pjax" default="'.$conf['ui_pjax'].'"><option value="0">0_关闭</option><option value="1">1_开启</option></select>
<font color="green">开启pjax控件可以实现免刷新切换页面，同时能够让背景音乐不间断播放，但是不支持低端浏览器。</font>
</div>
<div class="form-group">
<label>是否开启页面加载效果:</label><br><select class="form-control" name="ui_loading" default="'.$conf['ui_loading'].'"><option value="0">0_关闭</option><option value="1">1_开启</option></select>
</div>
<div class="form-group">
<label>是否开启列表半透明:</label><br><select class="form-control" name="ui_opacity" default="'.$conf['ui_opacity'].'"><option value="0">0_关闭</option><option value="1">1_开启</option></select>
</div>
<div class="form-group">
<label>网站首页背景音乐:</label><br/>
<input type="text" class="form-control" name="ui_backmusic" value="'.$conf['ui_backmusic'].'" placeholder="填写音乐的URL">
</div>
<script>
$("select[name=\'ui_style\']").change(function(){
	if($(this).val() == 1){
		$("#ui_flat").css("display","inherit");
		$("#ui_user").css("display","none");
	}else{
		$("#ui_flat").css("display","none");
		$("#ui_user").css("display","inherit");
	}
});
$("select[name=\'ui_style2\']").change(function(){
	if($(this).val() == 1 && $("select[name=\'ui_style\']").val()==1){
		$("#ui_flat").css("display","inherit");
		$("#ui_user").css("display","none");
	}else{
		$("#ui_flat").css("display","none");
		$("#ui_user").css("display","inherit");
	}
});
$("select[name=\'limhplayer\']").change(function(){
	if($(this).val() == 2){
		$("#limh_sq").css("display","inherit");
		$("#musicid").css("display","none");
	}else if($(this).val() == 3){
		$("#limh_sq").css("display","none");
		$("#musicid").css("display","inherit");
	}else{
		$("#limh_sq").css("display","none");
		$("#musicid").css("display","none");
	}
});
</script>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form>
<br/>小工具：<a href="http://pan.cccyun.cc/" target="_blank">外链网盘</a>｜<a href="http://link.hhtjim.com/" target="_blank">外链转换工具</a></div>';}elseif($my=='ad_ui'){$ui_index=$_POST['ui_index'];$ui_flat=$_POST['ui_flat'];$ui_user=$_POST['ui_user'];$limhplayer=$_POST['limhplayer'];$limh_domain=$_POST['limh_domain'];$limh_sq=$_POST['limh_sq'];$ui_pjax=$_POST['ui_pjax'];$ui_loading=$_POST['ui_loading'];$ui_style=$_POST['ui_style'];$ui_style2=$_POST['ui_style2'];$ui_opacity=$_POST['ui_opacity'];$ui_backmusic=$_POST['ui_backmusic'];$musicid=$_POST['musicid'];if($ui_flat==NULL or $limhplayer==NULL or $ui_pjax==NULL){showmsg('保存错误,请确保每项都不为空!',3);}else {saveSetting('ui_index', $ui_index);saveSetting('ui_flat', $ui_flat);saveSetting('ui_user', $ui_user);saveSetting('limhplayer', $limhplayer);saveSetting('limh_domain', $limh_domain);saveSetting('limh_sq', $limh_sq);saveSetting('ui_pjax', $ui_pjax);saveSetting('ui_loading', $ui_loading);saveSetting('ui_style', $ui_style);saveSetting('ui_style2', $ui_style2);saveSetting('ui_opacity', $ui_opacity);saveSetting('ui_backmusic', $ui_backmusic);saveSetting('musicid', $musicid);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}}elseif($my=='set_oauth'){$oauth_option=explode("|",$conf['oauth_option']);echo '<div class="panel-heading w h"><h3 class="panel-title">百度社会化登录组件</h3></div>
<div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_oauth">
<div class="form-group">
<label>是否启用百度社会化登录:</label><br>
<select class="form-control" name="oauth_open" default="'.$conf['oauth_open'].'"><option value="0">0_关闭</option><option value="1">1_开启</option><option value="2">2_开启(并关闭普通注册)</option></select></div>
<div id="oauth_option" style="'.($conf['oauth_open']==0?'display:none;':null).'">
<div class="form-group">
<label><input type="checkbox" name="oauth_option[]" value="qqdenglu" '.((in_array('qqdenglu',$oauth_option))?'checked':null).'> 开启ＱＱ登录</label><br/>
<label><input type="checkbox" name="oauth_option[]" value="baidu" '.((in_array('baidu',$oauth_option))?'checked':null).'> 开启百度登录</label><br/>
<label><input type="checkbox" name="oauth_option[]" value="sinaweibo" '.((in_array('sinaweibo',$oauth_option))?'checked':null).'> 开启新浪微博登录</label><br/>
<label><input type="checkbox" name="oauth_option[]" value="qqweibo" '.((in_array('qqweibo',$oauth_option))?'checked':null).'> 开启腾讯微博登录</label><br/>
<label><input type="checkbox" name="oauth_option[]" value="renren" '.((in_array('renren',$oauth_option))?'checked':null).'> 开启人人网登录</label><br/>
<label><input type="checkbox" name="oauth_option[]" value="kaixin" '.((in_array('kaixin',$oauth_option))?'checked':null).'> 开启开心网登录</label><br/>
</div>
<div class="form-group">
<label>新用户社会化账号登录之后:</label><br>
<select class="form-control" name="oauth_act" default="'.$conf['oauth_act'].'"><option value="1">以默认用户名直接注册本站账号</option><option value="0">自行输入用户名或绑定已有账号</option></select></div>
</div>
<script>
$("select[name=\'oauth_open\']").change(function(){
	if($(this).val() == 0){
		$("#oauth_option").css("display","none");
	}else{
		$("#oauth_option").css("display","inherit");
	}
});
</script>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form><br/>
<font color="green">开启百度社会化登录组件后，在登录界面可以使用以上社会化账号登录本站。</font>
</div>';}elseif($my=='ad_oauth'){$oauth_open=$_POST['oauth_open'];$oauth_option=$_POST['oauth_option'];$oauth_act=$_POST['oauth_act'];saveSetting('oauth_open', $oauth_open);saveSetting('oauth_option', implode("|",$oauth_option));saveSetting('oauth_act', $oauth_act);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}elseif($my=='syskey'){echo '<div class="panel-heading w h"><h3 class="panel-title">SYS_KEY查看</h3></div><div class="panel-body box">
<input type="text" value="'.SYS_KEY.'" class="form-control" disabled><br/>
<font color="green">SYS_KEY是安装时随机生成的，网站用于加密数据的密钥，请不要随意泄露。</font>
</div><br/>';}elseif($my=='set_gg'){echo '<div class="panel-heading w h"><h3 class="panel-title">广告与公告配置</h3></div><div class="panel-body box">
<form action="index.php?mod=admin-set" method="POST"><input type="hidden" name="my" value="ad_gg">
<div class="form-group">
<label>首页公告栏:</label><br><textarea class="form-control" name="gg" rows="6">'.htmlspecialchars($conf['gg']).'</textarea>
</div>
<div class="form-group">
<label>首页底部:</label><br><textarea class="form-control" name="bottom" rows="6">'.htmlspecialchars($conf['bottom']).'</textarea>
</div>
<div class="form-group">
<label>自助购买页公告:</label><br><textarea class="form-control" name="shop" rows="4">'.htmlspecialchars($conf['shop']).'</textarea>
</div>
<div class="form-group">
<label>代挂页面公告:</label><br><textarea class="form-control" name="qqlevel" rows="4">'.htmlspecialchars($conf['qqlevel']).'</textarea>
</div>
<div class="form-group">
<label>全局底部排版:</label><br><textarea class="form-control" name="footer" rows="4">'.htmlspecialchars($conf['footer']).'</textarea>
</div>
<div class="form-group">
<label>底部滚动字幕:</label><br><textarea class="form-control" name="marquee" rows="4">'.htmlspecialchars($conf['marquee']).'</textarea>
</div>
<div class="form-group">
<label>代刷业务卡密购买地址:</label><br/>
<input type="text" class="form-control" name="shua_kami" value="'.$conf['shua_kami'].'" placeholder="如不填写则显示默认购买地址">
</div>
<input type="submit" class="btn btn-primary btn-block"
value="确定修改"></form></div>';}elseif($my=='ad_gg'){$gg=$_POST['gg'];$bottom=$_POST['bottom'];$shop=$_POST['shop'];$qqlevel=$_POST['qqlevel'];$footer=$_POST['footer'];$marquee=$_POST['marquee'];saveSetting('gg', $gg);saveSetting('bottom', $bottom);saveSetting('shop', $shop);saveSetting('qqlevel', $qqlevel);saveSetting('footer', $footer);saveSetting('marquee', $marquee);saveSetting('shua_kami', $_POST['shua_kami']);$ad=$CACHE->clear();if($ad){showmsg('修改成功!',1);}else{showmsg('修改失败!'.$DB->error(),4);}}elseif($my=='renew'){if(isset($_GET['days'])){$vipdate =date("Y-m-d", strtotime("+ {$_GET['days']} days"));$DB->query("update ".DBQZ."_qq set vip='1',vipdate='$vipdate' where vipdate<'".date("Y-m-d")."'");echo '<div class="panel-heading w h"><h3 class="panel-title">一键续费网站所有QQ</h3></div><div class="panel-body box">
一键续期成功！已成功给'.$DB->affected().'个QQ续期'.$_GET['days'].'天VIP。
</div><br/>';}else{echo <<<HTML
<script type="text/javascript">
var days=prompt("请输入要续期的天数","")
if (days!=null && days!="")
{
	window.location.href='index.php?mod=admin-set&my=renew&days='+days
}
</script>
HTML;
}}elseif($my == 'qunfa'){echo '<div class="panel-heading w h"><h3 class="panel-title">本站所有用户邮箱导出</h3></div>';echo '<div class="panel-body box"><div id="row">';$rs=$DB->query("select * from ".DBQZ."_user where email is not null order by userid desc");while ($myrow =$DB->fetch($rs)){echo $myrow['email'].',';}echo '</div></div>';}elseif($my=='logo'){echo '<div class="panel-heading w h"><h3 class="panel-title">更改系统LOGO</h3></div><div class="panel-body box">';if($_POST['s']==1){$extension=explode('.',$_FILES['file']['name']);if (($length =count($extension))> 1){$ext =strtolower($extension[$length - 1]);}if($ext=='png'||$ext=='gif'||$ext=='jpg'||$ext=='jpeg'||$ext=='bmp')$ext='png';if($is_fenzhan)$logoname =DBQZ;else $logoname ='';copy($_FILES['file']['tmp_name'], ROOT.'images/'.$logoname.'logo.'.$ext);echo '成功上传文件!<br>（可能需要清空浏览器缓存才能看到效果）';}if(!file_exists(ROOT.'images/'.DBQZ.'logo.png'))$logoname='';else $logoname =DBQZ;echo '<form action="index.php?mod=admin-set&my=logo" method="POST" enctype="multipart/form-data"><label for="file"></label><input type="file" name="file" id="file" /><input type="hidden" name="s" value="1" /><br><input type="submit" class="btn btn-primary btn-block" value="确认更改LOGO" /></form><br>现在的LOGO：<br><img src="images/'.$logoname.'logo.png?r='.rand(10000,99999).'">';echo '</div>';}elseif($my == 'bj'){echo '<div class="panel-heading w h"><h3 class="panel-title">更改网站背景图片</h3></div><div class="panel-body box">';if($_POST['s']==1){saveSetting('ui_background', $_POST['ui_background']);saveSetting('ui_background2', $_POST['ui_background2']);saveSetting('ui_bing', $_POST['ui_bing']);$CACHE->clear();$extension=explode('.',$_FILES['file']['name']);if (($length =count($extension))> 1){$ext =strtolower($extension[$length - 1]);}if($ext=='png'||$ext=='gif'||$ext=='jpg'||$ext=='jpeg'||$ext=='bmp')$ext='png';if($is_fenzhan)$bjname =DBQZ;else $bjname ='';copy($_FILES['file']['tmp_name'], ROOT.'images/'.$bjname.'bj.'.$ext);echo '成功上传文件!<br>（可能需要清空浏览器缓存才能看到效果）';}echo '<form action="index.php?mod=admin-set&my=bj" method="POST" enctype="multipart/form-data">
<input type="hidden" name="s" value="1"/>
<div class="form-group">
<label for="file"></label>
<input type="file" name="file" id="file" class="form-control"/>
</div>
<div class="form-group">
<label>显示效果:</label><br><select class="form-control" name="ui_background" default="'.$conf['ui_background'].'"><option value="0">纵向和横向重复</option><option value="1">横向重复,纵向拉伸</option><option value="2">纵向重复,横向拉伸</option><option value="3">不重复,全屏拉伸</option></select>
</div>
<div class="form-group">
<label>是否固定:</label><br><select class="form-control" name="ui_background2" default="'.$conf['ui_background2'].'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>是否使用<a href="//cn.bing.com/" target="_blank">Bing每日壁纸</a></label><br>
<select class="form-control" name="ui_bing" default="'.$conf['ui_bing'].'"><option value="0">否</option><option value="1">是</option></select>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确认更改背景" />
</form>
<br>现在的背景：<br><img src="images/'.$bjname.'bj.png?r='.rand(10000,99999).'" style="max-width:100%"><br>
<a href="index.php?mod=admin-set&my=bj2">[更改首页背景图片]</a>';echo '</div>';}elseif($my == 'bj2'){echo '<div class="panel-heading w h"><h3 class="panel-title">更改首页背景图片</h3></div><div class="panel-body box">';if($_POST['s']==1){$CACHE->clear();copy($_FILES['file']['tmp_name'], ROOT.'assets/img/banner.jpg');echo '成功上传文件!<br>（可能需要清空浏览器缓存才能看到效果）';}echo '<form action="index.php?mod=admin-set&my=bj2" method="POST" enctype="multipart/form-data">
<input type="hidden" name="s" value="1"/>
<div class="form-group">
<label for="file"></label>
<input type="file" name="file" id="file" class="form-control"/>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确认更改背景" />
</form>
<br>自定义首页背景必须在[挂机API设置]里面选择不使用CDN才能生效。
<br>现在的背景：<br><img src="assets/img/banner.jpg?r='.rand(10000,99999).'" style="max-width:100%"><br>';echo '</div>';}elseif($my == 'info'){echo '<div class="panel-heading w h"><h3 class="panel-title">程序信息</h3></div>';echo '<div class="panel-body box">';echo '版权所有：消失的彩虹海<br/>ＱＱ：1277180438<br/>当前版本：V7.0 (Build '.VERSION.')<br/>官方网站：<a href="http://blog.cccyun.cc">blog.cccyun.cc</a><br/><a href="http://www.qqzzz.net">www.qqzzz.net</a><br/>开放API：<a href="http://www.qqzzz.net/wiki/client_api2.txt">http://www.qqzzz.net/wiki/client_api2.txt</a>
';echo '</div>';}elseif($my == 'help'){echo '
<div class="panel-heading w h"><h3 class="panel-title">任务监控说明</h3></div>';echo '<div class="panel-body box">';if(!empty($conf['cronkey']))$ext='&key='.$conf['cronkey'];echo '你可以根据需要监控以下文件：<br/><font color=brown>';if(OPEN_QQOL==1)echo "<li class=\"list-group-item\">{$siteurl}cron/qzonetask.php?sys=1{$ext}</li>";if(OPEN_QQOL==1)echo "<li class=\"list-group-item\">{$siteurl}cron/zantask.php?sys=1{$ext}</li>";if(OPEN_QQOL==1)echo "<li class=\"list-group-item\">{$siteurl}cron/qsigntask.php?sys=1{$ext}</li>";if(OPEN_SIGN==1)echo "<li class=\"list-group-item\">{$siteurl}cron/wsigntask.php?sys=1{$ext}</li>";if(OPEN_CRON==1)for($i=1;$i<=$conf['server_wz'];$i++){echo "<li class=\"list-group-item\">{$siteurl}cron/wztask.php?sys={$i}{$ext}</li>";}if(OPEN_QQOL==1)echo "<li class=\"list-group-item\">{$siteurl}cron/newsid.php?{$ext}</li>";echo '
</font>监控完监控网址后即可执行任务！<br/>
<font color="red">如果你的空间开启了防CC攻击，或者使用了加速乐等CDN，请将本站服务器IP:'.$_SERVER['SERVER_ADDR'].'加入到白名单中或者在任务运行配置中开启本地回路，否则任务将无法执行。</font><br/>
推荐监控系统:<br/>
<a target="_blank" href="http://cronx.sgwap.net/">http://cronx.sgwap.net/</a><br/>
<a target="_blank" href="http://www.qqzzz.net/">http://www.qqzzz.net/</a><br/>
<a target="_blank" href="http://jk.dg96.cn/">http://jk.dg96.cn/</a><br/>
<a target="_blank" href="http://52miaozan.cn/">http://52miaozan.cn/</a><br/>
<a target="_blank" href="http://ygjk.qqzzz.net/">http://ygjk.qqzzz.net/</a><br/>
';echo '</div>';}echo '</div>
<script>
var items = $("select[default]") || 0;
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default")||0);
}
</script>';}else {showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);}include TEMPLATE_ROOT.'foot.php';?>