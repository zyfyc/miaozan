<?php 
if (!defined('IN_CRONLITE')) {
    die;
}
$title = '财付通登录';
$breadcrumb = '<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-cogs"></i>财付通登录</a></li>';
include TEMPLATE_ROOT . 'head.php';
$my = isset($_POST['my']) ? $_POST['my'] : $_GET['my'];
echo '<div class="col-lg-8 col-sm-10 col-xs-12 center-block" role="main">';
if ($isadmin == 1) {
    if ($_POST['type'] == 'edit') {
        $qq = daddslashes($_POST['tenpay_account']);
        $pwd = md5($_POST['tenpay_pwd']);
        $sig = $_POST['sig'];
        $code = $_POST['code'];
        include SYSTEM_ROOT . 'tenpay/tenpaycore.php';
        $qlogin = new tenpay($qq, $pwd, $code, $sig);
        $arr = json_decode($qlogin->json, true);
        if (array_key_exists('code', $qlogin)) {
            if ($arr['code'] == -1) {
                $code = 1;
                $sig = $arr['sig'];
                $loginsig = $arr['vsig'];
            } elseif ($arr['code'] == -3) {
                $msg = $arr['msg'];
            } else {
                $cookie = $arr['cookies'];
                saveSetting('tenpay_account', $qq);
                saveSetting('tenpay_pwd', $pwd);
                saveSetting('tenpay_cookies', urlencode($arr['cookies']));
                $CACHE->clear();
                die('<script language="javascript">alert(\'登录成功,保存成功!\');history.go(-1);</script>');
            }
        }
    } elseif ($_POST['type'] == 'mail') {
        $tenpay_mail = daddslashes($_POST['tenpay_mail']);
        saveSetting('tenpay_mail', $tenpay_mail);
        $CACHE->clear();
        die('<script language="javascript">alert(\'保存成功!\');history.go(-1);</script>');
    }
    ?>
<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">财付通登录</h3></div><div class="panel-body box">
<form action="index.php?mod=tenpaylogin" method="post">
<input type="hidden" name="type" value="edit" />
<div class="form-group">               
	<label for="inputFirstName">*QQ账号</label>
	<input type="text" class="form-control" name="tenpay_account" value="<?php 
    echo @$_POST['tenpay_account'];
    ?>
"> 
</div>
<div class="form-group">
	<label for="inputFirstName">*QQ密码</label>
	<input type="password" class="form-control" name="tenpay_pwd" value="<?php 
    echo @$_POST['tenpay_pwd'];
    ?>
"> 
</div>
<div <?php 
    if (!$code) {
        ?>
 style="display:none;" <?php 
    }
    ?>
>
<div class="form-group">
	<label for="inputFirstName">*验证码</label>
	<input type="text" class="form-control" name="code" value="">
</div>
<div class="form-group" >
  <input type="hidden" name="sig" value="<?php 
    echo $sig;
    ?>
">
  <img src="other/getpic.php?uin=<?php 
    echo $qq;
    ?>
&sig=<?php 
    echo $sig;
    ?>
&loginsig=<?php 
    echo $loginsig;
    ?>
">
</div>
</div>
<?php 
    if ($msg) {
        ?>
<div class="form-group">
	<div class="alert alert-warning" id="load"><?php 
        echo $msg;
        ?>
</div>
</div>
<?php 
    }
    ?>
<div class="form-group text-right">
<button type="submit" class="btn btn-primary btn-block" id="save">登录并保存</button>
</div>
</form>
<form action="index.php?mod=tenpaylogin" method="post">
<input type="hidden" name="type" value="mail" />
<div class="form-group">               
	<label for="inputFirstName">财付通Cookies失效提醒邮箱</label>
	<input type="email" class="form-control" name="tenpay_mail" value="<?php 
    echo $conf['tenpay_mail'];
    ?>
"> 
</div>
<div class="form-group text-right">
<button type="submit" class="btn btn-primary btn-block" id="save">保存设置</button>
</div>
</form>
</div></div>
<?php 
} else {
    showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！', 3);
}
include TEMPLATE_ROOT . 'foot.php';