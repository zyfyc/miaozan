<?php
error_reporting(0);
define('IN_CRONLITE', true);
define('IN_CRONJOB', true);
define('SYSTEM_ROOT', dirname(preg_replace('@\\(.*\\(.*$@', '', preg_replace('@\\(.*\\(.*$@', '', __FILE__))) . '/');
define('ROOT', dirname(SYSTEM_ROOT) . '/');
define('TIMESTAMP', time());
function curl_run($url)
{
    global $conf;
    $ch = curl_init();
    $urlarr = parse_url($url);
    if ($conf['localcron'] == 1 && $urlarr['host'] == $_SERVER['HTTP_HOST']) {
        $url = str_replace('http://' . $_SERVER['HTTP_HOST'] . '/', 'http://127.0.0.1:80/', $url);
        $url = str_replace('https://' . $_SERVER['HTTP_HOST'] . '/', 'https://127.0.0.1:443/', $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Host: ' . $_SERVER['HTTP_HOST']));
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 1);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_NOSIGNAL, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    curl_close($ch);
    return true;
}
function run_once($row, $timeout, $ctimeout)
{
    $curl = curl_init();
    if (!empty($row['realip'])) {
        $urlarr = parse_url($row['url']);
        $row['url'] = str_replace('http://' . $urlarr['host'] . '/', 'http://' . $row['realip'] . ':80/', $row['url']);
        $row['url'] = str_replace('https://' . $urlarr['host'] . '/', 'https://' . $row['realip'] . ':443/', $row['url']);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Host: ' . $urlarr['host']));
    }
    if ($row['usep'] == 1) {
        curl_setopt($curl, CURLOPT_PROXY, $row['proxy']);
        curl_setopt($curl, CURLOPT_URL, $row['url']);
    } elseif ($row['usep'] == 2) {
        $row['url'] = 'http://www.pctowap.com/dowap.php?u=' . urlencode(str_replace(array('http://', 'https://'), '', $row['url'])) . '&__' . time();
        curl_setopt($curl, CURLOPT_URL, $row['url']);
        $row['referer'] = 'http://www.pctowap.com/dowap.php';
    } else {
        curl_setopt($curl, CURLOPT_URL, $row['url']);
    }
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $ctimeout);
    curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($curl, CURLOPT_NOBODY, 1);
    curl_setopt($curl, CURLOPT_NOSIGNAL, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    if ($row['referer'] != '') {
        curl_setopt($curl, CURLOPT_REFERER, $row['referer']);
    }
    if ($row['useragent'] != '') {
        curl_setopt($curl, CURLOPT_USERAGENT, $row['useragent']);
    }
    if ($row['cookie'] != '') {
        curl_setopt($curl, CURLOPT_COOKIE, $row['cookie']);
    }
    if ($row['post'] == 1) {
        $postfields = str_replace('[时间]', $date, $row['postfields']);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
    }
    curl_exec($curl);
    curl_close($curl);
}
function coin_check($uid, $coin, $type = null, $qq = 0)
{
    global $DB, $conf, $vip_func;
    if ($conf['vipmode'] == 1) {
        $udata = $DB->get_row("select userid,coin from " . DBQZ . "_user where userid='" . $uid . "' limit 1");
        $qqrow = $DB->get_row("select vip,vipdate from " . DBQZ . "_qq where uid='" . $uid . "' limit 1");
        if ($qqrow['vip'] == 1 && strtotime($qqrow['vipdate']) > time() || $qqrow['vip'] == 2 || $udata['userid'] == 1) {
            $isvip = 1;
        } else {
            $isvip = 0;
        }
    } else {
        $udata = $DB->get_row("select userid,coin,vip,vipdate from " . DBQZ . "_user where userid='" . $uid . "' limit 1");
        if ($udata['vip'] == 1 && strtotime($udata['vipdate']) > time() || $udata['vip'] == 2 || $udata['userid'] == 1) {
            $isvip = 1;
        } else {
            $isvip = 0;
        }
    }
    if ($conf['vip_coin'] == 1 && $isvip == 1) {
        return true;
    } elseif (in_array($type, $vip_func) && $isvip == 0) {
        return false;
    } else {
        if ($udata['coin'] >= $coin) {
            $DB->query("update " . DBQZ . "_user set coin=coin-{$coin} where userid='" . $uid . "'");
            return true;
        } else {
            return false;
        }
    }
}
function dojob()
{
    $fp = fsockopen($_SERVER["HTTP_HOST"], $_SERVER['SERVER_PORT']);
    $out = "GET {$_SERVER['PHP_SELF']}?key={$_GET['key']} HTTP/1.0" . PHP_EOL;
    $out .= "Host: {$_SERVER['HTTP_HOST']}" . PHP_EOL;
    $out .= "Connection: Close" . PHP_EOL . PHP_EOL;
    fputs($fp, $out);
    fclose($fp);
}
if (function_exists('set_time_limit')) {
    @set_time_limit(0);
}
if (function_exists('ignore_user_abort')) {
    @ignore_user_abort(true);
}
if (defined('SAE_ACCESSKEY')) {
    include_once ROOT . 'includes/sae.php';
} else {
    include_once ROOT . 'config.php';
}
date_default_timezone_set('PRC');
$date = date("Y-m-d H:i:s");
$time = time();
$t = date("H");
define('RUN_KEY', md5($dbconfig['user'] . md5($dbconfig['pwd'])));
include_once ROOT . 'includes/db.class.php';
$DB = new DB($dbconfig['host'], $dbconfig['user'], $dbconfig['pwd'], $dbconfig['dbname'], $dbconfig['port']);
include SYSTEM_ROOT . 'site.inc.php';
include_once ROOT . 'includes/cache.class.php';
$CACHE = new CACHE();
$conf = $CACHE->pre_fetch();
define('SYS_KEY', $conf['syskey']);
$rules = explode("|", $conf['rules']);
$vip_func = explode("|", $conf['vip_func']);
$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/cron/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
if (!$siteurl) {
    $siteurl = $conf['siteurl'];
}
$size = $conf['interval'] ? $conf['interval'] : 60;
include_once ROOT . 'includes/signapi.php';
include_once ROOT . 'includes/function.php';
include_once ROOT . 'includes/qq.func.php';
if (!empty($conf['cronkey']) && $conf['cronkey'] != $_GET['key']) {
    exit("CronKey Access Denied!");
}