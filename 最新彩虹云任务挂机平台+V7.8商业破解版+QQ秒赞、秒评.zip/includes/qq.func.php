<?php
if (!defined('IN_CRONLITE')) {
    exit;
}
$qqTaskNames = array('webqq' => 'WEBQQ机器人', '3gqq' => '３ＧＱＱ挂机', 'zan' => '空间说说秒赞', 'pl' => '空间说说秒评', 'kjqd' => '空间自动签到', 'shuo' => '发表图片说说', 'ht' => '空间花藤挂机', 'zfss' => '好友说说转发', 'del' => '空间说说删除', 'delly' => '空间留言删除', 'quantu' => '空间说说圈图', 'zyzan' => '空间互赞主页', 'liuyan' => '空间互刷留言', 'gift' => '空间互送礼物', 'qunqd' => 'QQ群自动签到', 'wenwen' => '群问问自动签到', 'buluo' => '兴趣部落签到', 'weiyun' => '微云自动签到', 'payqd' => '钱包自动签到', 'scqd' => '书城自动签到', 'gameqd' => '游戏大厅签到', 'jfsc' => '积分商城签到', 'wtjf' => '网厅积分签到', 'qqllq' => 'Ｑ浏积分签到', 'qqmgr' => 'ＱＱ管家签到', 'qd3366' => '3366自动签到', 'liuliang' => '自动领取流量豆', 'vipqd' => 'QQ会员自动签到', 'nianvip' => '年费会员每日抽奖', 'lzqd' => '绿钻自动签到', 'gamevip' => '蓝钻自动签到', 'yqd' => '黄钻自动签到', 'fzqd' => '粉钻自动签到', 'sqqqd' => '超Ｑ自动签到', 'video' => '好莱坞会员签到', 'dld' => '乐斗挂机签到', 'qqpet' => 'ＱＱ宠物挂机', 'mc' => 'ＱＱ牧场挂机', 'nc' => 'ＱＱ农场挂机', 'qqmusic' => 'ＱＱ音乐等级加速', 'mqq' => '手机QQ在线等级加速', 'qltree' => 'QQ情侣树挂机', 'qlsend' => 'QQ情侣发送蜜语', 'qipao' => 'QQ聊天百变气泡', 'bookqd' => '小说书架签到', 'daoju' => '道聚城签到', 'xinyue' => '心悦VIP签到', 'jpgame' => '精品页游签到', 'yyrank' => 'QQ音乐刷排行榜', 'nick' => 'QQ随机改变昵称', 'xing' => '星钻签到抽奖', 'zhongzhuan' => 'QQ邮箱中转站自动续期', 'dongman' => '腾讯动漫签到', 'face' => '自动更换头像');
$qqSignTasks = array('kjqd', 'qunqd', 'buluo', 'weiyun', 'payqd', 'scqd', 'gameqd', 'jfsc', 'wtjf', 'qqllq', 'qqmgr', 'qd3366', 'vipqd', 'lzqd', 'gamevip', 'yqd', 'fzqd', 'sqqqd', 'video', 'dld', 'wenwen', 'liuliang', 'nianvip', 'qltree', 'bookqd', 'qqmusic', 'mqq', 'daoju', 'xinyue', 'jpgame', 'xing', 'zhongzhuan', 'dongman');
$qqGuajiTasks = array('3gqq', 'qqpet', 'mc', 'nc', 'ht', 'bmw');
$qqLimitTasks = array('zyzan', 'liuyan', 'gift', 'quantu', 'del', 'delly');
$signTaskNames = array('klqd' => '柯林网站自动签到', 'klqd2' => '柯林网站自动签到', 'klol' => '柯林网站挂积时', 'klreply' => '柯林网站自动回帖', 'kltie' => '柯林网站自动发帖', 'dzsign' => 'Discuz自动签到', 'dzsign2' => 'Discuz自动签到', 'dzdk' => 'Discuz自动打卡', 'dzdk2' => 'Discuz自动打卡', 'dztask' => 'Discuz任务助手', 'dztask2' => 'Discuz任务助手', 'dzol' => 'Discuz挂积时', 'dzol2' => 'Discuz挂积时', 'pwsign' => 'PHPWind9.X自动签到', 'pwsign2' => 'PHPWind9.X自动签到', 'pw2sign' => 'PHPWind8.X自动签到', 'pw2sign2' => 'PHPWind8.X自动签到', '115' => '115网盘自动签到', '360yunpan' => '360云盘自动签到', 'vdisk' => '新浪微盘自动签到', 'xiami' => '虾米音乐自动签到', 'fuliba' => '福利吧论坛自动签到', '3gwen' => '文网自动签到', '52pojie' => '吾爱破解论坛签到', 'ucsign' => 'UC官方论坛签到', 'qiu' => '球球大作战刷棒棒糖');
function qqjob_encode($func)
{
    switch ($func) {
        case 'guaq':
            $str = array('method' => $_POST['method'], 'msg' => $_POST['msg']);
            break;
        case 'zan':
            $str = array('forbid' => $_POST['forbid']);
            break;
        case 'pl':
            $str = array('content' => $_POST['content'], 'forbid' => $_POST['forbid'], 'only' => $_POST['only'], 'img' => $_POST['img']);
            break;
        case 'kjqd':
            $str = array('content' => $_POST['content']);
            break;
        case 'shuo':
            $str = array('content' => $_POST['content'], 'img' => $_POST['img'], 'ua' => $_POST['ua'], 'delete' => $_POST['delete']);
            break;
        case 'zfss':
            $str = array('uin' => $_POST['uin'], 'reason' => $_POST['reason']);
            break;
        case 'qunqd':
            $str = array('forbid' => $_POST['forbid'], 'lat' => $_POST['lat'], 'lgt' => $_POST['lgt']);
            break;
        case 'wenwen':
            $str = array('forbid' => $_POST['forbid']);
            break;
        case 'qlsend':
            $str = array('content' => $_POST['content']);
            break;
        case 'nick':
            $str = array('nick' => $_POST['nick']);
            break;
        case 'webqq':
            $str = array('robot' => $_POST['robot'], 'msg' => $_POST['msg'], 'nick' => $_POST['nick'], 'apikey' => $_POST['apikey'], 'apisecret' => $_POST['apisecret']);
            break;
        default:
            $str = null;
            break;
    }
    if ($str == null) {
        return null;
    } else {
        return serialize($str);
    }
}
function qqjob_decode($qq, $type, $method, $data)
{
    global $DB, $siteurl, $qqapi_server, $conf;
    $sleep = $conf['sleep'] > 1 ? 1 : 0;
    $shuotail = $conf['shuotail'] ? $conf['shuotail'] : null;
    $qqrow = @unserialize($data);
    $qq = daddslashes($qq);
    $row = $DB->get_row("SELECT * FROM " . DBQZ . "_qq WHERE qq='{$qq}' limit 1");
    if (strpos($qqapi_server, '|')) {
        $qqapi_servers = explode('|', $qqapi_server);
        $qqapi_server = $qqapi_servers[array_rand($qqapi_servers, 1)];
    }
    $interapi = $siteurl;
    $methodarr = array(0 => '系统默认', 1 => '3G版协议', 2 => '触屏版协议', 3 => 'PC版协议', 4 => 'PC版协议New');
    switch ($type) {
        case 'webqq':
            if ($qqrow['robot'] == 1) {
                $addstr = '&nick=' . urlencode($qqrow['nick']);
            } elseif ($qqrow['robot'] == 2) {
                $addstr = '&apikey=' . $qqrow['apikey'] . '&apisecret=' . $qqrow['apisecret'];
            } else {
                $addstr = '&content=' . urlencode($qqrow['msg']);
            }
            $methodarr = array(0 => '系统默认', 1 => '不自动回复，只挂机', 2 => '只回复私人消息', 3 => '只回复群消息', 4 => '回复私人消息和群消息');
            $url = $interapi . 'qq/webqq.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&superkey=' . urlencode($row['superkey']) . '&method=' . $method . '&robot=' . $qqrow['robot'] . $addstr;
            $info = '运行方式：<u>' . $methodarr[$method] . '</u><br/>自定义回复语：<u>' . ($qqrow['robot'] ? '机器人自动回复' : $qqrow['msg']) . '</u>';
            $needsuper = true;
            break;
        case '3gqq':
            $url = $interapi . 'qq/3gqq.php?qq=' . $qq . '&sid=' . urlencode($row['sid']) . '&skey=' . urlencode($row['skey']);
            $info = '正在3GQQ挂机中。';
            $onlysid = true;
            break;
        case 'zan':
            $url = $qqapi_server . 'qq/zan.php?newpc=' . $conf['newpc'] . '&sleep=' . $sleep . '&qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method . '&forbid=' . urlencode($qqrow['forbid']);
            $info = '秒赞协议：<u>' . $methodarr[$method] . '</u><br/>不秒赞以下QQ：<u>' . $qqrow['forbid'] . '</u>';
            break;
        case 'pl':
            $url = $qqapi_server . 'qq/pl.php?sleep=' . $sleep . '&qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method . '&forbid=' . urlencode($qqrow['forbid']) . '&only=' . $qqrow['only'] . '&content=' . urlencode($qqrow['content']) . '&img=' . urlencode($qqrow['img']);
            $info = '秒评协议：<u>' . $methodarr[$method] . '</u><br/>评论内容：<u>' . $qqrow['content'] . '</u><br/>不秒评以下QQ：<u>' . $qqrow['forbid'] . '</u><br/>只秒评以下QQ：<u>' . $qqrow['only'] . '</u>';
            break;
        case 'kjqd':
            $url = $qqapi_server . 'qq/kjqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method . '&content=' . urlencode($qqrow['content']);
            $info = '签到协议：<u>' . $methodarr[$method] . '</u><br/>签到内容：<u>' . $qqrow['content'] . '</u>';
            break;
        case 'shuo':
            $url = $qqapi_server . 'qq/shuo.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method . '&content=' . urlencode($qqrow['content'] . $shuotail) . '&img=' . urlencode($qqrow['img']) . '&ua=' . urlencode($qqrow['ua']) . '&delete=' . $qqrow['delete'];
            $info = '运行协议：<u>' . $methodarr[$method] . '</u><br/>内容：<u>' . $qqrow['content'] . '</u><br/>图片地址：<u>' . $qqrow['img'] . '</u><br/>浏览器UA：<u>' . $qqrow['ua'] . '</u>';
            break;
        case 'ht':
            $url = $qqapi_server . 'qq/ht.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']);
            $info = '运行协议：<u>PC版</u><br/>正在花藤挂机中。';
            break;
        case 'del':
            $url = $qqapi_server . 'qq/del.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method;
            $info = '运行协议：<u>' . $methodarr[$method] . '</u>';
            break;
        case 'zfss':
            $url = $qqapi_server . 'qq/zfss.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&method=' . $method . '&uin=' . $qqrow['uin'] . '&nr=' . urlencode($qqrow['reason']) . $extend;
            $info = '运行协议：<u>' . $methodarr[$method] . '</u><br/>好友QQ：<u>' . $qqrow['uin'] . '</u><br/>转发原因：<u>' . $qqrow['reason'] . '</u>';
            break;
        case 'scqd':
            $url = $qqapi_server . 'qq/scqd.php?qq=' . $qq . '&sid=' . urlencode($row['sid']) . '&skey=' . urlencode($row['skey']);
            $info = '正在书城签到中。';
            $onlysid = true;
            break;
        case 'lzqd':
            $url = $qqapi_server . 'qq/lzqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在绿钻签到中。';
            break;
        case 'vipqd':
            $url = $qqapi_server . 'qq/vipqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在VIP签到中。';
            break;
        case 'payqd':
            $url = $qqapi_server . 'qq/payqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在钱包签到中。';
            break;
        case 'yqd':
            $url = $qqapi_server . 'qq/yqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']);
            $info = '正在黄钻签到中。';
            break;
        case 'sqqqd':
            $url = $qqapi_server . 'qq/sqqqd.php?qq=' . $qq . '&sid=' . urlencode($row['sid']) . '&skey=' . urlencode($row['skey']);
            $info = '正在超Q签到中。';
            $onlysid = true;
            break;
        case 'zyzan':
            $url = $interapi . 'qq/zyzan.php?qq=' . $qq;
            $info = '正在互赞主页中。<br/>运行协议：PC版';
            $onlysid = true;
            break;
        case 'liuyan':
            $url = $interapi . 'qq/liuyan.php?qq=' . $qq;
            $info = '正在互刷留言中。<br/>运行协议：触屏版';
            $onlysid = true;
            break;
        case 'gift':
            $url = $interapi . 'qq/gift.php?qq=' . $qq;
            $info = '正在互送礼物中。<br/>运行协议：触屏版';
            $onlysid = true;
            break;
        case 'delly':
            $url = $qqapi_server . 'qq/delly.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']);
            $info = '正在删除留言中。<br/>运行协议：触屏版';
            break;
        case 'quantu':
            $url = $qqapi_server . 'qq/quantu.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']);
            $info = '正在圈说说图中。<br/>运行协议：PC版';
            break;
        case 'qqpet':
            $url = $qqapi_server . 'qq/qqpet.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在QQ宠物挂机中。';
            break;
        case 'gamevip':
            $url = $interapi . 'qq/gamevip.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&superkey=' . urlencode($row['superkey']);
            $info = '正在蓝钻签到中。';
            break;
        case 'mc':
            $url = $qqapi_server . 'qq/mc.php?qq=' . $qq . '&sid=' . urlencode($row['sid']);
            $info = '正在牧场挂机中。';
            $onlysid = true;
            break;
        case 'nc':
            $url = $qqapi_server . 'qq/nc.php?qq=' . $qq . '&sid=' . urlencode($row['sid']);
            $info = '正在农场挂机中。';
            $onlysid = true;
            break;
        case 'dld':
            $url = $qqapi_server . 'qq/dld.php?qq=' . $qq . 'skey=' . urlencode($row['skey']);
            $info = '正在大乐斗签到中。';
            $onlysid = true;
            break;
        case 'fzqd':
            $url = $qqapi_server . 'qq/fzqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在粉钻签到中。';
            break;
        case 'video':
            $url = $qqapi_server . 'qq/video.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在好莱坞会员签到中。';
            break;
        case 'nianvip':
            $url = $qqapi_server . 'qq/nianvip.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '年费会员每日抽奖中。';
            break;
        case 'qqmgr':
            $url = $qqapi_server . 'qq/qqmgr.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在ＱＱ管家签到中。';
            break;
        case 'qd3366':
            $url = $qqapi_server . 'qq/qd3366.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在3366自动签到中。';
            break;
        case 'liuliang':
            $url = $qqapi_server . 'qq/liuliang.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在每日自动领取流量豆中。';
            break;
        case 'weiyun':
            $url = $qqapi_server . 'qq/weiyun.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在微云签到中。';
            break;
        case 'qunqd':
            $url = $qqapi_server . 'qq/qunqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&forbid=' . urlencode($qqrow['forbid']) . '&lat=' . urlencode($qqrow['lat']) . '&lgt=' . urlencode($qqrow['lgt']);
            $info = '正在QQ群签到中。' . ($qqrow['lat'] ? '<br/>坐标:' . $qqrow['lat'] . ',' . $qqrow['lgt'] : null) . ($qqrow['forbid'] ? '<br/>屏蔽的群:' . $qqrow['forbid'] : null);
            break;
        case 'wenwen':
            $url = $interapi . 'qq/wenwen.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&superkey=' . urlencode($row['superkey']) . '&forbid=' . urlencode($qqrow['forbid']);
            $info = '正在群问问签到中。' . ($qqrow['forbid'] ? '<br/>屏蔽的群:' . $qqrow['forbid'] : null);
            break;
        case 'gameqd':
            $url = $qqapi_server . 'qq/gameqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在游戏大厅签到中。';
            break;
        case 'buluo':
            $url = $qqapi_server . 'qq/buluo.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在兴趣部落签到中。';
            break;
        case 'jfsc':
            $url = $interapi . 'qq/jfsc.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在积分商城签到中。';
            break;
        case 'wtjf':
            $url = $interapi . 'qq/wtjf.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在网厅积分签到中。';
            break;
        case 'qqllq':
            $url = $qqapi_server . 'qq/qqllq.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在QQ浏览器签到中。';
            break;
        case 'bmw':
            $url = $interapi . 'qq/bmw.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在宝马挂Q在线中。';
            break;
        case 'qltree':
            $url = $qqapi_server . 'qq/qltree.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在QQ情侣树挂机中。';
            break;
        case 'qlsend':
            $url = $qqapi_server . 'qq/qlsend.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&content=' . $qqrow['content'];
            $info = '正在QQ情侣发送蜜语中。';
            break;
        case 'bookqd':
            $url = $qqapi_server . 'qq/bookqd.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在小说书架签到中。';
            break;
        case 'daoju':
            $url = $qqapi_server . 'qq/gameqd.php?m=daoju&qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在道聚城签到中。';
            break;
        case 'xinyue':
            $url = $qqapi_server . 'qq/gameqd.php?m=xinyue&qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在心锐VIP签到中。';
            break;
        case 'jpgame':
            $url = $qqapi_server . 'qq/gameqd.php?m=jpgame&qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在精品页游签到中。';
            break;
        case 'qipao':
            $url = $qqapi_server . 'qq/qipao.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = 'QQ聊天百变气泡运行中。';
            break;
        case 'qqmusic':
            $url = $interapi . 'qq/qqmusic.php?qq=' . $qq;
            $info = '正在QQ音乐等级加速中。';
            break;
        case 'mqq':
            $url = $qqapi_server . 'qq/mqq.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在手机QQ在线等级加速中。';
            break;
        case 'xing':
            $url = $qqapi_server . 'qq/xing.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在星钻自动签到与抽奖中。';
            break;
        case 'yyrank':
            $url = $qqapi_server . 'qq/yyrank.php?qq=' . $qq;
            $info = '正在手机QQ音乐刷听歌排行榜中。';
            break;
        case 'nick':
            $url = $qqapi_server . 'qq/nick.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']) . '&content=' . urlencode($qqrow['nick']);
            $info = '随机昵称：' . $qqrow['nick'];
            break;
        case 'zhongzhuan':
            $url = $interapi . 'qq/zhongzhuan.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&superkey=' . urlencode($row['superkey']);
            break;
        case 'dongman':
            $url = $qqapi_server . 'qq/dongman.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在腾讯动漫签到中。';
            break;
        case 'face':
            $url = $qqapi_server . 'qq/face.php?qq=' . $qq . '&skey=' . urlencode($row['skey']);
            $info = '正在自动更换头像中。<a href="http://ptlogin2.qq.com/jump?uin=' . $qq . '&skey=' . $row['skey'] . '&u1=http%3A%2F%2Fstyle.qq.com%2Fface%2Fmanage.html" target="_blank">点此修改头像种类</a>';
            break;
        case 'gx':
            $url = $qqapi_server . 'qq/gx.php?qq=' . $qq . '&skey=' . urlencode($row['skey']) . '&pskey=' . urlencode($row['pskey']);
            $info = '正在检测SKEY中。';
            break;
    }
    $info .= '<br/>【<a data-toggle="modal" data-target="#showresult" href="#" id="showresult" onclick="showresult(\'' . urlencode($url) . '\')">手动执行测试</a>】';
    if ($row['status'] != 1 || $row['status2'] != 1 && $needsuper == true) {
        $status = 'no';
    } else {
        $status = 'yes';
    }
    return array('url' => $url, 'info' => $info, 'status' => $status);
}
function signjob_decode($type, $data)
{
    global $DB, $siteurl, $apiserver, $apiserverid;
    $data = http_build_query(unserialize($data));
    switch ($type) {
        case 'klqd':
            $url = $apiserverid != 0 ? $apiserver . 'kelink/qdnew/qd.php?' . $data : $siteurl . 'sign/klqd.php?' . $data;
            break;
        case 'klqd2':
            $url = $apiserverid != 0 ? $apiserver . 'kelink/klqd/qd.php?' . $data : $siteurl . 'sign/klqd2.php?' . $data;
            break;
        case 'klol':
            $url = $siteurl . 'sign/klol.php?' . $data;
            break;
        case 'dzsign':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuz/do.php?' . $data : $siteurl . 'sign/dzsign.php?' . $data;
            break;
        case 'dzsign2':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuz/do2.php?' . $data : $siteurl . 'sign/dzsign2.php?' . $data;
            break;
        case 'dzdk':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuzdk/do.php?' . $data : $siteurl . 'sign/dzdk.php?' . $data;
            break;
        case 'dzdk2':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuzdk/do2.php?' . $data : $siteurl . 'sign/dzdk2.php?' . $data;
            break;
        case 'dztask':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuztask/do.php?' . $data : $siteurl . 'sign/dztask.php?' . $data;
            break;
        case 'dztask2':
            $url = $apiserverid != 0 ? $apiserver . 'sign/discuztask/do2.php?' . $data : $siteurl . 'sign/dztask2.php?' . $data;
            break;
        case 'dzol':
            $url = $siteurl . 'sign/dzol2.php?' . $data;
            break;
        case 'pwsign':
            $url = $apiserverid != 0 ? $apiserver . 'sign/pwsign/do.php?' . $data : $siteurl . 'sign/pwsign.php?' . $data;
            break;
        case 'pwsign2':
            $url = $apiserverid != 0 ? $apiserver . 'sign/pwsign/do2.php?' . $data : $siteurl . 'sign/pwsign2.php?' . $data;
            break;
        case 'pw2sign':
            $url = $apiserverid != 0 ? $apiserver . 'sign/pwsign2/do.php?' . $data : $siteurl . 'sign/pw2sign.php?' . $data;
            break;
        case 'pw2sign2':
            $url = $apiserverid != 0 ? $apiserver . 'sign/pwsign2/do2.php?' . $data : $siteurl . 'sign/pw2sign2.php?' . $data;
            break;
        case '115':
            $url = $apiserver . 'sign/115/do.php?' . $data;
            break;
        case '360yunpan':
            $url = $apiserver . 'sign/360yunpan/do.php?' . $data;
            break;
        case 'vdisk':
            $url = $apiserver . 'sign/vdisk/do.php?' . $data;
            break;
        case 'xiami':
            $url = $apiserver . 'sign/xiami/do.php?' . $data;
            break;
        case '52pojie':
            $url = $apiserverid != 0 ? $apiserver . 'sign/52pojie/do.php?' . $data : $siteurl . 'sign/52pojie.php?' . $data;
            break;
        case 'fuliba':
            $url = $apiserverid != 0 ? $apiserver . 'sign/fuliba/do.php?' . $data : $siteurl . 'sign/fuliba.php?' . $data;
            break;
        case 'ucsign':
            $url = $apiserver . 'sign/ucsign/do.php?' . $data;
            break;
        case '3gwen':
            $url = $apiserverid != 0 ? $apiserver . 'sign/3gwen/do.php?' . $data : $siteurl . 'sign/3gwen.php?' . $data;
            break;
        case 'dyml':
            $url = $apiserverid != 0 ? $apiserver . 'sign/dyml/qd.php?' . $data : $siteurl . 'sign/dyml.php?' . $data;
            break;
        case 'cmgq':
            $url = $siteurl . 'sign/cmgq.php?' . $data;
            break;
        case 'chenqd':
            $url = $siteurl . 'sign/chenqd.php?' . $data;
            break;
        case 'qiu':
            $url = $siteurl . 'sign/qiu.php?' . $data;
            break;
    }
    $info = '<br/>【<a data-toggle="modal" data-target="#showresult" href="#" id="showresult" onclick="showresult(\'' . urlencode($url) . '\')">手动执行测试</a>】';
    return array('url' => $url, 'info' => $info, 'data' => $data);
}