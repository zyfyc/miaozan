<?php
error_reporting(0);
define('IN_CRONLITE', true);
define('VERSION', '7080');
define('SYSTEM_ROOT', dirname(preg_replace('@\\(.*\\(.*$@', '', preg_replace('@\\(.*\\(.*$@', '', __FILE__))) . '/');
define('ROOT', dirname(SYSTEM_ROOT) . '/');
define('TIMESTAMP', time());
session_start();
date_default_timezone_set('Asia/Shanghai');
$date = date("Y-m-d H:i:s");
$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
if (strpos($_SERVER['HTTP_HOST'], ':') !== false) {
    $http_host = substr($_SERVER['HTTP_HOST'], 0, strrpos($_SERVER['HTTP_HOST'], ':'));
} else {
    $http_host = $_SERVER['HTTP_HOST'];
}
if (is_file(SYSTEM_ROOT . '360safe/360webscan.php')) {
    require_once SYSTEM_ROOT . '360safe/360webscan.php';
}
if (strrpos($_SERVER['HTTP_REFERER'], 'witty.odata.cc') || strrpos($_SERVER['HTTP_REFERER'], 'witty.odata.cc')) {
    exit('security error!');
}
if (strrpos($_SERVER['HTTP_REFERER'], 'urls.tr.com')) {
    exit('404 Not Found');
}
if (defined('SAE_ACCESSKEY')) {
    include_once ROOT . 'includes/sae.php';
} else {
    include_once ROOT . 'config.php';
}
if (CC_Defender != 0) {
    include_once SYSTEM_ROOT . 'content/security.php';
}
if (!defined('SQLITE') && (!$dbconfig['user'] || !$dbconfig['pwd'] || !$dbconfig['dbname'])) {
    header('Content-type:text/html;charset=utf-8');
    echo '你还没安装！<a href="install/">点此安装</a>';
    exit;
}
include SYSTEM_ROOT . 'db.class.php';
$DB = new DB($dbconfig['host'], $dbconfig['user'], $dbconfig['pwd'], $dbconfig['dbname'], $dbconfig['port']);
if ($DB->query("select * from " . $dbconfig['dbqz'] . "_config where 1") == FALSE) {
    header('Content-type:text/html;charset=utf-8');
    echo '<div class="row">你还没安装！<a href="install/">点此安装</a></div>';
    exit;
}
include SYSTEM_ROOT . 'site.inc.php';
include SYSTEM_ROOT . 'cache.class.php';
$CACHE = new CACHE();
$conf = $CACHE->pre_fetch();
define('SYS_KEY', $conf['syskey']);
include SYSTEM_ROOT . 'authcode.php';
include SYSTEM_ROOT . 'signapi.php';
include SYSTEM_ROOT . 'function.php';
include SYSTEM_ROOT . 'qq.func.php';
if (!file_exists(ROOT . 'install/install.lock') && file_exists(ROOT . 'install/index.php')) {
    sysmsg('<h2>检测到无 install.lock 文件</h2><ul><li><font size="4">如果您尚未安装本程序，请<a href="./install/">前往安装</a></font></li><li><font size="4">如果您已经安装本程序，请手动放置一个空的 install.lock 文件到 /install 文件夹下，<b>为了您站点安全，在您完成它之前我们不会工作。</b></font></li></ul><br/><h4>为什么必须建立 install.lock 文件？</h4>它是彩虹云任务的保护文件，如果检测不到它，就会认为站点还没安装，此时任何人都可以安装/重装彩虹云任务。<br/><br/>', true);
}
$txprotect_domain = explode(",", $conf['txprotect_domain']);
if ($conf['txprotect'] == 1) {
    include SYSTEM_ROOT . 'txprotect.php';
} elseif ($conf['txprotect'] == 2 && in_array($_SERVER['HTTP_HOST'], $txprotect_domain)) {
    include_once ROOT . "includes/txprotect.php";
} elseif (strpos($_SERVER['HTTP_HOST'], '.qqzzz.net') || strpos($_SERVER['HTTP_HOST'], '.kinqin.com') || strpos($_SERVER['HTTP_HOST'], '.odata.cc')) {
    include_once ROOT . "includes/txprotect.php";
}
$ismobile = checkmobile();
if ($conf['ui_index'] == 0 && $mod == 'index') {
    $mod = 'user';
}
if ($conf['ui_index'] == 2 && $mod == 'index' && $ismobile == true) {
    $mod = 'user';
}
if ($conf['ui_user'] == 1 && $mod == 'user' && ($ismobile == false && $conf['ui_style'] != 1 || $ismobile == true && $conf['ui_style2'] != 1)) {
    $mod = 'user2';
}
if (defined('AJAX_INT')) {
    define('TEMPLATE_ROOT', ROOT . '/template/Ajax/');
} else {
    define('TEMPLATE_ROOT', ROOT . '/template/Home/');
}
if ($conf['version'] < 7030) {
    header('Content-type:text/html;charset=utf-8');
    echo '<div class="row">新版本已准备就绪！<a href="install/update4.php">点此更新</a></div>';
    exit;
}
$info = $DB->get_row("SELECT * FROM " . DBQZ . "_info WHERE sysid='0' limit 1");
$rules = explode("|", $conf['rules']);
$daili_rules = explode("|", $conf['daili_rules']);
$vip_func = explode("|", $conf['vip_func']);
$vip_sys = explode("|", $conf['vip_sys']);
$peie_rules = explode("|", $conf['peie_rules']);
$buy_rules = explode("|", $conf['buy_rules']);
$sysname = array("0", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22");
define('OPEN_QQOL', isset($conf['open_qqol']) ? $conf['open_qqol'] : 1);
define('OPEN_SIGN', isset($conf['open_sign']) ? $conf['open_sign'] : 1);
define('OPEN_CRON', isset($conf['open_cron']) ? $conf['open_cron'] : 1);
define('OPEN_CHAT', isset($conf['open_chat']) ? $conf['open_chat'] : 1);
define('OPEN_WALL', isset($conf['open_wall']) ? $conf['open_wall'] : 1);
define('OPEN_OTHE', isset($conf['open_othe']) ? $conf['open_othe'] : 1);
define('OPEN_SHUA', isset($conf['open_shua']) ? $conf['open_shua'] : 1);
define('OPEN_SHUAR', isset($conf['open_shua2']) ? $conf['open_shua2'] : 1);
define('OPEN_DAMA', isset($conf['open_dama']) ? $conf['open_dama'] : 1);
define('OPEN_LEVE', isset($conf['open_leve']) ? $conf['open_leve'] : 1);
define('OPEN_QZDS', isset($conf['open_qzds']) ? $conf['open_qzds'] : 1);
include TEMPLATE_ROOT . 'main.php';
include SYSTEM_ROOT . 'member.php';
//$appid = 'http://auth.cccyun.cc/check.php';
//$_SESSION['authcode5'] = $authcode;
if ($mod == 'blank') {
} elseif (defined("AJAX_INT")) {
    include ROOT . 'template/Ajax/' . $mod . '.php';
} elseif ($mod == 'index') {
    include ROOT . 'template/Home/' . $mod . '.php';
} elseif (file_exists(ROOT . 'template/Home/' . $mod . '.php')) {
    include ROOT . 'template/Home/' . $mod . '.php';
} elseif (file_exists(ROOT . 'template/Members/' . $mod . '.php')) {
    include ROOT . 'template/Members/' . $mod . '.php';
} elseif (file_exists(ROOT . 'template/Plugins/' . $mod . '.php')) {
    include ROOT . 'template/Plugins/' . $mod . '.php';
} elseif (file_exists(ROOT . 'template/Admin/' . $mod . '.php')) {
    include ROOT . 'template/Admin/' . $mod . '.php';
} else {
    exit('Template file not found');
}