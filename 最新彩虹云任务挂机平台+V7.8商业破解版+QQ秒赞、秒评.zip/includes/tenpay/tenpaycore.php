<?php
/*
 * 财付通登录核心[只限于无验证码登录的QQ使用] author:云影 QQ8711973
 */
class tenpay{
	
	public $login_sig;
	
	public function __construct($uin,$pwd,$code=0,$sig=0){
		$this->login_sig = $this->get_login_sig();
		$this->uin=$uin;
		$this->pwd=$pwd;
		$this->code=$code;
		$this->sig=$sig;
	    if($code){
			$this->do_check();
		}else{
			$this->get_checkvc();
		}
	}
	
	public function get_login_sig(){ //获取登录sig
		$url = "https://xui.ptlogin2.tenpay.com/cgi-bin/xlogin?appid=546000248&style=34&hide_border=1&proxy_url=https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fproxy.html&target=self&daid=120&s_url=https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fres%2Fjs%2Fyui%2Fbuild%2Flogin%2Fptlogin.shtml&pt_no_auth=1&v=10063002";
		$data = $this->get_curl($url,0,0,0,1);
		preg_match('/pt_login_sig=(.*?);/',$data,$loginsig[1]);
		return $loginsig[1][1];
	}
	
	public function get_checkvc(){//获取是否有验证码
		$url = "https://ssl.ptlogin2.tenpay.com/check?regmaster=&pt_tea=1&pt_vcode=1&uin=".$this->uin."&appid=546000248&js_ver=10149&js_type=1&login_sig=".$this->login_sig."&u1=https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fres%2Fjs%2Fyui%2Fbuild%2Flogin%2Fptlogin.shtml&r=0.".time()."4319219";
		$data = $this->get_curl($url);
		if(preg_match("/ptui_checkVC\('(.*?)'\);/", $data, $arr)){
			$r=explode("','",$arr[1]);
			if($r[0]==1){
				$this->json='{"code":-2,"sig":"'.$r[1].'"}';
				$this->get_img($r[1]);
			}else{
				$this->code=$r[1];
				$this->sig=$r[3];
				$this->login();
			}
		}else{
			exit("<script language='javascript'>alert('判断是否有验证码失败，请稍候重试！');history.go(-1);</script>");
		}
	}
	
	public function login(){//登录
		$p = $this->getp();
		$url = "https://ssl.ptlogin2.tenpay.com/login?u=".$this->uin."&verifycode=".$this->code."&pt_vcode_v1=0&pt_verifysession_v1=".$this->sig."&p=".$p."&pt_randsalt=0&u1=https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fres%2Fjs%2Fyui%2Fbuild%2Flogin%2Fptlogin.shtml&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=2-10-1455798292806&js_ver=10149&js_type=1&login_sig=".$this->login_sig."&pt_uistyle=34&aid=546000248&daid=120&";
		$ret = $this->get_curl($url,0,0,0,1,0,0,1);
		if(preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr)){
			$r=explode("','",str_replace("', '","','",$arr[1]));
			if($r[0]==0){
				$cookie='';
				preg_match_all('/Set-Cookie: (.*);/iU',$ret,$matchs);
				foreach ($matchs[1] as $val) {
					$cookie.=$val.'; ';
				}
				/* 获取是否成功登录财付通状态 */
				$loginzt = $this->get_curl("https://www.tenpay.com/app/v1.0/unilogin.cgi?busi_type=3&channel=0&OutputType=JSONP&JsonObj=YUI.Env.JSONP.yui_3_2_0_1_145584180004519._do",0,0,$cookie);
				
				preg_match("/\"retcode\"\:\"(.*?)\"\,\"retmsg\"/is", $loginzt, $results);
				if($results[1]=="0"){
					$loginzt = true;
				}else{
					preg_match("/\"retmsg\"\:\"(.*?)\"\,/is", $loginzt, $results);
					$loginmsg = $results[1];
					$loginzt = false;
				}
				
				$d = $this->get_curl("https://www.tenpay.com/app/v1.0/unilogin.cgi?busi_type=3&channel=0&OutputType=JSONP&JsonObj=YUI.Env.JSONP.yui_3_2_0_1_145579829336220._do",0,0,$cookie,1);
				preg_match_all('/Set-Cookie: (.*);/iU',$d,$matchs);
				foreach ($matchs[1] as $val) {
					$cookie.=$val.'; ';
				}
				if($loginzt == true){
					$this->json='{"code":0,"uin":"'.$this->uin.'","cookies":"'.$cookie.'"}';
				}else{
					$this->json='{"code":-1,"uin":"'.$this->uin.'","msg":"'.$loginmsg.'"}';
				}
				/*  获取交易记录
				preg_match('/skey=@(.{9});/',$ret,$skey);
				$this->gtk = $this->getGTK($skey[1]);
				$geturl = "https://www.tenpay.com/app/v1.0/trans_manage.cgi?OutPutType=JSON&list_status=0&time_type=4&pay_status=1&sort_type=1&query_type=1&offset=0&limit=10&query_category=record&g_tk=".$this->gtk;
				$data = $this->get_curl($geturl,0,"https://www.tenpay.com/v2/trade/trade_mgr.shtml?ADTAG=TENPAY_V2.CFTACCOUNT.SIDERBAR_TOP.TRADE_MANAGE",$cookie,1);*/ 
				
			}elseif($r[0]==4){
				$this->json='{"code":-3,"msg":"验证码错误!"}';
				$this->checkvc();
			}elseif($r[0]==3){
				$this->json='{"code":-3,"msg":"密码错误！"}';
			}elseif($r[0]==19){
				$this->json='{"code":-3,"msg":"您的帐号暂时无法登录，请到 http://aq.qq.com/007 恢复正常使用！"}';
			}else{
				$this->json='{"code":-3,"msg":"'.str_replace('"','\'',$r[4]).'"}';
			}
		}else{
			$this->json='{"code":-3,"msg":"'.$ret.'"}';
		}
	}
		
	public function do_check(){//验证验证码
		$url='https://ssl.captcha.qq.com/cap_union_verify_new?clientype=2&uin='.$this->uin.'&aid=546000248&cap_cd='.$this->sig.'&pt_style=34&0.4768349'.time().'&rand=0.650716'.time().'&capclass=0&sig='.$this->login_sig.'&collect=CsfPdtFPYwzo-0O9YBOEfyY57Uom6dbkkbeneqTpUVq56HsJR1RBLBd36oXcGYEFsDOMc5C8aCatozZtMoA3pIyAjf4gBqkHtYynTEKrYElJQAFORph7Be4eOJkD2EusKcdDLhHlZgLN5EYEhiwaC0EWxtfUKx8Ji4wBloYViXHDlEHq30DKyixFxKsTLyxxyNwo0ke4tDJ3w_-kmsYHsRQ8LFFGTx7iZS3HUEfRA1esni26ycqrVYUyR_L4mrFai_sIKEjwWEA4qovmzlLMNdoWrf1Nakn_ECoElccwMS9O0pdIQSms9El59u5IM6cv9FOIfE6V2R3Onm6Zbe_wpCZrd8P4tUtnRBIwViVLBEA9WPm1wvpIr5r1jVpTcvF0VRISeRiJ-a-KPBhtpQJNJ2XEetcQRGCl5fbcruV8Mp1Yl77jwFFIff_ZfBSQbl1rEG2tmqplC-1VYxYohaZvRAEgR57wO2O452GqFBxVE8tCpfeHECB370oGXHbFsx61gzuJOMcXNNZTAIQSy4LGtksTeJYWJudQ9kTt6EZCvxRDF7dVs1Oi7b1Lo0C7OUB_duA2mV_bE3-MyEZ10ANnRBuQRNdAAy2HzTCaT2Sh3vWTJwtXglJ2nvIq0FgZlZHWS0es6X-PKhx7062oorJWlYK6YkwgBEgETWRbsJAIlj8*&ans='.$this->code;
		$data=$this->get_curl($url);
		$arr = json_decode($data,true);
		$randstr=$arr['randstr'];
		$sig=$arr['ticket'];
		if($randstr){
			$this->code=$randstr;
			$this->sig=$sig;
			$this->login();
		}else{
			$this->get_img($this->sig);
		}
	}
		
	public function get_img($sig){//获取验证码图片
		if(strlen($sig)==56){
			$url = 'https://ssl.captcha.qq.com/cap_union_show?clientype=2&aid=546000248&uin='.$this->uin.'&cap_cd='.$sig.'&pt_style=0.0672220'.time();
			$data=$this->get_curl($url);
			if(preg_match("/g\_vsig = \"(.*?)\";/", $data, $arr)){
				$this->json='{"code":-1,"vsig":"'.$arr[1].'","sig":"'.$sig.'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}else{
			$url='http://captcha.qq.com/getQueSig?aid=546000248&uin='.$this->uin.'&captype=8&sig='.$sig.'&0.819966'.time();
			$data=$this->get_curl($url);
			if(preg_match("/cap_getCapBySig\(\"(.*?)\"\);/", $data, $arr)){
				$this->json='{"code":-1,"sig":"'.$arr[1].'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}
	}
	
	public function getp(){
		$url="http://encode.qqzzz.net/?uin=".$this->uin."&pwd=".strtoupper($this->pwd)."&vcode=".strtoupper($this->code);
		$getp=$this->get_curl($url);
		if($getp){
			return $getp;
		}else{
			exit("<script language='javascript'>alert('获取P值失败，请稍候重试！');history.go(-1);</script>");
		}
	}
	
	public function getGTK($skey){
        $len = strlen($skey);
        $hash = 5381;
        for($i = 0; $i < $len; $i++){
            $hash += ($hash << 5) + ord($skey[$i]);
        }
        return $hash & 0x7fffffff;//计算g_tk
    }
	
	public function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}
}

