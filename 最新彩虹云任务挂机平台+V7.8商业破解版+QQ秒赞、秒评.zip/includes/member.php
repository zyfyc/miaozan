<?php
if (!defined('IN_CRONLITE')) {
    exit;
}
$my = isset($_GET['my']) ? $_GET['my'] : null;
$clientip = real_ip();
$password_hash = '!@#%!s!';
if ($my == 'login') {
    $gl = daddslashes($_GET['user']);
    $pa = daddslashes($_GET['pass']);
    $ctime = isset($_GET['ctime']) ? intval($_GET['ctime']) : '86400';
    if (isset($gl) && isset($pa)) {
        $row = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE user='{$gl}' limit 1");
        if ($row['user'] == '') {
            @header('Content-Type: text/html; charset=UTF-8');
            exit('<script language=\'javascript\'>alert(\'此用户不存在\');history.go(-1);</script>');
        } elseif ($pa != $row['pass']) {
            @header('Content-Type: text/html; charset=UTF-8');
            exit('<script language=\'javascript\'>alert(\'用户名或密码不正确,请重新输入\');history.go(-1);</script>');
        } elseif ($row['user'] == $gl && $row['pass'] == $pa) {
            if ($_SESSION['Oauth_access_token'] && $_SESSION['Oauth_social_uid'] && $_GET['connect']) {
                $srow = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE social_uid='{$_SESSION['Oauth_social_uid']}' limit 1");
                if ($srow['user'] && $srow['user'] != $row['user']) {
                    @header('Content-Type: text/html; charset=UTF-8');
                    exit("<script language='javascript'>alert('该社会化账号已绑定至本站用户 {$srow['user']}，无法重复绑定！');history.go(-1);</script>");
                }
                $DB->query("UPDATE " . DBQZ . "_user SET social_uid='{$_SESSION['Oauth_social_uid']}',social_token='{$_SESSION['Oauth_access_token']}' WHERE userid = '{$row['userid']}'");
                unset($_SESSION['Oauth_access_token']);
                unset($_SESSION['Oauth_social_uid']);
            }
            $session = md5($row['userid'] . md5($pa) . $password_hash);
            $expiretime = TIMESTAMP + $ctime;
            $token = authcode("{$row['userid']}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
            setcookie('token', $token, time() + $ctime);
            header('Location:index.php?mod=user');
            exit;
        }
    } else {
        @header('Content-Type: text/html; charset=UTF-8');
        exit('<script language=\'javascript\'>alert(\'用户名或密码不能为空!\');history.go(-1);</script>');
    }
} elseif ($my == 'loginout') {
    setcookie("token", "", time() - 2592000);
    @header('Content-Type: text/html; charset=UTF-8');
    exit('<script language=\'javascript\'>alert(\'退出成功!\');window.location.href=\'./\';</script>');
} elseif (isset($_COOKIE["token"])) {
    $token = authcode(daddslashes($_COOKIE['token']), 'DECODE', SYS_KEY);
    list($uid, $sid, $expiretime) = explode("\t", $token);
    $uid = intval($uid);
    $row = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE userid='{$uid}' limit 1");
    $gl = $row['user'];
    $session = md5($row['userid'] . md5($row['pass']) . $password_hash);
    if ($session == $sid && $expiretime > TIMESTAMP) {
        $DB->query("UPDATE " . DBQZ . "_user SET last='{$date}',dlip='{$clientip}' WHERE userid = '{$uid}'");
        $islogin = 1;
        $isactive = $row['active'];
        if (in_array($row['userid'], explode('|', $conf['adminid'])) && in_array($row['userid'], explode('|', $conf['deputy'])) || $row['userid'] == 1) {
            $isadmin = 1;
        }
        if (in_array($row['userid'], explode('|', $conf['deputy'])) && $isadmin != 1) {
            $isdeputy = 1;
        }
        if ($row['vip'] == 1) {
            if (strtotime($row['vipdate']) > time()) {
                $isvip = 1;
            } else {
                $isvip = 0;
            }
        } elseif ($row['vip'] == 2) {
            $isvip = 2;
        } else {
            $isvip = 0;
        }
        if ($row['daili'] == 1) {
            $isdaili = 1;
        } else {
            $isdaili = 0;
        }
        if (isset($_GET["userid"]) && $isadmin == 1) {
            $opuser = 1;
            $uid = intval($_GET['userid']);
            $row = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE userid='{$uid}' limit 1");
            $link = '&userid=' . $uid;
        } else {
            $opuser = 0;
            $link = '';
        }
    }
}
include ROOT . 'includes/content/banned.php';