<?php
if (!defined('IN_CRONLITE')) {
    exit;
}
$qqapiid = $conf['qqapiid'];
$qqloginid = $conf['qqloginid'];
$apiserverid = $conf['apiserver'];
$mail_api = isset($conf['mail_api']) ? $conf['mail_api'] : 0;
$qqlevelapi = isset($conf['qqlevelapi']) ? $conf['qqlevelapi'] : 1;
$shuaapiid = isset($conf['shuaapi']) ? $conf['shuaapi'] : 1;
$allapi = 'http://api.cccyun.cc/';
$smsapi = 'http://auth.cccyun.cc/';
$payapi = 'http://pay.cccyun.cc/';
if ($apiserverid == 1) {
    $apiserver = 'http://sign.cccyun.cc/';
} elseif ($apiserverid == 2) {
    $apiserver = 'http://3600.sturgeon.mopaas.com/';
} elseif ($apiserverid == 3) {
    $apiserver = 'http://cccyun.bj.bdysite.com/';
} else {
    $apiserver = 'http://sign.cccyun.cc/';
}
if ($qqapiid == 1) {
    $qqapi_server = 'http://cloud.odata.cc/';
} elseif ($qqapiid == 2) {
    $qqapi_server = 'http://api.odata.cc/';
} elseif ($qqapiid == 4) {
    $qqapi_server = 'http://api.jzesc.cn/';
} elseif ($qqapiid == 5) {
    $qqapi_server = 'http://qiqi.ccip360.com/';
} elseif ($qqapiid == 6) {
    $qqapi_server = 'http://mzapi.mz2.peak520.com/';
} elseif ($qqapiid == 7) {
    $qqapi_server = 'http://cloud.qqzzz.net/';
} elseif ($qqapiid == 8) {
    $qqapi_server = 'http://api.topug.com/';
} elseif ($qqapiid == 9) {
    $qqapi_server = 'http://mzbapi.odata.cc/';
} elseif ($qqapiid == 10) {
    $qqapi_server = 'http://liangcheng.duapp.com/api/';
} elseif ($qqapiid == 11) {
    $qqapi_server = 'http://tcpapa.qqzzz.net/';
} elseif ($qqapiid == 12) {
    $qqapi_server = 'http://clouds.qqzzz.net/';
} elseif ($qqapiid == 13) {
    $qqapi_server = 'http://api.qqmzp.cn/';
} elseif ($qqapiid == 3) {
    $qqapi_server = $conf['myqqapi'];
} else {
    $qqapi_server = $siteurl;
}
if ($qqlevelapi == 1) {
    $dgapi = 'http://auth.ccip360.com/';
} elseif ($qqlevelapi == 2) {
    $dgapi = 'http://daili.qqkub.com/';
} elseif ($qqlevelapi == 3) {
    $dgapi = 'http://daigua.miaozanba.com/';
} elseif ($qqlevelapi == 4) {
    $dgapi = 'http://qqdg.woaimiaozan.com/';
} elseif ($qqlevelapi == 7) {
    $dgapi = 'http://api2.cccyun.net/';
} elseif ($qqlevelapi == 8) {
    $dgapi = 'http://api.521dg.cn/';
} elseif ($qqlevelapi == 9) {
    $dgapi = 'http://dg.110mz.com/';
} elseif ($qqlevelapi == 10) {
    $dgapi = 'http://api.dg96.cn/';
} elseif ($qqlevelapi == 11) {
    $dgapi = 'http://api.itclub.cc/';
} elseif ($qqlevelapi == 12) {
    $dgapi = 'http://www.aff58.com/';
} elseif ($qqlevelapi == 13) {
    $dgapi = 'http://at138.net/';
} elseif ($qqlevelapi == 14) {
    $dgapi = 'http://www.91dg.wang/';
} elseif ($qqlevelapi == 6) {
    $dgapi = $conf['qqlevelapis'];
}
if ($shuaapiid == 1) {
    $shuaapi = 'http://api.52dg.net/';
} elseif ($shuaapiid == 2) {
    $shuaapi = 'http://api.cccyun.net/';
} elseif ($shuaapiid == 3) {
    $shuaapi = $conf['shuaapis'];
}
if ($qqloginid == 1) {
    $qqloginapi = 'http://cloud.sgwap.net/';
} elseif ($qqloginid == 2) {
    $qqloginapi = 'http://login.qqzzz.net/';
} elseif ($qqloginid == 3) {
    $qqloginapi = 'http://cloud.sgwap.net/';
}
$qqlogin = $qqloginid != 0 ? $qqloginapi : null;
if ($mail_api == 1) {
    $mail_api_url = 'http://auth.cccyun.cc/mail/';
} elseif ($mail_api == 2) {
    $mail_api_url = 'http://1.mail.qqmzp.cn/';
} elseif ($mail_api == 3) {
    $mail_api_url = 'http://mail.qqzzz.net/mail/';
} elseif ($mail_api == 4) {
    $mail_api_url = 'http://api.52dg.net/mail/';
}
if ($conf['cdnserver'] == 1) {
    $cdnserver = '//cdn.odata.cc/';
} elseif ($conf['cdnserver'] == 2) {
    $cdnserver = '//cdn.qqzzz.net/';
} elseif ($conf['cdnserver'] == 3) {
    $cdnserver = '//css.goloo.cc/';
} elseif ($conf['cdnserver'] == 4) {
    $cdnserver = '//css.6zhen.cn/';
} else {
    $cdnserver = null;
}