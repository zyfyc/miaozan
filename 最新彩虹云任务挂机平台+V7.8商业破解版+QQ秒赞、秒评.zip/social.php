<?php 
$mod = 'blank';
require "./includes/common.php";
require SYSTEM_ROOT . "Oauth.class.php";
$Oauth = new Oauth();
header("Content-Type: text/html; charset=UTF-8");
if ($_GET['code']) {
    $array = $Oauth->callback();
    $media_type = $array['media_type'];
    $access_token = $array['access_token'];
    $social_uid = $array['social_uid'];
    if (!$islogin) {
        $username = 'bd_' . $social_uid;
        $row = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE social_uid='{$social_uid}' limit 1");
        if ($row['user'] == '') {
            if ($conf['oauth_act'] == 1) {
                $sql = "insert into `" . DBQZ . "_user` (`pass`,`user`,`date`,`last`,`zcip`,`dlip`,`coin`,`peie`,`social_uid`,`social_token`) values ('" . $access_token . "','" . $username . "','" . $date . "','" . $date . "','" . $clientip . "','" . $clientip . "','" . $rules[1] . "','" . $conf['peie_free'] . "','" . $social_uid . "','" . $access_token . "')";
                if ($DB->query($sql)) {
                    exit("<script language='javascript'>alert('注册成功！点击登录！');window.location.href='./index.php?mod=user&my=login&user={$username}&pass={$access_token}';</script>");
                } else {
                    exit("<script language='javascript'>alert('注册失败！{$DB->error()}');history.go(-1);</script>");
                }
            } else {
                exit("<script language='javascript'>window.location.href='./index.php?mod=connect&my=reg';</script>");
            }
        } else {
            if ($row['social_token'] != $access_token) {
                $DB->query("update `" . DBQZ . "_user` set `social_token` ='{$access_token}' where `userid`='{$row['userid']}'");
            }
            exit("<script language='javascript'>alert('欢迎回来！');window.location.href='./index.php?mod=user&my=login&user={$row['user']}&pass={$row['pass']}';</script>");
        }
    } else {
        if ($media_type == 'qqdenglu' && $conf['active'] == 2 || $media_type == 'sinaweibo' && $conf['active'] == 3) {
            $allow_active = true;
        }
        $srow = $DB->get_row("SELECT * FROM " . DBQZ . "_user WHERE social_uid='{$social_uid}' limit 1");
        if ($srow['user'] == '') {
            $DB->query("UPDATE " . DBQZ . "_user SET social_uid='{$social_uid}',social_token='{$access_token}' WHERE userid = '{$uid}'");
            if ($isactive != 1 && $allow_active == true) {
                $DB->query("UPDATE " . DBQZ . "_user SET active='1' WHERE userid = '{$uid}'");
            }
            unset($_SESSION['Oauth_access_token']);
            unset($_SESSION['Oauth_social_uid']);
            exit("<script language='javascript'>alert('绑定社会化账号成功！');window.location.href='./index.php?mod=user';</script>");
        } elseif ($srow['user'] == $row['user']) {
            unset($_SESSION['Oauth_access_token']);
            unset($_SESSION['Oauth_social_uid']);
            if ($isactive != 1 && $allow_active == true) {
                $DB->query("UPDATE " . DBQZ . "_user SET active='1' WHERE userid = '{$uid}'");
                exit("<script language='javascript'>alert('激活账号成功！');window.location.href='./index.php?mod=user';</script>");
            } else {
                exit("<script language='javascript'>alert('请勿重复绑定！');window.location.href='./index.php?mod=user';</script>");
            }
        } else {
            unset($_SESSION['Oauth_access_token']);
            unset($_SESSION['Oauth_social_uid']);
            exit("<script language='javascript'>alert('该社会化账号已绑定至本站用户 {$srow['user']}，无法重复绑定！');window.location.href='./index.php?mod=user';</script>");
        }
    }
    unset($array);
} else {
    $Oauth->login();
}