<?php
include "update.inc.php";
include ROOT . "includes/qq.func.php";
@header("Content-Type: text/html; charset=UTF-8");
$do = isset($_GET['do']) ? $_GET['do'] : 0;
function showjsmessage($message)
{
    echo '<script type="text/javascript">showmessage(\'' . addslashes($message) . ' \');</script>' . "\r\n";
    flush();
    ob_flush();
}
function signjob_type($url)
{
    if (strpos($url, 'kelink/qdnew') || strpos($url, 'sign/klqd.php')) {
        return 'klqd';
    } elseif (strpos($url, 'klqd/qd') || strpos($url, 'sign/klqd2.php')) {
        return 'klqd2';
    } elseif (strpos($url, 'sign/klol')) {
        return 'klol';
    } elseif (strpos($url, 'sign/discuz/do.php') || strpos($url, 'sign/dzsign.php')) {
        return 'dzsign';
    } elseif (strpos($url, 'sign/discuz/do2.php') || strpos($url, 'sign/dzsign2.php')) {
        return 'dzsign2';
    } elseif (strpos($url, 'sign/discuzdk/do.php') || strpos($url, 'sign/dzdk.php')) {
        return 'dzdk';
    } elseif (strpos($url, 'sign/discuzdk/do2.php') || strpos($url, 'sign/dzdk2.php')) {
        return 'dztask';
    } elseif (strpos($url, 'sign/discuztask/do.php') || strpos($url, 'sign/dztask.php')) {
        return 'dztask2';
    } elseif (strpos($url, 'sign/dzol2.php')) {
        return 'dzol';
    } elseif (strpos($url, 'sign/pwsign/do.php') || strpos($url, 'sign/pwsign.php')) {
        return 'pwsign';
    } elseif (strpos($url, 'sign/pwsign/do2.php') || strpos($url, 'sign/pwsign2.php')) {
        return 'pwsign2';
    } elseif (strpos($url, 'sign/115/do.php')) {
        return '115';
    } elseif (strpos($url, 'sign/360yunpan/do.php')) {
        return '360yunpan';
    } elseif (strpos($url, 'sign/vdisk/do.php')) {
        return 'vdisk';
    } elseif (strpos($url, 'sign/xiami/do.php')) {
        return 'xiami';
    } elseif (strpos($url, 'sign/fuliba/do.php') || strpos($url, 'sign/fuliba.php')) {
        return 'fuliba';
    } elseif (strpos($url, 'sign/3gwen/do.php') || strpos($url, 'sign/3gwen.php')) {
        return '3gwen';
    } elseif (strpos($url, 'sign/dyml/qd.php') || strpos($url, 'sign/dyml.php')) {
        return 'dyml';
    } elseif (strpos($url, 'sign/cmgq.php')) {
        return 'cmgq';
    } elseif (strpos($url, 'sign/chenqd.php')) {
        return 'chenqd';
    } else {
        return false;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>彩虹云任务升级程序</title>
<link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<!--[if lt IE 9]>
	<script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
#notice { overflow: hidden; margin: 5px; padding: 5px; height: 300px; border: 1px solid #B5CFD9; text-align: left; }
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">彩虹云任务升级程序</span>
      </div><!-- /.navbar-header -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">
<?php 
if ($conf['version'] >= '7030') {
    echo '<div class="alert alert-info">系统提示:<hr/>您已经升级到V7.3版本!<a href="../index.php">>>返回网站首页</a></div>';
} else {
    if (!$conf['version'] || $conf['version'] < '6500') {
        exit('<div class="alert alert-info">系统提示:<hr/>请 <a href="update3.php">点击此处</a> 完成升级。</div>');
    }
    if ($conf['version'] == '7001') {
        $sql = "DROP TABLE IF EXISTS `{DBQZ}_pay`;</explode>\r\nCREATE TABLE `{DBQZ}_pay` (\r\n`id` int(11) NOT NULL AUTO_INCREMENT,\r\n`uid` int(11) NOT NULL,\r\n`qq` varchar(20) NULL,\r\n`type` varchar(20) NULL,\r\n`orderid` varchar(64) NULL,\r\n`addtime` datetime NULL,\r\n`endtime` datetime NULL,\r\n`shopid` int(11) NULL,\r\n`name` varchar(64) NULL,\r\n`num` int(11) NOT NULL DEFAULT '1',\r\n`money` varchar(32) NULL,\r\n`status` int(1) NOT NULL DEFAULT '0',\r\n PRIMARY KEY (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>\r\n\r\nDROP TABLE IF EXISTS `{DBQZ}_order`;</explode>\r\nCREATE TABLE `{DBQZ}_order` (\r\n`trade_no` varchar(64) NOT NULL,\r\n`type` varchar(20) NULL,\r\n`orderid` varchar(64) NULL,\r\n`time` datetime NULL,\r\n`name` varchar(64) NULL,\r\n`money` varchar(32) NULL,\r\n`status` int(1) NOT NULL DEFAULT '0',\r\n PRIMARY KEY (`trade_no`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>\r\n\r\nCREATE TABLE IF NOT EXISTS `{DBQZ}_invite` (\r\n  `id` int(11) NOT NULL AUTO_INCREMENT,\r\n  `uid` int(11) NOT NULL,\r\n  `reguid` int(11) NOT NULL,\r\n  `regip` varchar(32) NOT NULL,\r\n  `addtime` date NOT NULL,\r\n PRIMARY KEY (`id`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        $msg = updatedb($sql, '7030');
        $CACHE->clear();
        echo '<div class="alert alert-info">v7.3数据库更新成功！<br/>' . $msg . '<hr/><a href="../index.php">>>返回网站首页</a></div>';
    } else {
        if ($do == '0') {
            $_SESSION['updatestep'] = 0;
            ?>
<div class="panel panel-primary">
	<div class="panel-heading" style="background: #15A638;">
		<h3 class="panel-title" align="center">欢迎使用彩虹云任务V7</h3>
	</div>
	<div class="panel-body">
	<ul class="list-group">
		<li class="list-group-item">升级注意事项：</li>
		<li class="list-group-item">1.升级时会对数据表进行转换，为了数据安全考虑，建议先备份数据，当然这不是必须的。</li>
		<li class="list-group-item">2.升级后公告等页面排版内容将重置，如有需要可以事先备份现有公告等排版内容。</li>
		<li class="list-group-item">3.升级后监控地址全部都会改变，需要重新添加监控。</li>
	</ul>
		<p align="center"><a class="btn btn-primary" href="?do=1">开始升级</a></p>
	</div>
</div>
<?php 
        } elseif ($do == '1') {
            if ($_SESSION['updatestep'] < 1) {
                @mkdir('./backup');
                file_put_contents("./backup/gonggao.txt", $conf['gg']);
                file_put_contents("./backup/tuijian.txt", $conf['guang']);
                file_put_contents("./backup/buttom.txt", $conf['bottom']);
                file_put_contents("./backup/footer.txt", $conf['footer']);
                $c = 0;
                $d = 0;
                $a = file_get_contents("update4.sql");
                $a = str_replace('{DBQZ}', DBQZ, $a);
                $a = explode(";</explode>", $a);
                $error = '';
                for ($i = 0; $i < count($a); $i++) {
                    if ($DB->query($a[$i])) {
                        $c++;
                    } else {
                        $d++;
                        $error .= $DB->error() . '<br/>';
                    }
                }
                $_SESSION['updatestep'] = 1;
            }
            ?>
<div class="panel panel-primary">
	<div class="panel-heading" style="background: #15A638;">
		<h3 class="panel-title" align="center">更新数据表</h3>
	</div>
	<div class="panel-body">
	<?php 
            echo '<div class="alert alert-info">数据表结构更新成功！<br/>SQL成功' . $c . '句/失败' . $d . '句。</div>';
            ?>
		<p align="center"><a class="btn btn-primary" href="?do=2">下一步</a></p>
	</div>
</div>

<?php 
        } elseif ($do == '2') {
            ?>
<script type="text/javascript">
function showmessage(message) {
	document.getElementById('notice').innerHTML += message + '<br />';
	document.getElementById('notice').scrollTop = 100000000;
}
</script>
<div class="panel panel-primary">
	<div class="panel-heading" style="background: #15A638;">
		<h3 class="panel-title" align="center">转换数据表</h3>
	</div>
	<div class="panel-body">
		<div id="notice"></div>
		<p align="center"><input type="button" name="submit" value="正在转换数据表..." disabled="disabled" id="laststep" class="btn btn-primary" onclick="window.location='?do=3';"></p>
		<p>提示：如果出现无法继续进行的情况请修改php.ini里面的max_execution_time=0</p>
	</div>
</div>
<?php 
            ini_set("max_execution_time", "1800");
            set_time_limit(1800);
            if ($_SESSION['updatestep'] < 2) {
                $c = 0;
                $rs = $DB->query("SELECT * FROM " . DBQZ . "_qq order by id asc");
                while ($row = $DB->fetch($rs)) {
                    $myrow = $DB->get_row("SELECT * FROM " . DBQZ . "_user where user='{$row['lx']}' limit 1");
                    $DB->query("update " . DBQZ . "_qq set uid='{$myrow['userid']}' where id='" . $row['id'] . "'");
                    $c++;
                    if ($c % 50 == 0) {
                        showjsmessage('已成功转换 ' . DBQZ . '_qq 表的 ' . $c . '条记录！');
                    }
                }
                showjsmessage("转换数据表 " . DBQZ . "_qq 已完成！");
                $c = 0;
                $rs = $DB->query("SELECT * FROM " . DBQZ . "_job order by jobid asc");
                while ($row = $DB->fetch($rs)) {
                    $myrow = $DB->get_row("SELECT * FROM " . DBQZ . "_user where user='{$row['lx']}' limit 1");
                    if (!$myrow['user']) {
                        continue;
                    }
                    if ($row['type'] == 2) {
                        $data = explode('?', $row['url']);
                        $type = signjob_type($data[0]);
                        if (!$type) {
                            continue;
                        }
                        $arr = explode('&', $data[1]);
                        $data_new = array();
                        foreach ($arr as $rows) {
                            list($a, $b) = explode("=", $rows);
                            $data_new += array($a => $b);
                        }
                        $data = serialize($data_new);
                        $DB->query("insert into `" . DBQZ . "_signjob` (`uid`,`type`,`data`,`lasttime`,`nexttime`,`times`,`pl`,`start`,`stop`,`sysid`) values ('{$myrow['userid']}','{$type}','{$data}','" . time() . "','" . time() . "','{$row['times']}','18000','0','24','1')");
                    } elseif ($row['type'] == 3) {
                        $arr = json_decode($row['url'], true);
                        $type = $arr['func'];
                        if ($type == 'qqsign') {
                            $type = 'kjqd';
                        } elseif ($type == 'qqss') {
                            $type = 'shuo';
                        } elseif ($type == 'delll') {
                            $type = 'delly';
                        }
                        if (in_array($type, $qqSignTasks)) {
                            $sign = 1;
                        } else {
                            $sign = 0;
                        }
                        $method = $arr['method'] ? $arr['method'] : 0;
                        if ($type == 'shuo') {
                            $arr['content'] = $arr['nr'];
                            unset($arr['nr']);
                        }
                        unset($arr['func']);
                        unset($arr['qq']);
                        unset($arr['method']);
                        if (empty($arr)) {
                            $data = null;
                        } else {
                            $data = serialize($arr);
                        }
                        $DB->query("insert into `" . DBQZ . "_qqjob` (`uid`,`qq`,`type`,`sign`,`method`,`data`,`lasttime`,`nexttime`,`times`,`pl`,`start`,`stop`,`sysid`) values ('{$myrow['userid']}','{$row['proxy']}','{$type}','{$sign}','{$method}','{$data}','" . time() . "','" . time() . "','{$row['times']}','{$row['pl']}','{$row['start']}','{$row['stop']}','1')");
                    } else {
                        $DB->query("insert into `" . DBQZ . "_wzjob` (`uid`,`sysid`,`name`,`type`,`url`,`post`,`postfields`,`cookie`,`lasttime`,`nexttime`,`times`,`usep`,`proxy`,`referer`,`useragent`,`start`,`stop`,`pl`) values ('" . $myrow['userid'] . "','" . $row['sysid'] . "','" . $row['mc'] . "','0','" . $row['url'] . "','" . $row['post'] . "','" . $row['postfields'] . "','" . $row['cookie'] . "','" . time() . "','" . time() . "','" . $row['times'] . "','" . $row['usep'] . "','" . $row['proxy'] . "','" . $row['referer'] . "','" . $row['useragent'] . "','" . $row['start'] . "','" . $row['stop'] . "','" . $row['pl'] . "')");
                    }
                    $c++;
                    if ($c % 100 == 0) {
                        showjsmessage('已成功转换 ' . DBQZ . '_job 表的 ' . $c . '条记录！');
                    }
                }
                showjsmessage("转换数据表 " . DBQZ . "_job 已完成！");
                $_SESSION['updatestep'] = 2;
            }
            showjsmessage("所有数据表已全部转换完成，请点击下一步");
            echo '<script type="text/javascript">document.getElementById("laststep").disabled=false;document.getElementById("laststep").value="下一步";</script>';
        } elseif ($do == '3') {
            ?>
<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">升级完成</h3>
	</div>
	<div class="panel-body">
<?php 
            saveSetting('version', '7001');
            $CACHE->clear();
            $_SESSION['updatestep'] = 3;
            file_put_contents("install.lock", "wone");
            echo '<div class="alert alert-info"><font color="green">升级完成！当前版本：7.0</font><br/>原公告、强力推荐、底部排版内容已备份至/install/backup/<br/><br/><a href="../">>>网站首页</a><hr/><font color="blue">提示：要想正常运行，需要监控，监控说明请到后台查看。</font></div>';
            ?>
	</div>
</div>

<?php 
        }
    }
}
?>
</div></body></html>