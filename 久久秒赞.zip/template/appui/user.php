<?php
if(!defined('IN_CRONLITE'))exit();
$title="用户中心";
include_once(TEMPLATE_ROOT."head.php");
$qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1"); //获取QQ数量
$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1"); //获取用户数量

if(!empty($conf['gg']))
echo '<div class="col-sm-6 col-lg-6">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-list red"></i><span class="break"></span>&nbsp;<strong>网站公告</strong>
</div>
<!--ggS-->'.$conf['gg'].'<!--ggE--></font>
</div>
</div>';
echo'<div class="col-sm-6 col-lg-6">
	<a  class="widget">
		<div class="widget-content themed-background text-light-op">
			<span class="pull-right text-muted">QQ:'.$row['qq'].'</span> <i class="fa fa-user red"></i><span class="break"></span>&nbsp;<strong>'.$row['user'].' [UID:'.$row['userid'].']</strong>
		</div>
		<div class="widget-content border-bottom text-center themed-background-muted">
			<img src="'.($row['qq']?'//q1.qlogo.cn/g?b=qq&nk='.$row['qq'].'&s=100&t='.date("Ymd"):'assets/img/user.png').'" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x"><br/>
			<span class="text-muted"><strong>用户权限：</strong>'.usergroup().'</span>
		</div>
		<div class="widget-content widget-content-full-top-bottom">
			<div class="row text-center">
				<div class="col-xs-4 push-inner-top-bottom border-right">
					<h3 class="widget-heading"><i class="fa fa-qq text-dark push-bit"></i> <br>
						<font size="2">QQ数量</font><br><small>'.$row['qqnum'].'/'.$row['peie'].'</small>
					</h3>
				</div>
				<div class="col-xs-4 push-inner-top-bottom border-right">
					<h3 class="widget-heading"><i class="fa fa-rmb text-dark push-bit"></i> <br>
						<font size="2">'.$conf['coin_name'].'</font><br><small>'.$row['coin'].'个</small>
					</h3>
				</div>
				<div class="col-xs-4 push-inner-top-bottom">
					<h3 class="widget-heading"><i class="fa fa-star text-dark push-bit"></i> <br>
						<font size="2">VIP信息</font><br><small>';if($isvip==1) echo'<font color="green">'.$row['vipdate'].'</font>';elseif($isvip==2) echo '<font color="red">永久VIP</font>';elseif($isvip==0) echo '非VIP';echo'</small>
					</h3>
				</div>
			</div>
		</div>
	</a>
	</div>
'?>
</div>
<div class="row">
<?php
if(!empty($conf['bottom']))
echo '<div class="col-sm-12 col-md-12 col-lg-6">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-indent red"></i><span class="break"></span>&nbsp;<strong>商业广告</strong>
</div>
<div class="widget-content border-bottom">
<!--bottomS-->'.$conf['bottom'].'<!--bottomE-->
</div></div></div>';
?>

<div class="col-sm-12 col-md-12 col-lg-6">
<div class="widget">
       <div class="widget-content themed-background text-light-op">
          <a href="index.php?mod=wall" ui-sref="wall" class="pull-right label label-danger">QQ秒赞墙</a>
          <i class="fa fa-bookmark red"></i><span class="break"></span>&nbsp;<strong>最新秒赞QQ</strong>
       </div>
       <div data-height="180" data-scrollable="" class="list-group">
          <div class="list-group-item bb">
             <div class="media-box">

<?php //获取最新QQ列表
$liukay=$DB->query("select qq,time from ".DBQZ."_qq order by id desc limit 7");
while ($lingku = $DB->fetch($liukay))
{
echo '
<div class="list-group-item bb">
             <div class="media-box">
			 <div class="pull-left">
                   <img src="//q1.qlogo.cn/g?b=qq&nk='.$lingku['qq'].'&s=100" alt="Image" class="media-box-object img-circle thumb35">
                </div>
				<div class="media-box-body clearfix">
                   <a target="_blank" href="index.php?mod=wall&do=add&qq='.$lingku['qq'].'" class="label label-info pull-right" style="margin-top:8px;">加为好友</a>
                   <strong class="media-box-heading text-primary">
                      <span class="circle circle-success circle-lg text-left"></span>'.$lingku['qq'].'</strong>
                   <p class="mb-sm">
                      <small><i class="fa fa-clock-o"></i> '.$lingku['time'].'</small>
                   </p>
                </div>
</div>
          </div>
';
}
echo '
</div>
</div>
</div>
</div>
</div>
';
include TEMPLATE_ROOT."foot.php";
?>