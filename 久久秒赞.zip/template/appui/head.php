<?php
if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');

$sitename=$conf['sitename'];

if($title=='首页' || empty($title))
$titlename=$sitename.' '.$conf['sitetitle'];
else
$titlename=$title.'|'.$sitename.' '.$conf['sitetitle'];

?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="charset" content="utf-8">
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $titlename?></title>
<meta name="keywords" content="<?php echo $conf['keywords']?>" />
<meta name="description" content="<?php echo $conf['description']?>" />
<link rel="shortcut icon" href="images/favicon.ico">
	<!-- start: CSS file-->

	<!-- Vendor CSS-->
	<link href="<?php echo $cdnserver?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo $cdnserver?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="<?php echo $cdnserver?>assets/plugins/pjax/pjax.css" rel="stylesheet" />
	<link href="<?php echo $cdnserver?>assets/appui/css/main.css" rel="stylesheet">
	<link href="<?php echo $cdnserver?>assets/appui/css/themes.css" rel="stylesheet">
	<link href="<?php echo $cdnserver?>assets/css/app.css" id="maincss" rel="stylesheet">
	<link id="theme-link" rel="stylesheet" href="<?php echo $cdnserver?>assets/appui/css/themes/themes.css">
	<!-- Plugins CSS-->
	<link rel="stylesheet" type="text/css" href="<?php echo $cdnserver?>assets/plugins/sweetalert/sweetalert.css"/>

	<!-- end: CSS file-->

	<!-- Head Libs -->
	<script src="<?php echo $cdnserver?>assets/plugins/modernizr/js/modernizr.js"></script>
	<script src="<?php echo $cdnserver?>assets/vendor/js/jquery-2.1.4.min.js"></script>
	<!--[if lt IE 9]>
	<script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
<STYLE type="text/css">
	body{cursor:url('images/XSSB-1.cur'), auto;}
	a{cursor:url('images/XSSB-2.cur'), auto;}
<?php if($conf['ui_opacity']){?>
.table-responsive,.pagination,.alert{
filter:alpha(opacity=85);
-moz-opacity:0.85;
-khtml-opacity: 0.85;
opacity: 0.85;
}
<?php }?>
</STYLE>
</head>
<body>

<?php
if($conf['switch']=='0')
exit('系统正在升级中，请稍后访问。');

if(!$no_nav){
	include TEMPLATE_ROOT."nav.php";
}?>