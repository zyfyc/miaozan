<?php
/*
 *WEBQQ机器人
*/
require 'qq.inc.php';
require_once 'webqq.class.php';

$qq=isset($_GET['qq']) ? $_GET['qq'] : exit('参数不完整');
$method=isset($_GET['method']) ? $_GET['method'] : 0;
$robot=isset($_GET['robot']) ? $_GET['robot'] : 1;
$content=isset($_GET['content']) ? $_GET['content'] : null;
$nick=isset($_GET['nick']) ? $_GET['nick'] : null;
$apikey=isset($_GET['apikey']) ? $_GET['apikey'] : null;
$apisecret=isset($_GET['apisecret']) ? $_GET['apisecret'] : null;
$cookie_file='./cookie/'.md5(RUN_KEY.$qq.RUN_KEY).'.txt';

if(isset($_GET['do']) && $_GET['do']=='qqlogin'){
	$qzone=new webqq($qq);
	$qzone->qqlogin();
}
elseif(isset($_GET['do']) && $_GET['do']=='getqrpic'){
	$qzone=new webqq($qq);
	$qzone->getqrpic();
}
elseif(isset($_GET['do']) && $_GET['do']=='status'){
	if(file_exists($cookie_file)){
		exit('1');
	}else{
		exit('0');
	}
}


$starttime=time();
$runtime=50;//每次运行持续时间(秒)

$qzone=new webqq($qq);
if(file_exists($cookie_file)){
	$qzone->cookie=file_get_contents($cookie_file);
	if($qzone->login2()){
		$process=true;
	}else{
		unlink($cookie_file);
		exit('WEBQQ登录状态已失效，<a href="../index.php?mod=webqq&qq='.$qq.'" target="_blank">点此重新登录</a>');
	}
}else{
	exit('请先扫码登录WEBQQ，<a href="../index.php?mod=webqq&qq='.$qq.'" target="_blank">点此登录</a>');
}
if($process){
	$qzone->online();
	if($robot==1)$content='robot';
	if(isset($_GET['runkey'])){
		while(time()-$starttime<$runtime){
			$result=$qzone->poll();
			$qzone->process_message($result,$content,$method,$nick);
			usleep(100000);
		}
	}else{
		$result=$qzone->poll();
		$qzone->process_message($result,$content,$method,$nick);
	}
}

//结果输出
foreach($qzone->msg as $result){
	echo $result.'<br/>';
}

?>