<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

//Ajax入口文件
define('AJAX_INT', true);
$mod=isset($_GET['mod'])?$_GET['mod']:null;
include("./includes/common.php");
?>