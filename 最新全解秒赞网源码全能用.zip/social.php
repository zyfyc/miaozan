<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 global $zym_decrypt;$zym_decrypt['����������Ô�������È��Ë�������']=base64_decode('aGVhZGVy'); ?>
<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

$mod='blank';require base64_decode('Li9pbmNsdWRlcy9jb21tb24ucGhw');require SYSTEM_ROOT.base64_decode('T2F1dGguY2xhc3MucGhw');$Oauth=new Oauth();$GLOBALS['zym_decrypt']['����������Ô�������È��Ë�������'](base64_decode('Q29udGVudC1UeXBlOiB0ZXh0L2h0bWw7IGNoYXJzZXQ9VVRGLTg='));if($_GET['code']){$array=$Oauth->callback();$media_type=$array['media_type'];$access_token=$array['access_token'];$social_uid=$array['social_uid'];if(!$islogin){$username='bd_'.$social_uid;$row =$DB->get_row("SELECT * FROM ".DBQZ."_user WHERE social_uid='$social_uid' limit 1");if($row['user']==''){if($conf['oauth_act']==1){$sql="insert into `".DBQZ."_user` (`pass`,`user`,`date`,`last`,`zcip`,`dlip`,`coin`,`peie`,`social_uid`,`social_token`) values ('".$access_token."','".$username."','".$date."','".$date."','".$clientip."','".$clientip."','".$rules[1]."','".$conf['peie_free']."','".$social_uid."','".$access_token."')";if($DB->query($sql)){exit("<script language='javascript'>alert('注册成功！点击登录！');window.location.href='./index.php?mod=user&my=login&user={$username}&pass={$access_token}';</script>");}else{exit("<script language='javascript'>alert('注册失败！{$DB->error()}');history.go(-1);</script>");}}else{exit(base64_decode('PHNjcmlwdCBsYW5ndWFnZT0namF2YXNjcmlwdCc+d2luZG93LmxvY2F0aW9uLmhyZWY9Jy4vaW5kZXgucGhwP21vZD1jb25uZWN0Jm15PXJlZyc7PC9zY3JpcHQ+'));}}else{if($row['social_token']!=$access_token)$DB->query("update `".DBQZ."_user` set `social_token` ='$access_token' where `userid`='{$row['userid']}'");exit("<script language='javascript'>alert('欢迎回来！');window.location.href='./index.php?mod=user&my=login&user={$row['user']}&pass={$row['pass']}';</script>");}}else{if($media_type=='qqdenglu' && $conf['active']==2 || $media_type=='sinaweibo' && $conf['active']==3)$allow_active=true;$srow =$DB->get_row("SELECT * FROM ".DBQZ."_user WHERE social_uid='$social_uid' limit 1");if($srow['user']==''){$DB->query("UPDATE ".DBQZ."_user SET social_uid='{$social_uid}',social_token='{$access_token}' WHERE userid = '{$uid}'");if($isactive!=1&&$allow_active==true)$DB->query("UPDATE ".DBQZ."_user SET active='1' WHERE userid = '{$uid}'");unset($_SESSION['Oauth_access_token']);unset($_SESSION['Oauth_social_uid']);exit(base64_decode('PHNjcmlwdCBsYW5ndWFnZT0namF2YXNjcmlwdCc+YWxlcnQoJ+e7keWumuekvuS8muWMlui0puWPt+aIkOWKn++8gScpO3dpbmRvdy5sb2NhdGlvbi5ocmVmPScuL2luZGV4LnBocD9tb2Q9dXNlcic7PC9zY3JpcHQ+'));}elseif($srow['user']==$row['user']){unset($_SESSION['Oauth_access_token']);unset($_SESSION['Oauth_social_uid']);if($isactive!=1&&$allow_active==true){$DB->query("UPDATE ".DBQZ."_user SET active='1' WHERE userid = '{$uid}'");exit(base64_decode('PHNjcmlwdCBsYW5ndWFnZT0namF2YXNjcmlwdCc+YWxlcnQoJ+a/gOa0u+i0puWPt+aIkOWKn++8gScpO3dpbmRvdy5sb2NhdGlvbi5ocmVmPScuL2luZGV4LnBocD9tb2Q9dXNlcic7PC9zY3JpcHQ+'));}else exit(base64_decode('PHNjcmlwdCBsYW5ndWFnZT0namF2YXNjcmlwdCc+YWxlcnQoJ+ivt+WLv+mHjeWkjee7keWumu+8gScpO3dpbmRvdy5sb2NhdGlvbi5ocmVmPScuL2luZGV4LnBocD9tb2Q9dXNlcic7PC9zY3JpcHQ+'));}else{unset($_SESSION['Oauth_access_token']);unset($_SESSION['Oauth_social_uid']);exit("<script language='javascript'>alert('该社会化账号已绑定至本站用户 {$srow['user']}，无法重复绑定！');window.location.href='./index.php?mod=user';</script>");}}unset($array);}else{$Oauth->login();}?>