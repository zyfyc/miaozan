<?php
/**
***************************************
* 黑太阳解密 更新群145688818     *
* 本源码原作者 消失的彩虹海           *
* 黑太阳解密 更新群145688818          *
黑太阳解密 更新群145688818     *
***************************************
**/

/* *
 * 码支付异步通知页面
 */

$mod='blank';
$nosecu=true;
require_once("../includes/common.php");
require_once(SYSTEM_ROOT."codepay/codepay_config.php");
ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';
foreach ($_POST AS $key => $val) {
    if ($val == '') continue;
    if ($key != 'sign') {
        if ($sign != '') {
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //拼接为url参数形式
        $urls .= "$key=" . urlencode($val); //拼接为url参数形式
    }
}

if (!$_POST['pay_no'] || md5($sign . $codepay_config['key']) != $_POST['sign']) { //不合法的数据 KEY密钥为你的密钥
    exit('fail');
} else { //合法的数据

    $out_trade_no = daddslashes($_POST['param']);

    //支付宝交易号
    $trade_no = daddslashes($_POST['pay_no']);

    $srow=$DB->get_row("SELECT * FROM ".DBQZ."_pay WHERE orderid='{$out_trade_no}' limit 1");
	$uid=$srow['uid'];
    if($srow['status']==0) {
        $DB->query("update `".DBQZ."_pay` set `status` ='1',`endtime` ='$date' where `orderid`='$out_trade_no'");
		$msg = 'OK';
		$row=$DB->get_row("select * from ".DBQZ."_user where userid='".$uid."' limit 1");
		if($row['vip']==1 && strtotime($row['vipdate'])>time() || $row['vip']==2){
			$isvip=1;
		}else{
			$isvip=0;
		}
		getshop($srow['shopid'],$srow['qq'],$msg);
    }
    exit('success');
}

?>