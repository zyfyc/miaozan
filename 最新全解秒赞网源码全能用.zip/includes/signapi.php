<?php
/**
***************************************
黑太阳解密 更新群145688818      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();

$qqapiid=$conf['qqapiid'];
$apiserverid=$conf['apiserver'];
$mail_api=isset($conf['mail_api'])?$conf['mail_api']:0;
$qqlevelapi=isset($conf['qqlevelapi'])?$conf['qqlevelapi']:1;
$allapi='http://api.cccyun.cc/';

if($apiserverid==1)
{
	$apiserver='http://sign.cccyun.cc/';
}
elseif($apiserverid==2)
{
	$apiserver='http://sign2.cccyun.cc/';
}
else
{
	$apiserver='http://sign.cccyun.cc/';
}


if($qqapiid==1)
{
	$qqapi_server='http://cloud.odata.cc/';
}
elseif($qqapiid==2)
{
	$qqapi_server='http://api.odata.cc/';
}
elseif($qqapiid==7)
{
	$qqapi_server='http://cloud.qqzzz.net/';
}
elseif($qqapiid==8)
{
	$qqapi_server='http://apis.qqmzp.cn/';
}
elseif($qqapiid==9)
{
	$qqapi_server='http://mzbapi.odata.cc/';
}
elseif($qqapiid==12)
{
	$qqapi_server='http://clouds.qqzzz.net/';
}
elseif($qqapiid==13)
{
	$qqapi_server='http://api.qqmzp.cn/';
}
elseif($qqapiid==3)
{
	$qqapi_server=$conf['myqqapi'];
}
else
{
	$qqapi_server=$siteurl;
}

if($qqlevelapi==1)
{
	$dgapi='http://auth.v8daigua.com/';
}
elseif($qqlevelapi==3)
{
	$dgapi='http://www.52dg.net/';
}
elseif($qqlevelapi==11)
{
	$dgapi='http://api.52dg.gg/';
}
elseif($qqlevelapi==6)
{
	$dgapi=$conf['qqlevelapis'];
}

$qqlogin='';


if($mail_api==1)
{
	$mail_api_url='http://1.mail.qqzzz.net/';
}
elseif($mail_api==2)
{
	$mail_api_url='http://1.mail.qqmzp.cn/';
}
elseif($mail_api==3)
{
	$mail_api_url='http://2.mail.qqzzz.net/';
}

if($conf['cdnserver']==1)
{
	$cdnserver='//cdn.odata.cc/';
}
elseif($conf['cdnserver']==2)
{
	$cdnserver='//cdn.qqzzz.net/';
}
elseif($conf['cdnserver']==3)
{
	$cdnserver='//css.6zhen.cn/';
}
else
{
	$cdnserver=null;
}
?>