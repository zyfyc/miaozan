<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();
$title="播放器设置";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-cogs"></i>播放器设置</a></li>';
include TEMPLATE_ROOT."head.php";

$my=isset($_POST['my'])?$_POST['my']:$_GET['my'];
echo '<div class="col-lg-8 col-sm-10 col-xs-12 center-block" role="main">';
if ($isadmin==1)
{

if($_POST['type']=="edit"){
	$list = $_POST['list'];
	$list = str_replace(array("\r\n", "\r", "\n"), "[br]", $list);
	$match=explode("[br]",$list);
	$music=array();
	foreach($match as $val){
		if($val=='')continue;
		$array=explode('|',$val);
		$data['name']=$array[0];
		$data['id']=$array[1];
		$music[]=$data;
	}
	saveSetting('music_list', serialize($music));
	$CACHE->clear();
	exit("<script language=\"javascript\">alert('保存成功!');history.go(-1);</script>");
}else{
	$music=@unserialize($conf['music_list']);
	$list='';
	foreach($music as $val){
		$list.=$val['name'].'|'.$val['id']."\r\n";
	}
}
?>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">HTML5浮动播放器设置</h3></div><div class="panel-body">
<form action="index.php?mod=musicset" method="post">
<input type="hidden" name="type" value="edit" />
<div class="form-group">
<label>歌单列表:</label><br>
<textarea class="form-control" name="list" rows="8"><?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/
 echo $list?></textarea>
</div>
<div class="form-group text-right">
<button type="submit" class="btn btn-primary btn-block" id="save">保存</button>
</div>
</form>
<h5>歌单填写说明:</h5>
一行一首歌曲，可使用网易云音乐、虾米音乐、百度音乐和QQ音乐的歌曲。<br/>
网易ID需要在数字后面加上wy，虾米在后面加上xm，百度音乐在后面加上bd，QQ音乐在后面加上qq，比如网易音乐ID是26108693，那么加上wy就是26108693wy<br/>
格式：<br/>
<pre>歌曲名称|歌曲ID</pre>
例如：<br/>
<pre>秋殇别恋|1772313955xm
光辉岁月|22706999wy
无敌|0038RM350w8m1Vqq
倩女幽魂|13125209bd
</pre>
音乐ID可以在相应播放页面的地址栏中获得
</div></div>
<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>