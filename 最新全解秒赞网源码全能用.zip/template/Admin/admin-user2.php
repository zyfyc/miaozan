<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();
$title="注册用户管理";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-user"></i>注册用户管理</a></li>';

$my=isset($_GET['my'])?$_GET['my']:null;

if ($isadmin==1 || $isdeputy==1)
{
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-12" role="main">';

if(isset($_GET['daili'])) $link='&daili=1';

if($my==null){

if(isset($_GET['kw'])) {
	$sql=" `user` LIKE '%{$_GET['kw']}%' or `userid`='{$_GET['kw']}' or `email`='{$_GET['kw']}' or `qq`='{$_GET['kw']}'";
	$link='&kw='.$_GET['kw'];
	$rownum='包含'.$_GET['kw'].'的共有';
} elseif(isset($_GET['id'])) {
	$sql=" `userid`='{$_GET['id']}'";
	$link='';
	$rownum='本站共有';
} elseif(isset($_GET['daili'])) {
	$sql=" `daili`='1'";
	$rownum='本站共有代理用户';
} else {
	$sql=' 1';
	$link='';
	$rownum='本站共有';
}

$numrows = $DB->count("select count(*) from ".DBQZ."_user where".$sql);

echo '<h3>注册用户管理</h3>';
echo '<div class="alert alert-info">'.$rownum.$numrows.'个用户 [<a href="index.php?mod=reg">添加一个用户</a>]</div>';

if(isset($_GET['daili'])){
	echo '<form action="index.php?mod=admin-user2&my=daili_add" class="form-inline" method="post">
		<div class="form-group">设置UID为<input type="text" style="width:50px;" name="uid">的会员为代理.<input type="submit" class="btn btn-primary" name="submit" value="确定"></div>
		</form>
';
}
$pagesize=$conf['pagesize'];
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

?>
<style>
.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>td,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>thead>tr>th{white-space: pre-wrap;}
</style>
<div class="panel panel-default table-responsive">
<table class="table table-hover">
	<thead>
		<tr>
			<th>UID</th>
			<th>用户名</th>
			<th>注册及登录信息</th>
			<th>数量</th>
		</tr>
	</thead>
	<tobdy>
<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/


$rs=$DB->query("select * from ".DBQZ."_user where{$sql} order by userid desc limit $offset,$pagesize");
$i=0;
while ($myrow = $DB->fetch($rs))
{
$i++;
$pagesl=$i+($page-1)*$pagesize;
if($myrow['daili']==1)$dailicon='<font color="red">[代理]</font>RMB：'.$myrow['daili_rmb'];
if($myrow['vip']!=0)$vipcon='<font color="red">[VIP]</font>';
echo '<tr><td style="width:20%;"><b>'.$myrow['userid'].'</b></td><td style="width:30%">用户名:<a href="index.php?mod=admin-user2&my=user&uid='.$myrow['userid'].$link.'">'.$myrow['user'].'</a>'.$vipcon.'<br/>'.$dailicon.'</td><td style="width:30%">注册日期:<font color="blue">'.$myrow['date'].'</font><br>最后登录:<font color="blue">'.$myrow['last'].'</font></td><td style="width:20%"><a href="index.php?mod=admin-user2&my=user&uid='.$myrow['userid'].$link.'" class="btn btn-primary btn-xs">修改资料</a><br/>';
if($myrow['daili']==1)echo '<a href="index.php?mod=admin-user2&my=daili_del&uid='.$myrow['userid'].$link.'" onClick="if(!confirm(\'确认取消用户:'.$myrow['user'].'的代理？\')){return false;}" pjax="no" class="btn btn-danger btn-xs">取消代理</a>
</tr>';
else echo '<a href="index.php?mod=admin-user2&my=daili_add&uid='.$myrow['userid'].$link.'" onClick="if(!confirm(\'确认设置用户:'.$myrow['user'].'为代理？\')){return false;}" pjax="no" class="btn btn-success btn-xs">设为代理</a>
</tr>';
unset($dailicon);
unset($vipcon);
}
?>
	</tbody>
</table>
</div>

<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

echo '<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="index.php?mod=admin-user2&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="index.php?mod=admin-user2&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="index.php?mod=admin-user2&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="index.php?mod=admin-user2&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="index.php?mod=admin-user2&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="index.php?mod=admin-user2&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo '</ul>';
#分页
}
elseif($my=='user'){
$userid=intval($_GET['uid']);
$row=$DB->get_row("select * from ".DBQZ."_user where userid='$userid' limit 1");

echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">用户资料</h3></div>';
echo '<div class="panel-body">
<div class="col-md-6 col-sm-12">
<b>UID：</b>'.$row['userid'].'';
if(in_array($row['userid'], explode('|', $conf['adminid'])) || $row['userid']==1)$isadmin=1;
else $isadmin=0;
if($row['vip']==1){
	if(strtotime($row['vipdate'])>time()){
		$isvip=1;
		$vipstatus='到期时间:<font color="green">'.$row['vipdate'].'</font>';
	}else{
		$isvip=0;
		$vipstatus='<font color="red">非 VIP</font>';
	}
}elseif($row['vip']==2){
	$isvip=2;
	$vipstatus='<font color="green">永久 VIP</font>';
}else{
	$isvip=0;
	$vipstatus='<font color="red">非 VIP</font>';
}
if($row['daili']==1){
	$isdaili=1;
}else{
	$isdaili=0;
}
echo '<br><b>用户名：</b>'.$row['user'].'<br><b>用户组：</b>'.usergroup().'<br><b>邮箱：</b>'.$row['email'].'<br>'.($row['qq']?'<b>ＱＱ：</b>'.$row['qq'].'&nbsp;<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin='.$row['qq'].'&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:'.$row['qq'].':51" alt="点击这里给我发消息" title="点击这里给我发消息"/></a><br>':null).($row['phone']?'<b>手机：</b>'.$row['phone'].'<br>':null).'<b>注册日期：</b>'.$row['date'].'<br><b>最后登录：</b>'.$row['last'].'<br><b>注册IP：</b><a href="http://wap.ip138.com/ip_search138.asp?ip='.$row['zcip'].'" target="_blank">'.$row['zcip'].'</a><br><b>登录IP：</b><a href="http://wap.ip138.com/ip_search138.asp?ip='.$row['dlip'].'" target="_blank">'.$row['dlip'].'</a>';
if($conf['peie_open'])echo '<br><b>配额数量：</b><font color="orange">'.$row['peie'].'</font><br>';
echo '<b>'.$conf['coin_name'].'：</b><font color="red">'.$row['coin'].'</font><br>';
echo '<b>VIP状态：</b>'.$vipstatus.'</div>';
echo '</div>';
echo '<div class="panel-heading"><h3 class="panel-title">信息修改</h3></div>';
echo '<div class="panel-body"><form action="index.php?mod=admin-user2&my=edit'.$link.'" method="POST"><input type="hidden" name="userid" value="'.$row['userid'].'">
<b>是否VIP：</b><select name="isvip" default="'.$row['vip'].'"><option value="0">0_否</option><option value="1">1_是</option><option value="2">2_永久</option></select>
<br/>
<b>VIP到期时间：</b>
<input type="text" id="d11" name="vipdate" value="'.$row['vipdate'].'" onClick="WdatePicker({isShowClear:false})"><br/>
<b>'.$conf['coin_name'].'：</b>
<input type="text" name="coin" value="'.$row['coin'].'"><br/>
<b>配额数量：</b>
<input type="text" name="peie" value="'.$row['peie'].'"><br/>
<b>是否代理：</b><select name="daili" default="'.$row['daili'].'"><option value="0">0_否</option><option value="1">1_是</option></select>
<br/>
<b>代理账户余额：</b>
<input type="text" name="daili_rmb" value="'.$row['daili_rmb'].'"><br/>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form>
</div></div>
<script>
var items = $("select[default]");
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default"));
}
</script>';
echo '<a href="index.php?mod=admin-user2'.$link.'">>>返回用户管理</a>';
}
elseif($my=='edit'){
echo '<div class="panel panel-info"><div class="panel-heading"><h3 class="panel-title">信息修改</h3></div><div class="panel-body">';
$userid=intval($_POST['userid']);
$vip=$_POST['isvip'];
$vipdate=$_POST['vipdate'];
$coin=$_POST['coin'];
$peie=$_POST['peie'];
$password=$_POST['password'];
$daili=$_POST['daili'];
$daili_rmb=$_POST['daili_rmb'];
$sql=$DB->query("update `".DBQZ."_user` set `vip` ='$vip',`vipdate` ='$vipdate',`coin` ='$coin',`peie` ='$peie',`daili` ='$daili',`daili_rmb` ='$daili_rmb' where `userid`='$userid'");
if($sql){echo '修改成功！';}
else{echo '修改失败！';}
echo '<hr/><a href="index.php?mod=admin-user2'.$link.'">>>返回用户管理</a></div></div>';
}
elseif($my=='daili_add'){
$uid=intval($_REQUEST['uid']);
$DB->query("UPDATE ".DBQZ."_user SET daili='1' WHERE userid='$uid'");
exit('<script>window.location.href="index.php?mod=admin-user2'.$link.'";</script>');
}
elseif($my=='daili_del'){
$uid=intval($_REQUEST['uid']);
$DB->query("UPDATE ".DBQZ."_user SET daili='0' WHERE userid='$uid'");
exit('<script>window.location.href="index.php?mod=admin-user2'.$link.'";</script>');
}
}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>