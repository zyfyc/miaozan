<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

if(!defined('IN_CRONLITE'))exit();
$title="分站管理";

$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-list-alt"></i>分站管理</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-12" role="main">';

$my=isset($_GET['my'])?$_GET['my']:null;

if ($isadmin==1 && $is_fenzhan==0)
{
$date=date("Y-m-d");

if($my==null){

$numrows=$DB->count("select count(*) from ".DBQZ."_site where 1");
$outdate=$DB->count("select count(*) from ".DBQZ."_site where date<$date");
echo '<h3>分站管理</h3>';
echo '<div class="alert alert-info">系统共有'.$numrows.'个分站，其中过期的分站有'.$outdate.'个。<br/>
<a href="index.php?mod=admin-site&my=add" class="btn btn-primary">添加一个分站</a>';
echo '</div>';

$pagesize=$conf['pagesize'];
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

?>

<style>
.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>td,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>thead>tr>th{white-space: pre-wrap;}
</style>
<div class="panel panel-default table-responsive">
<table class="table table-hover">
	<thead>
		<tr>
			<th>数据表前缀</th>
			<th>绑定域名</th>
			<th>到期时间</th>
			<th>状态</th>
			<th>操作</th>
		</tr>
	</thead>
	<tobdy>
<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/


$rs=$DB->query("select * from ".DBQZ."_site where 1 order by id desc limit $offset,$pagesize");
$i=0;
while($myrow = $DB->fetch($rs))
{
	$i++;
	$pagesl = $i + ($page - 1) * $pagesize;
	
	echo '<tr id="'.$myrow['id'].'"><td style="width:15%;"><b>'.$myrow['db'].'</b></td><td style="width:30%">'.$myrow['url'].'</td><td style="width:20%">'.$myrow['date'].'</td><td style="width:10%">'.($myrow['active']==1?'开启':'关闭').'</td><td style="width:25%">';
	echo '<a href="index.php?mod=admin-site&my=edit&id='.$myrow['id'].$link.'" class="btn btn-info btn-xs">编辑</a>&nbsp;<a href="index.php?mod=admin-site&my=delete&id='.$myrow['id'].$link.'" class="btn btn-danger btn-xs">删除</a></td></tr>';
}
?>
	</tbody>
</table>
</div>

<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

echo '<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="index.php?mod=admin-site&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="index.php?mod=admin-site&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="index.php?mod=admin-site&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="index.php?mod=admin-site&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="index.php?mod=admin-site&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="index.php?mod=admin-site&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo '</ul>';
#分页
}
elseif($my=='add')
{
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">添加分站</h3></div>';
echo '<div class="panel-body">';
echo '<form action="index.php?mod=admin-site&my=add_submit" method="POST">
<div class="form-group">
<label>*数据表前缀(只能为小写英文，且不能超过6个字节):</label><br>
<input type="text" class="form-control" name="dbqz" value="" placeholder="wjob" required>
</div>
<div class="form-group">
<label>*绑定域名:</label><br>
<input type="text" class="form-control" name="url" value="" required>
<font color="green">绑定多个域名请用英文逗号,隔开！</font>
</div>
<div class="form-group">
<label>*过期时间:</label><br>
<input type="text" id="d11" class="form-control Wdate" name="date" value="" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
</div>
<div class="form-group">
<label>*是否允许更改API设置:</label><br><select class="form-control" name="api"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>*是否激活:</label><br><select class="form-control" name="active"><option value="1">1_激活</option><option value="0">0_封禁</option></select>
</div>
<div class="form-group">
<label>*是否写入数据表:</label><br><select class="form-control" name="force"><option value="1">1_是(新建分站)</option><option value="0">0_否(恢复已有分站)</option></select>
</div>
<div class="form-group">
<label>备注信息:</label><br>
<textarea class="form-control" name="note" rows="3" placeholder="仅用于备注"></textarea>
</div>
<input type="submit" class="btn btn-primary btn-block"
value="确定添加"></form>';
echo '<br/><a href="index.php?mod=admin-site">>>返回分站管理</a>';
echo '</div></div>';
}
elseif($my=='edit')
{
$id=$_GET['id'];
$row=$DB->get_row("select * from ".DBQZ."_site where id='$id' limit 1");
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改分站信息</h3></div>';
echo '<div class="panel-body">';
echo '<form action="index.php?mod=admin-site&my=edit_submit&id='.$id.'" method="POST">
<div class="form-group">
<label>*数据表前缀(只能为小写英文，且不能超过6个字节):</label><br>
<input type="text" class="form-control" name="dbqz" value="'.$row['db'].'" disabled="disabled" required>
</div>
<div class="form-group">
<label>*绑定域名:</label><br>
<input type="text" class="form-control" name="url" value="'.$row['url'].'" required>
<font color="green">绑定多个域名请用英文逗号,隔开！</font>
</div>
<div class="form-group">
<label>*过期时间:</label><br>
<input type="text" id="d11" class="form-control Wdate" name="date" value="'.$row['date'].'" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
</div>
<div class="form-group">
<label>*是否允许更改API设置:</label><br><select class="form-control" name="api" default="'.$row['api'].'"><option value="1">1_是</option><option value="0">0_否</option></select>
</div>
<div class="form-group">
<label>*是否激活:</label><br><select class="form-control" name="active" default="'.$row['active'].'"><option value="1">1_激活</option><option value="0">0_封禁</option></select>
</div>
<div class="form-group">
<label>备注信息:</label><br>
<textarea class="form-control" name="note" rows="3" placeholder="仅用于备注">'.$row['note'].'</textarea>
</div>
<input type="submit" class="btn btn-primary btn-block"
value="确定修改"></form>
';
echo '<br/><a href="index.php?mod=admin-site">>>返回分站管理</a>';
echo '</div></div>
<script>
var items = $("select[default]");
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default"));
}
</script>';
}
elseif($my=='add_submit')
{
$dbqz=$_POST['dbqz'];
$url=$_POST['url'];
$date=$_POST['date'];
$api=$_POST['api'];
$active=$_POST['active'];
$note=$_POST['note'];
$drop=$_POST['drop'];
if($dbqz==NULL or $url==NULL or $date==NULL){
showmsg('保存错误,请确保加*项都不为空!',3);
} else {
$siterow=$DB->get_row("select * from ".DBQZ."_site where db='$dbqz' limit 1");
if($siterow['url']||$dbqz==DBQZ)
	showmsg('新增分站失败！数据表前缀已被使用。',3);
$sqls="insert into `".DBQZ."_site` (`db`,`url`,`date`,`api`,`active`,`note`) values ('".$dbqz."','".$url."','".$date."','".$api."','".$active."','".$note."')";
$urls=explode(',',$url);
foreach($urls as $row){
	if($row==$_SERVER['HTTP_HOST'])showmsg('不能将主站域名绑定到分站!',3);
	$DB->query("REPLACE INTO ".DBQZ."_domain SET db='$dbqz',domain='$row'");
}

if($_POST['force']==1) {
//开始创建分站数据表
$sql=file_get_contents(ROOT."install/install.sql");
$sql=str_replace('{DBQZ}', $dbqz, $sql);
$sql=explode(';</explode>',$sql);
$t=0; $e=0; $error='';
for($i=0;$i<count($sql);$i++) {
	if ($sql[$i]=='')continue;
	if($DB->query($sql[$i])) {
		++$t;
	} else {
		++$e;
		$error.=$DB->error().'<br/>';
	}
}
saveSetting('build',date("Y-m-d H:i:s"),$dbqz);
saveSetting('syskey',random(32),$dbqz);
saveSetting('cronkey',rand(100000,999999),$dbqz);
if($api==0){
	saveSetting('qqlevelapi', $qqlevelapi,$dbqz);
	saveSetting('apiserver', $conf['apiserver'],$dbqz);
	saveSetting('qqapiid', $conf['qqapiid'],$dbqz);
	saveSetting('qqloginid', $conf['qqloginid'],$dbqz);
	saveSetting('mail_api', $conf['mail_api'],$dbqz);
	saveSetting('mzjc_api', $conf['mzjc_api'],$dbqz);
	saveSetting('myqqapi', $conf['myqqapi'],$dbqz);
	saveSetting('qqz_api', $conf['qqz_api'],$dbqz);
}
}
if($DB->query($sqls) && $e==0){
	showmsg('新增分站成功！SQL成功'.$t.'句/失败'.$e.'句。<br/><font color=red>注：分站首个注册的用户即为管理员，请分站站长尽快注册账号。</font><br/>请将该分站的域名解析到本站服务器，并添加授权，即可访问。<br/><br/><a href="index.php?mod=admin-site">>>返回分站管理</a>',1);
}else
	showmsg('新增分站失败！SQL成功'.$t.'句/失败'.$e.'句<br/>错误信息：'.$error.$DB->error(),4);
}
}
elseif($my=='edit_submit')
{
$id=$_GET['id'];
$rows=$DB->get_row("select * from ".DBQZ."_site where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$url=$_POST['url'];
$date=$_POST['date'];
$api=$_POST['api'];
$active=$_POST['active'];
$note=$_POST['note'];
if($url==NULL or $date==NULL){
showmsg('保存错误,请确保加*项都不为空!',3);
} else {
if($api==0){
	saveSetting('qqlevelapi', $qqlevelapi,$rows['db']);
	saveSetting('apiserver', $conf['apiserver'],$rows['db']);
	saveSetting('qqapiid', $conf['qqapiid'],$rows['db']);
	saveSetting('qqloginid', $conf['qqloginid'],$rows['db']);
	saveSetting('mail_api', $conf['mail_api'],$rows['db']);
	saveSetting('mzjc_api', $conf['mzjc_api'],$rows['db']);
	saveSetting('myqqapi', $conf['myqqapi'],$rows['db']);
	saveSetting('qqz_api', $conf['qqz_api'],$rows['db']);
}
$sql="update `".DBQZ."_site` set `url` ='$url',`date` ='$date',`api` ='$api',`active` ='$active',`note` ='$note' where `id`='$id'";
$urls=explode(',',$url);
foreach($urls as $row)
	$DB->query("REPLACE INTO ".DBQZ."_domain SET db='{$rows['db']}',domain='$row'");
if($DB->query($sql))
	showmsg('修改分站成功！<br/><br/><a href="index.php?mod=admin-site">>>返回分站管理</a>',1);
else
	showmsg('修改分站失败！'.$DB->error(),4);
}
}
elseif($my=='delete')
{
$id=$_GET['id'];
$rows=$DB->get_row("select * from ".DBQZ."_site where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$urls=explode(',',$rows['url']);
foreach($urls as $row)
	$DB->query("DELETE FROM ".DBQZ."_domain WHERE db='{$rows['db']}'");
$sql="DELETE FROM ".DBQZ."_site WHERE id='$id'";
if($DB->query($sql))
	showmsg('删除分站成功！<br/>此操作并没有删除该分站对应的数据表，如需删除请到数据库中删除。<br/><br/><a href="index.php?mod=admin-site">>>返回分站管理</a>',1);
else
	showmsg('删除分站失败！'.$DB->error(),4);
}
}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>