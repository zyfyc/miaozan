<?php
/**
***************************************
* 本源码由梓晨破解 转载请保留版权     *
* 本源码原作者 消失的彩虹海           *
* 博客: http://blog.54or.com          *
* QQ: 1251251214 QQ群: 703035250      *
***************************************
**/

 /*
　*　后台管理文件
*/
if(!defined('IN_CRONLITE'))exit();

if(isset($_GET['type'])){
	if($_GET['type']=='user')
		exit('<script>window.location.href="index.php?mod=admin-user'.($isadmin==1?null:2).'&kw='.$_GET['kw'].'";</script>');
	elseif($_GET['type']=='job')
		exit('<script>window.location.href="index.php?mod=admin-job&kw='.$_GET['kw'].'";</script>');
	elseif($_GET['type']=='qq')
		exit('<script>window.location.href="index.php?mod=qqlist&super=1&qq='.$_GET['kw'].'";</script>');
	elseif($_GET['type']=='km')
		exit('<script>window.location.href="index.php?mod=admin-kmlist&km='.$_GET['kw'].'";</script>');
}

$title="后台管理";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li class="active"><a href="#"><i class="icon fa fa-cog"></i>后台管理</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-lg-6 col-md-8 col-sm-10 col-xs-12 center-block" role="main">';

if ($isadmin==1 || $isdeputy==1)
{
echo '<div class="panel panel-primary">';
echo '<div class="panel-heading"><h3 class="panel-title">后台管理</h3></div><div class="panel-body">';
echo '<label>搜索：</label><br/><form action="index.php" medhod="get"><input type="hidden" name="mod" value="admin"><input type="text" class="form-control" name="kw" value="" placeholder= "输入搜索内容">
<label class="radio-inline"><input type="radio" name="type" value="user" checked="checked"/>用户</label>&nbsp;<label class="radio-inline"><input type="radio" name="type" value="job"/>任务</label>&nbsp;<label class="radio-inline"><input type="radio" name="type" value="qq"/>ＱＱ</label>&nbsp;<label class="radio-inline"><input type="radio" name="type" value="km"/>卡密</label><br/><br/>
<button type="submit" class="btn btn-primary btn-block">搜索管理</button></form><br/><div id="alertmsg"></div>';
echo '</div>';

echo '<div class="panel-heading"><h3 class="panel-title" align="center">基本操作</h3></div><div class="panel-body">';
if($isadmin==1)echo '<a href="index.php?mod=admin-job&table=qqjob" class="btn btn-success btn-block">QQ挂机类任务管理</a>
<a href="index.php?mod=admin-job&table=signjob" class="btn btn-success btn-block">自动签到类任务管理</a>
<a href="index.php?mod=admin-job&table=wzjob" class="btn btn-success btn-block">网址监控类任务管理</a>';
echo '<a href="index.php?mod=qqlist&super=1" class="btn btn-info btn-block">网站ＱＱ账号管理</a>
<a href="index.php?mod=admin-user'.($isadmin==1?null:2).'" class="btn btn-info btn-block">网站注册用户管理</a>
<a href="index.php?mod=admin-kmlist&kind=1" class="btn btn-default btn-block">充值卡卡密管理</a>
<a href="index.php?mod=admin-kmlist&kind=2" class="btn btn-default btn-block">VIP卡 卡密管理</a>
<a href="index.php?mod=admin-kmlist&kind=3" class="btn btn-default btn-block">试用卡卡密管理</a>
<a href="index.php?mod=admin-kmlist&kind=4" class="btn btn-default btn-block">配额卡卡密管理</a>';
//if($is_fenzhan==0)echo '<a href="index.php?mod=admin-site" class="btn btn-success btn-block">分站管理</a>';
echo '</div>';

if($isadmin==1){
echo '<div class="panel-heading"><h3 class="panel-title" align="center">系统设置</h3></div><div class="panel-body">';
echo '<a href="index.php?mod=admin-set&my=set_config" class="btn btn-default btn-block">网站信息配置</a>
<a href="index.php?mod=admin-set&my=set_func" class="btn btn-default btn-block">界面功能定制</a>
<a href="index.php?mod=admin-set&my=set_mail" class="btn btn-default btn-block">发信邮箱配置</a>
<a href="index.php?mod=admin-set&my=set_rw" class="btn btn-default btn-block">任务运行配置</a>
<a href="index.php?mod=admin-set&my=help" class="btn btn-default btn-block"><strong>任务监控说明</strong></a>
<a href="index.php?mod=admin-set&my=set_api" class="btn btn-default btn-block">挂机模块API配置</a>
<a href="index.php?mod=admin-set&my=set_gg" class="btn btn-default btn-block">广告与公告配置</a>
<a href="index.php?mod=admin-set&my=set_coin" class="btn btn-default btn-block">币种消费规则设定</a>
<a href="index.php?mod=admin-set&my=set_vip" class="btn btn-default btn-block">配额与VIP规则设定</a>
<a href="index.php?mod=admin-set&my=set_qd" class="btn btn-default btn-block">每日签到与说说尾巴设置</a>
<a href="index.php?mod=admin-set&my=set_shop" class="btn btn-default btn-block">在线购买价格设置</a>
<a href="index.php?mod=admin-set&my=set_pay" class="btn btn-default btn-block">支付接口设置</a>
<a href="index.php?mod=admin-set&my=set_oauth" class="btn btn-default btn-block">快捷登录组件设置</a>
<a href="index.php?mod=admin-set&my=set_dama" class="btn btn-default btn-block">自动打码平台对接设置</a>
<a href="index.php?mod=admin-set&my=set_defend" class="btn btn-default btn-block">防CC模块设置</a>
'.($conf['vipmode']==1?'<a href="index.php?mod=admin-set&my=renew" class="btn btn-default btn-block">一键续期网站所有QQ</a>':null).'
</div>';
}
echo '<div class="panel-heading"><h3 class="panel-title" align="center">代理管理</h3></div><div class="panel-body">';
echo '<a href="index.php?mod=admin-set&my=set_daili" class="btn btn-default btn-block">代理拿卡价格设置</a>
<a href="index.php?mod=admin-user'.($isadmin==1?null:2).'&daili=1" class="btn btn-default btn-block">网站代理用户管理</a>
</div>';

if($isadmin==1){
echo '<div class="panel-heading"><h3 class="panel-title" align="center">外观设置</h3></div><div class="panel-body">';
echo '<a href="index.php?mod=admin-set&my=set_ui" class="btn btn-default btn-block">界面风格配置 <font color="red">[NEW]</font></a>
<a href="index.php?mod=admin-set&my=bj" class="btn btn-default btn-block">更改背景图片</a>
<a href="index.php?mod=admin-set&my=logo" class="btn btn-default btn-block">更改系统LOGO</a>
</div>';

echo '<div class="panel-heading"><h3 class="panel-title" align="center">数据维护相关</h3></div><div class="panel-body">';
echo '
<a href="index.php?mod=admin-clear&my=cache" class="btn btn-default btn-block">清空系统设置缓存</a>
<a href="index.php?mod=admin-clear&my=qlzt" class="btn btn-default btn-block">清理所有已暂停的任务</a>
<a href="index.php?mod=admin-clear&my=qlqq" class="btn btn-default btn-block">清理所有SKEY过期QQ</a>
<a href="index.php?mod=admin-clear&my=chat" class="btn btn-default btn-block">清空所有聊天记录</a>
<a href="index.php?mod=admin-clear&my=optim" class="btn btn-default btn-block">[MySQL]优化数据表</a>
<a href="index.php?mod=admin-clear&my=repair" class="btn btn-default btn-block">[MySQL]修复数据表</a>
</div>';

echo '<div class="panel-heading"><h3 class="panel-title" align="center">程序相关</h3></div><div class="panel-body">';
if($is_fenzhan==0)echo '<a href="index.php?mod=update" class="btn btn-success btn-block">检测版本更新</a>';
echo '<a href="readme.txt" class="btn btn-default btn-block">查看更新日志</a>
<a href="install/update2.txt" class="btn btn-default btn-block">查看旧更新日志</a>
<a href="index.php?mod=admin-set&my=info" class="btn btn-default btn-block">查看程序版本信息</a>
<a href="index.php?mod=admin-set&my=set_client" class="btn btn-default btn-block">安卓客户端配置</a>
<a href="index.php?mod=admin-set&my=cleanbom" class="btn btn-default btn-block">清理BOM头部</a>
<a href="http://blog.cccyun.cc/post-241.html" target="_blank" class="btn btn-default btn-block">彩虹云任务常见问题汇总</a>
</div>';
}
echo '</div>';

$qqs=$DB->count("SELECT count(*) from ".DBQZ."_qq WHERE 1");
$qqjobs=$DB->count("SELECT count(*) from ".DBQZ."_qqjob WHERE 1");
$signjobs=$DB->count("SELECT count(*) from ".DBQZ."_signjob WHERE 1");
$wzjobs=$DB->count("SELECT count(*) from ".DBQZ."_wzjob WHERE 1");
$zongs=$qqjobs+$signjobs+$wzjobs;
$users=$DB->count("SELECT count(*) from ".DBQZ."_user WHERE 1");
echo '<div class="panel panel-primary"><div class="panel-heading"><h3 class="panel-title">运行日志:&nbsp&nbsp<a href="index.php?mod=all">详细>></a></h3></div><div class="panel-body">系统共有<font color="#ff0000">'.$zongs.'</font>条任务<br>共有<font color="#ff0000">'.$qqs.'</font>个QQ正在挂机<br>系统累计运行了<font color="#ff0000">'.$info['times'].'</font>次<br>上次运行:<font color="#ff0000">'.$info['last'].'</font><br>当前时间:<font color="#ff0000">'.$date.'</font></div>';
if(function_exists("sys_getloadavg")){
$f=sys_getloadavg();
if(!empty($f[0])){
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">系统负载:</h3></div>';
echo '<div class="panel-body">';
echo "1min:{$f[0]}";
echo "|5min:{$f[1]}";
echo "|15min:{$f[2]}";
echo '</div>';}
}
echo '<div class="panel-heading"><h3 class="panel-title">数据统计:</h3></div>';
echo '<div class="panel-body">';
echo '系统共有'.$users.'个用户<br/>';
include(ROOT.'includes/content/tongji.php');
echo '</div></div>';
}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>